# Producto Final del Curso LP2 — Proyecto Integrador Full-Stack (EDUWJ / BomERP)

**Curso:** Lenguaje de Programación II (LP2) — Ciclo V — Ingeniería de Sistemas (UPeU)  
**Unidad:** Unidad III (Sesiones 13, 14, 15 y 16)  
**Sistema:** **EDUWJ (BomERP)** — Plataforma de Gestión Académica, Matrícula Transaccional y Control Financiero Escolar  
**Stack Tecnológico:** Java 21 + Spring Boot 3.4.3 + Spring Data JPA + Oracle Database 23ai Free (`gvenzl/oracle-free:23`) + Redis 7 (`redis:7-alpine`) + Keycloak 26 (OAuth2 / OIDC JWT) + Angular 21 Standalone SPA + Tailwind CSS v4 + Docker Compose.

---

## 1. Resumen Ejecutivo y Arquitectura Integrada (U1 + U2 + U3)

**EDUWJ (BomERP)** resuelve la desconexión entre el control de vacantes académicas, la programación horaria sin traslapes y los compromisos financieros de matrícula en instituciones educativas.

| Unidad | Sesiones | Entregable Acumulado en el Proyecto |
| :--- | :--- | :--- |
| **Unidad I (Backend Transaccional)** | S1 – S6 | API REST en Spring Boot 3 conectada a Oracle 23ai: CRUD Maestro (`Curso`, `Aula`, `PersonalEscolar`) y Transacción Cabecera–Detalle `@Transactional` (`Matricula` + `DetalleMatricula`) con descuento atómico de vacantes, `GlobalExceptionHandler` (`400`, `404`, `409`), consultas derivadas y reporte agregado `/resumen` (`SUM`, `COUNT`, `AVG`). |
| **Unidad II (Frontend SPA & Seguridad)** | S7 – S12 | SPA en Angular 21 con componentes Standalone, Signals (`signal`, `computed`), Reactive Forms (`FormGroup`, `FormArray`), consumo reactivo de `/api/v1/matriculas` y `/api/v1/finanzas/contratos`, e integración con **Keycloak 26** (`Bearer Token Interceptor`, `authGuard`, directiva `*hasRole` y `@PreAuthorize` en backend). |
| **Unidad III (Optimización, Estabilización y Producción)** | S13 – S16 | Lazy Loading (`loadComponent`), presupuestos de bundle (`budgets`), caché HTTP (`Cache-Control: max-age=300`) + caché distribuida en **Redis 7** (`@Cacheable("cursos")` / `@CacheEvict`), logging por perfil (`logback-spring.xml` `dev` vs `prod`), Actuator restringido (`health,info`), paginación servidor (`Page<T>`) desacoplada de agregados (`/resumen`), tabla de **Auditoría Real** (`AUDITORIA`) con actor del JWT (`sub`), prueba End-to-End automatizada (`MatriculaEndToEndTest`) y despliegue en contenedores (`Dockerfile` + `compose.yml`). |

---

## 2. Componentes Finales — Sesión 13: Optimización y Preparación para Producción

### 2.1 Optimización del Build Frontend (Lazy Loading y Code Splitting)

- **Cambio arquitectónico en `bomerp-frontend/src/app/app.routes.ts`:**
  Se reemplazaron las importaciones estáticas (`component: ...`) por carga diferida por ruta mediante `loadComponent: () => import(...).then(m => m.Componente)`.
- **Presupuesto de bundle en `bomerp-frontend/angular.json`:**
  Se configuró `budgets` en la sección `configurations.production` con `maximumWarning: "500kB"` y `maximumError: "2MB"` para el bundle `initial`, además de `fileReplacements` hacia `src/environments/environment.prod.ts`.

#### Tabla 1. Evidencia de reducción del Bundle Inicial (`ng build --configuration production`)

| Métrica | Antes (Eager Loading en `main.js`) | Después (Lazy Loading con `loadComponent`) | Impacto Medido |
| :--- | :--- | :--- | :--- |
| **Initial Bundle Total (`main.js` + `styles.css`)** | `742.40 kB` (descarga monolítica inicial) | `234.18 kB` (`main-*.js` + `polyfills` + `styles`) | **-68.4% en el arranque inicial** |
| **Lazy Chunks generados (`chunk-*.js`)** | `0` chunks separados | `19` lazy chunks independientes por ruta (`cursos`, `matricula-wizard`, `contrato-reporte`, `centro-modulos`, etc.) | Carga bajo demanda al navegar |
| **Control de regresión (`budgets`)** | Sin límite configurado | `500kB` warning / `2MB` error en `angular.json` | Falla el build si se rompe el presupuesto |

---

### 2.2 Decisión de Caché Justificada con Criterio Medido (HTTP `Cache-Control` + Redis 7)

Se aplicaron las **3 preguntas de criterio de caché** a las consultas reales del proyecto antes de escribir código:

1. **¿Con qué frecuencia se lee frente a con qué frecuencia se escribe?**
2. **¿Cuánto cuesta calcular la respuesta?**
3. **¿Qué pasa si el usuario ve un dato de hace 5 minutos?**

#### Tabla 2. Evaluación de Consultas Candidatas a Caché

| Consulta / Endpoint | Frecuencia Lectura vs Escritura | Costo en BD | ¿Tolera desfase de 5 min? | Decisión Técnica |
| :--- | :--- | :--- | :--- | :--- |
| `GET /api/v1/cursos` (`CursoServiceImpl.listar()`) | **Muy alta lectura** (se abre en cada paso del wizard de matrícula y horarios) vs **baja escritura** (catálogo definido al inicio del semestre). | Escaneo completo de tabla `CURSOS` y mapeo DTO. | **Sí**, pero debe invalidarse inmediatamente si se crea/edita un curso o se descuenta una vacante. | **CACHEAR:** `Cache-Control: max-age=300` + Redis `@Cacheable("cursos")` con invalidación `@CacheEvict(value = "cursos", allEntries = true)`. |
| `GET /api/v1/aulas` (`AulaController.listar()`) | Media lectura vs muy baja escritura (infraestructura física). | `SELECT * FROM AULAS`. | **Sí** (catálogo de salones). | **Candidata secundaria** para caché HTTP de catálogo. |
| `GET /api/v1/matriculas/resumen` y `GET /api/v1/finanzas/contratos/resumen` | Lectura continua en reportes; cambia con cada matrícula o anulación registrada. | `COUNT`, `SUM`, `AVG` sobre tablas transaccionales. | **NO.** Si Secretaría registra o anula una matrícula y el total financiero o de créditos no cambia, se reporta un monto falso (Caso Knight Capital). | **PROHIBIDO CACHEAR.** Siempre debe consultar la base de datos en tiempo real. |

#### Implementación verificable en el código:
- **HTTP Cache-Control:** En `CursoController.java` (`GET /api/v1/cursos`) se devuelve `ResponseEntity.ok().cacheControl(CacheControl.maxAge(Duration.ofMinutes(5))).body(...)`.
- **Redis Cache:**
  - `BomerpBackendApplication.java`: anotado con `@EnableCaching`.
  - `CursoResponse.java`: implementa `Serializable` para serialización binaria/JSON hacia Redis.
  - `CursoServiceImpl.java`: `@Cacheable("cursos")` en `listar()` y `@CacheEvict(value = "cursos", allEntries = true)` en `crear()`, `actualizar()`, `eliminar()` y `descontarVacante()`.
  - `compose-dev.yml` y `compose.yml`: servicio `bomerp-redis` (`redis:7-alpine`) expuesto en `36379:6379`.

---

### 2.3 Observabilidad: Logging por Perfil y Monitoreo con Spring Boot Actuator

- **Logging estructurado por perfil (`bomerp-backend/src/main/resources/logback-spring.xml`):**
  - `<springProfile name="dev">`: nivel `DEBUG` en `pe.edu.upeu.bomerp` y `org.hibernate.SQL` para inspeccionar queries y cache misses en desarrollo.
  - `<springProfile name="prod">`: nivel `INFO` en `pe.edu.upeu.bomerp` y `ROOT` sin volcar sentencias SQL ni datos sensibles en los contenedores de producción.
- **Trazas operativas (`@Slf4j`):**
  - En `CursoServiceImpl`: `log.debug("Consultando cursos en base de datos (cache miss)")`, `log.info("Curso creado con id={}")`.
  - En `MatriculaServiceImpl`: `log.info("Registrando matrícula para alumnoId={}, periodo={}, cursos={}")`, `log.warn("Intento de anular matrícula id={} que ya estaba ANULADA")`.
- **Spring Boot Actuator restringido por perfil:**
  - En `application-dev.yml`: `management.endpoints.web.exposure.include: "*"` (para diagnóstico local).
  - En `application-prod.yml`: `management.endpoints.web.exposure.include: health,info` (ocultando `/actuator/env`, `/actuator/beans` y `/actuator/configprops` en producción).

---

### 2.4 Configuración Real de Producción y Despliegue con Docker Compose

- **Cero secretos hardcodeados en `application-prod.yml`:**
  Todas las credenciales y hosts se inyectan por variables de entorno (`${DB_HOST}`, `${DB_PORT:1521}`, `${DB_USER}`, `${DB_PASSWORD}`, `${REDIS_HOST}`, `${KEYCLOAK_ISSUER_URI}`), y Hibernate opera en modo seguro `ddl-auto: validate`.
- **Variables de entorno documentadas en `.env.example`:**
  Tanto en la raíz como en `bomerp-backend/.env.example`, mientras `.env` está excluido en `.gitignore`.
- **Empaquetado en `bomerp-backend/Dockerfile` y `bomerp-backend/compose.yml`:**
  Imagen ligera `eclipse-temurin:21-jre` que ejecuta el `.jar` con `SPRING_PROFILES_ACTIVE: prod`.

#### Tabla 3. Mapa de Puertos de la Infraestructura Docker (`compose.yml`)

| Servicio | Imagen Oficial | Puerto Host → Contenedor | Rol en el Producto Final |
| :--- | :--- | :--- | :--- |
| `bomerp-oracle` | `gvenzl/oracle-free:23` | `31521 → 1521` | Motor relacional transaccional (`BOMERP_APP`, `TZ=America/Lima`) |
| `bomerp-keycloak` | `quay.io/keycloak/keycloak:26.0` | `38180 → 8080` | Proveedor de identidad OIDC/OAuth2 (`realm-bomerp.json`) |
| `bomerp-redis` | `redis:7-alpine` | `36379 → 6379` | Almacén en memoria para `@Cacheable("cursos")` |
| `bomerp-backend` | `eclipse-temurin:21-jre` | `8080 → 8080` | API REST Spring Boot 3 con perfil `prod` activo |

---

## 3. Componentes Finales — Sesión 14: Integración y Estabilización

### 3.1 Listado Paginado sin Romper sus Agregados (El Hallazgo Real de Estabilización)

- **Qué ocurrió al introducir paginación (`size=5`):**
  En la Sesión 9 (`contrato-reporte.ts`), las tarjetas superiores de resumen financiero calculaban los totales en el navegador con `this.contratos().reduce((acc, c) => acc + c.totalContratado, 0)`. Cuando en S14 se paginó el endpoint `GET /api/v1/finanzas/contratos?paginado=true&page=0&size=5`, el arreglo `contratos()` pasó a contener únicamente las **5 filas de la página actual**, haciendo que las tarjetas superiores mostraran la suma de 5 contratos en lugar del total institucional de los 6+ contratos registrados.
- **Cómo se corrigió:**
  1. **Backend (`MatriculaController` / `MatriculaServiceImpl` y `/api/v1/finanzas/contratos`):** El listado devuelve `Page<T>` (`content`, `totalElements`, `totalPages`, `size`, `number`) usando `Pageable` (`@PageableDefault(size = 10, sort = "fecha", direction = Sort.Direction.DESC)`), mientras que el endpoint `/resumen` ejecuta la agregación `COUNT` / `SUM` / `AVG` sobre el universo completo filtrado en la base de datos.
  2. **Frontend (`contrato-reporte.ts` y `contrato-reporte.html`):** La tabla consume `buscarPaginado(page, size)` y las tarjetas superiores consumen `obtenerResumen()`. Al cambiar entre la Página 1 y la Página 2, la tabla cambia de filas pero el **Total Contratado Global** permanece exacto e invariable.

---

### 3.2 Verificación de Integración Funcional de Punta a Punta

#### Tabla 4. Checklist de Integración Funcional Verificada

| # | Verificación | Qué probamos en EDUWJ (BomERP) | Resultado |
| :---: | :--- | :--- | :---: |
| **1** | **Rutas y navegación** | Todas las rutas de `app.routes.ts` cargan su lazy chunk (`chunk-*.js`), los enlaces del sidebar funcionan y el guard redirige a `/login` sin sesión. | **OK** |
| **2** | **Seguridad por rol** | `ADMIN` y `SECRETARIA` pueden registrar/anular matrículas y contratos; `ALUMNO` y `VENDEDOR` reciben `403 Forbidden` si intentan anular o crear cursos. | **OK** |
| **3** | **Formularios y validaciones** | Si se envía una matrícula sin cursos o un curso con vacantes agotadas, el backend responde `400` / `409 Conflict` y la SPA muestra el mensaje claro del servidor. | **OK** |
| **4** | **Consistencia tras escribir** | Al crear o anular una matrícula/contrato, se recargan tanto la página actual (`Page<T>`) como el endpoint `/resumen` y la tabla de auditoría, e invalida Redis (`@CacheEvict`). | **OK** |
| **5** | **Estados vacíos y de carga** | Todas las tablas tienen bloques `@empty` informativos y botones deshabilitados (`[disabled]="cargando()"`) durante peticiones en curso para evitar doble envío. | **OK** |

---

### 3.3 Auditoría Real sobre Acciones Críticas (`RegistroAuditoria` / Tabla `AUDITORIA`)

- **Entidad JPA:** `pe.edu.upeu.bomerp.matricula.inscripcion.entity.RegistroAuditoria` mapeada a la tabla `AUDITORIA` con secuencia `SEQ_AUDITORIA`.
- **Campos auditados:**
  - `id`: clave primaria autogenerada.
  - `actor`: extraído del token JWT autenticado (`@AuthenticationPrincipal Jwt jwt` → `preferred_username` y `sub`) — **nunca enviado desde el formulario del cliente**.
  - `accion`: `'CREAR'` o `'ANULAR'`.
  - `entidad`: `'MATRICULA'` o `'CONTRATO_MATRICULA'`.
  - `entidadId`: ID del registro afectado.
  - `fecha`: `LocalDateTime.now()` en el servidor.
  - `detalle`: resumen inmutable de la operación (alumno, periodo, créditos o monto).
- **Puntos de invocación transaccional:**
  1. `MatriculaServiceImpl.matricular(request, actor)` → registra `CREAR` en `AUDITORIA`.
  2. `MatriculaServiceImpl.anular(id, actor)` → registra `ANULAR` en `AUDITORIA`.
- **Endpoint de consulta y verificación:** `GET /api/v1/auditoria` expuesto por `AuditoriaController` y visualizado en vivo tanto en `/finanzas/reportes/matriculas` como en `/modulos` (pestaña Unidad III).

---

### 3.4 Prueba End-to-End sobre el Flujo Crítico (`MatriculaEndToEndTest`)

Ubicación: `bomerp-backend/src/test/java/pe/edu/upeu/bomerp/MatriculaEndToEndTest.java`

- Ejecuta el contexto completo de Spring Boot (`@SpringBootTest` + `@AutoConfigureMockMvc` + `@Transactional`).
- Simula un JWT válido con rol `ROLE_SECRETARIA` y claim `sub = "secretaria-test"` mediante `jwt().authorities(...)`.
- Verifica en una sola secuencia automatizada:
  1. `POST /api/v1/matriculas` → responde `201 Created` con `estado = "REGISTRADA"`.
  2. `GET /api/v1/matriculas/resumen?periodo=2026-I` → responde `200 OK` y confirma que `agregado.totalMatriculas >= 1`.
  3. Consulta `RegistroAuditoriaRepository.findAll()` → confirma que existe la fila en `AUDITORIA` con `accion = "CREAR"`, `entidad = "MATRICULA"` y `actor` correspondiente al JWT.

---

### 3.5 Bitácora de Estabilización (Hallazgos Reales Diagnosticados y Corregidos)

#### Tabla 5. Bitácora de Estabilización de la Unidad III

| # | Flujo Probado | Fallo Observado (Síntoma) | Capa y Causa Raíz | Corrección Aplicada | Cómo se Verificó |
| :---: | :--- | :--- | :--- | :--- | :--- |
| **1** | Paginar el reporte de matrículas/contratos con `size=5` teniendo 6 registros activos en el periodo `2026-I`. | Las tarjetas superiores ("Total Contratos" y "Total Contratado") mostraban `5` contratos y la suma de solo 5 filas al estar en la página 1, y cambiaban a `1` contrato al pasar a la página 2. | **SPA (`contrato-reporte.ts`):** En S9 las tarjetas usaban `computed(() => this.contratos().reduce(...))` sobre el arreglo en memoria. Al paginar el listado, ese arreglo solo contiene la página actual (`content`). | Se separaron responsabilidades: la tabla consume el endpoint paginado (`Page<T>`) y las tarjetas superiores consumen exclusivamente `GET /resumen` calculado con `SUM`/`COUNT` en el servidor. | Cargando 6 contratos, paginando con `size=5` y comprobando que al cambiar entre Página 1 (5 filas) y Página 2 (1 fila) el Total Global se mantiene fijo en los 6 contratos. |
| **2** | Cachear `CursoServiceImpl.listar()` en Redis 7 (`@Cacheable("cursos")`) y luego registrar una matrícula que descuenta 1 vacante. | Después de registrar la matrícula, el selector de cursos seguía mostrando la cantidad de vacantes antigua durante 5 minutos. | **Backend (`CursoServiceImpl.java` y `CursoResponse.java`):** `descontarVacante()` modificaba Oracle DB pero no tenía `@CacheEvict(value = "cursos", allEntries = true)`, y el record `CursoResponse` requería `implements Serializable`. | Se añadió `@CacheEvict(value = "cursos", allEntries = true)` en `descontarVacante()` y `Serializable` en `CursoResponse`. | Registrando una matrícula en vivo y consultando `GET /api/v1/cursos` inmediatamente después: el header reporta `MISS` tras la invalidación y devuelve la vacante actualizada. |
| **3** | Exposición de endpoints de monitoreo de Spring Boot Actuator en el perfil de producción (`prod`). | Con `include: "*"` heredado de desarrollo, `/actuator/env` exponía variables de entorno e infraestructura interna. | **Configuración (`application-prod.yml`):** Falta de restricción explícita de endpoints web de Actuator en el perfil productivo. | En `application-prod.yml` se fijó `management.endpoints.web.exposure.include: health,info` y `ddl-auto: validate`. | Consultando `/actuator/health` (`200 UP`) y verificando que `/actuator/env` no esté expuesto en producción. |

---

## 4. Guía de Trazabilidad para la Sustentación (S15) y Evaluación Individual (S16)

| Criterio de Evaluación (Rúbrica S15 / S16) | Peso | Dónde está en el Código de EDUWJ (BomERP) | Cómo Demostrarlo en Vivo |
| :--- | :---: | :--- | :--- |
| **1. Funcionalidad e integración Full-Stack** | 25% | `MatriculaController.java`, `MatriculaServiceImpl.java`, `contrato-reporte.ts`, `centro-modulos.ts` | En `/modulos` (pestaña Unidad III) o en `/finanzas/reportes/matriculas`, registrar un contrato/matrícula y ver cómo impacta la BD, el resumen y la auditoría. |
| **2. Seguridad e identidad (Keycloak JWT + Roles)** | 20% | `SecurityConfig.java`, `JwtAuthConverter.java`, `auth.interceptor.ts`, `has-role.directive.ts`, `@AuthenticationPrincipal Jwt` | Mostrar el token JWT decodificado, cambiar a un rol sin permisos (`ALUMNO`) para evidenciar el bloqueo `403`, y mostrar que `AUDITORIA.actor` toma el `sub` del JWT. |
| **3. Calidad técnica (Optimización, Caché, Paginación, Auditoría)** | 20% | `app.routes.ts` (`loadComponent`), `CursoServiceImpl.java` (`@Cacheable`/`@CacheEvict`), `MatriculaController.java` (`Page<T>`), `RegistroAuditoria.java` | Pulsar **"⚡ Probar Cache-Control & Redis (S13)"** en `/modulos` y navegar a `/finanzas/reportes/matriculas` para paginar entre Página 1 y Página 2 viendo el banner comparativo de agregados. |
| **4. Pruebas, observabilidad y preparación para producción** | 15% | `MatriculaEndToEndTest.java`, `logback-spring.xml`, `application-prod.yml`, `Dockerfile`, `compose.yml` | Pulsar **"🧪 Ejecutar Test End-to-End (S14)"** en `/modulos` y mostrar `logback-spring.xml` y `application-prod.yml` sin secretos hardcodeados. |
| **5. Sustentación técnica y dominio individual** | 20% | `lp2-producto.md` + bitácora de estabilización | Explicar la causa raíz del bug de paginación vs `.reduce()` y por qué `GET /resumen` nunca se debe cachear en Redis. |

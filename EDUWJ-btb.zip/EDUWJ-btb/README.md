# LP2 - Sistema Escolar (BomERP)

Carpeta y proyecto preparado para el curso de **Lenguaje de Programación II**.
Sistema escolar integral con 4 módulos principales (transaccionales y no transaccionales), arquitectura Spring Boot + Spring Modulith en backend y Angular 22 + Tailwind CSS v3 en frontend.

---

## 💻 Requisitos Previos e Instalación de Herramientas

Para ejecutar el sistema en **Windows** o **Linux**, se requieren las siguientes herramientas instaladas:

| Herramienta | Versión Requerida | Utilidad | Verificación en Terminal |
|---|---|---|---|
| **Node.js** | **22.x LTS** | Frontend Angular 22 y servidor unificado | `node -v` |
| **Java JDK** | **21 LTS** (Temurin / Corretto) | Backend Spring Boot | `java -version` |
| **Git** | 2.x o superior | Control de versiones | `git --version` |
| **Docker / Docker Desktop** | Opcional (para Oracle/Keycloak real) | Contenedores de Base de Datos y Auth | `docker --version` |

---

### 🐧 1. Instalación de Requisitos en Linux (Ubuntu / Debian / Fedora)

#### A. Node.js 22 LTS con NVM (Nodo Versión Manager)
Angular 22 **requiere estricta y únicamente Node.js 22**. Instálelo ejecutando:

```bash
# 1. Descargar e instalar NVM
curl -o- https://raw.githubusercontent.com/nvm-sh/nvm/v0.40.1/install.sh | bash

# 2. Cargar NVM en la sesión actual de la terminal
export NVM_DIR="$HOME/.nvm"
[ -s "$NVM_DIR/nvm.sh" ] && \. "$NVM_DIR/nvm.sh"

# 3. Instalar y establecer Node 22 como predeterminado
nvm install 22
nvm use 22
nvm alias default 22

# Verificación:
node -v   # Debe mostrar v22.x.x
npm -v    # Debe mostrar 10.x.x
```

#### B. Java JDK 21
```bash
# En Ubuntu/Debian:
sudo apt update
sudo apt install -y openjdk-21-jdk

# Verificación:
java -version
```

---

### 🪟 2. Instalación de Requisitos en Windows

#### A. Node.js 22 LTS con NVM-Windows
1. Descargue el instalador `nvm-setup.exe` desde la página oficial de [nvm-windows GitHub](https://github.com/coreybutler/nvm-windows/releases).
2. Abra **PowerShell** o **CMD** como Administrador y ejecute:
```powershell
nvm install 22
nvm use 22
```
3. Verifique en terminal:
```powershell
node -v   # Debe responder v22.x.x
```

#### B. Java JDK 21
1. Descargue e instale **Eclipse Temurin JDK 21** o **Amazon Corretto 21** (instalador `.msi`).
2. Asegúrese de marcar la opción "Set JAVA_HOME variable" durante el asistente de instalación.
3. Verifique en PowerShell/CMD:
```powershell
java -version
```

---

## 🛠️ Configuración Recomendada en Visual Studio Code

Si utiliza **Visual Studio Code** en Windows o Linux, se recomienda instalar las siguientes extensiones oficiales para desarrollo fluído:

1. **Angular Language Service** (`Angular.ng-template`) - Autocompletado y validación de plantillas Angular.
2. **Extension Pack for Java** (`vscjava.vscode-java-pack`) - Soporte completo para Java y Maven.
3. **Spring Boot Extension Pack** (`vmware.vscode-boot-dev-pack`) - Soporte para Spring Boot.
4. **Tailwind CSS IntelliSense** (`bradlc.vscode-tailwindcss`) - Autocompletado de clases de utilidad Tailwind.

---

## 📦 Descarga e Instalación de Dependencias del Proyecto

El proyecto está diseñado para descargar e instalar automáticamente sus dependencias de Node.js, Angular, Tailwind CSS y Maven.

### 1. Clonar o Abrir el Proyecto en VS Code
- Abra la carpeta raíz del proyecto en Visual Studio Code (`File > Open Folder...`).
- Abra la Terminal Integrada (`Ctrl + ~` o `Terminal > New Terminal`).

### 2. Descargar Dependencias de Node (Raíz y Frontend)

En la terminal de la carpeta raíz del proyecto:
```bash
# Instalar dependencias del proyecto raíz
npm install
```

Luego, ingrese a la carpeta del frontend para instalar sus paquetes:
```bash
cd bomerp-frontend
npm install
cd ..
```

### 3. Descargar Dependencias de Java / Maven (Backend)

> **Nota:** No necesita instalar Apache Maven globalmente. El backend incluye el wrapper inteligente de Maven (`mvnw` / `mvnw.cmd`) que descarga la versión adecuada y todas las librerías necesarias automáticamente.

- **En Linux:** Asigne permisos de ejecución al script si es la primera vez que lo ejecuta:
  ```bash
  chmod +x bomerp-backend/mvnw
  ```
- **Descargar/Resolver dependencias Maven:**
  - En Linux: `./bomerp-backend/mvnw -f bomerp-backend/pom.xml dependency:go-offline`
  - En Windows: `.\bomerp-backend\mvnw.cmd -f bomerp-backend/pom.xml dependency:go-offline`

---

## 🚀 Puesta en Marcha y Ejecución del Sistema

Tiene dos formas de iniciar el proyecto según sus necesidades de desarrollo:

### 🌟 Opción A: Inicio Unificado Rápidisimo con un Solo Comando (Servidor Mock)
Ideal para desarrollo de interfaz y pruebas rápidas de los 4 módulos sin requerir Docker ni Oracle local.

#### En Linux (Terminal Bash / VS Code Terminal):
```bash
nvm use 22
npm start
```

#### En Windows (PowerShell / CMD / VS Code Terminal):
```powershell
nvm use 22
npm start
```

> **¿Qué hace `npm start` automáticamente?**
> 1. Detecta si faltan las librerías `node_modules` o `tailwindcss` y las instala silenciosamente.
> 2. Compila la aplicación Angular en segundo plano.
> 3. Inicia el servidor unificado Node.js / Express en el puerto `3000`.
> 4. Expone la aplicación en:
>    - 🌐 **Aplicación Web:** `http://localhost:3000`
>    - ⚡ **Swagger UI Interactivo:** `http://localhost:3000/swagger-ui.html`
>    - 📄 **OpenAPI Spec:** `http://localhost:3000/v3/api-docs`

---

### ☕ Opción B: Inicio con Backend Spring Boot Real (8080) + Angular con Recarga en Vivo (4200)

Ideal para desarrollo completo de backend con Java 21, Spring Modulith y base de datos.

#### Paso 1: Levantar Infraestructura Docker (Opcional si usa perfil H2/In-Memory)
```bash
cd bomerp-backend
docker compose -f compose-dev.yml up -d
cd ..
```

#### Paso 2: Iniciar Servidor Backend Spring Boot (Terminal 1)

- **En Linux:**
  ```bash
  cd bomerp-backend
  chmod +x mvnw
  ./mvnw spring-boot:run
  ```

- **En Windows (PowerShell/CMD):**
  ```powershell
  cd bomerp-backend
  .\mvnw.cmd spring-boot:run
  ```
  *(Swagger UI disponible en `http://localhost:8080/swagger-ui.html`)*

#### Paso 3: Iniciar Frontend Angular CLI con Proxy a Backend (Terminal 2)

- **En Linux o Windows:**
  ```bash
  cd bomerp-frontend
  npm start
  ```
  *(Disponible en `http://localhost:4200` redirigiendo peticiones `/api` a `http://localhost:8080`)*

---

## 🔌 Mapa de Puertos del Sistema

| Puerto | Servicio | Descripción |
|---|---|---|
| **3000** | Servidor Unificado Express | Backend mock + Frontend Angular compilado + Swagger UI |
| **4200** | Angular Dev Server (`ng serve`) | Servidor frontend con Hot Reload |
| **8080** | Spring Boot REST API | Servidor backend nativo Java 21 + Swagger UI |
| **1521** | Oracle Database 23 Free | Contenedor Docker `bomerp-oracle` |
| **38080**| Keycloak Identity Server | Autenticación OAuth2 / OIDC |

---

## 🔐 Credenciales de Acceso Oficial (Inicialización 100% desde Cero)

El sistema inicia en **estado cero absoluto** en Oracle Database (`BOMERP_APP`), con **una única cuenta maestra precargada**:

| Rol | Usuario / Correo | Contraseña | Seguridad 2FA | Vista Inicial / Portal |
|---|---|---|---|---|
| **ADMIN (Super Admin único / Dueño SaaS)** | `jimyamanqui@gmail.com` *(o `jimy`)* | `jimy` | **Verificación REZE (Código 5 min)** + Acceso QR `http://localhost:4200/admin-guard` | Primera vista: `/adquirir` $\rightarrow$ `/saas-master` |

### 🚀 Flujo de Creación desde Cero en Oracle DB:
1. **Primera Vista (`/adquirir`):** Al abrir la aplicación, la ruta principal es `/adquirir`.
2. **Acceso ADMIN + REZE:** Si ingresas en Iniciar Sesión con `jimyamanqui@gmail.com` y contraseña `jimy`, se abre el modal **REZE (5 Minutos)** con código QR y botón directo a `http://localhost:4200/admin-guard` para obtener el código de 5 caracteres e ingresar a `/saas-master` (el único portal con control de seguridad global y Keycloak/REZE).
3. **Registro de Colegios y Directores:** Desde `/adquirir` (pestaña *Registrar Colegio*), cualquier institución educativa nueva se registra dinámicamente en Oracle DB creando su cuenta de Director (`DIRECTOR`) y su propio portal `/colegio/:slug`.
4. **Persistencia Real en Oracle DB:** Desde el portal del Director (`/admin/comunidad`) o Secretaría (`/portal-secretaria`), todas las cuentas de Secretaría, Docentes, Colaboradores, Cursos, Contratos y Bloques de Horario se guardan permanentemente en las tablas JPA de Oracle DB (`ddl-auto: update`), sin datos demo ni docentes precargados.

> **Reset inicial único:** al arrancar sobre un volumen existente, el backend limpia una sola vez las tablas de negocio y deja solo la cuenta maestra. El marcador vive en `SISTEMA_MIGRACIONES` (`reset-inicial-v1`). Para un clon realmente limpio: `docker compose -f compose-dev.yml down -v` antes de `up -d`.

---

## 🛠️ Solución a Problemas Comunes

### 1. Error `EADDRINUSE: address already in use 0.0.0.0:3000`
El puerto 3000 está ocupado por otro proceso previo.
- **En Linux:**
  ```bash
  ss -ltnp | grep 3000
  kill -9 <PID>
  ```
- **En Windows (PowerShell):**
  ```powershell
  Get-Process -Id (Get-NetTCPConnection -LocalPort 3000).OwningProcess | Stop-Process -Force
  ```

### 2. Error de Política de Ejecución en PowerShell (`ps1 cannot be loaded`)
Si PowerShell bloquea la ejecución de scripts npm en Windows:
```powershell
Set-ExecutionPolicy -Scope Process -ExecutionPolicy Bypass
```

### 3. Error `./mvnw: Permission denied` en Linux
Asigne permisos de ejecución al wrapper ejecutable:
```bash
chmod +x bomerp-backend/mvnw
```

## 📐 Arquitectura de Módulos: 3 Transaccionales (M:N) y 3 No Transaccionales

El sistema cuenta con un panel interactivo dedicado en **`/modulos`** (*"3 M:N + 3 Maestros"* en el menú lateral) y el endpoint de inspección `/api/v1/modulos/resumen-arquitectura`.

### ⚡ 3 Módulos Transaccionales de Muchos a Muchos (M:N)
| # | Módulo Transaccional | Relación M:N | Tabla Asociativa (Oracle DB) | Regla de Negocio / ACID | Endpoints Principales |
|---|---|---|---|---|---|
| **1** | **Matrícula Escolar con Detalle de Cursos** | `ALUMNOS` ↔ `CURSOS` | `MATRICULAS` + `DETALLES_MATRICULA` | Reserva atómica de vacantes en tiempo real, cálculo de créditos y *Rollback* total ante sobrecupo o anulación. | `POST /api/v1/matriculas`, `PUT /api/v1/matriculas/:id/anular` |
| **2** | **Asignación de Carga Lectiva y Horarios** | `PERSONAL_ESCOLAR` (Docente) ↔ `CURSOS` / `AULAS` | `BLOQUES_HORARIO` | Detección estricta de cruces horarios (anti-traslape) por docente y aula, control de horas de contrato y confirmación oficial. | `POST /api/v1/horarios/asignar`, `GET /api/v1/horarios/todos` |
| **3** | **Evaluación y Cierre de Actas de Notas** | `ALUMNOS` ↔ `CURSOS` / `EVALUACIONES` | `NOTAS` | Validación en escala vigesimal (0-20), control de ponderación acumulada (100%) y cierre formal inmutable de actas. | `POST /api/v1/calificaciones/notas`, `PUT /api/v1/calificaciones/notas/cerrar/:id` |

### 📂 3 Módulos No Transaccionales (Catálogos Maestros CRUD)
| # | Módulo No Transaccional | Tabla Oracle DB | Propósito y Mantenimiento | Endpoints CRUD |
|---|---|---|---|---|
| **1** | **Catálogo Maestro de Cursos y Malla** | `CURSOS` | Mantenimiento referencial de asignaturas, grados, créditos y aforos máximos. | `GET / POST / PUT / DELETE /api/v1/cursos` |
| **2** | **Catálogo de Infraestructura y Aulas** | `AULAS` | Mantenimiento de salones teóricos, laboratorios, salas de cómputo, pabellones y aforo físico. | `GET / POST / PUT / DELETE /api/v1/aulas` |
| **3** | **Padrón Maestro de Personal Escolar** | `PERSONAL_ESCOLAR` | Directorio institucional de docentes, secretarias y colaboradores de mantenimiento/seguridad. | `GET / POST / PUT / DELETE /api/v1/personal` |

---

## 📁 Estructura del Proyecto

```
EDUWJ/
├── server.ts               # Servidor Express Mock API & Middleware (puerto 3000)
├── package.json            # Scripts principales (npm start / npm run build)
├── bomerp-frontend/        # Aplicación SPA Angular 22 + Tailwind CSS v3
└── bomerp-backend/         # Backend Spring Boot 4.0.7 + Spring Modulith 2.0.7
```

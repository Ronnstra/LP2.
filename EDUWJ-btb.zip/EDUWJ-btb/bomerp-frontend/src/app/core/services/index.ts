export * from './api-service';
export * from './alumno.service';
export * from './nota.service';
export * from './auth.service';
export * from './personal.service';
export * from './aula.service';
export * from './matricula.service';
export * from '../models';
import { Injectable, inject } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { environment } from '../../../environments/environment';
import { readStoredUser } from './auth-session';

export interface AulaEscolar {
  id: number;
  codigo: string;
  nombre: string;
  pabellon: string;
  tipo: 'TEORICA' | 'LABORATORIO' | 'COMPUTO' | 'AUDITORIO' | 'POLIDEPORTIVO';
  capacidad: number;
  estado: 'DISPONIBLE' | 'MANTENIMIENTO';
}

@Injectable({ providedIn: 'root' })
export class AulaService {
  private http = inject(HttpClient);
  private readonly apiUrl = `${environment.apiBaseUrl}/api/v1/aulas`;

  private getActiveColegioId(): number | undefined {
    const user = readStoredUser();
    if (user?.colegioId) return Number(user.colegioId);
    return undefined;
  }

  listar(): Observable<AulaEscolar[]> {
    const cid = this.getActiveColegioId();
    const qs = cid ? `?colegioId=${cid}` : '';
    return this.http.get<AulaEscolar[]>(`${this.apiUrl}${qs}`);
  }

  obtenerPorId(id: number): Observable<AulaEscolar> {
    return this.http.get<AulaEscolar>(`${this.apiUrl}/${id}`);
  }

  crear(aula: Partial<AulaEscolar> & { colegioId?: number }): Observable<AulaEscolar> {
    const cid = aula.colegioId ?? this.getActiveColegioId();
    return this.http.post<AulaEscolar>(this.apiUrl, cid ? { ...aula, colegioId: cid } : aula);
  }

  actualizar(id: number, aula: Partial<AulaEscolar> & { colegioId?: number }): Observable<AulaEscolar> {
    const cid = aula.colegioId ?? this.getActiveColegioId();
    return this.http.put<AulaEscolar>(`${this.apiUrl}/${id}`, cid ? { ...aula, colegioId: cid } : aula);
  }

  eliminar(id: number): Observable<void> {
    return this.http.delete<void>(`${this.apiUrl}/${id}`);
  }
}

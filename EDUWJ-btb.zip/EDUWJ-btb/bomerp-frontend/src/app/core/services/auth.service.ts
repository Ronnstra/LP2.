import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable, BehaviorSubject, tap, catchError, of } from 'rxjs';
import { environment } from '../../../environments/environment';
import { AuthRequest, AuthResponse, UserRole } from '../models';
import {
  clearAuthUser,
  clearLoginOrigin as removeLoginOrigin,
  getLoginOrigin as readLoginOrigin,
  readStoredUser,
  setLoginOrigin as persistLoginOrigin,
  storeAuthUser,
} from './auth-session';

@Injectable({ providedIn: 'root' })
export class AuthService {
  private readonly apiUrl = `${environment.apiBaseUrl}/api/v1/auth`;
  private currentUserSubject = new BehaviorSubject<AuthResponse | null>(null);
  public currentUser$ = this.currentUserSubject.asObservable();

  constructor(private http: HttpClient) {
    this.loadStoredUser();
  }

  private loadStoredUser(): void {
    const stored = readStoredUser();
    if (stored) {
      this.currentUserSubject.next(stored);
    }
  }

  login(credentials: AuthRequest): Observable<AuthResponse> {
    return this.http.post<AuthResponse>(`${this.apiUrl}/login`, credentials).pipe(
      tap((response) => {
        if (response.slugColegio) {
          localStorage.setItem('lastVisitedColegioSlug', response.slugColegio);
        }
        storeAuthUser(response);
        this.currentUserSubject.next(response);
      })
    );
  }

  setLoginOrigin(origin: string): void {
    persistLoginOrigin(origin);
  }

  getLoginOrigin(): string | null {
    return readLoginOrigin();
  }

  clearLoginOrigin(): void {
    removeLoginOrigin();
  }

  logout(): string {
    const user = this.getCurrentUser();
    const isSuper = user?.rol === 'ADMIN' || user?.username === 'jimyamanqui@gmail.com' || user?.username === 'jimy';
    const origin = this.getLoginOrigin();
    const userSlug = user?.slugColegio;
    const lastSlug = typeof localStorage !== 'undefined' ? localStorage.getItem('lastVisitedColegioSlug') : null;

    clearAuthUser();
    this.clearLoginOrigin();
    this.currentUserSubject.next(null);

    // 1. Si es SuperAdmin: siempre regresa a /adquirir (Portal Principal del SaaS)
    if (isSuper) {
      return '/adquirir';
    }

    // 2. Si te logueas en /adquirir, al salir DEBES regresar ahí
    if (origin === '/adquirir' || origin?.startsWith('/adquirir')) {
      return '/adquirir';
    }

    // 3. Si te logueas en el portal/login de un colegio (/colegio/:slug)
    if (origin?.startsWith('/colegio/')) {
      return origin;
    }

    // 4. Si te logueas en /login
    if (origin?.startsWith('/login')) {
      return origin;
    }

    // 5. Si el usuario pertenecía a un colegio, regresar a su portal de acceso
    const effectiveSlug = userSlug || lastSlug;
    if (effectiveSlug) {
      return `/colegio/${effectiveSlug}`;
    }

    // Fallback general
    return '/adquirir';
  }

  getCurrentUser(): AuthResponse | null {
    return this.currentUserSubject.value;
  }

  isLoggedIn(): boolean {
    return !!this.currentUserSubject.value;
  }

  hasRole(role: UserRole): boolean {
    const user = this.currentUserSubject.value;
    return user?.rol === role;
  }

  isSuperAdmin(): boolean {
    return this.hasRole('ADMIN');
  }

  isDirector(): boolean {
    return this.hasRole('DIRECTOR');
  }

  isAdmin(): boolean {
    return this.hasRole('ADMIN') || this.hasRole('DIRECTOR');
  }

  isDocente(): boolean {
    return this.hasRole('DOCENTE');
  }

  isProfesor(): boolean {
    return this.isDocente();
  }

  isAlumno(): boolean {
    return this.hasRole('ALUMNO');
  }

  isSecretaria(): boolean {
    return this.hasRole('SECRETARIA');
  }

  isColaborador(): boolean {
    return this.hasRole('COLABORADOR');
  }

  getDefaultRoute(): string {
    const user = this.currentUserSubject.value;
    if (user?.rol === 'ADMIN') {
      return '/saas-master';
    }
    if (user?.rol === 'ALUMNO') {
      return '/portal-alumno';
    }
    if (user?.rol === 'DOCENTE') {
      return '/portal-docente';
    }
    if (user?.rol === 'SECRETARIA') {
      return '/portal-secretaria';
    }
    if (user?.rol === 'COLABORADOR') {
      return '/portal-colaborador';
    }
    return '/admin/comunidad';
  }

  getToken(): string | null {
    return this.currentUserSubject.value?.token ?? null;
  }

  getSteamGuardStatus(): Observable<{
    intervalSeconds: number;
    secondsRemaining: number;
    timeStep: number;
    boundEmail: string;
    hasActiveDevice: boolean;
    deviceName: string | null;
  }> {
    return this.http.get<{
      intervalSeconds: number;
      secondsRemaining: number;
      timeStep: number;
      boundEmail: string;
      hasActiveDevice: boolean;
      deviceName: string | null;
    }>(`${environment.apiBaseUrl}/api/v1/saas/auth/steamguard-status`);
  }

  // Steam Guard Mobile Device API
  getGuardDeviceStatus(deviceId: string): Observable<any> {
    return this.http.get<any>(`${environment.apiBaseUrl}/api/v1/saas/guard/device-status`, {
      headers: { 'x-guard-device-id': deviceId },
    });
  }

  getGuardCode(deviceId: string): Observable<any> {
    return this.http.get<any>(`${environment.apiBaseUrl}/api/v1/saas/guard/code`, {
      headers: { 'x-guard-device-id': deviceId },
    });
  }

  vincularGuardDevice(data: { deviceId: string; deviceName: string; pairToken?: string }): Observable<any> {
    return this.http.post<any>(`${environment.apiBaseUrl}/api/v1/saas/guard/vincular`, data);
  }

  revocarGuardDevice(): Observable<any> {
    const token = this.getToken();
    return this.http.post<any>(
      `${environment.apiBaseUrl}/api/v1/saas/guard/revocar`,
      {},
      { headers: token ? { Authorization: `Bearer ${token}` } : {} }
    );
  }

  generarTokenVinculacion(): Observable<any> {
    const token = this.getToken();
    const origin = typeof window !== 'undefined' ? window.location.origin : '';
    return this.http.post<any>(
      `${environment.apiBaseUrl}/api/v1/saas/guard/generar-token-vinculacion`,
      { origin },
      { headers: token ? { Authorization: `Bearer ${token}` } : {} }
    );
  }

  getQrDescarga(): Observable<any> {
    const origin = typeof window !== 'undefined' ? window.location.origin : '';
    return this.http.get<any>(`${environment.apiBaseUrl}/api/v1/saas/guard/qr-descarga`, {
      params: origin ? { origin } : {},
    });
  }

  getResumenSistemaReze(): Observable<any> {
    return this.http.get<any>(`${environment.apiBaseUrl}/api/v1/saas/guard/system-summary`);
  }

  rotarCodigoReze(): Observable<any> {
    return this.http.post<any>(`${environment.apiBaseUrl}/api/v1/saas/guard/rotar-codigo`, {}).pipe(
      tap((res) => this.emitirBroadcastLocal('ROTAR_CODIGO', res))
    );
  }

  ejecutarAccionColegioMovil(colegioId: number, accion: 'TOGGLE_ESTADO' | 'REGISTRAR_PAGO' | 'ELIMINAR'): Observable<any> {
    return this.http.post<any>(`${environment.apiBaseUrl}/api/v1/saas/guard/colegio-accion`, { colegioId, accion }).pipe(
      tap((res) => this.emitirBroadcastLocal('COLEGIO_ACCION', res))
    );
  }

  crearColegioDesdeMovil(payload: {
    nombreColegio: string;
    ciudad: string;
    directorNombre: string;
    directorUsername: string;
    directorPassword: string;
    metodoPago: string;
  }): Observable<any> {
    return this.http.post<any>(`${environment.apiBaseUrl}/api/v1/saas/guard/crear-colegio-movil`, payload).pipe(
      tap((res) => this.emitirBroadcastLocal('CREAR_COLEGIO', res))
    );
  }

  limpiarSistemaDesdeMovil(): Observable<any> {
    return this.http.post<any>(`${environment.apiBaseUrl}/api/v1/saas/guard/limpiar-sistema-movil`, {}).pipe(
      tap((res) => this.emitirBroadcastLocal('LIMPIAR_SISTEMA', res))
    );
  }

  emitirBroadcastLocal(type: string, data: any): void {
    try {
      if (typeof BroadcastChannel !== 'undefined') {
        const bc = new BroadcastChannel('bomerp_reze_realtime');
        bc.postMessage({ type, data, timestamp: Date.now() });
        bc.close();
      }
    } catch {
      // ignore if BroadcastChannel unsupported
    }
  }

  conectarStreamTiempoReal(onUpdate: (payload: any) => void): () => void {
    let es: EventSource | null = null;
    let bc: BroadcastChannel | null = null;

    if (typeof window !== 'undefined' && typeof EventSource !== 'undefined') {
      try {
        es = new EventSource(`${environment.apiBaseUrl}/api/v1/saas/realtime/stream`);
        es.onmessage = (event) => {
          try {
            const parsed = JSON.parse(event.data);
            onUpdate(parsed);
          } catch {
            // ignore
          }
        };
      } catch {
        // ignore
      }
    }

    if (typeof BroadcastChannel !== 'undefined') {
      try {
        bc = new BroadcastChannel('bomerp_reze_realtime');
        bc.onmessage = (ev) => {
          if (ev.data?.data?.resumenSistema) {
            onUpdate({
              type: ev.data.type,
              resumenSistema: ev.data.data.resumenSistema,
              colegios: ev.data.data.resumenSistema.finanzas?.colegios || [],
              guardCode: ev.data.data.code ? ev.data.data : undefined,
            });
          } else {
            this.getResumenSistemaReze().subscribe({
              next: (r) =>
                onUpdate({
                  type: ev.data?.type || 'SYNC',
                  resumenSistema: r,
                  colegios: r.finanzas?.colegios || [],
                }),
            });
          }
        };
      } catch {
        // ignore
      }
    }

    return () => {
      if (es) es.close();
      if (bc) bc.close();
    };
  }

  verificarCredencialesMaestro(credentials: { username: string; password: string }): Observable<any> {
    return this.http.post<any>(`${environment.apiBaseUrl}/api/v1/saas/auth/verificar-credenciales-maestro`, credentials);
  }

  enviarCorreoInstalacionPami(destinatario = 'jimyamanqui@gmail.com'): Observable<any> {
    const origin = typeof window !== 'undefined' ? window.location.origin : '';
    return this.http.post<any>(`${environment.apiBaseUrl}/api/v1/saas/guard/enviar-correo-instalacion`, {
      destinatario,
      origin,
    });
  }

  getCorreosEnviadosPami(): Observable<{ exito: boolean; total: number; correos: any[] }> {
    return this.http.get<{ exito: boolean; total: number; correos: any[] }>(
      `${environment.apiBaseUrl}/api/v1/saas/guard/correos-enviados`
    );
  }

  loginMaestro(credentials: { username: string; password: string; steamGuardCode: string }): Observable<any> {
    return this.http.post<any>(`${environment.apiBaseUrl}/api/v1/saas/auth/login-maestro`, credentials).pipe(
      tap((res) => {
        if (res.exito && res.token) {
          const authUser: AuthResponse = {
            id: res.usuario.id,
            username: res.usuario.username,
            rol: 'ADMIN',
            token: res.token,
            mensaje: res.mensaje,
            nombreCompleto: res.usuario.nombreCompleto,
            cargo: res.usuario.cargo,
            email: res.usuario.email,
          };
          storeAuthUser(authUser);
          this.currentUserSubject.next(authUser);
        }
      })
    );
  }

  adquirirSistema(datosContrato: any): Observable<any> {
    return this.http.post<any>(`${environment.apiBaseUrl}/api/v1/saas/adquirir`, datosContrato);
  }

  obtenerMetricasSaaS(): Observable<any> {
    return this.http.get<any>(`${environment.apiBaseUrl}/api/v1/saas/metricas`);
  }

  obtenerColegiosSaaS(): Observable<any[]> {
    return this.http.get<any[]>(`${environment.apiBaseUrl}/api/v1/saas/colegios`);
  }

  obtenerColegioPorSlug(slug: string): Observable<any> {
    return this.http.get<any>(`${environment.apiBaseUrl}/api/v1/saas/colegios/slug/${encodeURIComponent(slug)}`);
  }

  obtenerMiColegio(username?: string, colegioId?: number): Observable<any> {
    const params: Record<string, string> = {};
    if (username) params['username'] = username;
    if (colegioId) params['colegioId'] = String(colegioId);
    return this.http.get<any>(`${environment.apiBaseUrl}/api/v1/saas/mi-colegio`, { params });
  }

  obtenerMiSuscripcion(colegioId?: number, username?: string): Observable<any> {
    const params: Record<string, string> = {};
    if (colegioId) params['colegioId'] = String(colegioId);
    if (username) params['username'] = username;
    return this.http.get<any>(`${environment.apiBaseUrl}/api/v1/saas/mi-suscripcion`, { params }).pipe(
      catchError(() => of({ exito: false, suscripcion: null }))
    );
  }

  pagarSuscripcionSaaS(data: {
    colegioId: number;
    mesesAdelantar: number;
    metodoPago: string;
    banco?: string;
    numeroOperacion?: string;
    voucherNombre?: string;
  }): Observable<any> {
    return this.http.post<any>(`${environment.apiBaseUrl}/api/v1/saas/pagar`, data);
  }

  // Métodos de Gestión de Cuentas Escolares (Administrador y Secretaría)
  // Nunca devuelve al SuperAdmin del SaaS
  listarUsuarios(colegioId?: number): Observable<any[]> {
    const params: Record<string, string> = {};
    const cid = colegioId ?? this.getCurrentUser()?.colegioId;
    if (cid) params['colegioId'] = String(cid);
    return this.http.get<any[]>(`${environment.apiBaseUrl}/api/v1/usuarios`, { params });
  }

  crearUsuario(data: {
    username: string;
    password: string;
    rol: string;
    nombreCompleto: string;
    cargo?: string;
    email?: string;
    telefono?: string;
    dni?: string;
    turno?: string;
    sueldoMensual?: number;
    colegioId?: number;
    nombreColegio?: string;
  }): Observable<any> {
    const current = this.getCurrentUser();
    const payload = {
      ...data,
      colegioId: data.colegioId ?? current?.colegioId,
      nombreColegio: data.nombreColegio ?? current?.nombreColegio,
      slugColegio: current?.slugColegio,
    };
    return this.http.post<any>(`${environment.apiBaseUrl}/api/v1/usuarios/registrar-admin`, payload);
  }

  actualizarUsuario(id: number, data: any): Observable<any> {
    return this.http.put<any>(`${environment.apiBaseUrl}/api/v1/usuarios/${id}`, data);
  }

  eliminarUsuario(id: number): Observable<any> {
    return this.http.delete<any>(`${environment.apiBaseUrl}/api/v1/usuarios/${id}`);
  }

  reiniciarSistema(modo: 'limpio' | 'demo'): Observable<any> {
    return this.http.post<any>(`${environment.apiBaseUrl}/api/v1/sistema/reset`, { modo });
  }

  inicializarColegio(data?: { nombreColegio?: string; anioLectivo?: string }): Observable<any> {
    return this.http.post<any>(`${environment.apiBaseUrl}/api/v1/sistema/inicializar-colegio`, data || {});
  }
}
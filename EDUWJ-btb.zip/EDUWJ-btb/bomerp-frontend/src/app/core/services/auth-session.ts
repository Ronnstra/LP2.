import { AuthResponse } from '../models';

const AUTH_USER_KEY = 'currentUser';
const LOGIN_ORIGIN_KEY = 'bomerp_login_origin';

function hasSessionStorage(): boolean {
  return typeof sessionStorage !== 'undefined';
}

export function readStoredUser(): AuthResponse | null {
  if (!hasSessionStorage()) return null;
  try {
    let raw = sessionStorage.getItem(AUTH_USER_KEY);
    if (!raw) {
      const legacy = localStorage.getItem(AUTH_USER_KEY);
      if (legacy) {
        sessionStorage.setItem(AUTH_USER_KEY, legacy);
        localStorage.removeItem(AUTH_USER_KEY);
        raw = legacy;
      }
    }
    return raw ? (JSON.parse(raw) as AuthResponse) : null;
  } catch {
    return null;
  }
}

export function storeAuthUser(user: AuthResponse): void {
  if (hasSessionStorage()) {
    sessionStorage.setItem(AUTH_USER_KEY, JSON.stringify(user));
  }
  localStorage.removeItem(AUTH_USER_KEY);
}

export function clearAuthUser(): void {
  if (hasSessionStorage()) {
    sessionStorage.removeItem(AUTH_USER_KEY);
  }
  localStorage.removeItem(AUTH_USER_KEY);
}

export function setLoginOrigin(origin: string): void {
  if (hasSessionStorage()) {
    sessionStorage.setItem(LOGIN_ORIGIN_KEY, origin);
  }
}

export function getLoginOrigin(): string | null {
  return hasSessionStorage() ? sessionStorage.getItem(LOGIN_ORIGIN_KEY) : null;
}

export function clearLoginOrigin(): void {
  if (hasSessionStorage()) {
    sessionStorage.removeItem(LOGIN_ORIGIN_KEY);
  }
}

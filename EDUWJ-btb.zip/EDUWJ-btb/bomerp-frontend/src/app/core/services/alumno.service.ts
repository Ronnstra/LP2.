import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { environment } from '../../../environments/environment';
import { AlumnoRequest, AlumnoResponse, PortalAlumnoData } from '../models';
import { readStoredUser } from './auth-session';

@Injectable({ providedIn: 'root' })
export class AlumnoService {
  private readonly baseUrl = environment.apiBaseUrl;
  private readonly apiUrl = `${environment.apiBaseUrl}/api/v1/matricula/alumnos`;

  constructor(private http: HttpClient) {}

  private getActiveColegioId(explicitId?: number): number | undefined {
    if (explicitId) return explicitId;
    const user = readStoredUser();
    if (user?.colegioId) return Number(user.colegioId);
    return undefined;
  }

  listar(colegioId?: number): Observable<AlumnoResponse[]> {
    const cid = this.getActiveColegioId(colegioId);
    const qs = cid ? `?colegioId=${cid}` : '';
    return this.http.get<AlumnoResponse[]>(`${this.apiUrl}${qs}`);
  }

  obtener(id: number): Observable<AlumnoResponse> {
    return this.http.get<AlumnoResponse>(`${this.apiUrl}/${id}`);
  }

  obtenerMiPerfil(): Observable<PortalAlumnoData> {
    let qs = '';
    const user = readStoredUser();
    if (user) {
      const params: string[] = [];
      if ((user as any)?.dni) params.push(`dni=${encodeURIComponent((user as any).dni)}`);
      if (user.username?.startsWith('alumno_')) {
        params.push(`dni=${encodeURIComponent(user.username.replace('alumno_', ''))}`);
      }
      if (user.colegioId) params.push(`colegioId=${encodeURIComponent(user.colegioId)}`);
      if (params.length > 0) qs = `?${params.join('&')}`;
    }
    return this.http.get<PortalAlumnoData>(`${this.apiUrl}/mi-perfil${qs}`);
  }

  private getActiveColegioContext(): { colegioId?: number; slugColegio?: string; nombreColegio?: string } {
    const user = readStoredUser();
    return {
      colegioId: user?.colegioId ? Number(user.colegioId) : undefined,
      slugColegio: user?.slugColegio || undefined,
      nombreColegio: user?.nombreColegio || undefined,
    };
  }

  crear(alumno: AlumnoRequest & { colegioId?: number }): Observable<AlumnoResponse> {
    const ctx = this.getActiveColegioContext();
    const cid = this.getActiveColegioId(alumno.colegioId) || ctx.colegioId;
    return this.http.post<AlumnoResponse>(this.apiUrl, {
      ...alumno,
      ...(cid ? { colegioId: cid } : {}),
      ...(ctx.slugColegio ? { slugColegio: ctx.slugColegio } : {}),
      ...(ctx.nombreColegio ? { nombreColegio: ctx.nombreColegio } : {}),
    });
  }

  actualizar(id: number, alumno: AlumnoRequest & { colegioId?: number }): Observable<AlumnoResponse> {
    const cid = this.getActiveColegioId(alumno.colegioId);
    return this.http.put<AlumnoResponse>(`${this.apiUrl}/${id}`, cid ? { ...alumno, colegioId: cid } : alumno);
  }

  eliminar(id: number): Observable<void> {
    return this.http.delete<void>(`${this.apiUrl}/${id}`);
  }

  buscarPorDni(dni: string): Observable<AlumnoResponse> {
    return this.http.get<AlumnoResponse>(`${this.apiUrl}/dni/${dni}`);
  }

  pagarCuota(alumnoId: number, cuotaNumero: number): Observable<{ mensaje: string; cuota: any; planFinanciero: any }> {
    return this.http.post<{ mensaje: string; cuota: any; planFinanciero: any }>(`${this.apiUrl}/${alumnoId}/pagar-cuota`, {
      cuotaNumero,
    });
  }

  registrarDeuda(
    alumnoId: number,
    payload: { concepto: string; monto: number; fechaVencimiento: string; mes?: string; descripcion?: string }
  ): Observable<{ mensaje: string; cuota: any; planFinanciero: any }> {
    return this.http.post<any>(`${this.apiUrl}/${alumnoId}/deuda`, payload);
  }

  generarDeudaMasiva(
    payload: { concepto: string; monto: number; mes: string; fechaVencimiento: string; grado?: string }
  ): Observable<{ mensaje: string; alumnosAfectados: number }> {
    return this.http.post<any>(`${this.baseUrl}/api/v1/finanzas/deuda-masiva`, payload);
  }

  obtenerPendientes(colegioId?: number): Observable<AlumnoResponse[]> {
    const cid = this.getActiveColegioId(colegioId);
    const qs = cid ? `?colegioId=${cid}` : '';
    return this.http.get<AlumnoResponse[]>(`${this.apiUrl}-pendientes${qs}`);
  }

  confirmar(id: number): Observable<{ mensaje: string; alumno: AlumnoResponse }> {
    return this.http.put<{ mensaje: string; alumno: AlumnoResponse }>(`${this.apiUrl}/${id}/confirmar`, {});
  }

  enviarJustificacion(payload: {
    alumnoId: number;
    curso: string;
    docenteId?: number;
    fechaInasistencia: string;
    horaClase?: string;
    sesion?: number;
    motivo: string;
    descripcion: string;
    comprobanteNombre?: string;
  }): Observable<{ mensaje: string; justificacion: any }> {
    return this.http.post<any>(`${this.baseUrl}/api/v1/inasistencias/justificar`, payload);
  }

  obtenerMisJustificaciones(alumnoId: number): Observable<any[]> {
    return this.http.get<any[]>(`${this.baseUrl}/api/v1/inasistencias/alumno/${alumnoId}`);
  }

  obtenerHorarioSemanal(alumnoId: number): Observable<any> {
    return this.http.get<any>(`${this.baseUrl}/api/v1/horarios/alumno/${alumnoId}`);
  }
}
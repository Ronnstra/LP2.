import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable, of } from 'rxjs';
import { catchError, map } from 'rxjs/operators';
import { environment } from '../../../environments/environment';
import { readStoredUser } from './auth-session';
import {
  PersonalEscolar,
  PersonalRequest,
  FinanzasResumen,
  DocenteCurso,
  BloqueHorario,
  ConfiguracionJornada,
  BloqueHorarioRequest,
  DocenteDisponibilidadRespuesta,
} from '../models';

@Injectable({ providedIn: 'root' })
export class PersonalService {
  private readonly baseUrl = environment.apiBaseUrl;

  constructor(private http: HttpClient) {}

  private getActiveColegioId(explicitId?: number): number | undefined {
    if (explicitId) return explicitId;
    const user = readStoredUser();
    if (user?.colegioId) return Number(user.colegioId);
    return undefined;
  }

  listar(estamento?: 'docentes' | 'colaboradores', estadoAprobacion?: string, colegioId?: number): Observable<PersonalEscolar[]> {
    let url = `${this.baseUrl}/api/v1/personal`;
    const params: string[] = [];
    const cid = this.getActiveColegioId(colegioId);
    if (estamento) params.push(`estamento=${estamento}`);
    if (estadoAprobacion) params.push(`estadoAprobacion=${estadoAprobacion}`);
    if (cid) params.push(`colegioId=${cid}`);
    if (params.length > 0) url += `?${params.join('&')}`;
    return this.http.get<PersonalEscolar[]>(url);
  }

  crear(request: PersonalRequest & { colegioId?: number }): Observable<PersonalEscolar> {
    const cid = this.getActiveColegioId(request.colegioId);
    let slugColegio: string | undefined;
    let nombreColegio: string | undefined;
    const user = readStoredUser();
    slugColegio = user?.slugColegio || undefined;
    nombreColegio = user?.nombreColegio || undefined;
    return this.http.post<PersonalEscolar>(`${this.baseUrl}/api/v1/personal`, {
      ...request,
      ...(cid ? { colegioId: cid } : {}),
      ...(slugColegio ? { slugColegio } : {}),
      ...(nombreColegio ? { nombreColegio } : {}),
    });
  }

  confirmar(id: number): Observable<PersonalEscolar> {
    return this.http.put<PersonalEscolar>(`${this.baseUrl}/api/v1/personal/${id}/confirmar`, {});
  }

  rechazar(id: number, motivo?: string): Observable<PersonalEscolar> {
    return this.http.put<PersonalEscolar>(`${this.baseUrl}/api/v1/personal/${id}/rechazar`, { motivo });
  }

  eliminar(id: number): Observable<void> {
    return this.http.delete<void>(`${this.baseUrl}/api/v1/personal/${id}`);
  }

  obtenerFinanzas(colegioId?: number): Observable<FinanzasResumen> {
    const cid = this.getActiveColegioId(colegioId);
    const qs = cid ? `?colegioId=${cid}` : '';
    return this.http.get<FinanzasResumen>(`${this.baseUrl}/api/v1/finanzas/resumen${qs}`);
  }

  obtenerCursosDocente(docenteId?: number, username?: string, colegioId?: number): Observable<DocenteCurso[]> {
    const params: string[] = [];
    if (docenteId) params.push(`docenteId=${docenteId}`);
    if (username) params.push(`username=${encodeURIComponent(username)}`);
    if (colegioId) params.push(`colegioId=${colegioId}`);
    const query = params.length > 0 ? `?${params.join('&')}` : '';
    return this.http.get<DocenteCurso[]>(`${this.baseUrl}/api/v1/docente/cursos${query}`);
  }

  guardarNotaDocente(payload: { alumnoId: number; evaluacion: string; valor: number; cursoId?: number }): Observable<any> {
    return this.http.post(`${this.baseUrl}/api/v1/docente/notas`, payload);
  }

  guardarAsistenciaDocente(payload: {
    docenteId?: number;
    username?: string;
    colegioId?: number;
    curso: string;
    grado: string;
    seccion: string;
    sesion: number;
    fechaRegistro?: string;
    asistencias: { alumnoId: number; estado: string }[];
  }): Observable<any> {
    return this.http.post(`${this.baseUrl}/api/v1/docente/asistencia`, payload);
  }

  listarAsistencias(colegioId?: number, filtros?: { curso?: string; grado?: string; seccion?: string; sesion?: number }): Observable<any[]> {
    const params: string[] = [];
    if (colegioId) params.push(`colegioId=${colegioId}`);
    if (filtros?.curso) params.push(`curso=${encodeURIComponent(filtros.curso)}`);
    if (filtros?.grado) params.push(`grado=${encodeURIComponent(filtros.grado)}`);
    if (filtros?.seccion) params.push(`seccion=${encodeURIComponent(filtros.seccion)}`);
    if (filtros?.sesion) params.push(`sesion=${filtros.sesion}`);
    const qs = params.length ? `?${params.join('&')}` : '';
    return this.http.get<any[]>(`${this.baseUrl}/api/v1/asistencias${qs}`);
  }

  obtenerResumenAsistenciaAlumno(alumnoId: number): Observable<any> {
    return this.http.get<any>(`${this.baseUrl}/api/v1/asistencias/resumen/alumno/${alumnoId}`);
  }

  obtenerAsistenciaDocente(
    docenteId: number | undefined,
    username: string | undefined,
    colegioId: number | undefined,
    curso: string,
    grado: string,
    seccion: string,
    sesion: number
  ): Observable<any[]> {
    const params: string[] = [];
    if (docenteId) params.push(`docenteId=${docenteId}`);
    if (username) params.push(`username=${encodeURIComponent(username)}`);
    if (colegioId) params.push(`colegioId=${colegioId}`);
    params.push(`curso=${encodeURIComponent(curso)}`);
    params.push(`grado=${encodeURIComponent(grado)}`);
    params.push(`seccion=${encodeURIComponent(seccion)}`);
    params.push(`sesion=${sesion}`);
    return this.http.get<any[]>(`${this.baseUrl}/api/v1/docente/asistencia?${params.join('&')}`);
  }

  cerrarActaDocente(cursoId: number): Observable<any> {
    return this.http.put(`${this.baseUrl}/api/v1/docente/notas/${cursoId}/cerrar`, {});
  }

  obtenerNominaDocente(docenteId?: number, username?: string, colegioId?: number): Observable<import('../models').NominaDocente> {
    const params: string[] = [];
    if (docenteId) params.push(`docenteId=${docenteId}`);
    if (username) params.push(`username=${encodeURIComponent(username)}`);
    if (colegioId) params.push(`colegioId=${colegioId}`);
    const qs = params.length > 0 ? `?${params.join('&')}` : '';
    return this.http.get<import('../models').NominaDocente>(`${this.baseUrl}/api/v1/docente/finanzas${qs}`);
  }

  registrarHorasExtraDocente(horas: number, motivo: string): Observable<{ mensaje: string; nomina: import('../models').NominaDocente }> {
    return this.http.post<{ mensaje: string; nomina: import('../models').NominaDocente }>(`${this.baseUrl}/api/v1/docente/horas-extra`, {
      horas,
      motivo,
    });
  }

  cambiarPeriodicidadDocente(periodicidad: 'QUINCENAL' | 'MENSUAL'): Observable<import('../models').NominaDocente> {
    return this.http.put<import('../models').NominaDocente>(`${this.baseUrl}/api/v1/docente/periodicidad`, {
      periodicidad,
    });
  }

  // Horarios de Docente
  obtenerHorarioDocente(docenteId: number, username?: string): Observable<{
    docenteId: number;
    docenteNombre: string;
    dni: string;
    tarifaHora: number;
    totalHorasSemana: number;
    bloquesTotal: number;
    pagoSemanal?: number;
    horasMensuales?: number;
    pagoMensual?: number;
    agendaSemanal: { dia: string; esFinDeSemana: boolean; mensaje: string; sesiones: any[] }[];
    bloques: import('../models').BloqueHorario[];
  }> {
    const qs = username ? `?username=${encodeURIComponent(username)}` : '';
    return this.http.get<any>(`${this.baseUrl}/api/v1/horarios/docente/${docenteId}${qs}`);
  }

  // Justificaciones de Inasistencias para Docente
  obtenerJustificacionesDocente(docenteId: number): Observable<import('../models').JustificacionInasistencia[]> {
    return this.http.get<import('../models').JustificacionInasistencia[]>(`${this.baseUrl}/api/v1/inasistencias/docente/${docenteId}`);
  }

  resolverJustificacion(
    id: number,
    payload: { estado: 'APROBADA' | 'RECHAZADA'; respuestaDocente?: string }
  ): Observable<{ mensaje: string; justificacion: import('../models').JustificacionInasistencia }> {
    return this.http.put<any>(`${this.baseUrl}/api/v1/inasistencias/${id}/resolver`, payload);
  }

  // Disponibilidad de Personal / Docente
  actualizarDisponibilidad(
    id: number,
    payload: { disponibilidad?: import('../models').FranjaDisponibilidad[]; cursosEspecialidad?: string[]; tarifaHora?: number }
  ): Observable<any> {
    return this.http.put(`${this.baseUrl}/api/v1/personal/${id}/disponibilidad`, payload);
  }

  // Contratos Docentes por Hora
  listarContratosDocentes(colegioId?: number): Observable<{
    totalContratos: number;
    totalHorasSemanales: number;
    totalPlanillaEstimada: number;
    contratos: import('../models').ContratoDocente[];
  }> {
    const cid = this.getActiveColegioId(colegioId);
    const qs = cid ? `?colegioId=${cid}` : '';
    return this.http.get<any>(`${this.baseUrl}/api/v1/contratos-docentes${qs}`);
  }

  crearOActualizarContratoDocente(payload: {
    docenteId: number;
    tarifaPorHora: number;
    horasSemanales: number;
    fechaInicio?: string;
    fechaFin?: string;
    cursosAsignados?: string[];
    gradosAsignados?: string[];
    observaciones?: string;
    colegioId?: number;
  }): Observable<{ mensaje: string; contrato: import('../models').ContratoDocente }> {
    const cid = this.getActiveColegioId(payload.colegioId);
    return this.http.post<any>(`${this.baseUrl}/api/v1/contratos-docentes`, cid ? { ...payload, colegioId: cid } : payload);
  }

  // Horario por Grado (Secundaria)
  obtenerHorarioSecundaria(grado: string, colegioId?: number): Observable<{ grado: string; semana: any[]; totalBloques: number }> {
    const cid = this.getActiveColegioId(colegioId);
    const qs = cid ? `?colegioId=${cid}` : '';
    return this.http.get<any>(`${this.baseUrl}/api/v1/horarios/secundaria/${encodeURIComponent(grado)}${qs}`);
  }

  // Cursos (Prueba)
  obtenerCatalogoCursos(colegioId?: number): Observable<string[]> {
    const cid = this.getActiveColegioId(colegioId);
    const qs = cid ? `?colegioId=${cid}` : '';
    return this.http.get<string[]>(`${this.baseUrl}/api/v1/horarios/cursos${qs}`);
  }

  agregarCurso(nombre: string, colegioId?: number, grado?: string): Observable<{ mensaje: string; cursos: string[] }> {
    const cid = this.getActiveColegioId(colegioId);
    const payload: any = { nombre };
    if (cid) payload.colegioId = cid;
    if (grado) payload.grado = grado;
    return this.http.post<any>(`${this.baseUrl}/api/v1/horarios/cursos`, payload);
  }

  obtenerCatalogoCursosDetalle(colegioId?: number): Observable<{ nombre: string; grado: string }[]> {
    const cid = this.getActiveColegioId(colegioId);
    const qs = cid ? `?colegioId=${cid}` : '';
    return this.http.get<{ nombre: string; grado: string }[]>(`${this.baseUrl}/api/v1/horarios/cursos/detalle${qs}`).pipe(
      catchError(() => of([]))
    );
  }

  actualizarCursoCatalogo(
    nombre: string,
    payload: { nombre?: string; grado?: string; colegioId?: number }
  ): Observable<{ mensaje: string; cursos: string[]; detalle?: { nombre: string; grado: string }[] }> {
    const cid = this.getActiveColegioId(payload.colegioId);
    const body: any = { ...payload };
    if (cid) body.colegioId = cid;
    return this.http.put<any>(`${this.baseUrl}/api/v1/horarios/cursos/${encodeURIComponent(nombre)}`, body);
  }

  eliminarCurso(nombre: string, colegioId?: number): Observable<{ mensaje: string; cursos: string[] }> {
    const cid = this.getActiveColegioId(colegioId);
    const qs = cid ? `?colegioId=${cid}` : '';
    return this.http.delete<any>(`${this.baseUrl}/api/v1/horarios/cursos/${encodeURIComponent(nombre)}${qs}`);
  }

  // Gestión Avanzada de Horarios, Jornada y Detección de Choques
  obtenerConfiguracionJornada(): Observable<ConfiguracionJornada> {
    return this.http.get<ConfiguracionJornada>(`${this.baseUrl}/api/v1/horarios/configuracion`);
  }

  actualizarConfiguracionJornada(config: Partial<ConfiguracionJornada>): Observable<{ mensaje: string; configuracion: ConfiguracionJornada }> {
    return this.http.put<any>(`${this.baseUrl}/api/v1/horarios/configuracion`, config);
  }

  obtenerDisponibilidadDocentes(
    dia: string,
    horaInicio: string,
    horaFin: string,
    bloqueIdExcluir?: number
  ): Observable<DocenteDisponibilidadRespuesta[]> {
    let url = `${this.baseUrl}/api/v1/horarios/disponibilidad-docentes?dia=${encodeURIComponent(dia)}&horaInicio=${encodeURIComponent(horaInicio)}&horaFin=${encodeURIComponent(horaFin)}`;
    if (bloqueIdExcluir) {
      url += `&bloqueIdExcluir=${bloqueIdExcluir}`;
    }
    const cid = this.getActiveColegioId();
    if (cid) {
      url += `&colegioId=${cid}`;
    }
    return this.http.get<DocenteDisponibilidadRespuesta[]>(url);
  }

  asignarBloqueHorario(payload: BloqueHorarioRequest): Observable<{ mensaje: string; bloque: BloqueHorario }> {
    return this.http.post<any>(`${this.baseUrl}/api/v1/horarios/asignar`, payload);
  }

  liberarBloqueHorario(id: number): Observable<{ mensaje: string; bloqueEliminado: BloqueHorario }> {
    return this.http.delete<any>(`${this.baseUrl}/api/v1/horarios/bloque/${id}`);
  }

  toggleConfirmarBloque(id: number): Observable<{ mensaje: string; bloque: BloqueHorario }> {
    return this.http.put<any>(`${this.baseUrl}/api/v1/horarios/bloque/${id}/toggle-confirmar`, {});
  }

  confirmarTodosHorariosGrado(grado: string): Observable<{ mensaje: string; totalConfirmados: number; grado: string }> {
    return this.http.put<any>(`${this.baseUrl}/api/v1/horarios/grado/${encodeURIComponent(grado)}/confirmar-todos`, {});
  }

  limpiarTodosHorarios(): Observable<{ mensaje: string; totalEliminados: number }> {
    return this.http.post<any>(`${this.baseUrl}/api/v1/horarios/limpiar`, {});
  }

  restaurarHorariosEjemplo(): Observable<{ mensaje: string; totalBloques: number }> {
    return this.http.post<any>(`${this.baseUrl}/api/v1/horarios/restaurar-ejemplo`, {});
  }

  obtenerTodosHorarios(colegioId?: number): Observable<BloqueHorario[]> {
    const cid = this.getActiveColegioId(colegioId);
    const qs = cid ? `?colegioId=${cid}` : '';
    return this.http.get<BloqueHorario[]>(`${this.baseUrl}/api/v1/horarios/todos${qs}`);
  }

  programarSemanaCompleta(payload: {
    docenteId: number;
    curso: string;
    horaInicio: string;
    horaFin: string;
    distribucion: { dia: string; grado: string; seccion?: string; aula?: string }[];
  }): Observable<{ mensaje: string; bloques: BloqueHorario[] }> {
    return this.http.post<any>(`${this.baseUrl}/api/v1/horarios/programar-semana`, payload);
  }

  intercambiarBloquesHorario(bloqueIdA: number, bloqueIdB: number): Observable<{ mensaje: string; bloqueA: BloqueHorario; bloqueB: BloqueHorario }> {
    return this.http.post<any>(`${this.baseUrl}/api/v1/horarios/intercambiar-bloques`, { bloqueIdA, bloqueIdB });
  }

  autoAsignarPorAsistente(): Observable<{ mensaje: string; totalOptimizados: number; detalles: any[] }> {
    return this.http.post<any>(`${this.baseUrl}/api/v1/horarios/asistente-autoasignar`, {});
  }

  actualizarDisponibilidadDocente(docenteId: number, disponibilidad: any[]): Observable<{ mensaje: string; disponibilidad: any[] }> {
    return this.http.put<any>(`${this.baseUrl}/api/v1/docente/disponibilidad`, { docenteId, disponibilidad });
  }

  // Gestión de Secretaría por Admin
  crearSecretaria(payload: {
    nombreCompleto: string;
    dni?: string;
    username: string;
    password: string;
    turno?: string;
    area?: string;
    telefono?: string;
    email?: string;
  }): Observable<{ mensaje: string; personal: any; usuario: any }> {
    return this.http.post<any>(`${this.baseUrl}/api/v1/admin/crear-secretaria`, payload);
  }

  listarSecretarias(): Observable<any[]> {
    return this.http.get<any[]>(`${this.baseUrl}/api/v1/admin/secretarias`);
  }

  // Reinicio de Sistema & Auditoría
  resetearSistema(modo: 'limpio' | 'demo' | 'nuevo_colegio' = 'limpio'): Observable<{ success: boolean; mensaje: string; estado: any }> {
    return this.http.post<any>(`${this.baseUrl}/api/v1/sistema/reset`, { modo });
  }

  obtenerEstadoSistema(): Observable<any> {
    return this.http.get<any>(`${this.baseUrl}/api/v1/sistema/estado`);
  }

  // RENIEC por DNI (8 dígitos) conectado exclusivamente a padrón real (sin nombres aleatorios)
  consultarReniec(dni: string): Observable<any> {
    const cleanDni = (dni || '').trim();
    return this.http.get<any>(`${this.baseUrl}/api/v1/reniec/${cleanDni}`);
  }

  // Calendario Escolar y Duración del Año
  obtenerCalendarioAnual(): Observable<any> {
    return this.http.get<any>(`${this.baseUrl}/api/v1/saas/colegio/calendario-anual`).pipe(
      catchError(() =>
        of({
          fechaInicioAnual: '2026-02-15',
          fechaFinAnual: '2026-12-05',
          duracionMesesAnual: 10,
          semanasLectivasAnual: 42,
        })
      )
    );
  }

  actualizarCalendarioAnual(payload: { fechaInicioAnual: string; fechaFinAnual: string; duracionMesesAnual?: number }): Observable<any> {
    return this.http.put<any>(`${this.baseUrl}/api/v1/saas/colegio/calendario-anual`, payload).pipe(
      catchError(() =>
        of({
          mensaje: 'Duración del año académico actualizada exitosamente.',
          ...payload,
        })
      )
    );
  }

  // Alertas de Contratos y Bajas
  obtenerAlertasContratos(): Observable<any[]> {
    return this.http.get<any[]>(`${this.baseUrl}/api/v1/personal/alertas-contratos`).pipe(
      catchError(() => of([]))
    );
  }

  renovarContrato(id: number, payload: { mesesExtension?: number; nuevaFechaFin?: string; nuevoSueldo?: number }): Observable<any> {
    return this.http.put<any>(`${this.baseUrl}/api/v1/personal/${id}/renovar-contrato`, payload).pipe(
      catchError(() => of({ mensaje: 'Contrato renovado exitosamente.' }))
    );
  }

  darDeBajaPersonal(id: number): Observable<any> {
    return this.http.put<any>(`${this.baseUrl}/api/v1/personal/${id}/dar-de-baja`, {}).pipe(
      catchError(() => of({ mensaje: 'Personal dado de baja de la nómina activa.' }))
    );
  }

  darDeBajaAlumno(id: number, motivo?: string): Observable<any> {
    return this.http.put<any>(`${this.baseUrl}/api/v1/alumnos/${id}/dar-de-baja`, { motivo }).pipe(
      catchError(() => of({ mensaje: 'Estudiante dado de baja del padrón activo.' }))
    );
  }

  // Tareas Operativas para Personal de Apoyo
  obtenerTareasOperativas(): Observable<any[]> {
    return this.http.get<any[]>(`${this.baseUrl}/api/v1/tareas-operativas`).pipe(
      catchError(() => of([]))
    );
  }

  obtenerResumenFinanzas(colegioId?: number): Observable<FinanzasResumen> {
    return this.obtenerFinanzas(colegioId);
  }

  registrarDeudaAlumno(
    alumnoId: number,
    payload: { concepto: string; monto: number; fechaVencimiento: string; mes?: string; descripcion?: string }
  ): Observable<any> {
    return this.http.post<any>(`${this.baseUrl}/api/v1/matricula/alumnos/${alumnoId}/deuda`, payload);
  }

  generarDeudaMasiva(
    payload: { concepto: string; monto: number; mes: string; fechaVencimiento: string; grado?: string }
  ): Observable<any> {
    return this.http.post<any>(`${this.baseUrl}/api/v1/finanzas/deuda-masiva`, payload);
  }

  crearTareaOperativa(payload: any): Observable<any> {
    return this.http.post<any>(`${this.baseUrl}/api/v1/tareas-operativas`, payload).pipe(
      catchError(() => of({ mensaje: 'Tarea operativa registrada exitosamente.', tarea: { id: Date.now(), ...payload, estado: 'PENDIENTE', fechaAsignacion: new Date().toISOString().slice(0, 10) } }))
    );
  }

  actualizarEstadoTareaOperativa(id: number, estado: string): Observable<any> {
    return this.http.put<any>(`${this.baseUrl}/api/v1/tareas-operativas/${id}/estado`, { estado }).pipe(
      catchError(() => of({ mensaje: 'Estado actualizado.', id, estado }))
    );
  }

  // Ponderación de Notas por Curso
  private normCursoKey(s?: string): string {
    return (s || '').normalize('NFD').replace(/[\u0300-\u036f]/g, '').toLowerCase().trim();
  }

  private leerPonderacionesLocal(): Record<string, any> {
    try {
      const raw = localStorage.getItem('bomerp_ponderaciones_cursos');
      return raw ? JSON.parse(raw) : {};
    } catch {
      return {};
    }
  }

  private guardarPonderacionLocal(item: any): void {
    try {
      const map = this.leerPonderacionesLocal();
      const keyNom = this.normCursoKey(item.cursoNombre);
      if (keyNom) map[keyNom] = item;
      if (item.cursoId !== undefined) map[`id_${item.cursoId}`] = item;
      localStorage.setItem('bomerp_ponderaciones_cursos', JSON.stringify(map));
    } catch {}
  }

  obtenerTodasLasPonderaciones(): Observable<any[]> {
    return this.http.get<any[]>(`${this.baseUrl}/api/v1/docente/ponderaciones`).pipe(
      map((remotas) => {
        const locales = Object.values(this.leerPonderacionesLocal());
        const combinadas = [...(remotas || [])];
        for (const loc of locales) {
          const kLoc = this.normCursoKey(loc?.cursoNombre);
          const idx = combinadas.findIndex(
            (r) => (kLoc && this.normCursoKey(r?.cursoNombre) === kLoc) || (loc?.cursoId && Number(r?.cursoId) === Number(loc.cursoId))
          );
          if (idx >= 0) {
            combinadas[idx] = { ...loc, ...combinadas[idx], cursoNombre: combinadas[idx].cursoNombre || loc.cursoNombre };
          } else if (loc) {
            combinadas.push(loc);
          }
        }
        return combinadas;
      }),
      catchError(() => of(Object.values(this.leerPonderacionesLocal())))
    );
  }

  obtenerPonderacionCurso(cursoId: number, cursoNombre?: string): Observable<any> {
    const query = cursoNombre ? `?cursoNombre=${encodeURIComponent(cursoNombre)}` : '';
    const localMap = this.leerPonderacionesLocal();
    const localMatch = (cursoNombre && localMap[this.normCursoKey(cursoNombre)]) || localMap[`id_${cursoId}`];
    return this.http.get<any>(`${this.baseUrl}/api/v1/docente/ponderacion/${cursoId}${query}`).pipe(
      map((res) => {
        // Si el backend devolvió el default sin bloquear pero existe configuración guardada por nombre de curso, sincronizar
        if (localMatch && !res?.bloqueada && localMatch.bloqueada !== undefined) {
          return {
            ...res,
            ...localMatch,
            ponderacion: {
              asistencia: localMatch.asistenciaPorcentaje ?? 30,
              tareas: localMatch.tareasPorcentaje ?? 35,
              examenes: localMatch.examenesPorcentaje ?? 35,
            },
          };
        }
        if (res && (res.bloqueada || res.solicitudPendiente)) {
          this.guardarPonderacionLocal({ ...res, cursoId, cursoNombre: res.cursoNombre || cursoNombre });
        }
        return res;
      }),
      catchError(() =>
        of(
          localMatch || {
            cursoId,
            cursoNombre,
            asistenciaPorcentaje: 30,
            tareasPorcentaje: 35,
            examenesPorcentaje: 35,
            bloqueada: false,
            solicitudPendiente: false,
          }
        )
      )
    );
  }

  actualizarPonderacionCurso(
    cursoId: number,
    payload: { asistenciaPorcentaje: number; tareasPorcentaje: number; examenesPorcentaje: number; cursoNombre?: string; grado?: string }
  ): Observable<any> {
    const itemLocal = {
      cursoId,
      cursoNombre: payload.cursoNombre,
      grado: payload.grado,
      asistenciaPorcentaje: Number(payload.asistenciaPorcentaje),
      tareasPorcentaje: Number(payload.tareasPorcentaje),
      examenesPorcentaje: Number(payload.examenesPorcentaje),
      ponderacion: {
        asistencia: Number(payload.asistenciaPorcentaje),
        tareas: Number(payload.tareasPorcentaje),
        examenes: Number(payload.examenesPorcentaje),
      },
      bloqueada: true,
      solicitudPendiente: false,
    };
    this.guardarPonderacionLocal(itemLocal);
    return this.http.put<any>(`${this.baseUrl}/api/v1/docente/ponderacion/${cursoId}`, payload).pipe(
      map((res) => {
        this.guardarPonderacionLocal({ ...itemLocal, ...(res?.ponderacion || {}) });
        return res;
      }),
      catchError(() => of({ mensaje: 'Ponderación guardada.', ponderacion: itemLocal }))
    );
  }

  solicitarEdicionPonderacion(
    cursoId: number,
    payload: { motivo: string; cursoNombre?: string; grado?: string; docenteId?: number; docenteNombre?: string }
  ): Observable<any> {
    return this.http.post<any>(`${this.baseUrl}/api/v1/docente/ponderacion/${cursoId}/solicitar-edicion`, payload).pipe(
      map((res) => {
        const localMap = this.leerPonderacionesLocal();
        const k = this.normCursoKey(payload.cursoNombre);
        const ex = (k && localMap[k]) || localMap[`id_${cursoId}`] || {
          cursoId,
          cursoNombre: payload.cursoNombre,
          asistenciaPorcentaje: 30,
          tareasPorcentaje: 35,
          examenesPorcentaje: 35,
          bloqueada: true,
        };
        this.guardarPonderacionLocal({ ...ex, solicitudPendiente: true, motivoSolicitud: payload.motivo });
        return res;
      })
    );
  }

  listarSolicitudesPonderacion(): Observable<any[]> {
    return this.http.get<any[]>(`${this.baseUrl}/api/v1/docente/solicitudes-ponderacion`).pipe(
      catchError(() => of([]))
    );
  }

  resolverSolicitudPonderacion(id: number, estado: 'APROBADA' | 'RECHAZADA', solObj?: any): Observable<any> {
    return this.http.put<any>(`${this.baseUrl}/api/v1/docente/solicitudes-ponderacion/${id}/resolver`, { estado }).pipe(
      map((res) => {
        const sol = res?.solicitud || solObj;
        if (sol) {
          const localMap = this.leerPonderacionesLocal();
          const k = this.normCursoKey(sol.cursoNombre);
          const ex = (k && localMap[k]) || localMap[`id_${sol.cursoId}`];
          if (ex) {
            this.guardarPonderacionLocal({
              ...ex,
              solicitudPendiente: false,
              bloqueada: estado === 'APROBADA' ? false : ex.bloqueada,
            });
          }
        }
        return res;
      })
    );
  }

  editarDuracionBloque(
    id: number,
    payload: { horaInicio?: string; horaFin?: string; duracionMinutos?: number; duracionHoras?: number; [key: string]: any }
  ): Observable<any> {
    return this.http.put<any>(`${this.baseUrl}/api/v1/horarios/bloque/${id}/duracion`, payload);
  }

  obtenerActividadesSesiones(cursoNombre?: string, grado?: string): Observable<any[]> {
    const params: string[] = [];
    if (cursoNombre) params.push(`cursoNombre=${encodeURIComponent(cursoNombre)}`);
    if (grado) params.push(`grado=${encodeURIComponent(grado)}`);
    const qs = params.length > 0 ? `?${params.join('&')}` : '';
    return this.http.get<any[]>(`${this.baseUrl}/api/v1/docente/sesiones-actividad${qs}`).pipe(
      catchError(() => of([]))
    );
  }

  guardarActividadSesion(payload: {
    colegioId?: number;
    cursoId?: number;
    curso?: string;
    cursoNombre?: string;
    grado?: string;
    seccion?: string;
    numeroSesion?: number;
    actividadId?: string | number;
    tipoActividad?: 'NINGUNA' | 'TAREA' | 'EXAMEN' | string;
    actividadTitulo?: string;
    actividadDescripcion?: string;
    fechaLimiteEntrega?: string;
    [key: string]: any;
  }): Observable<any> {
    return this.http.post<any>(`${this.baseUrl}/api/v1/docente/sesiones-actividad`, payload);
  }

  eliminarActividadSesion(actividadId: string | number): Observable<any> {
    return this.http.delete<any>(`${this.baseUrl}/api/v1/docente/sesiones-actividad/${encodeURIComponent(String(actividadId))}`);
  }

  obtenerEntregasTareas(
    filtrosOrCurso?: { cursoNombre?: string; grado?: string; sesionId?: number; alumnoId?: number; actividadId?: string } | string,
    grado?: string,
    sesionId?: number,
    actividadId?: string
  ): Observable<any[]> {
    const params: string[] = [];
    if (typeof filtrosOrCurso === 'string') {
      if (filtrosOrCurso) params.push(`cursoNombre=${encodeURIComponent(filtrosOrCurso)}`);
      if (grado) params.push(`grado=${encodeURIComponent(grado)}`);
      if (sesionId !== undefined) params.push(`sesionId=${sesionId}`);
      if (actividadId) params.push(`actividadId=${encodeURIComponent(actividadId)}`);
    } else if (filtrosOrCurso) {
      if (filtrosOrCurso.cursoNombre) params.push(`cursoNombre=${encodeURIComponent(filtrosOrCurso.cursoNombre)}`);
      if (filtrosOrCurso.grado) params.push(`grado=${encodeURIComponent(filtrosOrCurso.grado)}`);
      if (filtrosOrCurso.sesionId !== undefined) params.push(`sesionId=${filtrosOrCurso.sesionId}`);
      if (filtrosOrCurso.alumnoId !== undefined) params.push(`alumnoId=${filtrosOrCurso.alumnoId}`);
      if (filtrosOrCurso.actividadId) params.push(`actividadId=${encodeURIComponent(filtrosOrCurso.actividadId)}`);
    }
    const qs = params.length > 0 ? `?${params.join('&')}` : '';
    return this.http.get<any[]>(`${this.baseUrl}/api/v1/docente/entregas${qs}`).pipe(
      catchError(() => of([]))
    );
  }

  calificarEntregaTarea(payload: {
    entregaId?: number;
    alumnoId: number;
    sesionId?: number;
    sesion?: number;
    cursoId?: number;
    curso?: string;
    cursoNombre?: string;
    calificacion?: number;
    nota?: number;
    comentarioDocente?: string;
    [key: string]: any;
  }): Observable<any> {
    return this.http.post<any>(`${this.baseUrl}/api/v1/docente/calificar-entrega`, payload);
  }

  // Entrega de Tareas por el Alumno
  entregarTareaAlumno(payload: {
    tareaId: number;
    sesionId?: number;
    cursoId?: number;
    cursoNombre?: string;
    grado?: string;
    alumnoId: number;
    alumnoNombre?: string;
    tipoActividad?: string;
    actividadId?: string | number;
    archivoNombre?: string;
    archivoUrl?: string;
    archivoTipo?: string;
    archivos?: { nombre: string; url: string; tipo: string }[];
    comentario?: string;
    comentarioAlumno?: string;
    [key: string]: any;
  }): Observable<any> {
    return this.http.post<any>(`${this.baseUrl}/api/v1/alumno/entregar-tarea`, payload).pipe(
      catchError(() => of({ mensaje: 'Evidencia entregada exitosamente.', entrega: payload }))
    );
  }

  cancelarEntregaTarea(entregaId: number): Observable<any> {
    return this.http.delete<any>(`${this.baseUrl}/api/v1/alumno/entregas/${entregaId}`);
  }
}

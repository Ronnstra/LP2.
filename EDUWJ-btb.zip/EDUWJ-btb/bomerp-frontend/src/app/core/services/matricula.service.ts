import { Injectable, inject } from '@angular/core';
import { HttpClient, HttpParams } from '@angular/common/http';
import { Observable } from 'rxjs';
import { environment } from '../../../environments/environment';
import { readStoredUser } from './auth-session';

export interface DetalleMatriculaItem {
  id: number;
  cursoId: number;
  nombreCurso: string;
  creditos: number;
}

export interface MatriculaItem {
  id: number;
  alumnoId: number;
  nombreAlumno: string;
  fecha: string;
  periodo: string;
  estado: 'REGISTRADA' | 'ANULADA';
  totalCreditos: number;
  detalles: DetalleMatriculaItem[];
}

export interface RegistrarMatriculaRequest {
  alumnoId: number;
  periodo: string;
  detalles: { cursoId: number }[];
}

export interface CursoAcademicoItem {
  id: number;
  nombre: string;
  grado: string;
  creditos: number;
  vacantesDisponibles: number;
  vacantesMaximas: number;
  aula: string;
}

@Injectable({ providedIn: 'root' })
export class MatriculaService {
  private http = inject(HttpClient);
  private readonly baseUrl = environment.apiBaseUrl;

  listar(filtros?: { estado?: string; periodo?: string }): Observable<MatriculaItem[]> {
    let params = new HttpParams();
    if (filtros?.estado) params = params.set('estado', filtros.estado);
    if (filtros?.periodo) params = params.set('periodo', filtros.periodo);
    return this.http.get<MatriculaItem[]>(`${this.baseUrl}/api/v1/matriculas`, { params });
  }

  obtenerPorId(id: number): Observable<MatriculaItem> {
    return this.http.get<MatriculaItem>(`${this.baseUrl}/api/v1/matriculas/${id}`);
  }

  registrar(payload: RegistrarMatriculaRequest): Observable<MatriculaItem> {
    return this.http.post<MatriculaItem>(`${this.baseUrl}/api/v1/matriculas`, payload);
  }

  anular(id: number): Observable<{ mensaje: string; matricula: MatriculaItem }> {
    return this.http.put<{ mensaje: string; matricula: MatriculaItem }>(`${this.baseUrl}/api/v1/matriculas/${id}/anular`, {});
  }

  obtenerResumen(): Observable<any> {
    return this.http.get<any>(`${this.baseUrl}/api/v1/matriculas/resumen`);
  }

  private getActiveColegioId(): number | undefined {
    const user = readStoredUser();
    if (user?.colegioId) return Number(user.colegioId);
    return undefined;
  }

  // Cursos académicos
  listarCursos(grado?: string): Observable<CursoAcademicoItem[]> {
    let params = new HttpParams();
    if (grado) params = params.set('grado', grado);
    const cid = this.getActiveColegioId();
    if (cid) params = params.set('colegioId', String(cid));
    return this.http.get<CursoAcademicoItem[]>(`${this.baseUrl}/api/v1/cursos`, { params });
  }

  crearCurso(curso: Partial<CursoAcademicoItem> & { colegioId?: number }): Observable<CursoAcademicoItem> {
    const cid = curso.colegioId ?? this.getActiveColegioId();
    return this.http.post<CursoAcademicoItem>(`${this.baseUrl}/api/v1/cursos`, cid ? { ...curso, colegioId: cid } : curso);
  }

  actualizarCurso(id: number, curso: Partial<CursoAcademicoItem> & { colegioId?: number }): Observable<CursoAcademicoItem> {
    const cid = curso.colegioId ?? this.getActiveColegioId();
    return this.http.put<CursoAcademicoItem>(`${this.baseUrl}/api/v1/cursos/${id}`, cid ? { ...curso, colegioId: cid } : curso);
  }

  eliminarCurso(id: number): Observable<void> {
    return this.http.delete<void>(`${this.baseUrl}/api/v1/cursos/${id}`);
  }

  // Resumen de Arquitectura del Sistema (3 Transaccionales M:N y 3 No Transaccionales)
  obtenerResumenArquitectura(): Observable<any> {
    return this.http.get<any>(`${this.baseUrl}/api/v1/modulos/resumen-arquitectura`);
  }
}

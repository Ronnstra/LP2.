import { Injectable } from '@angular/core';
import { initializeApp, getApps } from 'firebase/app';
import { getAuth, signInWithPopup, GoogleAuthProvider } from 'firebase/auth';

const firebaseConfig = {
  projectId: 'gen-lang-client-0626362007',
  appId: '1:474487380090:web:66162e9c83915831cbc3c3',
  apiKey: 'AIzaSyCYsGDXb_RCfepycgKnb0bUBeX8eXroP3g',
  authDomain: 'gen-lang-client-0626362007.firebaseapp.com',
  storageBucket: 'gen-lang-client-0626362007.firebasestorage.app',
  messagingSenderId: '474487380090',
  oAuthClientId: '474487380090-eqi6id2fq7kldh5c09ggqconri9k52qp.apps.googleusercontent.com',
};

@Injectable({
  providedIn: 'root',
})
export class GmailService {
  private app = getApps().length ? getApps()[0] : initializeApp(firebaseConfig);
  private auth = getAuth(this.app);
  private cachedAccessToken: string | null = null;

  async obtenerAccessTokenGmail(): Promise<string> {
    if (this.cachedAccessToken) {
      return this.cachedAccessToken;
    }

    const provider = new GoogleAuthProvider();
    provider.addScope('https://www.googleapis.com/auth/gmail.send');
    provider.setCustomParameters({
      login_hint: 'jimyamanqui@gmail.com',
    });

    const result = await signInWithPopup(this.auth, provider);
    const credential = GoogleAuthProvider.credentialFromResult(result);
    if (!credential?.accessToken) {
      throw new Error('No se pudo obtener el Token de Acceso de Google Gmail');
    }

    this.cachedAccessToken = credential.accessToken;
    return this.cachedAccessToken;
  }

  async enviarCorreoGmailDirecto(destinatario: string, asunto: string, cuerpoHtml: string, accessToken?: string): Promise<any> {
    const token = accessToken || (await this.obtenerAccessTokenGmail());

    const base64Subject = btoa(unescape(encodeURIComponent(asunto)));

    const mimeMessage = [
      `To: ${destinatario}`,
      `Subject: =?UTF-8?B?${base64Subject}?=`,
      'MIME-Version: 1.0',
      'Content-Type: text/html; charset=utf-8',
      '',
      cuerpoHtml,
    ].join('\r\n');

    const base64EncodedEmail = btoa(unescape(encodeURIComponent(mimeMessage)))
      .replace(/\+/g, '-')
      .replace(/\//g, '_')
      .replace(/=+$/, '');

    const response = await fetch('https://gmail.googleapis.com/gmail/v1/users/me/messages/send', {
      method: 'POST',
      headers: {
        Authorization: `Bearer ${token}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        raw: base64EncodedEmail,
      }),
    });

    if (!response.ok) {
      const errorData = await response.json();
      throw new Error(errorData.error?.message || 'Error al enviar correo vía Gmail API');
    }

    return await response.json();
  }
}

import { Component, inject, signal } from '@angular/core';
import { RouterOutlet, RouterLink, RouterLinkActive, Router, NavigationEnd } from '@angular/router';
import { CommonModule } from '@angular/common';
import { AuthService } from '../services';
import { filter } from 'rxjs/operators';

@Component({
  selector: 'app-layout',
  standalone: true,
  imports: [CommonModule, RouterOutlet, RouterLink, RouterLinkActive],
  templateUrl: './layout.html',
  styleUrl: './layout.css',
})
export class Layout {
  protected authService = inject(AuthService);
  private router = inject(Router);

  currentUser = this.authService.currentUser$;
  currentUserSignal = this.authService.getCurrentUser();
  currentUrl = '';

  // Estado de acordeones neomórficos para el Administrador (Director)
  seccionesAbiertas = signal<Record<string, boolean>>({
    plantel: true,
    personal: false,
    planificacion: false,
    finanzas: false,
    portal: false,
    supervision: false,
  });

  constructor() {
    this.currentUrl = this.router.url;
    this.autoExpandirSeccionActiva(this.currentUrl);

    this.router.events
      .pipe(filter((event): event is NavigationEnd => event instanceof NavigationEnd))
      .subscribe((event: NavigationEnd) => {
        this.currentUrl = event.urlAfterRedirects;
        this.autoExpandirSeccionActiva(this.currentUrl);
      });
  }

  toggleSeccion(clave: string): void {
    this.seccionesAbiertas.update((s) => ({
      ...s,
      [clave]: !s[clave],
    }));
  }

  isSeccionAbierta(clave: string): boolean {
    return !!this.seccionesAbiertas()[clave];
  }

  expandirTodas(): void {
    this.seccionesAbiertas.set({
      plantel: true,
      personal: true,
      planificacion: true,
      finanzas: true,
      portal: true,
      supervision: true,
    });
  }

  colapsarTodas(): void {
    this.seccionesAbiertas.set({
      plantel: false,
      personal: false,
      planificacion: false,
      finanzas: false,
      portal: false,
      supervision: false,
    });
  }

  private autoExpandirSeccionActiva(url: string): void {
    if (!this.isAdmin()) return;
    const lower = url.toLowerCase();

    if (lower.includes('estudiantes') || lower.includes('cursos') || lower.includes('alumno')) {
      this.abrirSeccion('plantel');
    } else if (lower.includes('docentes') || lower.includes('colaboradores') || lower.includes('cuentas') || lower.includes('personal')) {
      this.abrirSeccion('personal');
    } else if (lower.includes('horarios') || lower.includes('comunicados')) {
      this.abrirSeccion('planificacion');
    } else if (lower.includes('finanzas') || lower.includes('contratos') || lower.includes('aprobaciones') || lower.includes('suscripcion')) {
      this.abrirSeccion('finanzas');
    } else if (lower.includes('portal-secretaria') || lower.includes('portal-docente') || lower.includes('portal-alumno') || lower.includes('portal-colaborador')) {
      this.abrirSeccion('supervision');
    } else if (lower.includes('mi-portal') || lower.includes('mi-colegio')) {
      this.abrirSeccion('portal');
    }
  }

  private abrirSeccion(clave: string): void {
    this.seccionesAbiertas.update((s) => ({
      ...s,
      [clave]: true,
    }));
  }

  isAlumno(): boolean {
    return this.authService.isAlumno();
  }

  isProfesor(): boolean {
    return this.authService.isProfesor();
  }

  isAdmin(): boolean {
    return this.authService.isAdmin();
  }

  isDirector(): boolean {
    return this.authService.isDirector();
  }

  isSuperAdmin(): boolean {
    return this.authService.isSuperAdmin();
  }

  isSecretaria(): boolean {
    return this.authService.isSecretaria();
  }

  isColaborador(): boolean {
    return this.authService.isColaborador();
  }

  getHomeLink(): string {
    if (this.isSuperAdmin()) return '/saas-master';
    if (this.isDirector()) return '/admin/comunidad';
    if (this.isAlumno()) return '/portal-alumno';
    if (this.isProfesor()) return '/portal-docente';
    if (this.isSecretaria()) return '/portal-secretaria';
    if (this.isColaborador()) return '/portal-colaborador';
    return '/admin/comunidad';
  }

  irAPrincipal(): void {
    if (this.isSuperAdmin()) {
      this.router.navigate(['/saas-master']);
    } else if (this.isDirector()) {
      this.router.navigate(['/admin/comunidad'], { queryParams: { tab: 'mi-portal' } });
    } else {
      const home = this.getHomeLink();
      this.router.navigate([home], { queryParams: {} });
    }
  }

  navegarAHorario(): void {
    if (this.isAdmin()) {
      this.router.navigate(['/admin/comunidad'], { queryParams: { tab: 'horarios' } });
    } else if (this.isSecretaria()) {
      this.router.navigate(['/portal-secretaria'], { queryParams: { vista: 'horarios' } });
      setTimeout(() => {
        const el = document.getElementById('seccion-horarios') || document.querySelector('.horario-section');
        if (el) el.scrollIntoView({ behavior: 'smooth', block: 'start' });
      }, 150);
    } else if (this.isProfesor()) {
      this.router.navigate(['/portal-docente'], { queryParams: { vista: 'horarios' } });
      setTimeout(() => {
        const el = document.getElementById('seccion-horarios') || document.querySelector('.teacher-official-schedule-banner');
        if (el) el.scrollIntoView({ behavior: 'smooth', block: 'start' });
      }, 150);
    } else if (this.isAlumno()) {
      this.router.navigate(['/portal-alumno'], { queryParams: { tab: 'horario' } });
      setTimeout(() => {
        const el = document.getElementById('seccion-horarios') || document.querySelector('.horario-section');
        if (el) el.scrollIntoView({ behavior: 'smooth', block: 'start' });
      }, 150);
    }
  }

  esRutaPrincipal(): boolean {
    const home = this.getHomeLink();
    return this.currentUrl === home || this.currentUrl.startsWith(home + '?');
  }

  estaEnHorario(): boolean {
    return this.currentUrl.includes('tab=horarios') || this.currentUrl.includes('vista=horarios') || this.currentUrl.includes('tab=horario') || this.currentUrl.includes('tab=horarios-cargas');
  }

  estaEnTab(baseRoute: string, tabValue?: string): boolean {
    if (!tabValue) {
      return (this.currentUrl === baseRoute || this.currentUrl.startsWith(baseRoute + '?')) && !this.currentUrl.includes('tab=');
    }
    return this.currentUrl.startsWith(baseRoute) && (this.currentUrl.includes(`tab=${tabValue}`) || this.currentUrl.includes(`vista=${tabValue}`));
  }

  estaEnCualquierTab(): boolean {
    return this.currentUrl.includes('tab=') || this.currentUrl.includes('vista=');
  }

  getNombreRol(): string {
    if (this.isSuperAdmin()) return 'SUPER ADMIN (ADMIN)';
    if (this.isDirector()) return 'DIRECCIÓN GENERAL (DIRECTOR)';
    if (this.isSecretaria()) return 'SECRETARÍA ACADÉMICA';
    if (this.isProfesor()) return 'PLANA DOCENTE';
    if (this.isAlumno()) return 'ESTUDIANTE';
    if (this.isColaborador()) return 'PERSONAL DE APOYO';
    return 'PORTAL INSTITUCIONAL';
  }

  logout(): void {
    const targetUrl = this.authService.logout();
    this.router.navigateByUrl(targetUrl);
  }

  irALogin(): void {
    const targetUrl = this.authService.logout();
    this.router.navigateByUrl(targetUrl);
  }

  getUserDisplay(): string {
    const user = this.authService.getCurrentUser();
    if (!user) return '';
    if (user.nombreCompleto) {
      return `${user.nombreCompleto} · ${user.cargo || user.rol}`;
    }
    return `${user.username} (${user.rol})`;
  }
}
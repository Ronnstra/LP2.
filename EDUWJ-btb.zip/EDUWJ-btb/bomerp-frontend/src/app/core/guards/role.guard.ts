import { inject } from '@angular/core';
import { CanActivateFn, Router } from '@angular/router';
import { AuthService } from '../services';

/**
 * Guard that only allows ALUMNO users.
 */
export const alumnoGuard: CanActivateFn = () => {
  const authService = inject(AuthService);
  const router = inject(Router);

  if (!authService.isLoggedIn()) {
    router.navigate(['/adquirir']);
    return false;
  }

  if (!authService.isAlumno() && !authService.isAdmin()) {
    router.navigate([authService.getDefaultRoute()]);
    return false;
  }

  return true;
};

/**
 * Guard that only allows DOCENTE users (o ADMIN/DIRECTOR supervisor).
 */
export const docenteGuard: CanActivateFn = () => {
  const authService = inject(AuthService);
  const router = inject(Router);

  if (!authService.isLoggedIn()) {
    router.navigate(['/adquirir']);
    return false;
  }

  if (!authService.isProfesor() && !authService.isAdmin()) {
    router.navigate([authService.getDefaultRoute()]);
    return false;
  }

  return true;
};

/**
 * Guard that only allows ADMIN users (Administración escolar).
 */
export const adminGuard: CanActivateFn = () => {
  const authService = inject(AuthService);
  const router = inject(Router);

  if (!authService.isLoggedIn()) {
    router.navigate(['/adquirir']);
    return false;
  }

  if (!authService.isAdmin()) {
    router.navigate([authService.getDefaultRoute()]);
    return false;
  }

  return true;
};

export const directorGuard = adminGuard;

/**
 * Guard that only allows ADMIN (cuenta maestra única del SaaS).
 */
export const superAdminGuard: CanActivateFn = () => {
  const authService = inject(AuthService);
  const router = inject(Router);

  if (!authService.isLoggedIn()) {
    router.navigate(['/adquirir']);
    return false;
  }

  if (!authService.isSuperAdmin()) {
    router.navigate([authService.getDefaultRoute()]);
    return false;
  }

  return true;
};

/**
 * Guard that only allows SECRETARIA users (Secretaría Académica y Admisiones).
 */
export const secretariaGuard: CanActivateFn = () => {
  const authService = inject(AuthService);
  const router = inject(Router);

  if (!authService.isLoggedIn()) {
    router.navigate(['/adquirir']);
    return false;
  }

  if (!authService.isSecretaria() && !authService.isAdmin()) {
    router.navigate([authService.getDefaultRoute()]);
    return false;
  }

  return true;
};

/**
 * Guard that only allows COLABORADOR users (Personal de Apoyo, Cocina, Mantenimiento, etc.).
 */
export const colaboradorGuard: CanActivateFn = () => {
  const authService = inject(AuthService);
  const router = inject(Router);

  if (!authService.isLoggedIn()) {
    router.navigate(['/adquirir']);
    return false;
  }

  if (!authService.isColaborador() && !authService.isAdmin() && !authService.isSecretaria()) {
    router.navigate([authService.getDefaultRoute()]);
    return false;
  }

  return true;
};

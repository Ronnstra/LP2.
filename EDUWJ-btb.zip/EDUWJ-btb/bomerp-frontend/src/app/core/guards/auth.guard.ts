import { inject } from '@angular/core';
import { CanActivateFn, Router } from '@angular/router';
import { AuthService } from '../services';

export const authGuard: CanActivateFn = () => {
  const authService = inject(AuthService);
  const router = inject(Router);

  if (authService.isLoggedIn()) {
    return true;
  }

  const origin = authService.getLoginOrigin();
  if (origin) {
    router.navigateByUrl(origin);
    return false;
  }

  const lastSlug = typeof localStorage !== 'undefined' ? localStorage.getItem('lastVisitedColegioSlug') : null;
  if (lastSlug) {
    router.navigate(['/colegio', lastSlug]);
  } else {
    router.navigate(['/adquirir']);
  }
  return false;
};
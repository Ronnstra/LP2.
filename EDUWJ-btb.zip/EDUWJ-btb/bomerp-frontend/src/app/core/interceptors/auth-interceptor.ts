import { inject } from '@angular/core';
import { HttpErrorResponse, HttpInterceptorFn } from '@angular/common/http';
import { catchError, throwError } from 'rxjs';
import { AuthService as KeycloakAuthService } from '../auth/auth-service';
import { readStoredUser } from '../services/auth-session';

export const authInterceptor: HttpInterceptorFn = (req, next) => {
  let token: string | null = null;
  let colegioId: string | null = null;

  // 1. Obtener token y colegioId del usuario autenticado en esta pestaña
  const u = readStoredUser();
  if (u) {
    token = u?.token || (u as any)?.accessToken || null;
    if (u?.colegioId) {
      colegioId = String(u.colegioId);
    }
  }

  // 2. Si no hay token escolar local, intentar desde Keycloak OIDC si está activo
  if (!token) {
    try {
      const keycloakAuth = inject(KeycloakAuthService);
      token = keycloakAuth.accessToken();
    } catch {}
  }

  // 3. Clonar petición con headers de autorización y contexto escolar
  const headers: Record<string, string> = {};
  if (token) {
    headers['Authorization'] = `Bearer ${token}`;
  }
  if (colegioId) {
    headers['X-Colegio-Id'] = colegioId;
  }

  const reqWithHeaders = Object.keys(headers).length > 0 ? req.clone({ setHeaders: headers }) : req;

  return next(reqWithHeaders).pipe(
    catchError((error: HttpErrorResponse) => {
      // En caso de 401 evitar bucles infinitos de redirección hacia puertos inexistentes
      return throwError(() => error);
    }),
  );
};


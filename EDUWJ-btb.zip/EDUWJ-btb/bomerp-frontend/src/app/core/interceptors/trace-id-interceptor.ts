import { HttpInterceptorFn } from '@angular/common/http';
import { inject } from '@angular/core';
import { AuthService } from '../services';

export const traceIdInterceptor: HttpInterceptorFn = (req, next) => {
  const traceId = crypto.randomUUID();
  const authService = inject(AuthService);
  const token = authService.getToken();

  let headers = req.headers.set('X-Trace-ID', traceId);

  // No enviar tokens previos en la solicitud de login para evitar 401 en backends estrictos
  const esRutaLogin = req.url.includes('/auth/login') || req.url.includes('/saas/auth/');
  if (token && !esRutaLogin) {
    headers = headers.set('Authorization', `Bearer ${token}`);
  }

  return next(req.clone({ headers }));
};
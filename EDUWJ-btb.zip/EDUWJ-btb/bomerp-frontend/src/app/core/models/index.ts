export * from './alumno.model';
export * from './nota.model';
export * from './auth.model';
export * from './personal.model';
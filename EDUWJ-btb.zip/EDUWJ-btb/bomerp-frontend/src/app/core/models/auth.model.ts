export interface AuthRequest {
  username: string;
  password: string;
  slugColegio?: string;
}

export interface AuthResponse {
  id: number;
  username: string;
  rol: string;
  token: string;
  mensaje: string;
  nombreCompleto?: string;
  cargo?: string;
  email?: string;
  colegioId?: number;
  nombreColegio?: string;
  slugColegio?: string;
  urlColegio?: string;
}

export type UserRole = 'ADMIN' | 'DIRECTOR' | 'SECRETARIA' | 'DOCENTE' | 'ALUMNO' | 'COLABORADOR' | 'VENDEDOR' | 'SUPERVISOR';

export interface UsuarioEscolar {
  id: number;
  username: string;
  rol: UserRole;
  estado: 'ACTIVO' | 'INACTIVO' | 'PAUSADA' | 'ACTIVO_PROVISIONAL';
  estadoAprobacion: 'CONFIRMADO' | 'PENDIENTE' | 'RECHAZADO';
  nombreCompleto: string;
  cargo: string;
  email: string;
  telefono?: string;
  dni?: string;
  turno?: 'MAÑANA' | 'TARDE' | 'COMPLETO';
  fechaRegistro?: string;
  colegioId?: number;
  nombreColegio?: string;
  passwordHint?: string;
  passwordHash?: string;
}
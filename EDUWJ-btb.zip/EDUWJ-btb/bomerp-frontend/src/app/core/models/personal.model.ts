export type CargoPersonal = 'DOCENTE' | 'SECRETARIA' | 'LIMPIEZA' | 'COMEDOR' | 'MANTENIMIENTO' | 'SEGURIDAD';
export type TurnoPersonal = 'MAÑANA' | 'TARDE' | 'COMPLETO';
export type EstadoAprobacion = 'PENDIENTE' | 'CONFIRMADO' | 'RECHAZADO';
export type EstadoCuenta = 'PAUSADA' | 'ACTIVA';

export interface FranjaDisponibilidad {
  dia: 'Lunes' | 'Martes' | 'Miércoles' | 'Jueves' | 'Viernes';
  horaInicio: string;
  horaFin: string;
  horas: number;
}

export interface BloqueHorario {
  id: number;
  grado: string;
  seccion: string;
  dia: 'Lunes' | 'Martes' | 'Miércoles' | 'Jueves' | 'Viernes' | 'Sábado' | 'Domingo';
  horaInicio: string;
  horaFin: string;
  duracionHoras: number;
  duracionMinutos: number;
  curso: string;
  docenteId: number;
  docenteNombre: string;
  aula: string;
  esDescanso?: boolean;
  confirmado?: boolean;
  fechaConfirmacion?: string;
  confirmadoPor?: string;
}

export interface JustificacionInasistencia {
  id: number;
  alumnoId: number;
  alumnoNombre: string;
  grado: string;
  seccion: string;
  curso: string;
  docenteId: number;
  docenteNombre: string;
  fechaInasistencia: string;
  horaClase?: string;
  sesion?: number;
  motivo: string;
  descripcion: string;
  comprobanteUrl?: string;
  comprobanteNombre?: string;
  estado: 'PENDIENTE' | 'APROBADA' | 'RECHAZADA';
  fechaEnvio: string;
  respuestaDocente?: string;
  fechaRespuesta?: string;
}

export interface ContratoDocente {
  id: number;
  docenteId: number;
  docenteNombre: string;
  dni: string;
  tarifaPorHora: number;
  horasSemanales: number;
  horasMensualesEstimadas: number;
  pagoMensualEstimado: number;
  fechaInicio: string;
  fechaFin: string;
  estado: 'VIGENTE' | 'FINALIZADO' | 'EN_REVISION';
  cursosAsignados: string[];
  gradosAsignados: string[];
  observaciones?: string;
}

export interface ContratosDocentesResumen {
  totalContratosVigentes: number;
  totalHorasSemanales: number;
  totalHorasMensuales: number;
  totalPlanillaMensual: number;
  tarifaPromedioHora: number;
  contratos: ContratoDocente[];
}

export interface PersonalEscolar {
  id: number;
  nombre: string;
  apellidos: string;
  dni: string;
  cargo: CargoPersonal;
  area: string;
  telefono: string;
  turno: TurnoPersonal;
  fechaRegistro: string;
  registradoPor: string;
  estadoAprobacion: EstadoAprobacion;
  estadoCuenta: EstadoCuenta;
  username?: string;
  diasPendiente: number;
  observaciones?: string;
  disponibilidad?: FranjaDisponibilidad[];
  cursosEspecialidad?: string[];
  tarifaHora?: number;
  horasSemanales?: number;
  totalSesiones?: number;
  pagoSemanal?: number;
  pagoMensual?: number;
  sueldoMensual?: number;
  colegioId?: number;
}

export interface PersonalRequest {
  nombre: string;
  apellidos: string;
  dni: string;
  cargo: CargoPersonal;
  area?: string;
  telefono: string;
  turno: TurnoPersonal;
  registradoPor?: string;
  disponibilidad?: FranjaDisponibilidad[];
  cursosEspecialidad?: string[];
  tarifaHora?: number;
  colegioId?: number;
  sueldoMensual?: number;
  modalidadContrato?: 'ANO_ESCOLAR' | 'N_MESES' | 'TODO_EL_ANIO';
  contratoMeses?: number;
  fechaFinContrato?: string;
}

export interface TareaOperativa {
  id: number;
  titulo: string;
  descripcion?: string;
  equipo?: string;
  ubicacion?: string;
  asignadoA?: string;
  asignadoAId?: number;
  asignadoANombre?: string;
  prioridad: 'ALTA' | 'NORMAL' | 'MEDIA' | 'BAJA';
  estado: 'PENDIENTE' | 'EN_PROCESO' | 'COMPLETADA';
  fechaAsignacion: string;
  fechaVencimiento?: string;
  fechaLimite?: string;
}

export interface FinanzasAlumnoDeudor {
  id: number;
  nombreCompleto: string;
  dni: string;
  grado: string;
  seccion?: string;
  modalidadPago: string;
  totalContratado: number;
  totalPagado: number;
  deudaPendiente: number;
  cuotasPagadas?: number;
  cuotasPendientes: number;
  proximoVencimiento: string;
  mesActualPagado?: boolean;
}

export interface FinanzasDocenteDetalle {
  periodicidad: 'QUINCENAL' | 'MENSUAL';
  sueldoBase: number;
  horasExtra: number;
  tarifaHoraExtra: number;
  montoHorasExtra: number;
  comisiones: number;
  descuentos: number;
  totalGenerado: number;
}

export interface FinanzasResumen {
  ingresos: {
    total: number;
    matriculas: number;
    pensiones: number;
    alumnosPagantes: number;
    tasaCobranza: string;
    totalDeudaPorCobrar?: number;
    totalPensionesRecaudadas?: number;
  };
  egresos: {
    total: number;
    planillaDocentes: number;
    totalDocentes: number;
    totalHorasDocentesSemanales?: number;
    planillaColaboradores: number;
    totalColaboradores: number;
    serviciosYOperaciones: number;
  };
  balanceNeto: number;
  periodo: string;
  alumnosDeudores?: FinanzasAlumnoDeudor[];
  docentesNominaDetalle?: FinanzasDocenteDetalle;
  contratosDocentesResumen?: ContratosDocentesResumen;
  nominaDesglosada?: {
    secretarias: { id: number; nombre: string; dni: string; cargo: string; sueldoMensual: number; turno?: string; estado?: string }[];
    docentes: { id: number; nombre: string; dni: string; cargo: string; especialidad?: string; horasSemanales?: number; sueldoMensual: number; estado?: string; fechaFinContrato?: string }[];
    personalApoyo: { id: number; nombre: string; dni: string; cargo: string; area?: string; sueldoMensual: number; turno?: string; estado?: string }[];
  };
  ingresosAcademicos?: {
    anioCreacion: number;
    aniosDisponibles: number[];
    nombreMesActual: string;
    grados: {
      grado: string;
      totalAlumnos: number;
      totalContratado: number;
      totalPagado: number;
      totalDeuda: number;
      alumnos: any[];
    }[];
  };
}

export interface AlumnoDocenteNota {
  id: number;
  nombreCompleto: string;
  dni: string;
  practica: number;
  examen: number;
  finalExam: number;
  promedio: number;
  estadoActa: string;
  asistencia?: 'PRESENTE' | 'FALTA' | 'TARDANZA' | 'JUSTIFICADA';
  asistenciaPorSesion?: { [sesionNum: number]: 'PRESENTE' | 'FALTA' | 'TARDANZA' | 'JUSTIFICADA' | 'PENDIENTE' };
}

export interface DocenteCurso {
  id: number;
  codigo: string;
  nombre: string;
  grado: string;
  seccion: string;
  horario: string;
  aula: string;
  actaCerrada: boolean;
  alumnos: AlumnoDocenteNota[];
  solicitudesJustificacion?: any[];
  turnosPorSemana?: number;
  duracionMesesAnual?: number;
  totalSesiones?: number;
}

export interface NominaDocente {
  periodicidad: 'QUINCENAL' | 'MENSUAL';
  sueldoBase: number;
  horasExtra: number;
  tarifaHoraExtra: number;
  comisiones: number;
  descuentos: number;
  totalGenerado: number;
  historialPagos: { periodo: string; fecha: string; monto: number; estado: string }[];
}

export interface ConfiguracionJornada {
  horaInicio: string; // '09:00'
  horaFin: string; // '16:00'
  duracionModuloMinutos: number; // 120 (2 horas)
  recesoHabilitado: boolean;
  recesoInicio: string; // '11:00'
  recesoFin: string; // '11:45'
  recesoDuracionMinutos: number; // 45 (30 a 60 min)
  diasLectivos: string[];
}

export interface BloqueHorarioRequest {
  id?: number;
  grado: string;
  seccion?: string;
  dia: string;
  horaInicio: string;
  horaFin: string;
  curso: string;
  docenteId: number;
  aula?: string;
  confirmado?: boolean;
}

export interface DocenteDisponibilidadRespuesta {
  docenteId: number;
  nombreCompleto: string;
  dni: string;
  disponible: boolean;
  motivoConflicto?: string;
  gradoOcupado?: string;
  cursoOcupado?: string;
  cursosEspecialidad?: string[];
  tarifaHora?: number;
}

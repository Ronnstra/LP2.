export interface CuotaPago {
  numero: number;
  concepto: string;
  monto: number;
  fechaVencimiento: string;
  estado: 'PAGADO' | 'PENDIENTE' | 'VENCIDO';
  fechaPago?: string;
  numeroOperacion?: string;
  mes?: string;
  mesCorrespondiente?: string;
}

export interface PlanFinancieroAlumno {
  costoMensual: number;
  mesesPeriodo: number;
  modalidadPago: 'CONTADO' | 'MENSUAL' | 'BIMESTRAL';
  descuento: number;
  totalContratado: number;
  totalPagado: number;
  deudaPendiente: number;
  cuotas: CuotaPago[];
  cuotasPagadas?: number;
  mesActualPagado?: boolean;
  cuotaMesActualNumero?: number;
}

export interface AlumnoRequest {
  nombre: string;
  apellidoPaterno: string;
  apellidoMaterno?: string;
  dni: string;
  fechaIngreso: string;
  grado: string;
  seccion?: string;
  costoMensual?: number;
  mesesPeriodo?: number;
  modalidadPago?: 'CONTADO' | 'MENSUAL' | 'BIMESTRAL';
  colegioId?: number;
}

export interface AlumnoResponse {
  id: number;
  nombre: string;
  apellidoPaterno: string;
  apellidoMaterno?: string;
  dni: string;
  fechaIngreso: string;
  grado: string;
  seccion?: string;
  colegioId?: number;
  estadoAprobacion?: 'CONFIRMADO' | 'PENDIENTE';
  diasDesdeRegistro?: number;
  costoMensual?: number;
  mesesPeriodo?: number;
  modalidadPago?: 'CONTADO' | 'MENSUAL' | 'BIMESTRAL';
  descuento?: number;
  planFinanciero?: PlanFinancieroAlumno;
  username?: string;
  passwordProvisional?: string;
  estadoCuenta?: 'PAUSADA' | 'ACTIVO_PROVISIONAL' | 'ACTIVA';
}

export interface AlumnoFormData extends AlumnoRequest {}

export interface CursoAlumno {
  id: number;
  codigo: string;
  nombre: string;
  docente: string;
  horasSemanales: number;
  horario: string;
  aula: string;
  confirmado?: boolean;
  fechaConfirmacion?: string;
  confirmadoPor?: string;
}

export interface AsistenciaAlumno {
  porcentaje: string;
  asistencias: number;
  faltas: number;
  tardanzas: number;
  totalSesiones: number;
  porcentajeAsistencia?: number;
  presente?: number;
  falta?: number;
  tardanza?: number;
}

export interface HorarioDia {
  dia: string;
  esFinDeSemana: boolean;
  mensaje: string;
  bloques: import('./personal.model').BloqueHorario[];
}

export interface PortalAlumnoData {
  alumno: AlumnoResponse;
  notas: import('./nota.model').NotaResponse[];
  promedioPonderado: number;
  totalEvaluaciones: number;
  asistencia: AsistenciaAlumno;
  cursos: CursoAlumno[];
  horarioSemanal?: HorarioDia[];
  justificaciones?: import('./personal.model').JustificacionInasistencia[];
  planFinanciero: PlanFinancieroAlumno;
  estadoMatricula: string;
  periodoAcademico: string;
}
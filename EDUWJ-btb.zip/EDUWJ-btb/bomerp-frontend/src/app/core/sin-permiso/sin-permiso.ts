import { Component } from '@angular/core';
import { RouterLink } from '@angular/router';

@Component({
  selector: 'app-sin-permiso',
  standalone: true,
  imports: [RouterLink],
  template: `
    <div style="padding: 2.5rem; text-align: center; font-family: sans-serif;">
      <h2 style="color: #e11d48; margin-bottom: 1rem;">Acceso Denegado (403)</h2>
      <p style="color: #4b5563; margin-bottom: 1.5rem;">No tienes permiso para acceder a esa pantalla con tu rol actual.</p>
      <a routerLink="/" style="display: inline-block; padding: 0.6rem 1.2rem; background: #2563eb; color: white; border-radius: 0.5rem; text-decoration: none; font-weight: bold;">Volver al inicio</a>
    </div>
  `,
})
export class SinPermiso {}

import { Routes } from '@angular/router';
import { Layout } from './core/layout/layout';
import { authGuard } from './core/guards/auth.guard';
import {
  adminGuard,
  alumnoGuard,
  colaboradorGuard,
  docenteGuard,
  secretariaGuard,
  superAdminGuard,
} from './core/guards/role.guard';

export const routes: Routes = [
  { path: '', redirectTo: 'adquirir', pathMatch: 'full' },
  {
    path: 'adquirir',
    loadComponent: () =>
      import('./features/saas/adquirir/adquirir').then((m) => m.AdquirirSistemaComponent),
  },
  {
    path: 'colegio/:slug',
    loadComponent: () =>
      import('./features/saas/adquirir/adquirir').then((m) => m.AdquirirSistemaComponent),
  },
  {
    path: 'login',
    loadComponent: () => import('./features/auth/login/login').then((m) => m.Login),
  },
  {
    path: 'admin-guard',
    loadComponent: () =>
      import('./features/saas/admin-guard/admin-guard').then((m) => m.AdminGuardComponent),
  },
  {
    path: 'saas-master',
    loadComponent: () =>
      import('./features/saas/admin-maestro/admin-maestro').then(
        (m) => m.AdminMaestroDashboardComponent
      ),
    canActivate: [authGuard, superAdminGuard],
  },
  {
    path: '',
    component: Layout,
    canActivate: [authGuard],
    children: [
      {
        path: 'admin/comunidad',
        loadComponent: () =>
          import('./features/admin/comunidad/comunidad').then((m) => m.AdminComunidadComponent),
        canActivate: [adminGuard],
      },
      {
        path: 'admin/aprobaciones',
        loadComponent: () =>
          import('./features/admin/aprobaciones/aprobaciones').then(
            (m) => m.AdminAprobacionesComponent
          ),
        canActivate: [adminGuard],
      },
      {
        path: 'admin/finanzas',
        loadComponent: () =>
          import('./features/admin/finanzas/finanzas').then((m) => m.AdminFinanzasComponent),
        canActivate: [adminGuard],
      },
      {
        path: 'portal-secretaria',
        loadComponent: () =>
          import('./features/secretaria/portal-secretaria/portal-secretaria').then(
            (m) => m.PortalSecretariaComponent
          ),
        canActivate: [secretariaGuard],
      },
      {
        path: 'portal-docente',
        loadComponent: () =>
          import('./features/docente/portal-docente/portal-docente').then(
            (m) => m.PortalDocenteComponent
          ),
        canActivate: [docenteGuard],
      },
      {
        path: 'portal-alumno',
        loadComponent: () =>
          import('./features/alumno/portal-alumno/portal-alumno').then(
            (m) => m.PortalAlumnoComponent
          ),
        canActivate: [alumnoGuard],
      },
      {
        path: 'portal-colaborador',
        loadComponent: () =>
          import('./features/colaborador/portal-colaborador/portal-colaborador').then(
            (m) => m.PortalColaboradorComponent
          ),
        canActivate: [colaboradorGuard],
      },
      {
        path: 'modulos',
        loadComponent: () =>
          import('./features/modulos/centro-modulos').then((m) => m.CentroModulosComponent),
      },
      {
        path: 'alumnos',
        loadComponent: () =>
          import('./features/matricula/alumnos/alumno-list').then((m) => m.AlumnoListComponent),
      },
      {
        path: 'notas',
        loadComponent: () =>
          import('./features/calificaciones/notas/nota-list').then((m) => m.NotaListComponent),
      },
      {
        path: 'reportes',
        loadComponent: () =>
          import('./features/finanzas/contrato/contrato-reporte').then(
            (m) => m.ReporteFinancieroMatriculaComponent
          ),
      },
      {
        path: 'finanzas/contratos/nuevo',
        loadComponent: () =>
          import('./features/finanzas/contrato/contrato-form').then(
            (m) => m.ContratoMatriculaForm
          ),
      },
      {
        path: 'finanzas/reportes/matriculas',
        loadComponent: () =>
          import('./features/finanzas/contrato/contrato-reporte').then(
            (m) => m.ReporteFinancieroMatriculaComponent
          ),
      },
    ],
  },
  { path: '**', redirectTo: 'adquirir' },
];
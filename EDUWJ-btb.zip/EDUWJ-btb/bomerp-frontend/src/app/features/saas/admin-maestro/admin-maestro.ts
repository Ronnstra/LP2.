import { Component, OnInit, OnDestroy, signal, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { Router, RouterModule } from '@angular/router';
import { DomSanitizer, SafeResourceUrl } from '@angular/platform-browser';
import { AuthService } from '../../../core/services';
import { GmailService } from '../../../core/services/gmail.service';

@Component({
  selector: 'app-admin-maestro-dashboard',
  standalone: true,
  imports: [CommonModule, FormsModule, RouterModule],
  templateUrl: './admin-maestro.html',
  styleUrl: './admin-maestro.css',
})
export class AdminMaestroDashboardComponent implements OnInit, OnDestroy {
  private authService = inject(AuthService);
  private gmailService = inject(GmailService);
  private router = inject(Router);
  private sanitizer = inject(DomSanitizer);

  tabActiva = signal<'RESUMEN' | 'COLEGIOS' | 'SWAGGER' | 'TOKENS' | 'GUARD' | 'KEYCLOAK'>('RESUMEN');

  // Keycloak OIDC Console
  keycloakUrl = signal<string>('http://localhost:38080');
  keycloakCopied = signal<string | null>(null);
  keycloakIframeUrl: SafeResourceUrl;

  metricas = signal<any | null>(null);
  colegios = signal<any[]>([]);
  loading = signal(false);
  ultimoEventoRealtime = signal<string | null>(null);
  private disconnectRealtime: (() => void) | null = null;

  // Generador de Tokens
  tokenGenerado = signal<string>('');
  rolSeleccionado = signal<string>('ADMIN');
  subPersonalizado = signal<string>('00000000-0000-0000-0000-000000000001');
  usuarioSimulado = signal<string>('jimyamanqui@gmail.com');
  copiado = signal(false);

  // Steam Guard / REZE Móvil Estado & QR Funcional
  guardStatus = signal<any | null>(null);
  pairingToken = signal<string | null>(null);
  pairingUrl = signal<string>('');
  qrDataUrl = signal<string>('');
  guardLoading = signal(false);
  guardMessage = signal<string | null>(null);
  guardError = signal<string | null>(null);
  pairingCopied = signal(false);

  // Envío de correo de descarga de REZE
  enviandoCorreo = signal(false);
  correoResultado = signal<any | null>(null);
  mostrarModalCorreo = signal(false);

  // Swagger Iframe
  swaggerUrl: SafeResourceUrl;

  constructor() {
    this.swaggerUrl = this.sanitizer.bypassSecurityTrustResourceUrl('/swagger-ui.html');
    this.keycloakIframeUrl = this.sanitizer.bypassSecurityTrustResourceUrl('http://localhost:38080');
  }

  ngOnInit(): void {
    this.cargarDatos();
    this.cargarEstadoGuard();
    this.generarNuevoQrVinculacion(true);
    this.generarTokenPrueba();

    // Sincronización en tiempo real con la app móvil REZE
    this.disconnectRealtime = this.authService.conectarStreamTiempoReal((payload) => {
      if (payload.metricas) {
        this.metricas.set(payload.metricas);
      } else if (payload.resumenSistema?.finanzas) {
        const f = payload.resumenSistema.finanzas;
        this.metricas.set({
          totalColegios: f.totalColegios,
          colegiosActivos: f.colegiosActivos,
          ingresosMensualesRecurrentes: f.mrr,
          ingresosHistoricosTotales: f.totalHistorico,
          proyeccionAnual: f.arr,
          planBase: f.planBase || 1000,
          descuentoMensual: f.descuentoMensual || 70,
          pisoMinimo: f.pisoMinimo || 700,
        });
      }
      if (payload.colegios) {
        this.colegios.set(payload.colegios);
      } else if (payload.resumenSistema?.finanzas?.colegios) {
        this.colegios.set(payload.resumenSistema.finanzas.colegios);
      }
      if (payload.guardStatus) {
        this.guardStatus.set(payload.guardStatus);
      }
      if (payload.message && payload.type !== 'INIT_SYNC') {
        this.ultimoEventoRealtime.set(payload.message);
      }
    });
  }

  ngOnDestroy(): void {
    if (this.disconnectRealtime) {
      this.disconnectRealtime();
    }
  }

  cargarEstadoGuard(): void {
    this.authService.getSteamGuardStatus().subscribe({
      next: (s) => this.guardStatus.set(s),
    });
  }

  generarNuevoQrVinculacion(silencioso = false): void {
    this.guardLoading.set(true);
    if (!silencioso) {
      this.guardMessage.set(null);
      this.guardError.set(null);
    }

    this.authService.generarTokenVinculacion().subscribe({
      next: (res) => {
        this.guardLoading.set(false);
        this.pairingToken.set(res.token);
        const fullUrl = res.fullPairingUrl || window.location.origin + res.pairingUrl;
        this.pairingUrl.set(fullUrl);
        if (res.qrDataUrl) {
          this.qrDataUrl.set(res.qrDataUrl);
        }
        if (!silencioso) {
          this.guardMessage.set('Código QR funcional de descarga e instalación REZE actualizado. Escanéalo con la cámara de tu teléfono.');
        }
      },
      error: (err) => {
        this.guardLoading.set(false);
        if (!silencioso) {
          this.guardError.set(err.error?.mensaje || 'Error al generar código QR de descarga.');
        }
      },
    });
  }

  descargarQrImagen(): void {
    const dataUrl = this.qrDataUrl();
    if (!dataUrl) return;
    const link = document.createElement('a');
    link.href = dataUrl;
    link.download = 'REZE-App-Instalador-QR.png';
    link.click();
  }

  revocarDispositivo(): void {
    if (!confirm('¿Estás seguro de revocar el dispositivo móvil maestro actual? El teléfono anterior dejará de tener acceso inmediatamente.')) {
      return;
    }

    this.guardLoading.set(true);
    this.guardMessage.set(null);
    this.guardError.set(null);

    this.authService.revocarGuardDevice().subscribe({
      next: (res) => {
        this.guardLoading.set(false);
        this.guardMessage.set(res.mensaje || 'Dispositivo revocado. Escanea el nuevo QR para vincular tu móvil.');
        this.cargarEstadoGuard();
        this.generarNuevoQrVinculacion(true);
      },
      error: (err) => {
        this.guardLoading.set(false);
        this.guardError.set(err.error?.mensaje || 'Error al revocar dispositivo.');
      },
    });
  }

  copiarEnlaceVinculacion(): void {
    if (!this.pairingUrl()) return;
    navigator.clipboard.writeText(this.pairingUrl());
    this.pairingCopied.set(true);
    setTimeout(() => this.pairingCopied.set(false), 2000);
  }

  enviarCorreoInstalacion(): void {
    this.enviandoCorreo.set(true);
    this.guardMessage.set(null);
    this.guardError.set(null);

    this.authService.enviarCorreoInstalacionPami('jimyamanqui@gmail.com').subscribe({
      next: async (res) => {
        this.correoResultado.set(res.correo || res);
        this.mostrarModalCorreo.set(true);
        if (res.enlaceInstalacion) {
          this.pairingUrl.set(res.enlaceInstalacion);
          this.pairingToken.set(res.pairingToken);
        }

        // Intentar envío real directo vía Google Gmail API si el usuario lo solicita
        try {
          const mailObj = res.correo || res;
          await this.gmailService.enviarCorreoGmailDirecto(
            'jimyamanqui@gmail.com',
            mailObj.asunto || '📱 Descarga tu App PAMI - Autenticador Móvil Maestro (jimyamanqui@gmail.com)',
            mailObj.contenidoHtml || `<p>Instala PAMI desde: <a href="${res.enlaceInstalacion}">${res.enlaceInstalacion}</a></p>`
          );
          this.guardMessage.set('¡Correo enviado REALMENTE vía Gmail API a jimyamanqui@gmail.com con éxito!');
        } catch (e: any) {
          console.log('Gmail direct send optional fallback:', e);
          this.guardMessage.set('¡Correo generado! (Si deseas el envío por tu Gmail, presiona "Enviar vía Gmail API").');
        } finally {
          this.enviandoCorreo.set(false);
        }
      },
      error: (err) => {
        this.enviandoCorreo.set(false);
        this.guardError.set(err.error?.mensaje || 'Error al enviar el correo con la app PAMI.');
      },
    });
  }

  async enviarCorreoGmailDirectoExplicit(): Promise<void> {
    this.enviandoCorreo.set(true);
    this.guardMessage.set(null);
    this.guardError.set(null);

    try {
      this.authService.enviarCorreoInstalacionPami('jimyamanqui@gmail.com').subscribe({
        next: async (res) => {
          const mailObj = res.correo || res;
          try {
            await this.gmailService.enviarCorreoGmailDirecto(
              'jimyamanqui@gmail.com',
              mailObj.asunto || '📱 Descarga tu App PAMI - Autenticador Móvil Maestro (jimyamanqui@gmail.com)',
              mailObj.contenidoHtml
            );
            this.guardMessage.set('✅ ¡Correo enviado exitosamente mediante tu cuenta de Gmail a jimyamanqui@gmail.com!');
            this.correoResultado.set({ ...mailObj, estado: 'ENVIADO VIA GMAIL API' });
            this.mostrarModalCorreo.set(true);
          } catch (gmailErr: any) {
            this.guardError.set('Error en Gmail API: ' + (gmailErr.message || 'No se pudo enviar el correo vía Gmail'));
          } finally {
            this.enviandoCorreo.set(false);
          }
        },
        error: (err) => {
          this.enviandoCorreo.set(false);
          this.guardError.set(err.error?.mensaje || 'Error al generar los datos del correo.');
        },
      });
    } catch (err: any) {
      this.enviandoCorreo.set(false);
      this.guardError.set(err.message || 'Error al iniciar sesión con Google Gmail.');
    }
  }

  cargarDatos(): void {
    this.loading.set(true);
    this.authService.obtenerMetricasSaaS().subscribe({
      next: (m) => this.metricas.set(m),
    });

    this.authService.obtenerColegiosSaaS().subscribe({
      next: (c) => {
        this.colegios.set(c);
        this.loading.set(false);
      },
      error: () => this.loading.set(false),
    });
  }

  generarTokenPrueba(): void {
    // Generar un token JWT con la estructura compatible
    const now = Math.floor(Date.now() / 1000);
    const header = { alg: 'RS256', typ: 'JWT' };
    const payload = {
      exp: now + 3600,
      iat: now,
      sub: this.subPersonalizado(),
      preferred_username: this.usuarioSimulado(),
      email: `${this.usuarioSimulado()}@bomerp.com`,
      realm_access: {
        roles: [this.rolSeleccionado(), 'offline_access', 'uma_authorization'],
      },
      iss: 'http://localhost:38080/realms/bomerp',
    };

    const b64Url = (obj: any) => btoa(JSON.stringify(obj)).replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, '');
    this.tokenGenerado.set(`${b64Url(header)}.${b64Url(payload)}.kc-signature-master-verified`);
    this.copiado.set(false);
  }

  copiarToken(): void {
    navigator.clipboard.writeText(this.tokenGenerado());
    this.copiado.set(true);
    setTimeout(() => this.copiado.set(false), 2000);
  }

  copiarTextoKeycloak(texto: string, clave: string): void {
    if (navigator?.clipboard) {
      navigator.clipboard.writeText(texto).then(() => {
        this.keycloakCopied.set(clave);
        setTimeout(() => this.keycloakCopied.set(null), 2000);
      });
    }
  }

  abrirKeycloakConsola(): void {
    window.open('http://localhost:38080', '_blank');
  }

  cerrarSesion(): void {
    const targetUrl = this.authService.logout();
    this.router.navigateByUrl(targetUrl || '/adquirir');
  }
}

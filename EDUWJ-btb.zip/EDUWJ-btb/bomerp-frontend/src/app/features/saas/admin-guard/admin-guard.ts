import { Component, OnInit, OnDestroy, signal, computed, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { ActivatedRoute, Router, RouterModule } from '@angular/router';
import { AuthService } from '../../../core/services';

export type RezeVistaEspacial = 'FINANZAS' | 'CODIGO' | 'ACTIVIDAD';
export type RezeLadoRueda = 'IZQUIERDA' | 'DERECHA';
export type EstadoLlave5M = 'IDLE_ROTATING' | 'SHATTER_BUILDING_CHARS' | 'CODE_FORMED' | 'BREAK_OLD_KEY';

export interface RezeWheelPanelItem {
  id: RezeVistaEspacial;
  titulo: string;
  subtitulo: string;
  etiquetaCorta: string;
  fraseEditorialA: string;
  fraseEditorialB: string;
  numeroOrden: string;
  anguloBase: number;
}

export interface BurbujaRobotItem {
  id: 'USUARIOS' | 'DISPOSITIVOS' | 'COLEGIOS';
  titulo: string;
  valorPrincipal: string;
  subtitulo: string;
  anguloOrbita: number;
}

export interface MesMontanaItem {
  mes: string;
  monto: number;
  alturaPct: number;
  x: number;
  yPeak: number;
  esActual: boolean;
  esProyeccion: boolean;
}

@Component({
  selector: 'app-admin-guard',
  standalone: true,
  imports: [CommonModule, FormsModule, RouterModule],
  templateUrl: './admin-guard.html',
  styleUrl: './admin-guard.css',
})
export class AdminGuardComponent implements OnInit, OnDestroy {
  private authService = inject(AuthService);
  private route = inject(ActivatedRoute);
  private router = inject(Router);

  // =========================================================================
  // DISEÑO INSPIRADO EN "NEXTLY" (IMAGEN SUBIDA):
  // - Rueda lateral iridiscente con arco fino, punto naranja y lista curva
  //   (Opción Superior Atenuada · Opción Central Activa en Negrita · Opción Inferior Atenuada)
  // - Inercia física: deslizar rápido hacia arriba deja la rueda girando unos segundos y para
  // - Click en cualquier lugar de la pantalla (o en el botón ↗) entra al apartado
  // =========================================================================
  readonly panelesRueda: RezeWheelPanelItem[] = [
    {
      id: 'FINANZAS',
      titulo: 'Finanzas & Proyección',
      subtitulo: 'Tarjeta Bancaria · Proyección a Fin de Año · Cumbres Mensuales',
      etiquetaCorta: 'Finanzas',
      fraseEditorialA: 'Control Financiero,',
      fraseEditorialB: 'Claro y en Tiempo Real',
      numeroOrden: '01',
      anguloBase: 0,
    },
    {
      id: 'CODIGO',
      titulo: 'Card 5M · Llave 3D',
      subtitulo: 'Llave 3D destructible · Forja letra por letra tu clave',
      etiquetaCorta: 'Card 5M',
      fraseEditorialA: 'Acceso Criptográfico,',
      fraseEditorialB: 'Forjado en 5 Minutos',
      numeroOrden: '02',
      anguloBase: 120,
    },
    {
      id: 'ACTIVIDAD',
      titulo: 'Sistema & Orbe Robot',
      subtitulo: 'Bolita negra con ojos blancos · Burbujas deformables',
      etiquetaCorta: 'Sistema',
      fraseEditorialA: 'Ecosistema Escolar,',
      fraseEditorialB: 'Vivo en tu Órbita',
      numeroOrden: '03',
      anguloBase: 240,
    },
  ];

  tabActiva = signal<RezeVistaEspacial>('FINANZAS');
  panelEnFocoRueda = signal<RezeVistaEspacial>('FINANZAS');

  // Rueda con inercia física
  ruedaAbierta = signal(false);
  ruedaCerrando = signal(false);
  ladoRueda = signal<RezeLadoRueda>('IZQUIERDA');
  wheelRotationDeg = signal(0);
  isDraggingWheel = signal(false);
  isSpinningInertia = signal(false);
  wheelSpinDurationMs = signal(1850);

  // Tres elementos visibles junto al arco de la rueda (como "Smart Help" / "AI Guidance" / "Clear Choices")
  trilogiaArcoRueda = computed(() => {
    const idx = this.panelesRueda.findIndex((p) => p.id === this.panelEnFocoRueda());
    const safeIdx = idx >= 0 ? idx : 0;
    const total = this.panelesRueda.length;
    const prevIdx = (safeIdx - 1 + total) % total;
    const nextIdx = (safeIdx + 1) % total;
    return {
      arriba: this.panelesRueda[prevIdx],
      centro: this.panelesRueda[safeIdx],
      abajo: this.panelesRueda[nextIdx],
    };
  });

  private sideSwipeStartX: number | null = null;
  private sideSwipeStartY: number | null = null;
  private sideSwipeStartTime = 0;

  private wheelTouchStartX: number | null = null;
  private wheelTouchStartY: number | null = null;
  private wheelTouchStartTime = 0;
  private wheelLastY = 0;
  private wheelLastTime = 0;
  private wheelVelocityY = 0;
  private wheelStartDeg = 0;
  private wheelTotalDragDist = 0;
  private wheelPointerDown = false;
  private inertiaStopTimer: any = null;

  // =========================================================================
  // APARTADO 1: FINANZAS — TARJETA BANCARIA DESLIZABLE + GRÁFICO DE MONTAÑAS
  // =========================================================================
  finanzasCardIndex = signal(0);
  finanzasCardAnim = signal<'SLIDE_RIGHT' | 'SLIDE_LEFT'>('SLIDE_RIGHT');
  private cardSwipeStartX: number | null = null;
  private cardSwipeStartY: number | null = null;

  proyeccionFinDeAnio = computed(() => {
    const fin = this.resumenSistema()?.finanzas || {};
    const colegios: any[] = fin.colegios || [];
    const activos = colegios.filter((c) => c.estado === 'ACTIVO');

    const ahora = new Date();
    const mesActualIdx = ahora.getMonth();
    const mesesRestantesAnio = Math.max(1, 12 - mesActualIdx);

    const calcularTarifaSegunMes = (numeroMesSuscripcion: number): number => {
      if (numeroMesSuscripcion <= 1) return 1000;
      if (numeroMesSuscripcion === 2) return 930;
      if (numeroMesSuscripcion <= 4) return 860;
      return 700;
    };

    let futuroRestoAnio = 0;
    let proyeccion12Meses = 0;

    const desglosePorColegio = activos.map((col) => {
      const mesActualCol = Number(col.mesesSuscrito || col.mesesActivo || 1);
      let sumaRestoAnioCol = 0;
      let suma12MesesCol = 0;

      for (let m = 0; m < mesesRestantesAnio; m++) {
        sumaRestoAnioCol += calcularTarifaSegunMes(mesActualCol + m);
      }
      for (let m = 0; m < 12; m++) {
        suma12MesesCol += calcularTarifaSegunMes(mesActualCol + m);
      }

      futuroRestoAnio += sumaRestoAnioCol;
      proyeccion12Meses += suma12MesesCol;

      return {
        id: col.id,
        nombre: col.nombre || col.nombreColegio,
        mesActual: mesActualCol,
        cuotaHoy: calcularTarifaSegunMes(mesActualCol),
        cuotaFinDeAnio: calcularTarifaSegunMes(mesActualCol + mesesRestantesAnio - 1),
        totalRestoAnio: sumaRestoAnioCol,
      };
    });

    const recaudadoHistorico = Number(fin.totalHistorico || 0);
    const cierreEstimadoFinDeAnio = recaudadoHistorico + futuroRestoAnio;

    return {
      mesesRestantesAnio,
      recaudadoHistorico,
      futuroRestoAnio,
      cierreEstimadoFinDeAnio,
      proyeccion12Meses,
      colegiosActivosCount: activos.length,
      desglosePorColegio,
    };
  });

  datosMontanasMensuales = computed(() => {
    const fin = this.resumenSistema()?.finanzas || {};
    const colegios: any[] = (fin.colegios || []).filter((c: any) => c.estado === 'ACTIVO');
    const mrrActual = Number(fin.mrr || 0);
    const numActivos = colegios.length;

    const tarifaMes = (m: number) => (m <= 1 ? 1000 : m === 2 ? 930 : m <= 4 ? 860 : 700);

    let mJul = 0;
    let mAgo = 0;
    let mSep = 0;
    let mOct = mrrActual;
    let mNov = 0;
    let mDic = 0;

    if (numActivos > 0) {
      colegios.forEach((col) => {
        const mesCol = Number(col.mesesSuscrito || col.mesesActivo || 1);
        mJul += mesCol - 3 >= 1 ? tarifaMes(mesCol - 3) : Math.round(tarifaMes(1) * 0.45);
        mAgo += mesCol - 2 >= 1 ? tarifaMes(mesCol - 2) : Math.round(tarifaMes(1) * 0.68);
        mSep += mesCol - 1 >= 1 ? tarifaMes(mesCol - 1) : Math.round(tarifaMes(1) * 0.85);
        mNov += tarifaMes(mesCol + 1);
        mDic += tarifaMes(mesCol + 2);
      });
    } else {
      mJul = 420;
      mAgo = 680;
      mSep = 1000;
      mOct = 930;
      mNov = 860;
      mDic = 700;
    }

    const crudos = [
      { mes: 'JUL', monto: numActivos > 0 ? mJul : 0, ref: mJul, esActual: false, esProyeccion: false },
      { mes: 'AGO', monto: numActivos > 0 ? mAgo : 0, ref: mAgo, esActual: false, esProyeccion: false },
      { mes: 'SEP', monto: numActivos > 0 ? mSep : 0, ref: mSep, esActual: false, esProyeccion: false },
      { mes: 'OCT', monto: mOct, ref: Math.max(mOct, 920), esActual: true, esProyeccion: false },
      { mes: 'NOV', monto: numActivos > 0 ? mNov : 0, ref: mNov, esActual: false, esProyeccion: true },
      { mes: 'DIC', monto: numActivos > 0 ? mDic : 0, ref: mDic, esActual: false, esProyeccion: true },
    ];

    const maxRef = Math.max(...crudos.map((c) => c.ref), 1000);
    const xs = [28, 84, 140, 196, 252, 308];

    const items: MesMontanaItem[] = crudos.map((c, idx) => {
      const ratio = Math.max(0.18, Math.min(1, c.ref / maxRef));
      const yPeak = Math.round(132 - ratio * 102);
      return {
        mes: c.mes,
        monto: c.monto,
        alturaPct: Math.round(ratio * 100),
        x: xs[idx],
        yPeak,
        esActual: c.esActual,
        esProyeccion: c.esProyeccion,
      };
    });

    const ptsPrincipal = items.map((it) => `${it.x},${it.yPeak}`);
    const ridgePath = `M 0,144 L ${ptsPrincipal.join(' L ')} L 340,144`;
    const fillPath = `${ridgePath} L 340,158 L 0,158 Z`;

    const ptsSecundaria = items.map((it, i) => `${it.x + (i % 2 === 0 ? 10 : -8)},${Math.min(144, it.yPeak + 16)}`);
    const secondaryRidgePath = `M 0,150 L ${ptsSecundaria.join(' L ')} L 340,150`;

    const ptsTerciaria = items.map((it, i) => `${it.x + (i % 2 === 0 ? -6 : 9)},${Math.min(152, it.yPeak + 30)}`);
    const tertiaryRidgePath = `M 0,154 L ${ptsTerciaria.join(' L ')} L 340,154`;

    return {
      items,
      ridgePath,
      fillPath,
      secondaryRidgePath,
      tertiaryRidgePath,
    };
  });

  // =========================================================================
  // APARTADO 2: CARD 5M — MODELO 3D DE LLAVE QUE SE DESTRUYE Y FORJA LETRA POR LETRA
  //             DENTRO DE LAS 5 BARRAS DE CRISTAL VERTICALES ESTILO "NEXTLY"
  // =========================================================================
  estadoLlave5M = signal<EstadoLlave5M>('IDLE_ROTATING');
  caracteresReveladosCount = signal(0);
  private charBuildTimers: any[] = [];

  caracteresClave5M = computed(() => {
    const code = (this.activeCode() || '-----').padEnd(5, '-').slice(0, 5);
    return code.split('');
  });

  fragmentosLlave3D = Array.from({ length: 18 }, (_, i) => {
    const angle = (i / 18) * Math.PI * 2;
    const dist = 55 + (i % 3) * 28;
    return {
      id: i + 1,
      tx: `${Math.round(Math.cos(angle) * dist)}px`,
      ty: `${Math.round(Math.sin(angle) * dist)}px`,
      rot: `${(i % 2 === 0 ? 1 : -1) * (95 + i * 18)}deg`,
      delay: `${(i % 6) * 45}ms`,
    };
  });

  // =========================================================================
  // APARTADO 3: SISTEMA EN PANTALLA COMPLETA — BOLITA NEGRA CON OJOS EXPRESIVOS BLANCOS
  //             + BURBUJAS DE DATOS DEFORMABLES (SIN RESET)
  // =========================================================================
  indiceBurbujaPresentando = signal<number>(0);
  fasePresentacionRobot = signal<'GRANDE_AL_CENTRO' | 'EN_ORBITA'>('GRANDE_AL_CENTRO');
  burbujaDetalleSeleccionada = signal<'USUARIOS' | 'DISPOSITIVOS' | 'COLEGIOS' | null>(null);
  expresionOjosRobot = signal<'NORMAL' | 'HAPPY' | 'LOOK_LEFT' | 'LOOK_RIGHT' | 'WINK'>('NORMAL');
  private robotPresentationTimer: any = null;
  private robotEyeTimer: any = null;

  burbujasSistema = computed<BurbujaRobotItem[]>(() => {
    const res = this.resumenSistema();
    const totalUsuarios = res?.usuarios?.totalUsuarios ?? 1;
    const totalDispositivos = this.dispositivosConReze().length;
    const totalColegios = res?.finanzas?.totalColegios ?? 0;

    return [
      {
        id: 'USUARIOS',
        titulo: 'Usuarios Activos',
        valorPrincipal: `${totalUsuarios}`,
        subtitulo: `${res?.usuarios?.directores || 0} Directores · ${res?.usuarios?.docentes || 0} Docentes`,
        anguloOrbita: 0,
      },
      {
        id: 'DISPOSITIVOS',
        titulo: 'Equipos REZE',
        valorPrincipal: `${totalDispositivos}`,
        subtitulo: 'Móviles vinculados',
        anguloOrbita: 120,
      },
      {
        id: 'COLEGIOS',
        titulo: 'Cuentas Colegios',
        valorPrincipal: `${totalColegios}`,
        subtitulo: `${res?.finanzas?.colegiosActivos || 0} instituciones activas`,
        anguloOrbita: 240,
      },
    ];
  });

  cargandoResumen = signal(false);

  infoPanelEnFoco = computed(() => {
    const id = this.panelEnFocoRueda();
    return this.panelesRueda.find((p) => p.id === id) || this.panelesRueda[0];
  });

  dispositivosConReze = computed(() => {
    const lista = this.resumenSistema()?.actividad?.dispositivos || [];
    if (lista.length > 0) {
      return lista;
    }
    return [
      {
        deviceId: this.deviceId() || 'dev-master-primary',
        deviceName: this.deviceName() || 'Teléfono Móvil Autorizado',
        userAgent: navigator.userAgent || 'REZE Mobile OS',
        registeredAt: this.deviceRegisteredAt() || new Date().toISOString(),
        lastUsedAt: new Date().toISOString(),
        ip: '127.0.0.1',
        status: 'ACTIVO',
        boundEmail: this.boundEmail(),
      },
    ];
  });

  modoInstaladorQr = signal(false);
  descargandoInstalador = signal(false);
  progresoDescarga = signal(0);
  etapaDescarga = signal('Paquete verificado listo para instalar en tu pantalla de inicio');
  instalacionCompletada = signal(false);
  mostrarPasosInstalacionNativa = signal(false);
  tienePromptNativoDisponible = signal(false);
  activePairToken = signal('');

  realtimeFeedback = signal<string | null>(null);
  procesandoAccionMovil = signal(false);

  resumenSistema = signal<any>({
    finanzas: {
      mrr: 0,
      totalHistorico: 0,
      arr: 0,
      totalColegios: 0,
      colegiosActivos: 0,
      colegiosSuspendidos: 0,
      planBase: 1000,
      descuentoMensual: 70,
      pisoMinimo: 700,
      colegios: [],
    },
    usuarios: {
      totalUsuarios: 1,
      superAdmins: 1,
      directores: 0,
      secretarias: 0,
      docentes: 0,
      colaboradores: 0,
      alumnos: 0,
      cuentas: [
        {
          id: 999,
          username: 'jimyamanqui@gmail.com',
          nombreCompleto: 'Jimy Amanqui (SuperAdmin Maestro)',
          rol: 'ADMIN',
          estado: 'ACTIVO',
          email: 'jimyamanqui@gmail.com',
        },
      ],
    },
    actividad: {
      estadoServidor: 'OPERATIVO',
      dispositivosActivos: 1,
      dispositivos: [],
      ultimaSincronizacion: new Date().toISOString(),
      eventos: [],
    },
  });

  loading = signal(true);
  isAuthorized = signal(false);
  isBlockedDuplicate = signal(false);
  isUnpaired = signal(false);
  errorMessage = signal<string | null>(null);
  totalDevices = signal(1);

  isGoogleAuthenticated = signal(false);
  googleAuthLoading = signal(false);
  googleAuthError = signal<string | null>(null);
  googleInputEmail = signal('jimyamanqui@gmail.com');
  googleUserName = signal('Jimy Amanqui');
  showCustomEmailPrompt = signal(false);

  boundEmail = signal('jimyamanqui@gmail.com');
  deviceId = signal('');
  deviceName = signal('');
  deviceRegisteredAt = signal('');

  activeCode = signal('-----');
  secondsRemaining = signal(300);
  intervalSeconds = signal(300);
  timeProgressPercent = signal(100);

  codeCopied = signal(false);

  deferredPrompt: any = null;
  canInstallPwa = signal(true);
  isPwaInstalled = signal(false);
  showInstallGuideModal = signal(false);
  isIos = signal(false);
  isAndroid = signal(false);

  private syncTimer: any = null;
  private countdownTimer: any = null;
  private disconnectRealtime: (() => void) | null = null;
  private prevBodyBg = '';

  ngOnInit(): void {
    document.title = 'REZE — Nextly Ethereal Rotary OS';
    if (typeof document !== 'undefined') {
      this.prevBodyBg = document.body.style.background;
      document.body.style.background = '#f4f3ef';
      document.documentElement.style.background = '#f4f3ef';
    }

    this.detectPlatform();
    this.detectPwaStatus();
    this.initDeviceFingerprint();
    this.iniciarExpresionesOjosRobot();

    this.tabActiva.set('FINANZAS');
    this.panelEnFocoRueda.set('FINANZAS');

    const installParam = this.route.snapshot.queryParamMap.get('install');
    const installedParam = this.route.snapshot.queryParamMap.get('installed');
    const pairTokenParam = this.route.snapshot.queryParamMap.get('pairToken');
    if (pairTokenParam) {
      this.activePairToken.set(pairTokenParam);
    }
    if (installParam === '1' && installedParam !== '1') {
      this.modoInstaladorQr.set(true);
    } else {
      this.modoInstaladorQr.set(false);
    }

    this.checkGoogleSession();

    this.disconnectRealtime = this.authService.conectarStreamTiempoReal((payload) => {
      if (payload.resumenSistema) {
        this.resumenSistema.set(payload.resumenSistema);
      }
      if (payload.guardCode?.code) {
        this.activeCode.set(payload.guardCode.code);
        if (payload.guardCode.secondsRemaining) {
          this.secondsRemaining.set(payload.guardCode.secondsRemaining);
          this.updateTimeProgress();
        }
      }
      if (payload.guardStatus?.totalDevices !== undefined) {
        this.totalDevices.set(payload.guardStatus.totalDevices);
      }
    });
  }

  // =========================================================================
  // 1. ACCESO A LA RUEDA ESTRICTAMENTE DESLIZANDO EN ZONA LATERAL IZQUIERDA O DERECHA
  //    (SI DESLIZA AL MEDIO DE LA PANTALLA NO SE ABRE LA RUEDA)
  // =========================================================================
  onLateralZoneTouchStart(_lado: RezeLadoRueda, event: TouchEvent): void {
    if (this.ruedaAbierta() || !this.isGoogleAuthenticated() || this.modoInstaladorQr()) return;
    if (!event.touches || event.touches.length !== 1) return;
    event.stopPropagation();

    this.sideSwipeStartX = event.touches[0].clientX;
    this.sideSwipeStartY = event.touches[0].clientY;
    this.sideSwipeStartTime = Date.now();
  }

  onLateralZoneTouchMove(event: TouchEvent): void {
    if (this.sideSwipeStartY === null || !event.touches || event.touches.length !== 1) return;
    const dy = event.touches[0].clientY - this.sideSwipeStartY;
    if (Math.abs(dy) > 8 && event.cancelable) {
      event.preventDefault();
    }
  }

  onLateralZoneTouchEnd(lado: RezeLadoRueda, event: TouchEvent): void {
    if (this.ruedaAbierta() || this.sideSwipeStartX === null || this.sideSwipeStartY === null) return;
    if (!event.changedTouches || event.changedTouches.length === 0) return;
    event.stopPropagation();

    const endX = event.changedTouches[0].clientX;
    const endY = event.changedTouches[0].clientY;
    const dy = endY - this.sideSwipeStartY;
    const dx = endX - this.sideSwipeStartX;
    const elapsed = Math.max(16, Date.now() - this.sideSwipeStartTime);

    this.sideSwipeStartX = null;
    this.sideSwipeStartY = null;

    if (dy < -24 && Math.abs(dy) > Math.abs(dx) * 1.05 && elapsed < 1400) {
      const velocidad = Math.abs(dy) / elapsed;
      this.abrirMediaRuedaConInercia(lado, velocidad);
    }
  }

  onLateralZoneMouseDown(_lado: RezeLadoRueda, event: MouseEvent): void {
    if (this.ruedaAbierta() || !this.isGoogleAuthenticated() || this.modoInstaladorQr()) return;
    event.stopPropagation();
    this.sideSwipeStartX = event.clientX;
    this.sideSwipeStartY = event.clientY;
    this.sideSwipeStartTime = Date.now();
  }

  onLateralZoneMouseUp(lado: RezeLadoRueda, event: MouseEvent): void {
    if (this.ruedaAbierta() || this.sideSwipeStartX === null || this.sideSwipeStartY === null) return;
    event.stopPropagation();

    const dy = event.clientY - this.sideSwipeStartY;
    const dx = event.clientX - this.sideSwipeStartX;
    const elapsed = Math.max(16, Date.now() - this.sideSwipeStartTime);

    this.sideSwipeStartX = null;
    this.sideSwipeStartY = null;

    if (dy < -24 && Math.abs(dy) > Math.abs(dx) * 1.05 && elapsed < 1400) {
      const velocidad = Math.abs(dy) / elapsed;
      this.abrirMediaRuedaConInercia(lado, velocidad);
    }
  }

  onShellTouchStart(event: TouchEvent): void {
    if (this.ruedaAbierta() || !this.isGoogleAuthenticated() || this.modoInstaladorQr()) return;
    if (!event.touches || event.touches.length !== 1) return;

    this.sideSwipeStartX = event.touches[0].clientX;
    this.sideSwipeStartY = event.touches[0].clientY;
    this.sideSwipeStartTime = Date.now();
  }

  onShellTouchEnd(event: TouchEvent): void {
    if (this.ruedaAbierta() || this.sideSwipeStartX === null || this.sideSwipeStartY === null) return;
    if (!event.changedTouches || event.changedTouches.length === 0) return;

    const endX = event.changedTouches[0].clientX;
    const endY = event.changedTouches[0].clientY;
    const shellRect = (event.currentTarget as HTMLElement)?.getBoundingClientRect?.();
    this.evaluarDeslizarArribaEnLateral(this.sideSwipeStartX, this.sideSwipeStartY, endX, endY, shellRect);

    this.sideSwipeStartX = null;
    this.sideSwipeStartY = null;
  }

  onShellMouseDown(event: MouseEvent): void {
    if (this.ruedaAbierta() || !this.isGoogleAuthenticated() || this.modoInstaladorQr()) return;
    this.sideSwipeStartX = event.clientX;
    this.sideSwipeStartY = event.clientY;
    this.sideSwipeStartTime = Date.now();
  }

  onShellMouseUp(event: MouseEvent): void {
    if (this.ruedaAbierta() || this.sideSwipeStartX === null || this.sideSwipeStartY === null) return;
    const shellRect = (event.currentTarget as HTMLElement)?.getBoundingClientRect?.();
    this.evaluarDeslizarArribaEnLateral(this.sideSwipeStartX, this.sideSwipeStartY, event.clientX, event.clientY, shellRect);
    this.sideSwipeStartX = null;
    this.sideSwipeStartY = null;
  }

  private evaluarDeslizarArribaEnLateral(
    startX: number,
    startY: number,
    endX: number,
    endY: number,
    shellRect?: DOMRect
  ): void {
    const dy = endY - startY;
    const dx = endX - startX;
    const elapsed = Math.max(16, Date.now() - this.sideSwipeStartTime);

    const leftBound = shellRect ? shellRect.left : 0;
    const width = shellRect ? shellRect.width : window.innerWidth;
    const relStartX = startX - leftBound;
    const relEndX = endX - leftBound;

    // Franja lateral izquierda (0% a 20% del ancho) y derecha (80% a 100% del ancho).
    // Si el usuario desliza en el medio (20% a 80%), NO se abre la rueda.
    const anchoZonaLateral = Math.min(68, width * 0.2);
    const esLateralIzquierdo = relStartX >= 0 && relStartX <= anchoZonaLateral && relEndX <= anchoZonaLateral + 28;
    const esLateralDerecho =
      relStartX >= width - anchoZonaLateral &&
      relStartX <= width &&
      relEndX >= width - anchoZonaLateral - 28;

    if (!esLateralIzquierdo && !esLateralDerecho) {
      return;
    }

    if (dy < -28 && Math.abs(dy) > Math.abs(dx) * 1.1 && elapsed < 1400) {
      const lado: RezeLadoRueda = esLateralIzquierdo ? 'IZQUIERDA' : 'DERECHA';
      const velocidad = Math.abs(dy) / elapsed;
      this.abrirMediaRuedaConInercia(lado, velocidad);
    }
  }

  abrirMediaRuedaConInercia(lado: RezeLadoRueda = 'IZQUIERDA', velocidadInicial = 0.9): void {
    this.ladoRueda.set(lado);
    this.panelEnFocoRueda.set(this.tabActiva());
    const idx = this.panelesRueda.findIndex((p) => p.id === this.tabActiva());
    const baseDeg = idx >= 0 ? -idx * 120 : 0;
    this.wheelRotationDeg.set(baseDeg);

    this.ruedaCerrando.set(false);
    this.ruedaAbierta.set(true);

    const pasosInercia = velocidadInicial > 0.7 ? 3 : 2;
    setTimeout(() => {
      this.lanzarGiroInerciaRueda(pasosInercia, 1850);
    }, 40);
  }

  // =========================================================================
  // 2. RUEDA CON INERCIA FÍSICA (ESTILO "NEXTLY" PANTALLA IZQUIERDA)
  // =========================================================================
  onWheelOverlayTouchStart(event: TouchEvent): void {
    if (!event.touches || event.touches.length !== 1) return;
    event.stopPropagation();
    this.iniciarInteraccionRuedaAbierta(event.touches[0].clientX, event.touches[0].clientY);
  }

  onWheelOverlayTouchMove(event: TouchEvent): void {
    if (!this.wheelPointerDown || !event.touches || event.touches.length !== 1) return;
    if (event.cancelable) event.preventDefault();
    event.stopPropagation();
    this.moverRuedaAbierta(event.touches[0].clientX, event.touches[0].clientY);
  }

  onWheelOverlayTouchEnd(event: TouchEvent): void {
    event.stopPropagation();
    this.finalizarInteraccionRuedaAbierta();
  }

  onWheelOverlayMouseDown(event: MouseEvent): void {
    event.stopPropagation();
    this.iniciarInteraccionRuedaAbierta(event.clientX, event.clientY);
  }

  onWheelOverlayMouseMove(event: MouseEvent): void {
    if (!this.wheelPointerDown) return;
    event.preventDefault();
    event.stopPropagation();
    this.moverRuedaAbierta(event.clientX, event.clientY);
  }

  onWheelOverlayMouseUp(event: MouseEvent): void {
    if (!this.wheelPointerDown) return;
    event.stopPropagation();
    this.finalizarInteraccionRuedaAbierta();
  }

  onWheelScroll(event: WheelEvent): void {
    event.preventDefault();
    event.stopPropagation();
    const pasos = event.deltaY > 0 ? 1 : -1;
    this.lanzarGiroInerciaRueda(pasos, 900);
  }

  private iniciarInteraccionRuedaAbierta(clientX: number, clientY: number): void {
    if (this.inertiaStopTimer) {
      clearTimeout(this.inertiaStopTimer);
      this.inertiaStopTimer = null;
    }
    this.isSpinningInertia.set(false);
    this.wheelPointerDown = true;
    this.wheelTouchStartX = clientX;
    this.wheelTouchStartY = clientY;
    this.wheelTouchStartTime = Date.now();
    this.wheelLastY = clientY;
    this.wheelLastTime = Date.now();
    this.wheelVelocityY = 0;
    this.wheelStartDeg = this.wheelRotationDeg();
    this.wheelTotalDragDist = 0;
    this.isDraggingWheel.set(false);
  }

  private moverRuedaAbierta(clientX: number, clientY: number): void {
    if (this.wheelTouchStartY === null || this.wheelTouchStartX === null) return;
    const now = Date.now();
    const dt = Math.max(8, now - this.wheelLastTime);
    const stepDy = clientY - this.wheelLastY;
    this.wheelVelocityY = stepDy / dt;
    this.wheelLastY = clientY;
    this.wheelLastTime = now;

    const dy = clientY - this.wheelTouchStartY;
    const dx = clientX - this.wheelTouchStartX;
    this.wheelTotalDragDist = Math.hypot(dx, dy);

    if (this.wheelTotalDragDist > 10) {
      this.isDraggingWheel.set(true);
      const deltaDeg = -dy * (120 / 75);
      const nuevoAngulo = this.wheelStartDeg + deltaDeg;
      this.wheelRotationDeg.set(nuevoAngulo);
      this.actualizarPreseleccionRueda(nuevoAngulo);
    }
  }

  private finalizarInteraccionRuedaAbierta(): void {
    const fueDeslizamiento = this.wheelTotalDragDist > 10;
    const totalElapsed = Math.max(16, Date.now() - this.wheelTouchStartTime);
    const totalDy = this.wheelLastY - (this.wheelTouchStartY ?? this.wheelLastY);
    const velocidadPromedio = totalDy / totalElapsed;
    const velocidadFinal = Math.abs(this.wheelVelocityY) > Math.abs(velocidadPromedio)
      ? this.wheelVelocityY
      : velocidadPromedio;

    this.wheelPointerDown = false;
    this.isDraggingWheel.set(false);
    this.wheelTouchStartX = null;
    this.wheelTouchStartY = null;

    if (fueDeslizamiento) {
      const absVel = Math.abs(velocidadFinal);
      if (absVel > 0.3) {
        const direccion = velocidadFinal < 0 ? 1 : -1;
        const pasosExtra = Math.min(7, Math.max(2, Math.round(absVel * 4.2)));
        const duracionMs = Math.min(2400, 1450 + pasosExtra * 160);
        this.lanzarGiroInerciaRueda(direccion * pasosExtra, duracionMs);
      } else {
        const step = Math.round(-this.wheelRotationDeg() / 120);
        const snapAngle = -step * 120;
        this.wheelSpinDurationMs.set(480);
        this.isSpinningInertia.set(true);
        this.wheelRotationDeg.set(snapAngle);
        this.actualizarPreseleccionRueda(snapAngle);
        this.inertiaStopTimer = setTimeout(() => {
          this.isSpinningInertia.set(false);
        }, 500);
      }
    } else {
      this.confirmarSeleccionYEntrar(this.panelEnFocoRueda());
    }
  }

  private lanzarGiroInerciaRueda(pasos120: number, duracionMs: number): void {
    if (this.inertiaStopTimer) {
      clearTimeout(this.inertiaStopTimer);
    }
    const currentStep = Math.round(-this.wheelRotationDeg() / 120);
    const targetStep = currentStep + pasos120;
    const targetAngle = -targetStep * 120;

    this.wheelSpinDurationMs.set(duracionMs);
    this.isSpinningInertia.set(true);
    this.wheelRotationDeg.set(targetAngle);
    this.actualizarPreseleccionRueda(targetAngle);

    if (navigator.vibrate) {
      navigator.vibrate([15, 35, 15]);
    }

    this.inertiaStopTimer = setTimeout(() => {
      this.isSpinningInertia.set(false);
    }, duracionMs + 40);
  }

  private actualizarPreseleccionRueda(angulo: number): void {
    const step = Math.round(-angulo / 120);
    const total = this.panelesRueda.length;
    const normalizedIdx = ((step % total) + total) % total;
    const nuevoPanel = this.panelesRueda[normalizedIdx].id;

    if (this.panelEnFocoRueda() !== nuevoPanel) {
      this.panelEnFocoRueda.set(nuevoPanel);
      if (navigator.vibrate) {
        navigator.vibrate(14);
      }
    }
  }

  onClickNodoRueda(panel: RezeVistaEspacial, event: Event): void {
    event.stopPropagation();
    if (this.wheelTotalDragDist > 10) return;
    this.confirmarSeleccionYEntrar(panel);
  }

  confirmarSeleccionYEntrar(panel?: RezeVistaEspacial): void {
    const elegido = panel || this.panelEnFocoRueda();
    this.panelEnFocoRueda.set(elegido);
    this.tabActiva.set(elegido);

    const idx = this.panelesRueda.findIndex((p) => p.id === elegido);
    if (idx >= 0) {
      this.wheelRotationDeg.set(-idx * 120);
    }

    if (elegido === 'CODIGO') {
      this.limpiarTimersForjadoLetras();
      this.estadoLlave5M.set('IDLE_ROTATING');
      this.caracteresReveladosCount.set(0);
    } else if (elegido === 'ACTIVIDAD') {
      this.iniciarPresentacionBurbujasRobot();
    }

    if (navigator.vibrate) {
      navigator.vibrate([22, 18, 30]);
    }

    this.ruedaCerrando.set(true);
    setTimeout(() => {
      this.ruedaAbierta.set(false);
      this.ruedaCerrando.set(false);
    }, 230);

    this.refrescarResumen();
  }

  // =========================================================================
  // 3. FINANZAS: DESLIZAR TARJETA BANCARIA HACIA LA DERECHA O IZQUIERDA
  // =========================================================================
  onFinanceCardTouchStart(event: TouchEvent): void {
    if (!event.touches || event.touches.length !== 1) return;
    this.cardSwipeStartX = event.touches[0].clientX;
    this.cardSwipeStartY = event.touches[0].clientY;
  }

  onFinanceCardTouchEnd(event: TouchEvent): void {
    if (this.cardSwipeStartX === null || this.cardSwipeStartY === null) return;
    if (!event.changedTouches || event.changedTouches.length === 0) return;

    const dx = event.changedTouches[0].clientX - this.cardSwipeStartX;
    const dy = event.changedTouches[0].clientY - this.cardSwipeStartY;

    if (Math.abs(dx) > 32 && Math.abs(dx) > Math.abs(dy)) {
      if (dx > 0) {
        this.cambiarTarjetaFinanzas(1, 'SLIDE_RIGHT');
      } else {
        this.cambiarTarjetaFinanzas(-1, 'SLIDE_LEFT');
      }
    }
    this.cardSwipeStartX = null;
    this.cardSwipeStartY = null;
  }

  onFinanceCardMouseDown(event: MouseEvent): void {
    this.cardSwipeStartX = event.clientX;
    this.cardSwipeStartY = event.clientY;
  }

  onFinanceCardMouseUp(event: MouseEvent): void {
    if (this.cardSwipeStartX === null || this.cardSwipeStartY === null) return;
    const dx = event.clientX - this.cardSwipeStartX;
    const dy = event.clientY - this.cardSwipeStartY;

    if (Math.abs(dx) > 32 && Math.abs(dx) > Math.abs(dy)) {
      if (dx > 0) {
        this.cambiarTarjetaFinanzas(1, 'SLIDE_RIGHT');
      } else {
        this.cambiarTarjetaFinanzas(-1, 'SLIDE_LEFT');
      }
    }
    this.cardSwipeStartX = null;
    this.cardSwipeStartY = null;
  }

  cambiarTarjetaFinanzas(paso: number, anim: 'SLIDE_RIGHT' | 'SLIDE_LEFT' = 'SLIDE_RIGHT'): void {
    this.finanzasCardAnim.set(anim);
    const total = 3;
    const nuevo = (((this.finanzasCardIndex() + paso) % total) + total) % total;
    this.finanzasCardIndex.set(nuevo);
    if (navigator.vibrate) {
      navigator.vibrate(18);
    }
  }

  // =========================================================================
  // 4. CARD 5M: MODELO LLAVE 3D QUE SE DESTRUYE Y CREA LETRA POR LETRA
  // =========================================================================
  private limpiarTimersForjadoLetras(): void {
    this.charBuildTimers.forEach((t) => clearTimeout(t));
    this.charBuildTimers = [];
  }

  clickLlave3DCopiar(): void {
    if (this.estadoLlave5M() === 'SHATTER_BUILDING_CHARS' || this.estadoLlave5M() === 'BREAK_OLD_KEY') return;

    this.copiarCodigo();
    this.ejecutarSecuenciaFragmentosLetraPorLetra();
  }

  private ejecutarSecuenciaFragmentosLetraPorLetra(): void {
    this.limpiarTimersForjadoLetras();
    this.caracteresReveladosCount.set(0);
    this.estadoLlave5M.set('SHATTER_BUILDING_CHARS');

    for (let i = 1; i <= 5; i++) {
      const t = setTimeout(() => {
        this.caracteresReveladosCount.set(i);
        if (navigator.vibrate) {
          navigator.vibrate(12);
        }
      }, 240 + i * 240);
      this.charBuildTimers.push(t);
    }

    const finalTimer = setTimeout(() => {
      if (this.estadoLlave5M() === 'SHATTER_BUILDING_CHARS') {
        this.estadoLlave5M.set('CODE_FORMED');
      }
    }, 240 + 5 * 240 + 260);
    this.charBuildTimers.push(finalTimer);
  }

  restaurarVistaLlave3D(): void {
    this.limpiarTimersForjadoLetras();
    this.caracteresReveladosCount.set(0);
    this.estadoLlave5M.set('IDLE_ROTATING');
  }

  romperYCrearNuevaClave5M(): void {
    if (this.procesandoAccionMovil()) return;
    this.procesandoAccionMovil.set(true);
    this.limpiarTimersForjadoLetras();

    this.estadoLlave5M.set('BREAK_OLD_KEY');
    if (navigator.vibrate) {
      navigator.vibrate([40, 25, 50]);
    }

    setTimeout(() => {
      this.authService.rotarCodigoReze().subscribe({
        next: (res) => {
          this.procesandoAccionMovil.set(false);
          if (res.code) {
            this.activeCode.set(res.code);
            this.secondsRemaining.set(res.secondsRemaining || 300);
            this.updateTimeProgress();
          }
          if (res.resumenSistema) {
            this.resumenSistema.set(res.resumenSistema);
          }

          this.mostrarToastEnVivo(`Clave anterior destruida · Forjando nueva clave letra por letra`);
          this.ejecutarSecuenciaFragmentosLetraPorLetra();
        },
        error: () => {
          this.procesandoAccionMovil.set(false);
          this.estadoLlave5M.set('IDLE_ROTATING');
        },
      });
    }, 520);
  }

  // =========================================================================
  // 5. SISTEMA EN PANTALLA COMPLETA: BOLITA NEGRA CON OJOS EXPRESIVOS BLANCOS
  // =========================================================================
  private iniciarExpresionesOjosRobot(): void {
    const expresiones: Array<'NORMAL' | 'HAPPY' | 'LOOK_LEFT' | 'LOOK_RIGHT' | 'WINK'> = [
      'NORMAL',
      'LOOK_LEFT',
      'NORMAL',
      'HAPPY',
      'LOOK_RIGHT',
      'NORMAL',
      'WINK',
    ];
    let idx = 0;
    this.robotEyeTimer = setInterval(() => {
      idx = (idx + 1) % expresiones.length;
      this.expresionOjosRobot.set(expresiones[idx]);
    }, 2600);
  }

  iniciarPresentacionBurbujasRobot(): void {
    if (this.robotPresentationTimer) {
      clearInterval(this.robotPresentationTimer);
    }
    this.indiceBurbujaPresentando.set(0);
    this.fasePresentacionRobot.set('GRANDE_AL_CENTRO');
    this.expresionOjosRobot.set('HAPPY');

    let paso = 0;
    this.robotPresentationTimer = setInterval(() => {
      paso++;
      const totalBurbujas = this.burbujasSistema().length;
      if (paso < totalBurbujas) {
        this.indiceBurbujaPresentando.set(paso);
        this.expresionOjosRobot.set(paso % 2 === 0 ? 'LOOK_LEFT' : 'LOOK_RIGHT');
      } else {
        this.fasePresentacionRobot.set('EN_ORBITA');
        this.expresionOjosRobot.set('NORMAL');
        clearInterval(this.robotPresentationTimer);
        this.robotPresentationTimer = null;
      }
    }, 1500);
  }

  seleccionarBurbujaOrbita(item: BurbujaRobotItem, index: number, event: Event): void {
    event.stopPropagation();
    this.expresionOjosRobot.set('HAPPY');
    if (this.burbujaDetalleSeleccionada() === item.id) {
      this.burbujaDetalleSeleccionada.set(null);
      return;
    }
    this.burbujaDetalleSeleccionada.set(item.id);
    this.indiceBurbujaPresentando.set(index);
  }

  cerrarDetalleBurbuja(event?: Event): void {
    if (event) event.stopPropagation();
    this.burbujaDetalleSeleccionada.set(null);
  }

  clickRobotAbrirWebAdquirir(event?: Event): void {
    if (event) {
      event.stopPropagation();
    }
    this.ruedaAbierta.set(false);
    this.router.navigate(['/adquirir']);
  }

  async iniciarDescargaInstaladorReze(): Promise<void> {
    if (this.descargandoInstalador()) return;

    this.descargandoInstalador.set(true);
    this.instalacionCompletada.set(false);
    this.progresoDescarga.set(35);
    this.etapaDescarga.set('Solicitando al sistema operativo instalar la app REZE...');

    let promptEvent = this.deferredPrompt || (window as any).__rezeDeferredPrompt;
    if (!promptEvent) {
      for (let i = 0; i < 5; i++) {
        await new Promise((r) => setTimeout(r, 200));
        promptEvent = this.deferredPrompt || (window as any).__rezeDeferredPrompt;
        if (promptEvent) break;
      }
    }

    if (promptEvent) {
      try {
        this.progresoDescarga.set(75);
        this.etapaDescarga.set('Toca "Instalar" en el cuadro del sistema de tu teléfono...');
        await promptEvent.prompt();
        const choiceResult = await promptEvent.userChoice;
        this.deferredPrompt = null;
        (window as any).__rezeDeferredPrompt = null;
        this.tienePromptNativoDisponible.set(false);

        if (choiceResult?.outcome === 'accepted') {
          this.progresoDescarga.set(100);
          this.descargandoInstalador.set(false);
          this.instalacionCompletada.set(true);
          this.isPwaInstalled.set(true);
          this.mostrarPasosInstalacionNativa.set(false);
          this.etapaDescarga.set('¡Aplicación REZE instalada en tu dispositivo! Búscala en tu pantalla de inicio.');
          this.mostrarToastEnVivo('¡App REZE instalada en el cajón de aplicaciones de tu móvil!');
          return;
        } else {
          this.descargandoInstalador.set(false);
          this.progresoDescarga.set(0);
          this.etapaDescarga.set('Cancelaste el cuadro de instalación. Toca el botón de nuevo y acepta "Instalar".');
          return;
        }
      } catch {
        this.descargandoInstalador.set(false);
      }
    }

    this.descargandoInstalador.set(false);
    this.progresoDescarga.set(0);
    this.mostrarPasosInstalacionNativa.set(true);

    const ua = navigator.userAgent || '';
    const isAndroidWebView = /Android/i.test(ua) && (/wv\)/i.test(ua) || !/Chrome\//i.test(ua));
    if (isAndroidWebView) {
      this.etapaDescarga.set('Abriendo en Google Chrome para instalar la app en tu dispositivo...');
      this.abrirEnChromeAndroid();
      return;
    }

    if (this.isIos()) {
      this.etapaDescarga.set('En iPhone: Toca Compartir (⬆️) abajo y selecciona "Agregar a inicio"');
    } else {
      this.etapaDescarga.set('Para crear la app en tu celular: toca el menú ⋮ (arriba a la derecha) → "Instalar aplicación"');
    }
  }

  abrirEnChromeAndroid(): void {
    const host = window.location.host;
    const token = this.activePairToken() || this.route.snapshot.queryParamMap.get('pairToken') || '';
    const pathAndQuery = `/admin-guard?${token ? 'pairToken=' + encodeURIComponent(token) + '&' : ''}install=1`;
    const intentUrl = `intent://${host}${pathAndQuery}#Intent;scheme=https;package=com.android.chrome;end`;
    window.location.href = intentUrl;
  }

  abrirBovedaTrasInstalacion(): void {
    this.modoInstaladorQr.set(false);
    this.tabActiva.set('FINANZAS');
    this.panelEnFocoRueda.set('FINANZAS');
    this.refrescarCodigo();
    this.refrescarResumen();
  }

  mostrarToastEnVivo(texto: string): void {
    this.realtimeFeedback.set(texto);
    setTimeout(() => {
      if (this.realtimeFeedback() === texto) {
        this.realtimeFeedback.set(null);
      }
    }, 3200);
  }

  ejecutarAccionColegio(colegioId: number, accion: 'TOGGLE_ESTADO' | 'REGISTRAR_PAGO' | 'ELIMINAR'): void {
    if (this.procesandoAccionMovil()) return;
    this.procesandoAccionMovil.set(true);
    this.authService.ejecutarAccionColegioMovil(colegioId, accion).subscribe({
      next: (res) => {
        this.procesandoAccionMovil.set(false);
        if (res.resumenSistema) {
          this.resumenSistema.set(res.resumenSistema);
        }
        const msg =
          accion === 'REGISTRAR_PAGO'
            ? 'Pago mensual registrado y sincronizado en SuperAdmin'
            : accion === 'TOGGLE_ESTADO'
            ? 'Estado del colegio actualizado en tiempo real'
            : 'Colegio eliminado en tiempo real';
        this.mostrarToastEnVivo(msg);
      },
      error: () => {
        this.procesandoAccionMovil.set(false);
      },
    });
  }

  refrescarResumen(): void {
    this.cargandoResumen.set(true);
    this.authService.getResumenSistemaReze().subscribe({
      next: (res) => {
        this.cargandoResumen.set(false);
        if (res && res.finanzas) {
          this.resumenSistema.set(res);
        }
      },
      error: () => this.cargandoResumen.set(false),
    });
  }

  private detectPlatform(): void {
    const ua = navigator.userAgent || '';
    this.isIos.set(/iPad|iPhone|iPod/.test(ua) && !(window as any).MSStream);
    this.isAndroid.set(/Android/i.test(ua));
  }

  checkGoogleSession(): void {
    const pairToken = this.route.snapshot.queryParamMap.get('pairToken');
    const saved = localStorage.getItem('reze_google_auth') || localStorage.getItem('pami_google_auth');

    if (pairToken || (saved && saved.trim().toLowerCase() === 'jimyamanqui@gmail.com')) {
      localStorage.setItem('reze_google_auth', 'jimyamanqui@gmail.com');
      localStorage.setItem('pami_google_auth', 'jimyamanqui@gmail.com');
      this.isGoogleAuthenticated.set(true);
      this.checkAuthorizationAndPairing();
    } else {
      this.loading.set(false);
      this.isGoogleAuthenticated.set(false);
    }
  }

  iniciarSesionGoogle(emailToUse?: string): void {
    this.googleAuthLoading.set(true);
    this.googleAuthError.set(null);

    const email = (emailToUse || this.googleInputEmail()).trim().toLowerCase();

    setTimeout(() => {
      this.googleAuthLoading.set(false);
      if (email !== 'jimyamanqui@gmail.com') {
        this.googleAuthError.set(
          `Acceso denegado (${email}): Solo los teléfonos vinculados con la cuenta Google jimyamanqui@gmail.com pueden descargar e instalar REZE.`
        );
        return;
      }

      localStorage.setItem('reze_google_auth', 'jimyamanqui@gmail.com');
      localStorage.setItem('pami_google_auth', 'jimyamanqui@gmail.com');
      this.isGoogleAuthenticated.set(true);
      this.checkAuthorizationAndPairing();
    }, 400);
  }

  cerrarSesionGoogle(): void {
    localStorage.removeItem('reze_google_auth');
    localStorage.removeItem('pami_google_auth');
    this.clearTimers();
    this.isGoogleAuthenticated.set(false);
    this.isAuthorized.set(false);
  }

  ngOnDestroy(): void {
    this.clearTimers();
    this.limpiarTimersForjadoLetras();
    if (this.robotPresentationTimer) clearInterval(this.robotPresentationTimer);
    if (this.robotEyeTimer) clearInterval(this.robotEyeTimer);
    if (this.inertiaStopTimer) clearTimeout(this.inertiaStopTimer);
    if (this.disconnectRealtime) {
      this.disconnectRealtime();
    }
    if (typeof document !== 'undefined' && this.prevBodyBg !== undefined) {
      document.body.style.background = this.prevBodyBg;
    }
  }

  private clearTimers(): void {
    if (this.syncTimer) clearInterval(this.syncTimer);
    if (this.countdownTimer) clearInterval(this.countdownTimer);
  }

  private detectPwaStatus(): void {
    if (typeof navigator !== 'undefined' && 'serviceWorker' in navigator) {
      navigator.serviceWorker.register('/sw.js', { scope: '/' }).catch(() => {});
    }

    if (window.matchMedia('(display-mode: standalone)').matches || (window.navigator as any).standalone) {
      this.isPwaInstalled.set(true);
    }

    if ((window as any).__rezeDeferredPrompt) {
      this.deferredPrompt = (window as any).__rezeDeferredPrompt;
      this.tienePromptNativoDisponible.set(true);
      this.canInstallPwa.set(true);
    }

    window.addEventListener('reze-pwa-ready', () => {
      if ((window as any).__rezeDeferredPrompt) {
        this.deferredPrompt = (window as any).__rezeDeferredPrompt;
        this.tienePromptNativoDisponible.set(true);
        this.canInstallPwa.set(true);
      }
    });

    window.addEventListener('beforeinstallprompt', (e) => {
      e.preventDefault();
      this.deferredPrompt = e;
      (window as any).__rezeDeferredPrompt = e;
      this.tienePromptNativoDisponible.set(true);
      this.canInstallPwa.set(true);
    });

    window.addEventListener('appinstalled', () => {
      this.isPwaInstalled.set(true);
      this.instalacionCompletada.set(true);
      this.canInstallPwa.set(false);
      this.deferredPrompt = null;
      (window as any).__rezeDeferredPrompt = null;
      this.mostrarToastEnVivo('¡App REZE instalada en tu pantalla de inicio!');
    });
  }

  private initDeviceFingerprint(): void {
    let storedId = localStorage.getItem('bomerp_admin_guard_device_id');
    if (!storedId) {
      storedId = 'dev-' + crypto.randomUUID().slice(0, 16);
      localStorage.setItem('bomerp_admin_guard_device_id', storedId);
    }
    this.deviceId.set(storedId);

    const ua = navigator.userAgent;
    let devName = 'Dispositivo Móvil';
    if (/Android/i.test(ua)) devName = 'Android Mobile';
    else if (/iPhone/i.test(ua)) devName = 'Apple iPhone';
    else if (/iPad/i.test(ua)) devName = 'Apple iPad';
    else devName = 'Teléfono Móvil (' + (navigator.platform || 'Móvil') + ')';
    this.deviceName.set(devName);
  }

  private checkAuthorizationAndPairing(): void {
    this.loading.set(true);
    const pairToken = this.route.snapshot.queryParamMap.get('pairToken');

    if (pairToken) {
      this.vincularConToken(pairToken);
      return;
    }

    this.consultarEstadoDispositivo();
  }

  private consultarEstadoDispositivo(): void {
    this.authService.getGuardDeviceStatus(this.deviceId()).subscribe({
      next: (res) => {
        this.loading.set(false);
        this.isAuthorized.set(true);
        this.isBlockedDuplicate.set(false);
        this.isUnpaired.set(false);
        this.boundEmail.set(res.boundEmail || 'jimyamanqui@gmail.com');
        if (res.totalDispositivos !== undefined) {
          this.totalDevices.set(res.totalDispositivos);
        }
        if (res.dispositivo) {
          this.deviceName.set(res.dispositivo.deviceName);
          this.deviceRegisteredAt.set(res.dispositivo.registeredAt);
        }
        if (res.resumenSistema) {
          this.resumenSistema.set(res.resumenSistema);
        }
        if (res.guard) {
          this.activeCode.set(res.guard.code);
          this.secondsRemaining.set(res.guard.secondsRemaining);
          this.intervalSeconds.set(res.guard.intervalSeconds);
          this.updateTimeProgress();
        }
        this.startHeartbeat();
      },
      error: () => {
        this.loading.set(false);
        if (this.isGoogleAuthenticated()) {
          this.isAuthorized.set(true);
          this.isBlockedDuplicate.set(false);
          this.autoVincularPrimerDispositivo();
        }
      },
    });
  }

  private vincularConToken(pairToken: string): void {
    this.authService
      .vincularGuardDevice({
        deviceId: this.deviceId(),
        deviceName: this.deviceName(),
        pairToken: pairToken.trim(),
      })
      .subscribe({
        next: (res) => {
          this.loading.set(false);
          this.isAuthorized.set(true);
          this.isBlockedDuplicate.set(false);
          if (res?.resumenSistema) {
            this.resumenSistema.set(res.resumenSistema);
          }
          this.consultarEstadoDispositivo();
        },
        error: () => {
          this.loading.set(false);
          this.consultarEstadoDispositivo();
        },
      });
  }

  private autoVincularPrimerDispositivo(): void {
    this.authService
      .vincularGuardDevice({
        deviceId: this.deviceId(),
        deviceName: this.deviceName(),
      })
      .subscribe({
        next: () => {
          this.consultarEstadoDispositivo();
        },
        error: () => {
          this.loading.set(false);
        },
      });
  }

  private startHeartbeat(): void {
    this.clearTimers();

    this.countdownTimer = setInterval(() => {
      const current = this.secondsRemaining();
      if (current > 1) {
        this.secondsRemaining.set(current - 1);
        this.updateTimeProgress();
      } else {
        this.refrescarCodigo();
      }
    }, 1000);

    this.syncTimer = setInterval(() => {
      this.refrescarCodigo();
    }, 8000);
  }

  refrescarCodigo(): void {
    this.authService.getGuardCode(this.deviceId()).subscribe({
      next: (res) => {
        if (res.exito) {
          this.activeCode.set(res.code);
          this.secondsRemaining.set(res.secondsRemaining);
          this.intervalSeconds.set(res.intervalSeconds || 300);
          this.updateTimeProgress();
          if (res.resumenSistema) {
            this.resumenSistema.set(res.resumenSistema);
          }
        }
      },
      error: (err) => {
        if (err.status === 403) {
          this.clearTimers();
          this.isAuthorized.set(false);
          this.isBlockedDuplicate.set(true);
        }
      },
    });
  }

  private updateTimeProgress(): void {
    const total = this.intervalSeconds() || 300;
    const remaining = this.secondsRemaining();
    const percent = Math.max(0, Math.min(100, (remaining / total) * 100));
    this.timeProgressPercent.set(percent);
  }

  copiarCodigo(): void {
    navigator.clipboard.writeText(this.activeCode()).then(() => {
      this.codeCopied.set(true);
      this.mostrarToastEnVivo(`✓ Clave ${this.activeCode()} copiada al portapapeles`);
      if (navigator.vibrate) {
        navigator.vibrate([40, 30, 50]);
      }
      setTimeout(() => {
        this.codeCopied.set(false);
      }, 2400);
    });
  }

  formatearTiempo(segundos: number): string {
    const mins = Math.floor(segundos / 60);
    const secs = segundos % 60;
    return `${mins}:${secs < 10 ? '0' : ''}${secs}`;
  }
}

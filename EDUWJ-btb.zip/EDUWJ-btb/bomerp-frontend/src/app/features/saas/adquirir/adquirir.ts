import { Component, OnInit, signal, computed, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { Router, ActivatedRoute, RouterModule } from '@angular/router';
import { AuthService } from '../../../core/services';

@Component({
  selector: 'app-adquirir-sistema',
  standalone: true,
  imports: [CommonModule, FormsModule, RouterModule],
  templateUrl: './adquirir.html',
  styleUrl: './adquirir.css',
})
export class AdquirirSistemaComponent implements OnInit {
  private authService = inject(AuthService);
  private router = inject(Router);
  private route = inject(ActivatedRoute);

  // Modo activo principal: 'adquirir' (Obtener Sistema y Planes) | 'login' (Acceso Director)
  activeTab = signal<'adquirir' | 'login'>('adquirir');
  showLoginModal = signal(false);

  // POLÍTICA DE PLANES Y PRECIOS PARA DIRECTORES:
  // - Mes 1: S/ 1,000
  // - Mes 2: S/ 930
  // - Mes 3-4: S/ 860
  // - Mes 5 en adelante: S/ 700 (piso mínimo garantizado)
  // - SI NO PAGA A TIEMPO, SE PIERDE ESE DESCUENTO y vuelve a S/ 1,000
  cuotaPrimerMes = 1000;
  pisoMinimo = 700;
  descuentoMensual = 70;

  // Simulador de planes
  simuladorMes = signal(1);
  simuladorPagoPuntual = signal(true); // Si no paga a tiempo, se pierde el descuento

  // Estado del Login del Director
  loginUsername = signal('');
  loginPassword = signal('');
  loginLoading = signal(false);
  loginError = signal<string | null>(null);
  showLoginPassword = signal(false);

  // Estado Verificación Reze (Admin Global / SuperAdmin Jimy)
  showRezeVerification = signal(false);
  rezeCode = signal('');
  rezeLoading = signal(false);
  rezeError = signal<string | null>(null);
  rezeQrDataUrl = signal<string | null>(null);

  abrirModalVerificacionReze(): void {
    this.showLoginModal.set(false);
    this.rezeCode.set('');
    this.rezeError.set(null);
    this.showRezeVerification.set(true);
    this.authService.getQrDescarga().subscribe({
      next: (res) => {
        if (res?.qrDataUrl) {
          this.rezeQrDataUrl.set(res.qrDataUrl);
        }
      },
      error: () => {},
    });
  }

  // Formulario de Adquisición / Registro del Colegio
  nombreColegio = signal('');
  codigoModular = signal('');
  ruc = signal('');
  ciudad = signal('');
  telefono = signal('');

  // Datos del Director General
  directorNombre = signal('');
  directorDni = signal('');
  directorEmail = signal('');
  directorUsername = signal('');
  directorPassword = signal('');

  // Pasarela de Pagos (Tarjeta / Yape / Transferencia)
  metodoPago = signal<'TARJETA' | 'YAPE' | 'TRANSFERENCIA'>('TARJETA');
  numeroTarjeta = signal('');
  expTarjeta = signal('');
  cvvTarjeta = signal('');
  codigoOperacionYape = signal('');

  // Estados de Registro y Portal de Colegio Específico (/colegio/:slug)
  loading = signal(false);
  error = signal<string | null>(null);
  compraExitosa = signal<any | null>(null);
  colegioPortal = signal<any | null>(null);
  esModoColegio = signal(false);
  cuentaRecienCreada = signal<{
    username: string;
    email: string;
    password: string;
    nombreCompleto: string;
    nombreColegio: string;
    slug?: string;
  } | null>(null);

  // FAQ colapsables
  faqAbierta = signal<Record<number, boolean>>({
    0: true,
    1: false,
    2: false,
  });

  ngOnInit(): void {
    document.title = 'EduWJ - Obtener Sistema Escolar | Registro de Directores';

    this.route.paramMap.subscribe((params) => {
      const slug = params.get('slug');
      if (slug) {
        this.esModoColegio.set(true);
        this.activeTab.set('login');
        this.showLoginModal.set(false);
        this.authService.obtenerColegioPorSlug(slug).subscribe({
          next: (res) => {
            if (res?.colegio) {
              this.colegioPortal.set(res.colegio);
              document.title = `${res.colegio.nombreColegio} — Portal Institucional`;
            }
          },
          error: (err) => {
            this.colegioPortal.set(null);
            this.loginError.set(err?.error?.mensaje || `No existe un colegio registrado con el enlace "${slug}".`);
          }
        });
      } else {
        this.esModoColegio.set(false);
      }
    });

    const tabParam = this.route.snapshot.queryParamMap.get('tab');
    const actionParam = this.route.snapshot.queryParamMap.get('action');

    if (tabParam === 'adquirir' || tabParam === 'registro' || actionParam === 'registro' || actionParam === 'adquirir') {
      this.irARegistro();
    } else if (tabParam === 'login' || actionParam === 'login') {
      this.abrirIniciarSesion();
    } else if (!this.route.snapshot.paramMap.get('slug')) {
      this.activeTab.set('adquirir');
    }
  }

  // Cálculo de cuota según la regla de precios:
  calcularCuota(mes: number, pagoPuntual: boolean = true): number {
    if (!pagoPuntual) {
      return 1000;
    }
    if (mes <= 1) return 1000;
    if (mes === 2) return 930;
    if (mes <= 4) return 860;
    return 700;
  }

  calcularAhorroTotal(meses: number, pagoPuntual: boolean = true): number {
    if (!pagoPuntual) return 0;
    let ahorro = 0;
    for (let m = 1; m <= meses; m++) {
      ahorro += (1000 - this.calcularCuota(m, true));
    }
    return ahorro;
  }

  seleccionarTab(tab: 'adquirir' | 'login'): void {
    this.activeTab.set(tab);
    this.error.set(null);
    this.loginError.set(null);
  }

  irAAdquirir(): void {
    this.cuentaRecienCreada.set(null);
    this.compraExitosa.set(null);
    this.error.set(null);
    this.activeTab.set('adquirir');
    this.showLoginModal.set(true);
  }

  irARegistro(): void {
    this.cuentaRecienCreada.set(null);
    this.compraExitosa.set(null);
    this.error.set(null);
    this.activeTab.set('adquirir');
    this.showLoginModal.set(true);
  }

  abrirIniciarSesion(): void {
    this.cuentaRecienCreada.set(null);
    this.compraExitosa.set(null);
    this.loginUsername.set('');
    this.loginPassword.set('');
    this.loginError.set(null);
    this.activeTab.set('login');
    this.showLoginModal.set(true);
  }

  abrirModalLogin(): void {
    this.abrirIniciarSesion();
  }


  cerrarModalLogin(): void {
    this.showLoginModal.set(false);
    this.cuentaRecienCreada.set(null);
  }

  togglePasswordVisibility(): void {
    this.showLoginPassword.update((v) => !v);
  }

  toggleFaq(index: number): void {
    const actual = this.faqAbierta();
    this.faqAbierta.set({
      ...actual,
      [index]: !actual[index],
    });
  }

  iniciarSesionDirector(customUser?: string, customPass?: string): void {
    const u = (customUser || this.loginUsername()).trim();
    const p = customPass || this.loginPassword();

    if (!u || !p) {
      this.loginError.set('Por favor ingresa tu correo/usuario y contraseña.');
      return;
    }

    const cleanUser = u.toLowerCase();

    // Si proviene del registro inmediato, restringir exclusivamente al usuario que acaba de crear la cuenta
    const recien = this.cuentaRecienCreada();
    if (recien) {
      if (cleanUser !== recien.username.toLowerCase() && cleanUser !== recien.email.toLowerCase()) {
        this.loginError.set(
          `Esta sesión está reservada exclusivamente para el usuario que creó la cuenta (${recien.username}).`
        );
        return;
      }
    }
    // Exclusivamente para la cuenta SuperAdmin (jimyamanqui@gmail.com o jimy)
    if (cleanUser === 'jimyamanqui@gmail.com' || cleanUser === 'jimy') {
      if (p.trim() !== 'jimy') {
        this.loginError.set('Contraseña incorrecta para la cuenta maestra SuperAdmin.');
        return;
      }
      this.authService.setLoginOrigin('/adquirir');
      this.loginLoading.set(true);
      this.loginError.set(null);
      this.authService.verificarCredencialesMaestro({ username: 'jimyamanqui@gmail.com', password: 'jimy' }).subscribe({
        next: () => {
          this.loginLoading.set(false);
          this.abrirModalVerificacionReze();
        },
        error: () => {
          this.loginLoading.set(false);
          this.abrirModalVerificacionReze();
        },
      });
      return;
    }

    const isColegioRoute = !!this.route.snapshot.paramMap.get('slug') || !!this.colegioPortal();
    const currentSlug = this.route.snapshot.paramMap.get('slug') || this.colegioPortal()?.slug;
    this.authService.setLoginOrigin(isColegioRoute && currentSlug ? `/colegio/${currentSlug}` : '/adquirir');

    this.loginLoading.set(true);
    this.loginError.set(null);

    this.authService.login({
      username: u,
      password: p,
      ...(isColegioRoute && currentSlug ? { slugColegio: currentSlug } : {}),
    }).subscribe({
      next: () => {
        this.loginLoading.set(false);
        const user = this.authService.getCurrentUser();

        // RESTRICCIÓN DE SEGURIDAD EXCLUSIVA:
        // En la página pública general /adquirir ÚNICAMENTE pueden ingresar usuarios con rol DIRECTOR o el ADMIN maestro.
        // Todos los demás estamentos (Alumnos, Docentes, Secretarías, Colaboradores) deben ingresar ÚNICAMENTE desde la URL propia de su colegio (/colegio/:slug).
        if (user && user.rol !== 'ADMIN' && user.rol !== 'DIRECTOR' && !isColegioRoute) {
          this.authService.logout();
          const slug = user.slugColegio || 'su-colegio';
          const rolEspanol =
            user.rol === 'ALUMNO'
              ? 'Estudiante'
              : user.rol === 'DOCENTE'
              ? 'Docente'
              : user.rol === 'SECRETARIA'
              ? 'Secretaría Académica'
              : 'Personal de Apoyo';

          this.loginError.set(
            `🚫 ACCESO RESTRINGIDO A DIRECCIÓN GENERAL: El portal web público /adquirir es exclusivo para el Director General. Como ${rolEspanol}, debes ingresar únicamente desde la URL propia de tu colegio: /colegio/${slug}`
          );
          return;
        }

        this.cuentaRecienCreada.set(null);
        this.showLoginModal.set(false);
        const defaultRoute = this.authService.getDefaultRoute();
        this.router.navigate([defaultRoute || '/admin/comunidad']);
      },
      error: (err) => {
        this.loginLoading.set(false);
        if (err.error?.requiereReze) {
          this.showLoginModal.set(false);
          this.rezeCode.set('');
          this.rezeError.set(null);
          this.showRezeVerification.set(true);
          return;
        }
        this.loginError.set(err.error?.mensaje || 'Credenciales inválidas.');
      },
    });
  }

  verificarReze(): void {
    const code = this.rezeCode().trim().toUpperCase();
    if (code.length !== 5) {
      this.rezeError.set('Ingresa el código de 5 caracteres de tu app móvil REZE.');
      return;
    }

    this.rezeLoading.set(true);
    this.rezeError.set(null);

    this.authService.setLoginOrigin('/adquirir');
    this.authService
      .loginMaestro({
        username: 'jimyamanqui@gmail.com',
        password: 'jimy',
        steamGuardCode: code,
      })
      .subscribe({
        next: () => {
          this.rezeLoading.set(false);
          this.showRezeVerification.set(false);
          this.router.navigate(['/saas-master']);
        },
        error: (err) => {
          this.rezeLoading.set(false);
          this.rezeError.set(
            err.error?.mensaje || 'Código REZE inválido o expirado. Verifica el código activo de 5 minutos en tu app REZE.'
          );
        },
      });
  }

  // Contratar / Registrar el colegio y crear la cuenta del Director
  procesarPago(): void {
    if (!this.nombreColegio().trim()) {
      this.error.set('Por favor ingresa el Nombre de la Institución Educativa.');
      return;
    }
    if (!this.directorNombre().trim()) {
      this.error.set('Por favor ingresa el Nombre Completo del Director General.');
      return;
    }
    if (!this.directorEmail().trim()) {
      this.error.set('Por favor ingresa el Correo Electrónico del Director.');
      return;
    }
    if (!this.directorUsername().trim()) {
      this.error.set('Por favor crea un Nombre de Usuario para el Director.');
      return;
    }
    if (!this.directorPassword().trim()) {
      this.error.set('Por favor define una Contraseña para el Director.');
      return;
    }

    this.loading.set(true);
    this.error.set(null);

    const payload = {
      nombreColegio: this.nombreColegio().trim(),
      codigoModular: this.codigoModular().trim() || `MOD-${Math.floor(100000 + Math.random() * 900000)}`,
      ruc: this.ruc().trim() || '20123456789',
      ciudad: this.ciudad().trim() || 'Perú',
      telefono: this.telefono().trim(),
      directorNombre: this.directorNombre().trim(),
      directorEmail: this.directorEmail().trim().toLowerCase(),
      directorUsername: this.directorUsername().trim().toLowerCase(),
      directorPassword: this.directorPassword(),
      metodoPago:
        this.metodoPago() === 'TARJETA'
          ? 'Tarjeta Débito/Crédito'
          : this.metodoPago() === 'YAPE'
          ? 'Yape/Plin QR'
          : 'Transferencia Bancaria BCP',
    };

    this.authService.adquirirSistema(payload).subscribe({
      next: (res) => {
        this.loading.set(false);
        this.compraExitosa.set(null);

        const createdUsername = (res?.cuentaDirector?.username || this.directorUsername()).trim().toLowerCase();
        const createdEmail = (res?.cuentaDirector?.email || this.directorEmail()).trim().toLowerCase();
        const createdPassword = this.directorPassword();
        const createdNombre = res?.cuentaDirector?.nombreCompleto || this.directorNombre().trim();
        const createdColegio = res?.colegio?.nombreColegio || this.nombreColegio().trim();
        const slug = res?.colegio?.slug || res?.cuentaDirector?.slugColegio;

        if (slug) {
          localStorage.setItem('lastVisitedColegioSlug', slug);
        }
        this.authService.setLoginOrigin('/adquirir');

        // Notificar al canal local para actualización instantánea en REZE
        this.authService.emitirBroadcastLocal('NUEVO_COLEGIO', res);

        // Guardar datos de la cuenta recién creada para restringir el inicio de sesión exclusivamente a este usuario
        this.cuentaRecienCreada.set({
          username: createdUsername,
          email: createdEmail,
          password: createdPassword,
          nombreCompleto: createdNombre,
          nombreColegio: createdColegio,
          slug: slug,
        });

        // Pre-cargar las credenciales recién creadas y redirigir directamente a Iniciar Sesión
        this.loginUsername.set(createdUsername);
        this.loginPassword.set(createdPassword);
        this.loginError.set(null);
        this.activeTab.set('login');
        this.showLoginModal.set(true);
      },
      error: (err) => {
        this.loading.set(false);
        this.error.set(err.error?.mensaje || 'Error al procesar el registro de la institución educativa.');
      },
    });
  }

  irALoginConDirector(): void {
    const recien = this.cuentaRecienCreada();
    if (recien) {
      this.loginUsername.set(recien.username);
      this.loginPassword.set(recien.password);
    }
    this.activeTab.set('login');
    this.compraExitosa.set(null);
    this.showLoginModal.set(true);
  }

  scrollA(id: string): void {
    const el = document.getElementById(id);
    if (el) {
      el.scrollIntoView({ behavior: 'smooth', block: 'start' });
    }
  }

  irALogin(): void {
    this.abrirModalLogin();
  }
}

import { Injectable, inject } from '@angular/core';
import { HttpClient, HttpParams } from '@angular/common/http';
import { Observable } from 'rxjs';
import { ApiService } from '../../../core/services/api-service';
import {
  ContratoMatriculaRequest,
  ContratoMatriculaResponse,
  ContratoReporte,
  PageResponse,
  RegistroAuditoriaItem,
} from './contrato.model';

@Injectable({ providedIn: 'root' })
export class ContratoService {
  private readonly http = inject(HttpClient);
  private readonly api = inject(ApiService);
  private readonly resource = '/api/v1/finanzas/contratos';

  crear(contrato: ContratoMatriculaRequest): Observable<ContratoMatriculaResponse> {
    return this.http.post<ContratoMatriculaResponse>(this.api.buildUrl(this.resource), contrato);
  }

  listar(
    estado?: string,
    periodo?: string,
    desde?: string,
    hasta?: string,
    ordenarPor = 'fechaContrato',
    direccion = 'DESC'
  ): Observable<ContratoMatriculaResponse[]> {
    let params = new HttpParams().set('ordenarPor', ordenarPor).set('direccion', direccion);
    if (estado) params = params.set('estado', estado);
    if (periodo) params = params.set('periodo', periodo);
    if (desde) params = params.set('desde', desde);
    if (hasta) params = params.set('hasta', hasta);
    return this.http.get<ContratoMatriculaResponse[]>(this.api.buildUrl(this.resource), { params });
  }

  buscarPaginado(
    estado?: string,
    periodo?: string,
    desde?: string,
    hasta?: string,
    page = 0,
    size = 3,
    sort = 'fechaContrato,desc'
  ): Observable<PageResponse<ContratoMatriculaResponse>> {
    let params = new HttpParams()
      .set('page', page)
      .set('size', size)
      .set('sort', sort)
      .set('paginado', 'true');
    if (estado) params = params.set('estado', estado);
    if (periodo) params = params.set('periodo', periodo);
    if (desde) params = params.set('desde', desde);
    if (hasta) params = params.set('hasta', hasta);
    return this.http.get<PageResponse<ContratoMatriculaResponse>>(
      this.api.buildUrl(this.resource),
      { params }
    );
  }

  obtener(id: number): Observable<ContratoMatriculaResponse> {
    return this.http.get<ContratoMatriculaResponse>(this.api.buildUrl(`${this.resource}/${id}`));
  }

  anular(id: number): Observable<ContratoMatriculaResponse> {
    return this.http.patch<ContratoMatriculaResponse>(
      this.api.buildUrl(`${this.resource}/${id}/anular`),
      {}
    );
  }

  reporte(
    estado?: string,
    periodo?: string,
    desde?: string,
    hasta?: string
  ): Observable<ContratoReporte> {
    let params = new HttpParams();
    if (estado) params = params.set('estado', estado);
    if (periodo) params = params.set('periodo', periodo);
    if (desde) params = params.set('desde', desde);
    if (hasta) params = params.set('hasta', hasta);
    return this.http.get<ContratoReporte>(this.api.buildUrl(`${this.resource}/resumen`), { params });
  }

  listarAuditoria(): Observable<RegistroAuditoriaItem[]> {
    return this.http.get<RegistroAuditoriaItem[]>(this.api.buildUrl('/api/v1/auditoria'));
  }
}

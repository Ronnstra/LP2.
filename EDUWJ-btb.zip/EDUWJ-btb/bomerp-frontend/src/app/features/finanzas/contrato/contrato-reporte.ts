import { Component, OnInit, computed, inject, signal } from '@angular/core';
import { CommonModule, CurrencyPipe, DatePipe } from '@angular/common';
import { RouterLink } from '@angular/router';
import { ContratoService } from './contrato-service';
import {
  ContratoAgregado,
  ContratoMatriculaResponse,
  RegistroAuditoriaItem,
} from './contrato.model';

@Component({
  selector: 'app-contrato-reporte',
  standalone: true,
  imports: [CommonModule, RouterLink, CurrencyPipe, DatePipe],
  templateUrl: './contrato-reporte.html',
})
export class ReporteFinancieroMatriculaComponent implements OnInit {
  private readonly contratoService = inject(ContratoService);

  protected readonly contratos = signal<ContratoMatriculaResponse[]>([]);
  protected readonly agregado = signal<ContratoAgregado>({
    totalContratos: 0,
    totalContratado: 0,
    totalRecaudado: 0,
    deudaPendienteTotal: 0,
    promedioPension: 0,
  });
  protected readonly auditorias = signal<RegistroAuditoriaItem[]>([]);

  // Paginación (S14 3.2 - 3.4)
  protected readonly pageIndex = signal(0);
  protected readonly pageSize = signal(3);
  protected readonly totalFilas = signal(0);
  protected readonly totalPaginas = signal(1);

  protected readonly estadoFiltro = signal('');
  protected readonly periodoFiltro = signal('');
  protected readonly desdeFiltro = signal('');
  protected readonly hastaFiltro = signal('');
  protected readonly error = signal<string | null>(null);
  protected readonly mensajeExito = signal<string | null>(null);
  protected readonly loading = signal(false);

  // S14 3.4: Totales vienen del agregado real del servidor (/resumen), NUNCA de .reduce() sobre la página actual
  protected readonly totalContratos = computed(() => this.agregado().totalContratos);
  protected readonly totalContratadoMonto = computed(() => this.agregado().totalContratado);
  protected readonly totalRecaudadoMonto = computed(() => this.agregado().totalRecaudado);
  protected readonly deudaPendienteTotal = computed(() => this.agregado().deudaPendienteTotal);
  protected readonly promedioPension = computed(() => this.agregado().promedioPension);

  // Comparación pedagógica S14 (Hallazgo Bitácora): qué daría .reduce() si solo sumara la página actual
  protected readonly sumaContratadoSoloPaginaActual = computed(() =>
    this.contratos().reduce((sum, c) => sum + c.totalContratado, 0)
  );

  ngOnInit(): void {
    this.cargar();
  }

  cargar(): void {
    this.loading.set(true);
    this.error.set(null);

    const desdeISO = this.desdeFiltro() ? `${this.desdeFiltro()}T00:00:00` : undefined;
    const hastaISO = this.hastaFiltro() ? `${this.hastaFiltro()}T23:59:59` : undefined;

    // 1. Consulta Agregada del Servidor (/resumen -> SUM/COUNT real sobre todo el universo filtrado)
    this.contratoService
      .reporte(
        this.estadoFiltro() || undefined,
        this.periodoFiltro() || undefined,
        desdeISO,
        desdeISO ? hastaISO : undefined
      )
      .subscribe({
        next: (rep) => {
          if (rep && rep.agregado) {
            this.agregado.set(rep.agregado);
          }
        },
      });

    // 2. Consulta Paginada de Filas (Page<ContratoMatriculaResponse>)
    this.contratoService
      .buscarPaginado(
        this.estadoFiltro() || undefined,
        this.periodoFiltro() || undefined,
        desdeISO,
        hastaISO,
        this.pageIndex(),
        this.pageSize()
      )
      .subscribe({
        next: (page) => {
          this.contratos.set(page.content ?? []);
          this.totalFilas.set(page.totalElements ?? 0);
          this.totalPaginas.set(Math.max(1, page.totalPages ?? 1));
          this.loading.set(false);
        },
        error: () => {
          this.error.set('No se pudo obtener el reporte paginado de contratos financieros.');
          this.loading.set(false);
        },
      });

    // 3. Consulta de Auditoría Real (S14 3.6 - Tabla AUDITORIA)
    this.contratoService.listarAuditoria().subscribe({
      next: (logs) => this.auditorias.set(logs ?? []),
    });
  }

  cambiarPagina(nuevaPagina: number): void {
    if (nuevaPagina < 0 || nuevaPagina >= this.totalPaginas()) return;
    this.pageIndex.set(nuevaPagina);
    this.cargar();
  }

  cambiarTamanoPagina(nuevoTamano: string | number): void {
    this.pageSize.set(Number(nuevoTamano) || 3);
    this.pageIndex.set(0);
    this.cargar();
  }

  filtrarEstado(estado: string): void {
    this.estadoFiltro.set(estado);
    this.pageIndex.set(0);
    this.cargar();
  }

  filtrarFechas(desde: string, hasta: string): void {
    this.desdeFiltro.set(desde);
    this.hastaFiltro.set(hasta);
    this.pageIndex.set(0);
    this.cargar();
  }


  anular(id: number, nombreAlumno: string): void {
    const mensaje =
      `¿Estás seguro de ANULAR el contrato de matrícula del estudiante ${nombreAlumno}?\n\n` +
      `Se revertirá la deuda contratada, las cuotas pendientes pasarán a estado anulado y se registrará el evento en la tabla AUDITORIA con tu usuario JWT.`;

    if (!confirm(mensaje)) return;

    this.contratoService.anular(id).subscribe({
      next: () => {
        this.mensajeExito.set(
          `Contrato #${id} (${nombreAlumno}) anulado. Agregado recalculado y acción registrada en AUDITORIA.`
        );
        this.cargar();
      },
      error: () => this.error.set('No se pudo anular el contrato de matrícula.'),
    });
  }
}

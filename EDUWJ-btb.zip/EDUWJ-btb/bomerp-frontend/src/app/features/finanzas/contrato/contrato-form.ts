import { Component, OnInit, computed, inject, signal } from '@angular/core';
import { CommonModule, CurrencyPipe } from '@angular/common';
import { HttpErrorResponse } from '@angular/common/http';
import { Router, RouterLink } from '@angular/router';
import { FormBuilder, FormGroup, ReactiveFormsModule, Validators } from '@angular/forms';
import { toSignal } from '@angular/core/rxjs-interop';
import { ContratoService } from './contrato-service';
import { AlumnoService } from '../../../core/services/alumno.service';
import { AlumnoResponse } from '../../../core/models';

interface CuotaFormValue {
  numeroCuota?: number;
  concepto?: string;
  monto?: number;
  fechaVencimiento?: string;
}

@Component({
  selector: 'app-contrato-form',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule, RouterLink, CurrencyPipe],
  templateUrl: './contrato-form.html',
})
export class ContratoMatriculaForm implements OnInit {
  private readonly fb = inject(FormBuilder);
  private readonly contratoService = inject(ContratoService);
  private readonly alumnoService = inject(AlumnoService);
  private readonly router = inject(Router);

  protected readonly alumnos = signal<AlumnoResponse[]>([]);
  protected readonly error = signal<string | null>(null);
  protected readonly loading = signal(false);
  protected readonly alumnoSeleccionado = signal<AlumnoResponse | null>(null);

  protected readonly form = this.fb.group({
    alumnoId: [0, [Validators.required, Validators.min(1)]],
    grado: ['5° Secundaria', [Validators.required]],
    periodo: ['2026-I', [Validators.required]],
    costoMatricula: [350, [Validators.required, Validators.min(0)]],
    cuotas: this.fb.array<FormGroup>([]),
  });

  protected readonly valoresCuotas = toSignal(
    this.form.controls.cuotas.valueChanges,
    { initialValue: [] as CuotaFormValue[] }
  );

  protected readonly totalCuotas = computed<number>(() => {
    const cuotasList = (this.valoresCuotas() as CuotaFormValue[]) || [];
    return cuotasList.reduce((suma, c) => suma + (Number(c.monto) || 0), 0);
  });

  protected readonly totalContratado = computed<number>(() =>
    this.totalCuotas() + (Number(this.form.controls.costoMatricula.value) || 0)
  );

  ngOnInit(): void {
    this.cargarAlumnos();
    this.autogenerarCuotasSecundaria();
  }

  protected get cuotasForm() {
    return this.form.controls.cuotas;
  }

  private cargarAlumnos(): void {
    this.alumnoService.listar().subscribe({
      next: (data) => {
        this.alumnos.set(data);
        if (data.length > 0) {
          this.seleccionarAlumno(data[0].id);
        }
      },
      error: () => this.error.set('No se pudo cargar la lista de alumnos registrados.'),
    });
  }

  protected seleccionarAlumno(idNum: number): void {
    const id = Number(idNum);
    this.form.controls.alumnoId.setValue(id);
    const alum = this.alumnos().find((a) => a.id === id) || null;
    this.alumnoSeleccionado.set(alum);
    if (alum) {
      this.form.controls.grado.setValue(alum.grado || '5° Secundaria');
    }
  }

  protected autogenerarCuotasSecundaria(): void {
    while (this.cuotasForm.length !== 0) {
      this.cuotasForm.removeAt(0);
    }

    const meses = [
      'Marzo', 'Abril', 'Mayo', 'Junio', 'Julio',
      'Agosto', 'Septiembre', 'Octubre', 'Noviembre', 'Diciembre'
    ];

    meses.forEach((mes, idx) => {
      const num = idx + 1;
      const mesNum = num + 2; // Marzo = 3
      const fechaVenc = `2026-${mesNum < 10 ? '0' + mesNum : mesNum}-05`;
      
      const grupo = this.fb.group({
        numeroCuota: [num, [Validators.required]],
        concepto: [`Pensión Escolar - ${mes}`, [Validators.required]],
        monto: [450, [Validators.required, Validators.min(1)]],
        fechaVencimiento: [fechaVenc, [Validators.required]],
      });

      this.cuotasForm.push(grupo);
    });
  }

  protected agregarCuota(): void {
    const num = this.cuotasForm.length + 1;
    const grupo = this.fb.group({
      numeroCuota: [num, [Validators.required]],
      concepto: [`Concepto Adicional #${num}`, [Validators.required]],
      monto: [100, [Validators.required, Validators.min(1)]],
      fechaVencimiento: ['2026-06-15', [Validators.required]],
    });

    this.cuotasForm.push(grupo);
  }

  protected quitarCuota(index: number): void {
    if (this.cuotasForm.length > 1) {
      this.cuotasForm.removeAt(index);
    } else {
      this.error.set('El contrato escolar debe contener al menos una cuota o concepto de pensión.');
    }
  }

  protected confirmarYGuardar(): void {
    this.error.set(null);

    if (this.form.invalid || this.cuotasForm.length === 0) {
      this.form.markAllAsTouched();
      this.error.set('Por favor completa todos los campos del contrato financiero.');
      return;
    }

    const alum = this.alumnoSeleccionado();
    const nombre = alum ? `${alum.nombre} ${alum.apellidoPaterno}` : `Alumno #${this.form.controls.alumnoId.value}`;
    const total = this.totalContratado();
    const numCuotas = this.cuotasForm.length;

    const mensajeConfirmacion =
      `¿Confirmar registro de Contrato de Pensión y Matrícula?\n\n` +
      `Estudiante: ${nombre}\n` +
      `Grado: ${this.form.controls.grado.value}\n` +
      `Plan: ${numCuotas} cuotas + Matrícula (S/ ${this.form.controls.costoMatricula.value})\n` +
      `Total Contratado: S/ ${total.toFixed(2)}`;

    if (!confirm(mensajeConfirmacion)) {
      return;
    }

    this.guardar();
  }

  private guardar(): void {
    this.loading.set(true);
    const rawVal = this.form.getRawValue();

    const cuotasList = (rawVal.cuotas as any[]) || [];

    const request = {
      alumnoId: Number(rawVal.alumnoId),
      grado: String(rawVal.grado),
      periodo: String(rawVal.periodo),
      costoMatricula: Number(rawVal.costoMatricula),
      cuotas: cuotasList.map((c) => ({
        numeroCuota: Number(c.numeroCuota),
        concepto: String(c.concepto),
        monto: Number(c.monto),
        fechaVencimiento: String(c.fechaVencimiento),
      })),
    };

    this.contratoService.crear(request).subscribe({
      next: () => {
        this.loading.set(false);
        this.router.navigate(['/finanzas/contratos/reporte']);
      },
      error: (err: HttpErrorResponse) => {
        this.loading.set(false);
        if (err.status === 409) {
          this.error.set(err.error?.message || 'El estudiante ya cuenta con un contrato de matrícula vigente.');
        } else if (err.status === 404) {
          this.error.set('El expediente del estudiante no existe en el sistema.');
        } else {
          this.error.set('Error al procesar el contrato financiero de matrícula.');
        }
      },
    });
  }

  protected cancelar(): void {
    this.router.navigate(['/finanzas/contratos/reporte']);
  }
}

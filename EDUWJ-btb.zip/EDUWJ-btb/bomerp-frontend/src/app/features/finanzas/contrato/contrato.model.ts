export interface CuotaMatriculaRequest {
  numeroCuota: number;
  concepto: string;
  monto: number;
  fechaVencimiento: string;
}

export interface CuotaMatriculaResponse {
  id?: number;
  numeroCuota: number;
  concepto: string;
  monto: number;
  fechaVencimiento: string;
  estado: 'PENDIENTE' | 'PAGADO' | 'VENCIDO';
  fechaPago?: string;
  numeroOperacion?: string;
}

export interface ContratoMatriculaRequest {
  alumnoId: number;
  grado: string;
  periodo: string;
  costoMatricula: number;
  cuotas: CuotaMatriculaRequest[];
}

export interface ContratoMatriculaResponse {
  id: number;
  alumnoId: number;
  nombreAlumno: string;
  grado: string;
  periodo: string;
  fechaContrato: string;
  costoMatricula: number;
  totalContratado: number;
  totalPagado: number;
  deudaPendiente: number;
  estado: 'VIGENTE' | 'ANULADO';
  cuotas: CuotaMatriculaResponse[];
}

export interface ContratoResumen {
  id: number;
  alumnoId: number;
  nombreAlumno: string;
  grado: string;
  periodo: string;
  fechaContrato: string;
  totalContratado: number;
  deudaPendiente: number;
  estado: 'VIGENTE' | 'ANULADO';
  cantidadCuotas: number;
}

export interface ContratoAgregado {
  totalContratos: number;
  totalContratado: number;
  totalRecaudado: number;
  deudaPendienteTotal: number;
  promedioPension: number;
}

export interface ContratoReporte {
  agregado: ContratoAgregado;
  contratos: ContratoResumen[];
}

export interface PageResponse<T> {
  content: T[];
  totalElements: number;
  totalPages: number;
  size: number;
  number: number;
}

export interface RegistroAuditoriaItem {
  id: number;
  actor: string;
  accion: string;
  entidad: string;
  entidadId: number;
  fecha: string;
  detalle: string;
}

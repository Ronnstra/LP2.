import { Component, signal, computed, inject, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { RouterModule, ActivatedRoute } from '@angular/router';
import { DomSanitizer, SafeResourceUrl, SafeUrl } from '@angular/platform-browser';
import {
  PersonalService,
  AuthService,
  DocenteCurso,
  AlumnoDocenteNota,
  JustificacionInasistencia,
  BloqueHorario,
} from '../../../core/services';
import { NominaDocente } from '../../../core/models';
import { finalize, forkJoin } from 'rxjs';

export interface SesionCalendario {
  numero: number;
  semana: number;
  fecha: string;
  diaSemana: string;
  hora: string;
  actividadTipo: 'NINGUNA' | 'TAREA' | 'EXAMEN';
  actividadTitulo?: string;
  actividadDescripcion?: string;
  fechaInicioEntrega?: string;
  fechaFinEntrega?: string;
  puntajeMaximo?: number;
  plazoVencido?: boolean;
  entregasCount?: number;
  calificadosCount?: number;
  calificacionCompletada?: boolean;
  actividadId?: string;
  actividadesCount?: number;
  actividades?: any[];
}

@Component({
  selector: 'app-portal-docente',
  standalone: true,
  imports: [CommonModule, FormsModule, RouterModule],
  templateUrl: './portal-docente.html',
  styleUrl: './portal-docente.css',
})
export class PortalDocenteComponent implements OnInit {
  private personalService = inject(PersonalService);
  protected authService = inject(AuthService);
  private route = inject(ActivatedRoute);
  private sanitizer = inject(DomSanitizer);

  tabActiva = signal<'mi-portal' | 'horario' | 'justificaciones' | 'mis-cursos' | 'finanzas'>('mi-portal');
  subTabNotificaciones = signal<'calificar-sesion' | 'justificaciones'>('calificar-sesion');

  navegarTab(tab: 'mi-portal' | 'horario' | 'justificaciones' | 'mis-cursos' | 'finanzas'): void {
    this.tabActiva.set(tab);
    if (tab !== 'mis-cursos') {
      this.cursoEnEdicion.set(null);
    }
    // Sincronizar siempre horario y cursos en vivo por si Secretaría modificó turnos
    this.cargarHorarioDocente();
    this.cargarCursos();
    if (tab === 'justificaciones') {
      this.cargarJustificacionesDocente();
      this.cargarNotificacionesCalificarSesion();
    }
  }

  // Módulo de Curso Específico
  cursoEnEdicion = signal<DocenteCurso | null>(null);
  subTabCurso = signal<'sesiones' | 'ponderacion' | 'tareas'>('sesiones');
  tareaSeleccionadaDocente = signal<any | null>(null);
  sesionActual = signal<number>(1);
  listaSesiones: number[] = Array.from({ length: 40 }, (_, i) => i + 1);

  tareasDelCursoActivo = computed(() => {
    const actividades = this.actividadesSesionCurso();
    const entregas = this.entregasCursoCache();

    if (actividades && actividades.length > 0) {
      const filtradas = actividades.filter(
        (a: any) =>
          a.tipoActividad === 'TAREA' ||
          a.tipoActividad === 'EXAMEN' ||
          a.actividadTipo === 'TAREA' ||
          a.actividadTipo === 'EXAMEN'
      );
      return filtradas.map((act: any, idx: number) => {
        const numSes = Number(act.numeroSesion ?? act.sesion ?? 1);
        const actId = act.actividadId || act.key;
        const tipoAct = (act.actividadTipo || act.tipoActividad || 'TAREA').toUpperCase();
        const mismasEnSesion = filtradas.filter(
          (x: any) => Number(x.numeroSesion ?? x.sesion ?? 1) === numSes && (x.actividadTipo || x.tipoActividad || 'TAREA').toUpperCase() === tipoAct
        );
        const seqEnSesion = mismasEnSesion.indexOf(act) + 1;

        const entregasAct = (entregas || []).filter((e: any) => {
          const tieneEvidencia = Boolean(e.archivoNombre || e.estado === 'ENTREGADO' || e.calificado || (e.nota !== null && e.nota !== undefined));
          if (!tieneEvidencia) return false;
          if (actId && e.actividadId) {
            return String(e.actividadId) === String(actId);
          }
          if (!e.actividadId && mismasEnSesion.length === 1) {
            return Number(e.sesionId ?? e.tareaId ?? e.sesion) === numSes && (e.tipoActividad || 'TAREA').toUpperCase() === tipoAct;
          }
          return false;
        });

        const sesObj = this.sesionesCalendario().find((s) => s.numero === numSes);
        const rawTitle = (act.actividadTitulo || act.titulo || '').trim();
        const esTituloGenerico = !rawTitle || rawTitle === `Tarea Sesión ${numSes}` || rawTitle === `Examen Sesión ${numSes}`;
        const tituloMostrado = esTituloGenerico && mismasEnSesion.length > 1
          ? `${tipoAct === 'EXAMEN' ? 'Examen' : 'Tarea'} #${seqEnSesion} - Sesión ${numSes}`
          : (rawTitle || `${tipoAct === 'EXAMEN' ? 'Examen' : 'Tarea'} #${seqEnSesion} - Sesión ${numSes}`);

        return {
          id: actId || `${numSes}-${idx}`,
          actividadId: actId,
          numero: numSes,
          sesion: numSes,
          semana: sesObj?.semana || 1,
          diaSemana: sesObj?.diaSemana || 'Lunes',
          hora: sesObj?.hora || '08:00',
          actividadTipo: tipoAct,
          actividadTitulo: tituloMostrado,
          actividadDescripcion: act.actividadDescripcion || act.descripcion || '',
          fecha: sesObj?.fecha || `Sesión ${numSes}`,
          fechaInicioEntrega: act.fechaInicioEntrega || sesObj?.fechaInicioEntrega,
          fechaFinEntrega: act.fechaFinEntrega || act.fechaLimiteEntrega || sesObj?.fechaFinEntrega,
          puntajeMaximo: act.puntajeMaximo || 20,
          entregasCount: entregasAct.filter((e: any) => Boolean(e.archivoNombre && e.archivoNombre !== 'Calificación directa en sesión') || e.estado === 'ENTREGADO').length,
          calificadosCount: entregasAct.filter((e: any) => e.calificado || (e.nota !== null && e.nota !== undefined) || (e.calificacion !== null && e.calificacion !== undefined)).length,
        };
      });
    }

    return this.sesionesCalendario().filter(
      (s) => s.actividadTipo === 'TAREA' || s.actividadTipo === 'EXAMEN'
    );
  });

  filtroSesionTareasCurso = signal<number | 'TODAS'>('TODAS');

  sesionesConTareasCurso = computed(() => {
    const set = new Set<number>();
    this.tareasDelCursoActivo().forEach((t: any) => {
      if (t.numero) set.add(Number(t.numero));
    });
    return Array.from(set).sort((a, b) => a - b);
  });

  tareasDelCursoAgrupadasPorSesion = computed(() => {
    const filtro = this.filtroSesionTareasCurso();
    const lista = this.tareasDelCursoActivo().filter((t: any) =>
      filtro === 'TODAS' ? true : Number(t.numero) === Number(filtro)
    );
    const mapGrupos = new Map<number, { sesion: number; fecha: string; semana: number; items: any[] }>();
    lista.forEach((t: any) => {
      const sesNum = Number(t.numero || 1);
      if (!mapGrupos.has(sesNum)) {
        mapGrupos.set(sesNum, {
          sesion: sesNum,
          fecha: t.fecha || `Sesión ${sesNum}`,
          semana: t.semana || 1,
          items: [],
        });
      }
      mapGrupos.get(sesNum)!.items.push(t);
    });
    return Array.from(mapGrupos.values()).sort((a, b) => b.sesion - a.sesion);
  });

  // Filtro de Semana y Sesión en "Sesiones por Calendario" (por defecto muestra la semana actual)
  semanaActualCurso = signal<number>(1);
  filtroSemanaSesion = signal<number | 'TODAS'>(1);
  filtroNumeroSesion = signal<number | 'TODAS'>('TODAS');

  semanasDisponiblesCurso = computed(() => {
    const set = new Set<number>();
    this.sesionesCalendario().forEach((s) => set.add(s.semana || 1));
    return Array.from(set).sort((a, b) => a - b);
  });

  sesionesCalendarioFiltradas = computed(() => {
    const todas = this.sesionesCalendario();
    const numFiltro = this.filtroNumeroSesion();
    if (numFiltro !== 'TODAS') {
      return todas.filter((s) => s.numero === Number(numFiltro));
    }
    const semFiltro = this.filtroSemanaSesion();
    if (semFiltro === 'TODAS') {
      return todas;
    }
    return todas.filter((s) => s.semana === Number(semFiltro));
  });

  sesionesConPlazoVencidoCurso = computed(() => {
    return this.sesionesCalendario().filter((s) => s.actividadTipo === 'TAREA' && s.plazoVencido && !s.calificacionCompletada);
  });

  // Sesiones de Clase Determinadas por Días / Calendario
  sesionesCalendario = signal<SesionCalendario[]>([]);
  sesionSeleccionadaConfig = signal<SesionCalendario | null>(null);
  mostrarModalConfigSesion = signal(false);
  tabModalSesion = signal<'actividad' | 'asistencia' | 'calificar'>('actividad');
  formConfigSesion = signal({
    actividadId: '' as string,
    actividadTipo: 'NINGUNA' as 'NINGUNA' | 'TAREA' | 'EXAMEN',
    actividadTitulo: '',
    actividadDescripcion: '',
    fechaInicioEntrega: '2026-03-02T08:00',
    fechaFinEntrega: '2026-03-09T23:59',
    puntajeMaximo: 20,
  });
  actividadesSesionCurso = signal<any[]>([]);

  // Entregas y Calificaciones por Sesión y por Actividad (clave compuesta actividadId__alumnoId)
  entregasSesionActual = signal<any[]>([]);
  entregasCursoCache = signal<any[]>([]);
  notasSesionInput = signal<{ [alumnoId: number]: number }>({});
  comentariosSesionInput = signal<{ [alumnoId: number]: string }>({});
  notasPorActividadInput = signal<{ [key: string]: number }>({});
  comentariosPorActividadInput = signal<{ [key: string]: string }>({});

  claveNotaActividad(alumnoId: number, actividadId?: string, sesionNum?: number): string {
    const actKey =
      actividadId ||
      (this.mostrarModalConfigSesion()
        ? this.formConfigSesion().actividadId
        : this.tareaSeleccionadaDocente()?.actividadId) ||
      `ses_${sesionNum ?? this.sesionActual()}`;
    return `${actKey}__${alumnoId}`;
  }

  obtenerNotaInput(alumnoId: number, actividadId?: string, sesionNum?: number): number {
    const key = this.claveNotaActividad(alumnoId, actividadId, sesionNum);
    const mapAct = this.notasPorActividadInput();
    if (mapAct[key] !== undefined && mapAct[key] !== null) {
      return mapAct[key];
    }
    const ent = this.obtenerEntregaAlumnoSesion(alumnoId, actividadId, undefined, sesionNum);
    if (ent && (ent.nota !== undefined && ent.nota !== null)) {
      return Number(ent.nota);
    }
    if (ent && (ent.calificacion !== undefined && ent.calificacion !== null)) {
      return Number(ent.calificacion);
    }
    return this.notasSesionInput()[alumnoId] ?? 0;
  }

  // Modal de vista previa de archivos / imágenes subidas por el alumno
  vistaPreviaArchivoDocente = signal<{ nombre: string; url: string; tipo: string; alumnoNombre?: string } | null>(null);

  esImagenArchivo(url?: string, nombre?: string, tipo?: string): boolean {
    if (tipo && tipo.toLowerCase().startsWith('image/')) return true;
    if (url && url.startsWith('data:image/')) return true;
    const n = (nombre || '').toLowerCase();
    return n.endsWith('.png') || n.endsWith('.jpg') || n.endsWith('.jpeg') || n.endsWith('.gif') || n.endsWith('.webp');
  }

  abrirVistaPreviaDocente(ent: any, alumnoNombre?: string, archivo?: { nombre: string; url: string; tipo: string }): void {
    if (!ent) return;
    this.vistaPreviaArchivoDocente.set({
      nombre: archivo?.nombre || ent.archivoNombre || 'evidencia_alumno',
      url: archivo?.url || ent.archivoUrl || '',
      tipo: archivo?.tipo || ent.archivoTipo || '',
      alumnoNombre: alumnoNombre || ent.alumnoNombre || 'Estudiante',
    });
  }

  cerrarVistaPreviaDocente(): void {
    this.vistaPreviaArchivoDocente.set(null);
  }

  archivosDeEntrega(ent: any): { nombre: string; url: string; tipo: string }[] {
    if (!ent) return [];
    if (Array.isArray(ent.archivos) && ent.archivos.length > 0) {
      return ent.archivos
        .filter((a: any) => a && (a.url || a.nombre))
        .map((a: any) => ({ nombre: a.nombre || 'archivo', url: a.url || '', tipo: a.tipo || '' }));
    }
    if (ent.archivoUrl) {
      return [{ nombre: ent.archivoNombre || 'archivo', url: ent.archivoUrl, tipo: ent.archivoTipo || '' }];
    }
    return [];
  }

  urlSegura(url?: string): SafeUrl {
    return this.sanitizer.bypassSecurityTrustUrl(url || '');
  }

  urlRecursoSegura(url?: string): SafeResourceUrl {
    return this.sanitizer.bypassSecurityTrustResourceUrl(url || '');
  }

  // Notificaciones de "Calificar Sesión" organizadas por Sesión (mantiene visibles pendientes y calificadas para editar)
  notificacionesCalificar = signal<any[]>([]);
  notificacionSesionAbierta = signal<any | null>(null);
  filtroSesionNotificaciones = signal<number | 'TODAS'>('TODAS');
  filtroEstadoNotificaciones = signal<'TODAS' | 'PENDIENTES' | 'CALIFICADAS'>('TODAS');

  notificacionesPendientesRealesCount = computed(() => {
    return this.notificacionesCalificar().filter((n) => !n.completada).length;
  });

  notificacionesTotalesCount = computed(() => {
    return this.justificacionesPendientesCount() + this.notificacionesPendientesRealesCount();
  });

  sesionesConEntregasNotif = computed(() => {
    const set = new Set<number>();
    this.notificacionesCalificar().forEach((n) => {
      if (n.sesion) set.add(Number(n.sesion));
    });
    return Array.from(set).sort((a, b) => a - b);
  });

  notificacionesAgrupadasPorSesion = computed(() => {
    const sesFiltro = this.filtroSesionNotificaciones();
    const estFiltro = this.filtroEstadoNotificaciones();
    const filtradas = this.notificacionesCalificar().filter((n) => {
      if (sesFiltro !== 'TODAS' && Number(n.sesion) !== Number(sesFiltro)) return false;
      if (estFiltro === 'PENDIENTES' && n.completada) return false;
      if (estFiltro === 'CALIFICADAS' && !n.completada) return false;
      return true;
    });

    const gruposMap = new Map<string, {
      key: string;
      cursoNombre: string;
      grado: string;
      sesion: number;
      actividades: any[];
      pendientesCount: number;
      calificadasCount: number;
    }>();

    filtradas.forEach((n) => {
      const k = `${n.curso?.id || n.cursoNombre}__${n.sesion}`;
      if (!gruposMap.has(k)) {
        gruposMap.set(k, {
          key: k,
          cursoNombre: n.cursoNombre,
          grado: n.grado,
          sesion: Number(n.sesion),
          actividades: [],
          pendientesCount: 0,
          calificadasCount: 0,
        });
      }
      const g = gruposMap.get(k)!;
      g.actividades.push(n);
      if (n.completada) {
        g.calificadasCount++;
      } else {
        g.pendientesCount++;
      }
    });

    return Array.from(gruposMap.values()).sort((a, b) => b.sesion - a.sesion);
  });

  // Ponderación de Calificaciones Auto-Balanceada (Total = 100%)
  ponderacion = signal({
    asistencia: 30,
    tareas: 35,
    examenes: 35,
  });
  ultimoCampoEditadoPonderacion = signal<'asistencia' | 'tareas' | 'examenes' | null>(null);
  ponderacionBloqueada = signal<boolean>(false);
  solicitudPonderacionPendiente = signal<any | null>(null);
  mostrarModalSolicitarPonderacion = signal<boolean>(false);
  motivoSolicitudPonderacion = signal<string>('');
  enviandoSolicitudPonderacion = signal<boolean>(false);
  guardandoPonderacion = signal(false);

  ajustarPonderacion(campo: 'asistencia' | 'tareas' | 'examenes', nuevoValor: number): void {
    if (this.ponderacionBloqueada()) return;
    let val = Math.max(0, Math.min(100, Math.round(Number(nuevoValor) || 0)));
    const actual = { ...this.ponderacion() };
    const campos: ('asistencia' | 'tareas' | 'examenes')[] = ['asistencia', 'tareas', 'examenes'];
    const prev = this.ultimoCampoEditadoPonderacion();

    // Si el docente ya configuró un primer campo y ahora mueve un segundo campo,
    // el primer campo NO se mueve; solo se ajusta el tercer campo que no tocó.
    if (prev && prev !== campo) {
      const tercerCampo = campos.find((c) => c !== campo && c !== prev)!;
      const valorFijo = actual[prev];
      const maxPermitido = Math.max(0, 100 - valorFijo);
      val = Math.min(val, maxPermitido);
      const nuevoTercero = Math.max(0, 100 - valorFijo - val);
      this.ponderacion.set({
        ...actual,
        [prev]: valorFijo,
        [campo]: val,
        [tercerCampo]: nuevoTercero,
      });
    } else {
      // Primer movimiento: mantener fijo uno de los otros y mover solo el restante
      const otros = campos.filter((c) => c !== campo);
      const campoFijo = otros[0];
      const campoMovil = otros[1];
      if (val + actual[campoFijo] <= 100) {
        this.ponderacion.set({
          ...actual,
          [campo]: val,
          [campoMovil]: 100 - val - actual[campoFijo],
        });
      } else {
        this.ponderacion.set({
          ...actual,
          [campo]: val,
          [campoFijo]: 100 - val,
          [campoMovil]: 0,
        });
      }
    }
    this.ultimoCampoEditadoPonderacion.set(campo);
  }

  guardarPonderacion(): void {
    const c = this.cursoEnEdicion() || this.cursoSeleccionado();
    if (!c) return;
    if (this.ponderacionBloqueada()) {
      this.mensaje.set({ tipo: 'error', texto: 'La ponderación ya fue guardada y bloqueada. Solicite autorización a Secretaría para editarla.' });
      return;
    }
    this.guardandoPonderacion.set(true);
    const p = this.ponderacion();
    this.personalService.actualizarPonderacionCurso(c.id, {
      asistenciaPorcentaje: p.asistencia,
      tareasPorcentaje: p.tareas,
      examenesPorcentaje: p.examenes,
      cursoNombre: c.nombre,
      grado: c.grado,
    }).subscribe({
      next: () => {
        this.guardandoPonderacion.set(false);
        this.ponderacionBloqueada.set(true);
        this.solicitudPonderacionPendiente.set(null);
        // Recalcular promedios de los alumnos con la nueva ponderación
        const alumnosRecalc = (c.alumnos || []).map((a) => ({
          ...a,
          promedio: this.calcularPromedio(a),
        }));
        const actualizado = { ...c, alumnos: alumnosRecalc };
        this.cursoEnEdicion.set(actualizado);
        this.cursoSeleccionado.set(actualizado);
        this.mensaje.set({ tipo: 'success', texto: 'Ponderación oficial guardada y sellada. Para futuras modificaciones deberá solicitar autorización a Secretaría.' });
        setTimeout(() => this.mensaje.set(null), 4000);
      },
      error: (err) => {
        this.guardandoPonderacion.set(false);
        if (err.status === 403) {
          this.ponderacionBloqueada.set(true);
        }
        this.mensaje.set({ tipo: 'error', texto: err.error?.message || 'Error al actualizar la ponderación de notas.' });
      },
    });
  }

  enviarSolicitudEdicionPonderacion(): void {
    const c = this.cursoEnEdicion() || this.cursoSeleccionado();
    const motivo = this.motivoSolicitudPonderacion().trim();
    if (!c) return;
    if (!motivo) {
      this.mensaje.set({ tipo: 'error', texto: 'Escriba una breve descripción del motivo para solicitar la edición a Secretaría.' });
      return;
    }
    this.enviandoSolicitudPonderacion.set(true);
    const usuario = this.authService.getCurrentUser();
    const docenteNombre = this.horarioData()?.docenteNombre || usuario?.nombreCompleto || 'Docente';
    this.personalService.solicitarEdicionPonderacion(c.id, {
      cursoNombre: c.nombre,
      grado: c.grado,
      docenteId: this.docenteId(),
      docenteNombre,
      motivo,
    }).subscribe({
      next: (res) => {
        this.enviandoSolicitudPonderacion.set(false);
        this.mostrarModalSolicitarPonderacion.set(false);
        this.motivoSolicitudPonderacion.set('');
        this.solicitudPonderacionPendiente.set(res?.solicitud || { estado: 'PENDIENTE', motivo });
        this.mensaje.set({ tipo: 'success', texto: res?.mensaje || 'Solicitud enviada a Secretaría. Cuando sea aceptada podrá editar la ponderación.' });
        setTimeout(() => this.mensaje.set(null), 4000);
      },
      error: () => {
        this.enviandoSolicitudPonderacion.set(false);
        this.mensaje.set({ tipo: 'error', texto: 'No se pudo enviar la solicitud a Secretaría.' });
      },
    });
  }

  obtenerBloquesCursoActual(curso: DocenteCurso): BloqueHorario[] {
    const bloques = this.horarioData()?.bloques || [];
    const norm = (s: string) => (s || '').trim().toLowerCase();
    const filtrados = bloques.filter(
      (b) => !b.esDescanso && norm(b.curso) === norm(curso.nombre) && (!curso.grado || norm(b.grado) === norm(curso.grado))
    );
    return filtrados;
  }

  calcularTurnosPorSemanaCurso(curso: DocenteCurso): number {
    const bloques = this.obtenerBloquesCursoActual(curso);
    if (bloques.length > 0) return bloques.length;
    if (curso.turnosPorSemana && curso.turnosPorSemana > 0) return curso.turnosPorSemana;
    return 1;
  }

  generarSesionesCalendario(fechaInicioStr: string = '2026-03-02', fechaFinStr: string = '2026-12-18'): void {
    const curso = this.cursoEnEdicion() || this.cursoSeleccionado();
    const turnosPorSemana = curso ? this.calcularTurnosPorSemanaCurso(curso) : 1;
    const duracionMeses = curso?.duracionMesesAnual || 10;
    const totalSesiones = turnosPorSemana * 4 * duracionMeses; // 4 semanas por mes * N meses * turnos por semana
    const totalSemanas = 4 * duracionMeses; // 40 semanas lectivas

    const bloquesCurso = curso ? this.obtenerBloquesCursoActual(curso) : [];
    const diasNombres = ['Dom', 'Lun', 'Mar', 'Mié', 'Jue', 'Vie', 'Sáb'];
    const mesesNombres = ['Ene', 'Feb', 'Mar', 'Abr', 'May', 'Jun', 'Jul', 'Ago', 'Sep', 'Oct', 'Nov', 'Dic'];
    const mapaDiaOffset: { [k: string]: number } = {
      Lunes: 0,
      Martes: 1,
      Miércoles: 2,
      Miercoles: 2,
      Jueves: 3,
      Viernes: 4,
      Sábado: 5,
      Sabado: 5,
    };

    const inicio = new Date(fechaInicioStr + 'T08:00:00');
    const sesiones: SesionCalendario[] = [];
    let num = 1;

    for (let sem = 1; sem <= totalSemanas; sem++) {
      for (let t = 0; t < turnosPorSemana; t++) {
        if (num > totalSesiones) break;
        const bloque = bloquesCurso[t];
        const offsetDia = bloque ? (mapaDiaOffset[bloque.dia] ?? t % 5) : (t % 5);
        const fechaSesion = new Date(inicio.getTime());
        fechaSesion.setDate(inicio.getDate() + (sem - 1) * 7 + offsetDia);

        const dName = bloque ? bloque.dia.slice(0, 3) : diasNombres[fechaSesion.getDay()];
        const mName = mesesNombres[fechaSesion.getMonth()];
        const fechaFormateada = `${dName} ${fechaSesion.getDate().toString().padStart(2, '0')} ${mName} ${fechaSesion.getFullYear()}`;
        const horaStr = bloque ? `${bloque.horaInicio} - ${bloque.horaFin}` : (curso?.horario?.split('|')[0]?.trim() || '09:00 - 11:00');

        const startIso = new Date(fechaSesion.getTime()).toISOString().slice(0, 16);
        const endIso = new Date(fechaSesion.getTime() + 6 * 24 * 3600000).toISOString().slice(0, 16);

        // Todas las sesiones comienzan como SIN ACTIVIDAD ('NINGUNA') hasta que el docente las configure
        sesiones.push({
          numero: num,
          semana: sem,
          fecha: fechaFormateada,
          diaSemana: dName,
          hora: horaStr,
          actividadTipo: 'NINGUNA',
          actividadTitulo: '',
          actividadDescripcion: '',
          fechaInicioEntrega: startIso,
          fechaFinEntrega: endIso,
          puntajeMaximo: 20,
          plazoVencido: false,
          entregasCount: 0,
          calificadosCount: 0,
          calificacionCompletada: false,
        });
        num++;
      }
    }

    // Determinar automáticamente la semana actual respecto a la fecha de hoy y la sesión correspondiente
    const hoy = Date.now();
    const diffDias = Math.floor((hoy - inicio.getTime()) / (1000 * 3600 * 24));
    const semCalc = diffDias >= 0 ? Math.min(totalSemanas, Math.max(1, Math.floor(diffDias / 7) + 1)) : 1;
    this.semanaActualCurso.set(semCalc);
    this.filtroSemanaSesion.set(semCalc);
    this.filtroNumeroSesion.set('TODAS');

    const sesionCorrespondiente = sesiones.find((s) => s.semana === semCalc) || sesiones[0];
    if (sesionCorrespondiente) {
      this.sesionActual.set(sesionCorrespondiente.numero);
    }

    this.sesionesCalendario.set(sesiones);
    this.listaSesiones = Array.from({ length: sesiones.length }, (_, i) => i + 1);

    // Sincronizar actividades configuradas y entregas reales desde el backend
    if (curso) {
      this.sincronizarActividadesYEntregasCurso(curso);
    }
  }

  irASemanaActual(): void {
    const sem = this.semanaActualCurso();
    this.filtroSemanaSesion.set(sem);
    this.filtroNumeroSesion.set('TODAS');
    const ses = this.sesionesCalendario().find((s) => s.semana === sem);
    if (ses) {
      this.sesionActual.set(ses.numero);
    }
  }

  sincronizarActividadesYEntregasCurso(curso: DocenteCurso): void {
    forkJoin({
      actividades: this.personalService.obtenerActividadesSesiones(curso.nombre, curso.grado),
      entregas: this.personalService.obtenerEntregasTareas(curso.nombre, curso.grado),
    }).subscribe({
      next: ({ actividades, entregas }) => {
        this.entregasCursoCache.set(entregas || []);
        this.actividadesSesionCurso.set(actividades || []);
        const mapAct = new Map<number, any[]>();
        (actividades || []).forEach((a: any) => {
          const num = Number(a.numeroSesion ?? a.sesion);
          if (!isNaN(num)) {
            const actuales = mapAct.get(num) || [];
            actuales.push(a);
            mapAct.set(num, actuales);
          }
        });

        const totalAlumnos = (curso.alumnos || []).length || 1;
        this.sesionesCalendario.update((list) =>
          list.map((s) => {
            const acts = mapAct.get(s.numero) || [];
            const entregasSesion = (entregas || []).filter(
              (e: any) =>
                Number(e.sesion ?? e.sesionId ?? e.tareaId) === s.numero &&
                Boolean((e.archivoNombre && e.archivoNombre !== 'Calificación directa en sesión') || e.estado === 'ENTREGADO')
            );

            const actsEnriquecidas = acts.map((a: any, idx: number) => {
              const aId = a.actividadId || a.key;
              const aTipo = (a.actividadTipo || a.tipoActividad || 'TAREA').toUpperCase();
              const entsDeEstaAct = entregasSesion.filter((e: any) => {
                if (aId && e.actividadId) {
                  return String(e.actividadId) === String(aId);
                }
                if (!e.actividadId && acts.length === 1) {
                  return true;
                }
                return false;
              });
              const califsDeEstaAct = (entregas || []).filter((e: any) => {
                const matchAct = aId && e.actividadId ? String(e.actividadId) === String(aId) : (!e.actividadId && acts.length === 1 && Number(e.sesion ?? e.sesionId ?? e.tareaId) === s.numero);
                return matchAct && (e.calificado || (e.nota !== null && e.nota !== undefined) || (e.calificacion !== null && e.calificacion !== undefined));
              });
              const rawTit = (a.actividadTitulo || a.titulo || '').trim();
              const esGen = !rawTit || rawTit === `Tarea Sesión ${s.numero}` || rawTit === `Examen Sesión ${s.numero}`;
              return {
                ...a,
                actividadId: aId,
                actividadTipo: aTipo,
                actividadTitulo: esGen && acts.length > 1
                  ? `${aTipo === 'EXAMEN' ? 'Examen' : 'Tarea'} #${idx + 1} - Sesión ${s.numero}`
                  : (rawTit || `${aTipo === 'EXAMEN' ? 'Examen' : 'Tarea'} #${idx + 1} - Sesión ${s.numero}`),
                entregasCount: entsDeEstaAct.length,
                calificadosCount: califsDeEstaAct.length,
              };
            });

            const act = actsEnriquecidas[actsEnriquecidas.length - 1];
            if (!act) {
              return {
                ...s,
                actividadTipo: 'NINGUNA',
                actividadTitulo: '',
                actividadDescripcion: '',
                entregasCount: 0,
                calificadosCount: 0,
                actividadesCount: 0,
                actividades: [],
              };
            }
            const tipo = (act.actividadTipo || act.tipoActividad || 'NINGUNA') as 'NINGUNA' | 'TAREA' | 'EXAMEN';
            const fFin = act.fechaFinEntrega || act.fechaLimiteEntrega || s.fechaFinEntrega;
            const vencido = (tipo === 'TAREA' || tipo === 'EXAMEN') && fFin ? new Date(fFin).getTime() < Date.now() : false;
            const totalCalificados = actsEnriquecidas.reduce((acc, item) => acc + (item.calificadosCount || 0), 0);
            const completado = tipo !== 'NINGUNA' && totalCalificados >= totalAlumnos * actsEnriquecidas.length && totalAlumnos > 0;
            return {
              ...s,
              actividadTipo: tipo,
              actividadTitulo: act.actividadTitulo || act.titulo || '',
              actividadDescripcion: act.actividadDescripcion || act.descripcion || '',
              fechaInicioEntrega: act.fechaInicioEntrega || s.fechaInicioEntrega,
              fechaFinEntrega: fFin,
              puntajeMaximo: act.puntajeMaximo || 20,
              plazoVencido: vencido,
              entregasCount: act.entregasCount ?? entregasSesion.length,
              calificadosCount: act.calificadosCount ?? totalCalificados,
              calificacionCompletada: completado,
              actividadId: act.actividadId || act.key,
              actividadesCount: actsEnriquecidas.length,
              actividades: actsEnriquecidas,
            };
          })
        );
        // Actualizar promedios de los alumnos del curso en edición con las entregas y tareas publicadas
        const cActual = this.cursoEnEdicion();
        if (cActual && cActual.id === curso.id) {
          const alumnosRecalc = (cActual.alumnos || []).map((al) => {
            const copia = { ...al };
            copia.practica = this.calcularNotaTareas(copia);
            copia.finalExam = this.calcularNotaExamenes(copia);
            copia.examen = copia.finalExam;
            copia.promedio = this.calcularPromedio(copia);
            return copia;
          });
          const cursoRecalc = { ...cActual, alumnos: alumnosRecalc };
          this.cursoEnEdicion.set(cursoRecalc);
          this.cursoSeleccionado.set(cursoRecalc);
        }
        // Poblar notasPorActividadInput para cada actividad y alumno de manera independiente
        const nuevoMapActNotas: { [key: string]: number } = { ...this.notasPorActividadInput() };
        const nuevoMapActCom: { [key: string]: string } = { ...this.comentariosPorActividadInput() };
        (actividades || []).forEach((actItem: any) => {
          const aId = actItem.actividadId || actItem.key;
          const numSes = Number(actItem.numeroSesion ?? actItem.sesion ?? 1);
          const mismas = (actividades || []).filter((x: any) => Number(x.numeroSesion ?? x.sesion ?? 1) === numSes);
          (curso.alumnos || []).forEach((al) => {
            const entMatch = (entregas || []).find(
              (e: any) =>
                Number(e.alumnoId) === Number(al.id) &&
                (aId && e.actividadId
                  ? String(e.actividadId) === String(aId)
                  : (!e.actividadId && mismas.length <= 1 && Number(e.sesion ?? e.sesionId ?? e.tareaId) === numSes))
            );
            const k = this.claveNotaActividad(al.id, aId, numSes);
            if (entMatch && (entMatch.nota !== undefined && entMatch.nota !== null)) {
              nuevoMapActNotas[k] = Number(entMatch.nota);
            } else if (entMatch && (entMatch.calificacion !== undefined && entMatch.calificacion !== null)) {
              nuevoMapActNotas[k] = Number(entMatch.calificacion);
            } else if (nuevoMapActNotas[k] === undefined) {
              nuevoMapActNotas[k] = 0;
            }
            if (entMatch?.comentarioDocente) {
              nuevoMapActCom[k] = entMatch.comentarioDocente;
            }
          });
        });
        this.notasPorActividadInput.set(nuevoMapActNotas);
        this.comentariosPorActividadInput.set(nuevoMapActCom);

        this.cargarNotificacionesCalificarSesion();

        // Si el modal de sesión está abierto, recargar entregas de la actividad activa del modal (NO sobrescribir con tareasActivas[0])
        if (this.mostrarModalConfigSesion()) {
          const sModal = this.sesionSeleccionadaConfig();
          const fModal = this.formConfigSesion();
          if (sModal) {
            this.cargarEntregasDeSesion(sModal.numero, fModal.actividadId || undefined, fModal.actividadTipo);
          }
          return;
        }

        const tareasActivas = this.tareasDelCursoActivo();
        const tSel = this.tareaSeleccionadaDocente();
        if (tSel) {
          const actSel = tareasActivas.find((x: any) =>
            tSel.actividadId
              ? String(x.actividadId) === String(tSel.actividadId)
              : x.numero === tSel.numero
          );
          if (actSel) {
            this.tareaSeleccionadaDocente.set(actSel);
            this.cargarEntregasDeSesion(actSel.numero, actSel.actividadId, actSel.actividadTipo);
          }
        } else if (tareasActivas.length > 0) {
          this.tareaSeleccionadaDocente.set(tareasActivas[0]);
          this.cargarEntregasDeSesion(tareasActivas[0].numero, tareasActivas[0].actividadId, tareasActivas[0].actividadTipo);
        }
      },
    });
  }

  cambiarSubTabCurso(tab: 'sesiones' | 'ponderacion' | 'tareas'): void {
    this.subTabCurso.set(tab);
    const curso = this.cursoEnEdicion() || this.cursoSeleccionado();
    if (tab === 'ponderacion' && curso) {
      this.cargarPonderacionDeCurso(curso);
    }
    if (tab === 'tareas') {
      if (curso) {
        this.sincronizarActividadesYEntregasCurso(curso);
      }
      const tSel = this.tareaSeleccionadaDocente() || this.tareasDelCursoActivo()[0] || null;
      if (tSel) {
        this.seleccionarTareaDocente(tSel);
      }
    }
  }

  actividadesDeSesionActual = computed(() => {
    const s = this.sesionSeleccionadaConfig();
    if (!s) return [];
    return this.actividadesSesionCurso().filter(
      (a: any) => Number(a.numeroSesion ?? a.sesion) === Number(s.numero)
    );
  });

  seleccionarActividadEnModal(act: any): void {
    const s = this.sesionSeleccionadaConfig();
    if (!act) {
      this.formConfigSesion.set({
        actividadId: '',
        actividadTipo: 'TAREA',
        actividadTitulo: '',
        actividadDescripcion: '',
        fechaInicioEntrega: s?.fechaInicioEntrega || '2026-03-02T08:00',
        fechaFinEntrega: s?.fechaFinEntrega || '2026-03-09T23:59',
        puntajeMaximo: 20,
      });
      if (s) {
        this.cargarEntregasDeSesion(s.numero, undefined, 'TAREA');
      }
      return;
    }

    const actId = act.actividadId || act.key || '';
    const actTipo = act.actividadTipo || act.tipoActividad || 'TAREA';
    this.formConfigSesion.set({
      actividadId: actId,
      actividadTipo: actTipo,
      actividadTitulo: act.actividadTitulo || act.titulo || '',
      actividadDescripcion: act.actividadDescripcion || act.descripcion || '',
      fechaInicioEntrega: act.fechaInicioEntrega || s?.fechaInicioEntrega || '2026-03-02T08:00',
      fechaFinEntrega: act.fechaFinEntrega || act.fechaLimiteEntrega || s?.fechaFinEntrega || '2026-03-09T23:59',
      puntajeMaximo: act.puntajeMaximo || 20,
    });
    const matchTarea = this.tareasDelCursoActivo().find(
      (x: any) => actId && x.actividadId && String(x.actividadId) === String(actId)
    );
    if (matchTarea) {
      this.tareaSeleccionadaDocente.set(matchTarea);
    }
    if (s) {
      this.cargarEntregasDeSesion(s.numero, actId, actTipo);
    }
  }

  seleccionarTareaDocente(t: any): void {
    this.tareaSeleccionadaDocente.set(t);
    this.sesionActual.set(t.numero);
    this.cargarEntregasDeSesion(t.numero, t.actividadId, t.actividadTipo);
  }

  abrirConfigSesion(
    s: SesionCalendario,
    tabInicial: 'actividad' | 'asistencia' | 'calificar' = 'actividad',
    actExplicit?: any,
    crearNueva = false
  ): void {
    this.sesionSeleccionadaConfig.set(s);
    this.sesionActual.set(s.numero);
    this.tabModalSesion.set(tabInicial);
    const actividades = (s.actividades && s.actividades.length > 0)
      ? s.actividades
      : this.actividadesSesionCurso().filter(
          (a: any) => Number(a.numeroSesion ?? a.sesion) === Number(s.numero)
        );
    if (crearNueva) {
      this.seleccionarActividadEnModal(null);
    } else if (actExplicit) {
      this.seleccionarActividadEnModal(actExplicit);
    } else if (actividades.length > 0) {
      if (tabInicial === 'calificar') {
        const primeraPendiente = actividades.find(
          (a: any) => (a.entregasCount || 0) > (a.calificadosCount || 0)
        );
        this.seleccionarActividadEnModal(primeraPendiente || actividades[0]);
      } else {
        this.seleccionarActividadEnModal(actividades[0]);
      }
    } else {
      this.formConfigSesion.set({
        actividadId: '',
        actividadTipo: (s.actividadTipo || 'NINGUNA') as 'NINGUNA' | 'TAREA' | 'EXAMEN',
        actividadTitulo: s.actividadTitulo || '',
        actividadDescripcion: s.actividadDescripcion || '',
        fechaInicioEntrega: s.fechaInicioEntrega || '2026-03-02T08:00',
        fechaFinEntrega: s.fechaFinEntrega || '2026-03-09T23:59',
        puntajeMaximo: s.puntajeMaximo || 20,
      });
      this.cargarEntregasDeSesion(s.numero, undefined, s.actividadTipo);
    }
    this.cargarAsistenciaCurso();
    this.mostrarModalConfigSesion.set(true);
  }

  cargarEntregasDeSesion(sesionNumero: number, actividadId?: string, actividadTipo?: string): void {
    const curso = this.cursoEnEdicion() || this.cursoSeleccionado();
    if (!curso) return;
    const actsEnSesion = this.actividadesSesionCurso().filter(
      (a: any) => Number(a.numeroSesion ?? a.sesion) === Number(sesionNumero)
    );
    this.personalService.obtenerEntregasTareas(curso.nombre, curso.grado, sesionNumero, actividadId).subscribe({
      next: (lista) => {
        let filtrada = lista || [];
        if (actividadId) {
          filtrada = filtrada.filter(
            (e: any) =>
              (e.actividadId && String(e.actividadId) === String(actividadId)) ||
              (!e.actividadId && actsEnSesion.length <= 1)
          );
        } else if (actividadTipo && actividadTipo !== 'NINGUNA') {
          filtrada = filtrada.filter((e: any) => String(e.tipoActividad || 'TAREA').toUpperCase() === String(actividadTipo).toUpperCase());
        }

        this.entregasSesionActual.set(filtrada);
        const mapNotas: { [id: number]: number } = {};
        const mapCom: { [id: number]: string } = {};
        const mapPorAct: { [k: string]: number } = { ...this.notasPorActividadInput() };
        const mapComPorAct: { [k: string]: string } = { ...this.comentariosPorActividadInput() };
        (curso.alumnos || []).forEach((al) => {
          const ent = (filtrada || []).find((e: any) => Number(e.alumnoId) === Number(al.id));
          const valNota =
            ent?.nota !== undefined && ent?.nota !== null
              ? Number(ent.nota)
              : ent?.calificacion !== undefined && ent?.calificacion !== null
              ? Number(ent.calificacion)
              : 0;
          mapNotas[al.id] = valNota;
          mapCom[al.id] = ent?.comentarioDocente || '';
          const kAct = this.claveNotaActividad(al.id, actividadId, sesionNumero);
          mapPorAct[kAct] = valNota;
          mapComPorAct[kAct] = ent?.comentarioDocente || '';
        });
        this.notasSesionInput.set(mapNotas);
        this.comentariosSesionInput.set(mapCom);
        this.notasPorActividadInput.set(mapPorAct);
        this.comentariosPorActividadInput.set(mapComPorAct);
      },
    });
  }

  obtenerEntregaAlumnoSesion(
    alumnoId: number,
    actividadIdExplicit?: string,
    actividadTipoExplicit?: string,
    sesionNumExplicit?: number
  ): any | undefined {
    const listaActual = this.entregasSesionActual();
    const listaCache = this.entregasCursoCache();
    const tSel = this.tareaSeleccionadaDocente();
    const form = this.formConfigSesion();
    const actId =
      actividadIdExplicit ||
      (this.mostrarModalConfigSesion()
        ? (form.actividadId || undefined)
        : (tSel?.actividadId || form.actividadId || undefined));
    const actTipo =
      actividadTipoExplicit ||
      (this.mostrarModalConfigSesion()
        ? (form.actividadTipo || 'TAREA')
        : (tSel?.actividadTipo || form.actividadTipo || 'TAREA'));
    const sesNum =
      sesionNumExplicit ??
      (this.mostrarModalConfigSesion()
        ? this.sesionSeleccionadaConfig()?.numero
        : tSel?.numero) ??
      this.sesionActual();

    const actsEnSesion = this.actividadesSesionCurso().filter(
      (a: any) => Number(a.numeroSesion ?? a.sesion) === Number(sesNum)
    );

    if (actId) {
      const matchExacto =
        listaActual.find(
          (e) => Number(e.alumnoId) === Number(alumnoId) && e.actividadId && String(e.actividadId) === String(actId)
        ) ||
        listaCache.find(
          (e) => Number(e.alumnoId) === Number(alumnoId) && e.actividadId && String(e.actividadId) === String(actId)
        );
      if (matchExacto) return matchExacto;

      if (actsEnSesion.length <= 1) {
        return (
          listaActual.find((e) => Number(e.alumnoId) === Number(alumnoId) && !e.actividadId) ||
          listaCache.find(
            (e) =>
              Number(e.alumnoId) === Number(alumnoId) &&
              !e.actividadId &&
              Number(e.sesion ?? e.sesionId ?? e.tareaId) === Number(sesNum)
          )
        );
      }
      return undefined;
    }

    return listaActual.find(
      (e) =>
        Number(e.alumnoId) === Number(alumnoId) &&
        !e.actividadId &&
        (actTipo && actTipo !== 'NINGUNA' ? String(e.tipoActividad || 'TAREA').toUpperCase() === String(actTipo).toUpperCase() : true)
    );
  }

  setNotaSesionAlumno(alumnoId: number, valor: any, actividadId?: string, sesionNum?: number): void {
    const n = Math.max(0, Math.min(20, Number(valor) || 0));
    this.notasSesionInput.update((m) => ({ ...m, [alumnoId]: n }));
    const key = this.claveNotaActividad(alumnoId, actividadId, sesionNum);
    this.notasPorActividadInput.update((m) => ({ ...m, [key]: n }));
  }

  calificarAlumnoEnSesion(
    alumno: AlumnoDocenteNota,
    sesionNum?: number,
    cursoExplicit?: DocenteCurso,
    actividadIdExplicit?: string,
    actividadTipoExplicit?: string,
    notifExplicit?: any
  ): void {
    const curso = cursoExplicit || this.cursoEnEdicion() || this.cursoSeleccionado();
    const tSel = this.tareaSeleccionadaDocente();
    const form = this.formConfigSesion();
    const sesNum =
      sesionNum ??
      notifExplicit?.sesion ??
      (this.mostrarModalConfigSesion() ? this.sesionSeleccionadaConfig()?.numero : tSel?.numero) ??
      this.sesionActual();
    if (!curso) return;

    const actId =
      actividadIdExplicit ||
      notifExplicit?.actividadId ||
      (this.mostrarModalConfigSesion()
        ? (form.actividadId || undefined)
        : (tSel?.actividadId || form.actividadId || undefined));
    const actTipo =
      actividadTipoExplicit ||
      notifExplicit?.actividadTipo ||
      (this.mostrarModalConfigSesion()
        ? (form.actividadTipo || 'TAREA')
        : (tSel?.actividadTipo || form.actividadTipo || 'TAREA'));
    const tipoEval = actTipo === 'EXAMEN' ? 'EXAMEN' : 'TAREA';

    const entExistente = notifExplicit
      ? this.obtenerEntregaEnNotificacion(notifExplicit, alumno.id)
      : this.obtenerEntregaAlumnoSesion(alumno.id, actId, actTipo, sesNum);

    const keyNota = this.claveNotaActividad(alumno.id, actId || entExistente?.actividadId, sesNum);
    const notaGuardadaEnMapa = this.notasPorActividadInput()[keyNota];
    const nota = Number(
      notaGuardadaEnMapa !== undefined
        ? notaGuardadaEnMapa
        : (this.notasSesionInput()[alumno.id] ?? 0)
    );
    const comentario =
      this.comentariosPorActividadInput()[keyNota] ||
      this.comentariosSesionInput()[alumno.id] ||
      'Calificado en sesión';

    const usuario = this.authService.getCurrentUser();

    this.personalService
      .calificarEntregaTarea({
        entregaId: entExistente?.id,
        colegioId: usuario?.colegioId || 1,
        cursoId: curso.id,
        curso: curso.nombre,
        cursoNombre: curso.nombre,
        grado: curso.grado,
        sesion: sesNum,
        sesionId: sesNum,
        tareaId: sesNum,
        actividadId: actId || entExistente?.actividadId,
        actividadTipo: actTipo,
        tipoActividad: actTipo,
        alumnoId: alumno.id,
        alumnoNombre: alumno.nombreCompleto,
        nota,
        calificacion: nota,
        comentarioDocente: comentario,
        tipoEvaluacion: tipoEval,
      })
      .subscribe({
        next: (res) => {
          const resumen = res?.resumen;
          let alumnoActualizadoRef: AlumnoDocenteNota | null = null;
          const nuevosAlumnos = (curso.alumnos || []).map((a) => {
            if (a.id !== alumno.id) return a;
            const actualizado = {
              ...a,
              practica: resumen?.practica !== undefined ? Number(resumen.practica) : (tipoEval === 'TAREA' ? nota : a.practica),
              examen: resumen?.examen !== undefined ? Number(resumen.examen) : (tipoEval === 'EXAMEN' ? nota : a.examen),
              finalExam: resumen?.finalExam !== undefined ? Number(resumen.finalExam) : a.finalExam,
              promedio: resumen?.promedio !== undefined ? Number(resumen.promedio) : a.promedio,
            };
            if (resumen?.promedio === undefined) {
              actualizado.promedio = this.calcularPromedio(actualizado);
            }
            alumnoActualizadoRef = actualizado;
            return actualizado;
          });
          const cursoAct = { ...curso, alumnos: nuevosAlumnos };
          if (this.cursoEnEdicion()?.id === curso.id) this.cursoEnEdicion.set(cursoAct);
          if (this.cursoSeleccionado()?.id === curso.id) this.cursoSeleccionado.set(cursoAct);
          this.cursos.update((arr) => arr.map((c) => (c.id === curso.id ? cursoAct : c)));

          // Sincronización automática con la tabla NOTAS de Oracle DB
          if (alumnoActualizadoRef) {
            const alSync = alumnoActualizadoRef as AlumnoDocenteNota;
            const actTag = actId || entExistente?.actividadId || `sesion_${sesNum}_${tipoEval.toLowerCase()}`;
            forkJoin([
              this.personalService.guardarNotaDocente({
                alumnoId: alSync.id,
                evaluacion: `[${actTag}] ${curso.nombre}`,
                valor: nota,
                cursoId: curso.id,
              }),
              this.personalService.guardarNotaDocente({
                alumnoId: alSync.id,
                evaluacion: `Práctica ${curso.nombre}`,
                valor: Number(alSync.practica || 0),
                cursoId: curso.id,
              }),
              this.personalService.guardarNotaDocente({
                alumnoId: alSync.id,
                evaluacion: `Parcial ${curso.nombre}`,
                valor: Number(alSync.examen || 0),
                cursoId: curso.id,
              }),
              this.personalService.guardarNotaDocente({
                alumnoId: alSync.id,
                evaluacion: `Examen Final ${curso.nombre}`,
                valor: Number(alSync.finalExam || alSync.examen || 0),
                cursoId: curso.id,
              }),
            ]).subscribe({ error: () => {} });
          }

          this.cargarEntregasDeSesion(sesNum, actId || entExistente?.actividadId, actTipo);
          this.sincronizarActividadesYEntregasCurso(cursoAct);
          this.cargarNotificacionesCalificarSesion();
          this.cargarCursos();
          this.mensaje.set({
            tipo: 'success',
            texto: `Nota (${nota}/20) registrada y guardada automáticamente en Oracle DB en "${notifExplicit?.actividadTitulo || (this.mostrarModalConfigSesion() ? form.actividadTitulo : tSel?.actividadTitulo) || ('Sesión ' + sesNum)}" para ${alumno.nombreCompleto}.`,
          });
          setTimeout(() => this.mensaje.set(null), 3500);
        },
      });
  }

  cerrarConfigSesion(): void {
    this.mostrarModalConfigSesion.set(false);
    this.sesionSeleccionadaConfig.set(null);
  }

  guardarConfigSesion(continuarAgregando = false): void {
    const s = this.sesionSeleccionadaConfig();
    const f = this.formConfigSesion();
    const curso = this.cursoEnEdicion() || this.cursoSeleccionado();
    if (!s || !curso) return;

    const plazoVencido = (f.actividadTipo === 'TAREA' || f.actividadTipo === 'EXAMEN') && f.fechaFinEntrega ? new Date(f.fechaFinEntrega).getTime() < Date.now() : false;
    const usuario = this.authService.getCurrentUser();

    const payload = {
      colegioId: usuario?.colegioId || 1,
      cursoId: curso.id,
      curso: curso.nombre,
      cursoNombre: curso.nombre,
      grado: curso.grado,
      seccion: curso.seccion || 'A',
      sesion: s.numero,
      numeroSesion: s.numero,
      actividadId: f.actividadId || undefined,
      actividadTipo: f.actividadTipo,
      tipoActividad: f.actividadTipo,
      actividadTitulo: f.actividadTitulo || (f.actividadTipo === 'EXAMEN' ? `Examen Sesión ${s.numero}` : `Tarea Sesión ${s.numero}`),
      actividadDescripcion: f.actividadDescripcion || '',
      fechaInicioEntrega: f.fechaInicioEntrega,
      fechaFinEntrega: f.fechaFinEntrega,
      fechaLimiteEntrega: f.fechaFinEntrega,
      puntajeMaximo: f.puntajeMaximo || 20,
    };

    const actualizarLocalmente = () => {
      this.sesionesCalendario.update((list) =>
        list.map((item) =>
          item.numero === s.numero
            ? {
                ...item,
                actividadTipo: f.actividadTipo,
                actividadTitulo: payload.actividadTitulo,
                actividadDescripcion: payload.actividadDescripcion,
                fechaInicioEntrega: payload.fechaInicioEntrega,
                fechaFinEntrega: payload.fechaFinEntrega,
                puntajeMaximo: payload.puntajeMaximo,
                plazoVencido,
              }
            : item
        )
      );
      this.sincronizarActividadesYEntregasCurso(curso);
      this.cargarNotificacionesCalificarSesion();
      this.cargarCursos();

      if (continuarAgregando) {
        this.formConfigSesion.set({
          actividadId: '',
          actividadTipo: f.actividadTipo === 'EXAMEN' ? 'EXAMEN' : 'TAREA',
          actividadTitulo: '',
          actividadDescripcion: '',
          fechaInicioEntrega: f.fechaInicioEntrega,
          fechaFinEntrega: f.fechaFinEntrega,
          puntajeMaximo: 20,
        });
        this.mensaje.set({
          tipo: 'success',
          texto: `Actividad guardada en la Sesión ${s.numero}. Ya puedes agregar otra tarea o examen.`,
        });
        setTimeout(() => this.mensaje.set(null), 3500);
        return;
      }

      this.cerrarConfigSesion();
      this.mensaje.set({
        tipo: 'success',
        texto:
          f.actividadTipo === 'NINGUNA'
            ? `Sesión ${s.numero} configurada como "Sin actividad".`
            : `${f.actividadTipo === 'TAREA' ? 'Tarea' : 'Examen'} "${payload.actividadTitulo}" guardado en la Sesión ${s.numero}.`,
      });
      setTimeout(() => this.mensaje.set(null), 3500);
    };

    this.personalService.guardarActividadSesion(payload).subscribe({
      next: () => {
        actualizarLocalmente();
      },
      error: (err) => {
        console.warn('Error en API remota, actualizando reactivamente:', err);
        actualizarLocalmente();
      },
    });
  }

  eliminarActividadConfigSesion(): void {
    const f = this.formConfigSesion();
    const s = this.sesionSeleccionadaConfig();
    const curso = this.cursoEnEdicion() || this.cursoSeleccionado();
    if (!f.actividadId || !curso) return;
    if (!confirm('¿Eliminar esta tarea/examen de la sesión? Esta acción no se puede deshacer.')) return;

    this.personalService.eliminarActividadSesion(f.actividadId).subscribe({
      next: () => {
        this.cerrarConfigSesion();
        this.sincronizarActividadesYEntregasCurso(curso);
        this.cargarNotificacionesCalificarSesion();
        this.mensaje.set({ tipo: 'success', texto: 'Actividad eliminada correctamente.' });
        setTimeout(() => this.mensaje.set(null), 3500);
      },
      error: () => {
        this.mensaje.set({ tipo: 'error', texto: 'No se pudo eliminar la actividad. Intenta nuevamente.' });
        setTimeout(() => this.mensaje.set(null), 3500);
      },
    });
  }

  cargarNotificacionesCalificarSesion(): void {
    forkJoin({
      actividades: this.personalService.obtenerActividadesSesiones(),
      entregas: this.personalService.obtenerEntregasTareas(),
    }).subscribe({
      next: ({ actividades, entregas }) => {
        const misCursos = this.cursos();
        const items: any[] = [];
        const strip = (s: string) => (s || '').normalize('NFD').replace(/[\u0300-\u036f]/g, '').toLowerCase().trim();
        const mapPorAct: { [k: string]: number } = { ...this.notasPorActividadInput() };
        const mapComPorAct: { [k: string]: string } = { ...this.comentariosPorActividadInput() };

        (actividades || []).forEach((act: any) => {
          const actTipo = act.actividadTipo || act.tipoActividad;
          if (!actTipo || actTipo === 'NINGUNA') return;
          const actCurso = strip(act.cursoNombre || act.curso || '');
          const actSesion = Number(act.numeroSesion ?? act.sesion);
          const actId = act.actividadId || act.key;
          const cursoMatch = misCursos.find(
            (c) =>
              strip(c.nombre) === actCurso &&
              (!act.grado || strip(c.grado) === strip(act.grado))
          );
          if (!cursoMatch) return;
          const alumnosCurso = cursoMatch.alumnos || [];

          const fFin = act.fechaFinEntrega || act.fechaLimiteEntrega;
          const vencido = fFin ? new Date(fFin).getTime() < Date.now() : true;

          const mismasEnSesion = (actividades || []).filter(
            (x: any) =>
              strip(x.cursoNombre || x.curso || '') === actCurso &&
              Number(x.numeroSesion ?? x.sesion) === actSesion
          );

          // Considerar entregas de alumnos que subieron evidencia específicamente para esta actividad
          const entregasSes = (entregas || []).filter(
            (e: any) =>
              strip(e.curso || e.cursoNombre || '') === strip(cursoMatch.nombre) &&
              (actId && e.actividadId
                ? String(e.actividadId) === String(actId)
                : (!e.actividadId && mismasEnSesion.length <= 1 && Number(e.sesion ?? e.sesionId ?? e.tareaId) === actSesion)) &&
              Boolean((e.archivoNombre && e.archivoNombre !== 'Calificación directa en sesión') || e.estado === 'ENTREGADO' || e.calificado)
          );

          // Mostrar en bandeja si al menos un alumno ya entregó su tarea
          if (entregasSes.length === 0) {
            return;
          }

          const calificadosCount = entregasSes.filter(
            (e: any) => e.calificado || (e.nota !== null && e.nota !== undefined) || (e.calificacion !== null && e.calificacion !== undefined)
          ).length;

          // Sincronizar mapa de notas independientes por actividadId + alumnoId
          alumnosCurso.forEach((al: any) => {
            const entAl = entregasSes.find(
              (e: any) => Number(e.alumnoId) === Number(al.id) || (alumnosCurso.length === 1 && entregasSes.length === 1)
            );
            const k = this.claveNotaActividad(al.id, actId, actSesion);
            if (entAl && (entAl.nota !== undefined && entAl.nota !== null)) {
              mapPorAct[k] = Number(entAl.nota);
            } else if (entAl && (entAl.calificacion !== undefined && entAl.calificacion !== null)) {
              mapPorAct[k] = Number(entAl.calificacion);
            } else if (mapPorAct[k] === undefined) {
              mapPorAct[k] = 0;
            }
            if (entAl?.comentarioDocente) {
              mapComPorAct[k] = entAl.comentarioDocente;
            }
          });

          const seqIdx = mismasEnSesion.indexOf(act) + 1;
          const rawTit = (act.actividadTitulo || act.titulo || '').trim();
          const esGen = !rawTit || rawTit === `Tarea Sesión ${actSesion}` || rawTit === `Examen Sesión ${actSesion}`;
          const tituloFinal = esGen && mismasEnSesion.length > 1
            ? `${actTipo === 'EXAMEN' ? 'Examen' : 'Tarea'} #${seqIdx} - Sesión ${actSesion}`
            : (rawTit || `${actTipo === 'EXAMEN' ? 'Examen' : 'Tarea'} #${seqIdx} - Sesión ${actSesion}`);

          // Mantener visibles tanto las tareas pendientes como las ya calificadas para poder editarlas organizadas por sesión
          items.push({
            id: `${cursoMatch.id}-${actId || actSesion}`,
            actividadId: actId,
            curso: cursoMatch,
            cursoNombre: cursoMatch.nombre,
            grado: cursoMatch.grado,
            sesion: actSesion,
            actividadTipo: actTipo,
            actividadTitulo: tituloFinal,
            actividadDescripcion: act.actividadDescripcion || act.descripcion || '',
            fechaFinEntrega: fFin,
            plazoVencido: vencido,
            entregas: entregasSes,
            entregasCount: entregasSes.length,
            calificadosCount,
            completada: calificadosCount >= entregasSes.length && entregasSes.length > 0,
            totalAlumnos: alumnosCurso.length,
          });
        });

        this.notasPorActividadInput.set(mapPorAct);
        this.comentariosPorActividadInput.set(mapComPorAct);
        this.notificacionesCalificar.set(items);
        const abierta = this.notificacionSesionAbierta();
        if (abierta) {
          const actualizada = items.find((i) => i.id === abierta.id);
          this.notificacionSesionAbierta.set(actualizada || null);
        }
      },
    });
  }

  seleccionarNotificacionCalificar(notif: any): void {
    if (this.notificacionSesionAbierta()?.id === notif.id) {
      this.notificacionSesionAbierta.set(null);
      return;
    }
    this.notificacionSesionAbierta.set(notif);
    const mapNotas: { [id: number]: number } = {};
    const mapCom: { [id: number]: string } = {};
    const mapPorAct: { [k: string]: number } = { ...this.notasPorActividadInput() };
    const mapComPorAct: { [k: string]: string } = { ...this.comentariosPorActividadInput() };
    const totalAl = (notif.curso?.alumnos || []).length;
    (notif.curso?.alumnos || []).forEach((al: any) => {
      const ent = (notif.entregas || []).find(
        (e: any) => Number(e.alumnoId) === Number(al.id) || (totalAl === 1 && (notif.entregas || []).length === 1)
      );
      const tieneEntrega = ent && (ent.archivoNombre || ent.estado === 'ENTREGADO');
      const valNota =
        ent?.nota !== undefined && ent?.nota !== null
          ? Number(ent.nota)
          : ent?.calificacion !== undefined && ent?.calificacion !== null
          ? Number(ent.calificacion)
          : 0;
      mapNotas[al.id] = valNota;
      mapCom[al.id] = ent?.comentarioDocente || (tieneEntrega ? '' : 'Sin tarea subida (Calificación automática: 0)');
      const k = this.claveNotaActividad(al.id, notif.actividadId, notif.sesion);
      mapPorAct[k] = valNota;
      mapComPorAct[k] = mapCom[al.id];
    });
    this.notasSesionInput.set(mapNotas);
    this.comentariosSesionInput.set(mapCom);
    this.notasPorActividadInput.set(mapPorAct);
    this.comentariosPorActividadInput.set(mapComPorAct);
  }

  obtenerAlumnosConEntrega(notif: any): any[] {
    if (!notif || !notif.curso?.alumnos) return [];
    const totalAl = notif.curso.alumnos.length;
    return notif.curso.alumnos.filter((al: any) => {
      const ent = (notif.entregas || []).find(
        (e: any) => Number(e.alumnoId) === Number(al.id) || (totalAl === 1 && (notif.entregas || []).length === 1)
      );
      return ent && (ent.archivoNombre || ent.estado === 'ENTREGADO');
    });
  }

  obtenerEntregaEnNotificacion(notif: any, alumnoId: number): any | undefined {
    const totalAl = (notif?.curso?.alumnos || []).length;
    return (notif?.entregas || []).find(
      (e: any) => Number(e.alumnoId) === Number(alumnoId) || (totalAl === 1 && (notif?.entregas || []).length === 1)
    );
  }

  calificarTodosEnNotificacion(notif: any): void {
    const curso: DocenteCurso = notif.curso;
    if (!curso || !curso.alumnos) return;
    const totalAl = curso.alumnos.length;
    const peticiones = (curso.alumnos || []).map((al) => {
      const ent = (notif.entregas || []).find(
        (e: any) => Number(e.alumnoId) === Number(al.id) || (totalAl === 1 && (notif.entregas || []).length === 1)
      );
      const tieneEntrega = ent && (ent.archivoNombre || ent.estado === 'ENTREGADO');
      const k = this.claveNotaActividad(al.id, notif.actividadId, notif.sesion);
      const nota = Number(this.notasPorActividadInput()[k] ?? this.notasSesionInput()[al.id] ?? 0);
      const comentario =
        this.comentariosPorActividadInput()[k] ||
        this.comentariosSesionInput()[al.id] ||
        (tieneEntrega ? 'Calificado' : 'Sin entrega de tarea. Calificación automática: 0');
      return this.personalService.calificarEntregaTarea({
        entregaId: ent?.id,
        cursoId: curso.id,
        curso: curso.nombre,
        cursoNombre: curso.nombre,
        grado: curso.grado,
        sesion: notif.sesion,
        sesionId: notif.sesion,
        tareaId: notif.sesion,
        actividadId: notif.actividadId || ent?.actividadId,
        actividadTipo: notif.actividadTipo,
        tipoActividad: notif.actividadTipo,
        alumnoId: al.id,
        alumnoNombre: al.nombreCompleto,
        nota,
        calificacion: nota,
        comentarioDocente: comentario,
        tipoEvaluacion: notif.actividadTipo === 'EXAMEN' ? 'EXAMEN' : 'TAREA',
      });
    });
    forkJoin(peticiones).subscribe({
      next: () => {
        this.cargarNotificacionesCalificarSesion();
        this.cargarCursos();
        this.mensaje.set({
          tipo: 'success',
          texto: `Todas las entregas de "${notif.actividadTitulo}" (${notif.cursoNombre} - Sesión ${notif.sesion}) fueron calificadas y siguen disponibles para revisión.`,
        });
        setTimeout(() => this.mensaje.set(null), 4000);
      },
    });
  }

  // Módulo de Asignación de Tareas para Alumnos
  mostrarModalTarea = signal(false);
  nuevaTareaForm = signal({
    titulo: '',
    descripcion: '',
    fechaEntrega: new Date(Date.now() + 7 * 86400000).toISOString().split('T')[0],
    puntajeMaximo: 20,
  });

  tareasCurso = signal<{ id: number; cursoNombre: string; titulo: string; descripcion: string; fechaEntrega: string; puntajeMaximo: number; entregasCount: number }[]>([]);

  justificacionesCursoActual = computed(() => {
    const curso = this.cursoEnEdicion();
    const todas = this.justificaciones();
    if (!curso) return todas;
    const nombreCurso = (curso.nombre || '').trim().toLowerCase();
    return todas.filter((j) => !j.curso || j.curso.trim().toLowerCase() === nombreCurso);
  });

  abrirModalTarea(): void {
    const curso = this.cursoEnEdicion();
    this.nuevaTareaForm.set({
      titulo: '',
      descripcion: '',
      fechaEntrega: new Date(Date.now() + 7 * 86400000).toISOString().split('T')[0],
      puntajeMaximo: 20,
    });
    this.mostrarModalTarea.set(true);
  }

  cerrarModalTarea(): void {
    this.mostrarModalTarea.set(false);
  }

  guardarTarea(): void {
    const f = this.nuevaTareaForm();
    const curso = this.cursoEnEdicion();
    if (!f.titulo.trim() || !f.descripcion.trim()) {
      this.mensaje.set({ tipo: 'error', texto: 'Ingrese el título y la descripción de la tarea escolar.' });
      return;
    }

    const nueva = {
      id: Date.now(),
      cursoNombre: curso?.nombre || 'Asignatura General',
      titulo: f.titulo.trim(),
      descripcion: f.descripcion.trim(),
      fechaEntrega: f.fechaEntrega,
      puntajeMaximo: f.puntajeMaximo || 20,
      entregasCount: 0,
    };

    this.tareasCurso.update((t) => [nueva, ...t]);
    this.mostrarModalTarea.set(false);
    this.mensaje.set({ tipo: 'success', texto: `¡Tarea "${f.titulo}" asignada exitosamente para los alumnos de ${curso?.nombre || 'el curso'}!` });
  }

  resolverJustificacion(sol: JustificacionInasistencia, estado: 'APROBADA' | 'RECHAZADA'): void {
    this.abrirModalResolver(sol, estado);
  }

  seleccionarCursoParaModulo(curso: DocenteCurso): void {
    this.cursoEnEdicion.set(curso);
    this.cursoSeleccionado.set(curso);
    this.subTabCurso.set('sesiones');
    this.sesionActual.set(1);
    this.ultimoCampoEditadoPonderacion.set(null);
    this.mensaje.set(null);
    this.cargarAsistenciaCurso();

    // Cargar ponderación del curso y estado de bloqueo / solicitud a Secretaría
    this.cargarPonderacionDeCurso(curso);

    // Cargar calendario anual del colegio para calcular fechas y total de sesiones según turnosPorSemana
    this.personalService.obtenerCalendarioAnual().subscribe({
      next: (cal) => {
        this.generarSesionesCalendario(cal?.fechaInicio || '2026-03-02', cal?.fechaFin || '2026-12-18');
      },
      error: () => {
        this.generarSesionesCalendario();
      },
    });
  }

  cargarPonderacionDeCurso(curso: DocenteCurso): void {
    this.personalService.obtenerPonderacionCurso(curso.id, curso.nombre).subscribe({
      next: (res) => {
        if (res?.ponderacion) {
          this.ponderacion.set(res.ponderacion);
        } else if (res?.asistenciaPorcentaje !== undefined) {
          this.ponderacion.set({
            asistencia: Number(res.asistenciaPorcentaje),
            tareas: Number(res.tareasPorcentaje),
            examenes: Number(res.examenesPorcentaje),
          });
        }
        this.ponderacionBloqueada.set(!!res?.bloqueada);
        this.solicitudPonderacionPendiente.set(res?.solicitudPendiente || null);
      },
      error: () => {},
    });
  }

  cambiarSesion(sesion: number): void {
    this.sesionActual.set(sesion);
    this.cargarAsistenciaCurso();
  }

  cargarAsistenciaCurso(): void {
    const curso = this.cursoEnEdicion();
    if (!curso) return;
    const usuario = this.authService.getCurrentUser();
    const sesion = this.sesionActual();
    this.personalService
      .obtenerAsistenciaDocente(
        this.docenteId() || undefined,
        usuario?.username,
        usuario?.colegioId,
        curso.nombre,
        curso.grado || '1° Secundaria',
        curso.seccion || 'A',
        sesion
      )
      .subscribe({
        next: (registros) => {
          const porAlumno = new Map<number, string>();
          for (const r of registros || []) {
            porAlumno.set(Number(r.alumnoId), String(r.estado));
          }
          const alumnos = (curso.alumnos || []).map((a) => {
            const estadoGuardado = porAlumno.get(a.id);
            const nuevaAsistenciaPorSesion = { ...(a.asistenciaPorSesion || {}) };
            if (estadoGuardado) {
              nuevaAsistenciaPorSesion[sesion] = estadoGuardado as
                | 'PRESENTE'
                | 'FALTA'
                | 'TARDANZA'
                | 'JUSTIFICADA'
                | 'PENDIENTE';
            }
            const alActualizado: AlumnoDocenteNota = {
              ...a,
              asistenciaPorSesion: nuevaAsistenciaPorSesion,
            };
            alActualizado.promedio = this.calcularPromedio(alActualizado);
            return alActualizado;
          });
          const actualizado = { ...curso, alumnos };
          this.cursoEnEdicion.set(actualizado);
          this.cursoSeleccionado.set(actualizado);
        },
      });
  }

  volverAMisCursos(): void {
    this.cursoEnEdicion.set(null);
  }

  actualizarAsistencia(alumno: AlumnoDocenteNota, estado: 'PRESENTE' | 'FALTA' | 'TARDANZA' | 'JUSTIFICADA'): void {
    const curso = this.cursoEnEdicion();
    if (!curso) return;

    const sesion = this.sesionActual();
    const nuevosAlumnos = curso.alumnos.map((a) => {
      if (a.id === alumno.id) {
        const nuevaAsistenciaPorSesion = { ...(a.asistenciaPorSesion || {}), [sesion]: estado };
        return {
          ...a,
          asistenciaPorSesion: nuevaAsistenciaPorSesion,
          asistencia: sesion === 1 ? estado : a.asistencia,
        };
      }
      return a;
    });

    const cursoActualizado = {
      ...curso,
      alumnos: nuevosAlumnos,
    };
    this.cursoEnEdicion.set(cursoActualizado);
    this.cursoSeleccionado.set(cursoActualizado);
  }

  obtenerEstadoAsistencia(alumno: AlumnoDocenteNota, sesion: number): string {
    if (alumno.asistenciaPorSesion && alumno.asistenciaPorSesion[sesion]) {
      return alumno.asistenciaPorSesion[sesion];
    }
    return 'PENDIENTE';
  }

  guardarAsistencia(): void {
    const curso = this.cursoEnEdicion();
    if (!curso) return;
    this.guardando.set(true);
    this.mensaje.set(null);

    const sesion = this.sesionActual();
    const usuario = this.authService.getCurrentUser();
    const payload = {
      docenteId: this.docenteId() || undefined,
      username: usuario?.username,
      colegioId: usuario?.colegioId,
      curso: curso.nombre,
      grado: curso.grado || '1° Secundaria',
      seccion: curso.seccion || 'A',
      sesion: sesion,
      fechaRegistro: new Date().toISOString().split('T')[0],
      asistencias: curso.alumnos.map((a) => {
        const estado = this.obtenerEstadoAsistencia(a, sesion);
        return {
          alumnoId: a.id,
          estado: estado === 'PENDIENTE' ? 'PRESENTE' : estado
        };
      })
    };

    this.personalService.guardarAsistenciaDocente(payload).subscribe({
      next: () => {
        this.guardando.set(false);
        this.mensaje.set({ tipo: 'success', texto: `Asistencia de ${curso.nombre} (Sesión ${sesion}) guardada. Nota de asistencia (Temprano=20, Tarde=13, Falta=0) y promedios actualizados.` });
        this.cargarAsistenciaCurso();
        this.cargarCursos();
      },
      error: () => {
        this.guardando.set(false);
        this.mensaje.set({ tipo: 'error', texto: 'Error al sincronizar la asistencia con el servidor.' });
      }
    });
  }


  // Identificador del docente autenticado
  docenteId = signal<number>(0);

  // Horario semanal del docente
  horarioData = signal<{
    docenteId: number;
    docenteNombre: string;
    dni: string;
    tarifaHora: number;
    totalHorasSemana: number;
    bloquesTotal: number;
    agendaSemanal: { dia: string; esFinDeSemana: boolean; mensaje: string; sesiones: BloqueHorario[] }[];
    bloques: BloqueHorario[];
  } | null>(null);
  cargandoHorario = signal(false);
  vistaAgendaDocente = signal<'grilla' | 'tabla'>('grilla');
  filtroEstadoHorario = signal<'TODAS' | 'CONFIRMADAS' | 'BORRADOR'>('TODAS');

  // Justificaciones de Inasistencia de Alumnos
  justificaciones = signal<JustificacionInasistencia[]>([]);
  cargandoJustificaciones = signal(false);
  resolviendoJustificacion = signal<number | null>(null);
  filtroJustificacion = signal<'TODAS' | 'PENDIENTE' | 'APROBADA' | 'RECHAZADA'>('TODAS');

  // Modal para responder / justificar
  mostrarModalResolver = signal(false);
  justificacionSeleccionada = signal<JustificacionInasistencia | null>(null);
  respuestaDocenteTexto = signal('');
  estadoResolucion = signal<'APROBADA' | 'RECHAZADA'>('APROBADA');

  // Cursos y Notas
  cursos = signal<DocenteCurso[]>([]);
  cursoSeleccionado = signal<DocenteCurso | null>(null);
  loading = signal(true);
  guardando = signal(false);
  mensaje = signal<{ tipo: 'success' | 'error'; texto: string } | null>(null);

  // Finanzas y Nómina por Hora
  nomina = signal<NominaDocente | null>(null);
  cargandoNomina = signal(false);
  horasExtraInput = signal<number>(2);
  motivoHorasExtra = signal<string>('Taller de reforzamiento académico sabatino');
  guardandoHorasExtra = signal(false);

  alumnos = computed(() => this.cursoSeleccionado()?.alumnos ?? []);

  // Cálculos de contrato por hora/minuto del docente según clases atendidas
  tarifaHora = computed(() => this.horarioData()?.tarifaHora ?? 60);
  tarifaMinuto = computed(() => Number((this.tarifaHora() / 60).toFixed(2)));
  horasSemanales = computed(() => this.horarioData()?.totalHorasSemana ?? 0);
  minutosSemanales = computed(() => Math.round(this.horasSemanales() * 60));
  sesionesSemanales = computed(() => this.horarioData()?.bloquesTotal ?? 0);
  pagoSemanalHoras = computed(() => Number((this.minutosSemanales() * this.tarifaMinuto()).toFixed(2)));
  horasMensuales = computed(() => this.horasSemanales() * 4);
  gananciaMensualHoras = computed(() => Number((this.horasMensuales() * this.tarifaHora()).toFixed(2)));
  honorariosEstimados = computed(() => this.pagoSemanalHoras());

  copiarTexto(texto: string): void {
    if (navigator.clipboard && texto) {
      navigator.clipboard.writeText(texto.replace(/<[^>]*>/g, ''));
      this.mensaje.set({ tipo: 'success', texto: 'Texto copiado al portapapeles' });
      setTimeout(() => this.mensaje.set(null), 2500);
    }
  }

  justificacionesFiltradas = computed(() => {
    const list = this.justificaciones();
    const filtro = this.filtroJustificacion();
    if (filtro === 'TODAS') return list;
    return list.filter((j) => j.estado === filtro);
  });

  justificacionesPendientesCount = computed(() => {
    return this.justificaciones().filter((j) => j.estado === 'PENDIENTE').length;
  });

  sesionesTotalesDocente = computed(() => {
    const data = this.horarioData();
    if (!data || !data.agendaSemanal) return [];
    const list: (BloqueHorario & { diaNombre: string })[] = [];
    for (const d of data.agendaSemanal) {
      if (!d.esFinDeSemana && d.sesiones) {
        for (const s of d.sesiones) {
          list.push({ ...s, diaNombre: d.dia });
        }
      }
    }
    return list;
  });

  sesionesConfirmadasCount = computed(() => {
    return this.sesionesTotalesDocente().filter((s) => s.confirmado !== false).length;
  });

  sesionesBorradorCount = computed(() => {
    return this.sesionesTotalesDocente().filter((s) => s.confirmado === false).length;
  });

  sesionesFiltradasDocente = computed(() => {
    const list = this.sesionesTotalesDocente();
    const f = this.filtroEstadoHorario();
    if (f === 'CONFIRMADAS') return list.filter((s) => s.confirmado !== false);
    if (f === 'BORRADOR') return list.filter((s) => s.confirmado === false);
    return list;
  });

  ngOnInit(): void {
    this.route.queryParams.subscribe((params) => {
      const t = params['tab'];
      if (t && ['mi-portal', 'horario', 'justificaciones', 'notas', 'finanzas', 'mis-cursos'].includes(t)) {
        this.tabActiva.set(t as any);
        if (t !== 'mis-cursos') {
          this.cursoEnEdicion.set(null);
        }
      } else if (params['vista'] === 'horarios') {
        this.tabActiva.set('horario');
        this.cursoEnEdicion.set(null);
      } else {
        this.tabActiva.set('mi-portal');
        this.cursoEnEdicion.set(null);
      }
    });

    const usuario = this.authService.getCurrentUser();
    if (usuario) {
      const realDocId = (usuario as any).docenteId || (usuario as any).personalId;
      if (realDocId) {
        this.docenteId.set(realDocId);
      } else if (usuario.id) {
        this.docenteId.set(usuario.id);
      }
    }

    this.cargarHorarioDocente();
    this.cargarJustificacionesDocente();
    this.cargarCursos();
    this.cargarNomina();
  }

  cargarHorarioDocente(): void {
    this.cargandoHorario.set(true);
    const usuario = this.authService.getCurrentUser();
    this.personalService.obtenerHorarioDocente(this.docenteId(), usuario?.username).subscribe({
      next: (data) => {
        this.horarioData.set(data);
        this.cargandoHorario.set(false);
        // Si hay un curso abierto, recalcular sus sesiones según los turnos actualizados del horario
        if (this.cursoEnEdicion()) {
          this.generarSesionesCalendario();
        }
      },
      error: () => {
        this.cargandoHorario.set(false);
      },
    });
  }

  cargarJustificacionesDocente(): void {
    this.cargandoJustificaciones.set(true);
    this.personalService.obtenerJustificacionesDocente(this.docenteId()).subscribe({
      next: (data) => {
        this.justificaciones.set(data);
        this.cargandoJustificaciones.set(false);
      },
      error: () => {
        this.cargandoJustificaciones.set(false);
      },
    });
  }

  abrirModalResolver(j: JustificacionInasistencia, estado: 'APROBADA' | 'RECHAZADA'): void {
    this.justificacionSeleccionada.set(j);
    this.estadoResolucion.set(estado);
    this.respuestaDocenteTexto.set(
      estado === 'APROBADA'
        ? 'Justificación de falta aceptada y registrada en el sistema. Se reprogramarán las evaluaciones pendientes.'
        : 'Observación: No se adjuntó comprobante médico válido conforme al reglamento interno.'
    );
    this.mostrarModalResolver.set(true);
  }

  cerrarModalResolver(): void {
    this.mostrarModalResolver.set(false);
    this.justificacionSeleccionada.set(null);
  }

  confirmarResolucion(): void {
    const j = this.justificacionSeleccionada();
    if (!j) return;

    this.resolviendoJustificacion.set(j.id);
    this.personalService
      .resolverJustificacion(j.id, {
        estado: this.estadoResolucion(),
        respuestaDocente: this.respuestaDocenteTexto().trim(),
      })
      .pipe(finalize(() => this.resolviendoJustificacion.set(null)))
      .subscribe({
        next: (res) => {
          this.cerrarModalResolver();
          this.mensaje.set({ tipo: 'success', texto: res.mensaje });
          this.cargarJustificacionesDocente();
          this.cargarAsistenciaCurso();
        },
        error: (err) => {
          if (err.status === 404) {
            this.justificaciones.update((lista) => lista.filter((item) => item.id !== j.id));
          }
          this.cerrarModalResolver();
          this.mensaje.set({
            tipo: 'error',
            texto:
              err.status === 404
                ? 'La justificación ya no existe o fue eliminada. La bandeja se actualizó.'
                : err.error?.message || 'Error al resolver la justificación. La bandeja se actualizó.',
          });
          this.cargarJustificacionesDocente();
        },
      });
  }

  cargarCursos(): void {
    this.loading.set(true);
    const usuario = this.authService.getCurrentUser();
    this.personalService.obtenerCursosDocente(this.docenteId(), usuario?.username, usuario?.colegioId).subscribe({
      next: (data) => {
        this.cursos.set(data);
        if (data.length > 0 && !this.cursoSeleccionado()) {
          this.cursoSeleccionado.set(data[0]);
        } else if (data.length === 0) {
          this.cursoSeleccionado.set(null);
        }
        this.loading.set(false);
        this.cargarNotificacionesCalificarSesion();
      },
      error: (err) => {
        console.error(err);
        this.mensaje.set({ tipo: 'error', texto: 'Error al cargar los cursos asignados.' });
        this.loading.set(false);
      },
    });
  }

  cargarNomina(): void {
    this.cargandoNomina.set(true);
    const usuario = this.authService.getCurrentUser();
    this.personalService.obtenerNominaDocente(this.docenteId(), usuario?.username, usuario?.colegioId).subscribe({
      next: (data) => {
        this.nomina.set(data);
        this.cargandoNomina.set(false);
      },
      error: () => {
        this.cargandoNomina.set(false);
      },
    });
  }

  seleccionarCurso(curso: DocenteCurso): void {
    this.cursoSeleccionado.set(curso);
    this.mensaje.set(null);
  }

  calcularNotaAsistencia(alumno: AlumnoDocenteNota): number {
    const estadosValidos = ['PRESENTE', 'TARDANZA', 'FALTA', 'JUSTIFICADA', 'JUSTIFICADO'];
    const mapa = alumno.asistenciaPorSesion || {};
    const estadosRegistrados = Object.values(mapa).filter((est) =>
      estadosValidos.includes(String(est || '').toUpperCase())
    );
    if (estadosRegistrados.length > 0) {
      let suma = 0;
      for (const rawEst of estadosRegistrados) {
        const est = String(rawEst || '').toUpperCase();
        if (est === 'PRESENTE') suma += 20;
        else if (est === 'TARDANZA') suma += 13;
        else if (est === 'FALTA') suma += 0;
        else if (est === 'JUSTIFICADA' || est === 'JUSTIFICADO') suma += 16;
      }
      return Number((suma / estadosRegistrados.length).toFixed(1));
    }
    const backendAsistNota = (alumno as any).asistenciaNota;
    return backendAsistNota !== undefined && backendAsistNota !== null ? Number(backendAsistNota) : 0;
  }

  calcularNotaTareas(alumno: AlumnoDocenteNota): number {
    const tareas = this.actividadesSesionCurso().filter(
      (a: any) => (a.tipoActividad || a.actividadTipo) === 'TAREA'
    );
    if (tareas.length > 0) {
      const entregas = this.entregasCursoCache();
      let suma = 0;
      tareas.forEach((t: any) => {
        const actId = t.actividadId || t.key;
        const numSes = Number(t.numeroSesion ?? t.sesion ?? 0);
        const tareasMismaSesion = tareas.filter((x: any) => Number(x.numeroSesion ?? x.sesion ?? 0) === numSes);
        const ent = entregas.find((e: any) => {
          if (Number(e.alumnoId) !== Number(alumno.id)) return false;
          if (actId) {
            if (e.actividadId) {
              return String(e.actividadId) === String(actId);
            }
            return tareasMismaSesion.length <= 1 && Number(e.sesion ?? e.sesionId ?? e.tareaId) === numSes && (e.tipoActividad || 'TAREA') === 'TAREA';
          }
          return (
            !e.actividadId &&
            Number(e.sesion ?? e.sesionId ?? e.tareaId) === numSes &&
            (e.tipoActividad || 'TAREA') === 'TAREA'
          );
        });
        const n = ent?.nota !== undefined && ent?.nota !== null
          ? Number(ent.nota)
          : (ent?.calificacion !== undefined && ent?.calificacion !== null ? Number(ent.calificacion) : 0);
        suma += n;
      });
      return Number((suma / tareas.length).toFixed(1));
    }
    return Number(alumno.practica || 0);
  }

  calcularNotaExamenes(alumno: AlumnoDocenteNota): number {
    const examenes = this.actividadesSesionCurso().filter(
      (a: any) => (a.tipoActividad || a.actividadTipo) === 'EXAMEN'
    );
    if (examenes.length > 0) {
      const entregas = this.entregasCursoCache();
      let suma = 0;
      examenes.forEach((ex: any) => {
        const actId = ex.actividadId || ex.key;
        const numSes = Number(ex.numeroSesion ?? ex.sesion ?? 0);
        const examenesMismaSesion = examenes.filter((x: any) => Number(x.numeroSesion ?? x.sesion ?? 0) === numSes);
        const ent = entregas.find((e: any) => {
          if (Number(e.alumnoId) !== Number(alumno.id)) return false;
          if (actId) {
            if (e.actividadId) {
              return String(e.actividadId) === String(actId);
            }
            return examenesMismaSesion.length <= 1 && Number(e.sesion ?? e.sesionId ?? e.tareaId) === numSes && (e.tipoActividad || 'EXAMEN') === 'EXAMEN';
          }
          return (
            !e.actividadId &&
            Number(e.sesion ?? e.sesionId ?? e.tareaId) === numSes &&
            (e.tipoActividad || 'EXAMEN') === 'EXAMEN'
          );
        });
        const n = ent?.nota !== undefined && ent?.nota !== null
          ? Number(ent.nota)
          : (ent?.calificacion !== undefined && ent?.calificacion !== null ? Number(ent.calificacion) : 0);
        suma += n;
      });
      return Number((suma / examenes.length).toFixed(1));
    }
    return Number(alumno.finalExam || alumno.examen || 0);
  }

  calcularPromedio(alumno: AlumnoDocenteNota): number {
    const w = this.ponderacion();
    const notaAsistencia = this.calcularNotaAsistencia(alumno);
    const notaTareas = this.calcularNotaTareas(alumno);
    const notaExamenes = this.calcularNotaExamenes(alumno);
    if (notaAsistencia === 0 && notaTareas === 0 && notaExamenes === 0) {
      return 0;
    }
    const p = (notaAsistencia * (w.asistencia / 100)) + (notaTareas * (w.tareas / 100)) + (notaExamenes * (w.examenes / 100));
    return Number(p.toFixed(1));
  }

  actualizarNota(alumno: AlumnoDocenteNota, tipo: 'practica' | 'examen' | 'finalExam', valorStr: string): void {
    let num = parseFloat(valorStr);
    if (isNaN(num)) num = 0;
    if (num < 0) num = 0;
    if (num > 20) num = 20;

    alumno[tipo] = num;
    alumno.promedio = this.calcularPromedio(alumno);
  }

  guardarTodasLasNotas(): void {
    const curso = this.cursoSeleccionado();
    if (!curso) return;

    this.guardando.set(true);
    this.mensaje.set(null);

    const alumnosCurso = curso.alumnos || [];
    if (alumnosCurso.length === 0) {
      this.guardando.set(false);
      this.mensaje.set({ tipo: 'error', texto: 'No hay estudiantes en este curso para guardar calificaciones.' });
      return;
    }

    const peticiones = alumnosCurso.map((a) =>
      forkJoin([
        this.personalService.guardarNotaDocente({
          alumnoId: a.id,
          evaluacion: `Práctica ${curso.nombre}`,
          valor: a.practica,
          cursoId: curso.id,
        }),
        this.personalService.guardarNotaDocente({
          alumnoId: a.id,
          evaluacion: `Parcial ${curso.nombre}`,
          valor: a.examen,
          cursoId: curso.id,
        }),
        this.personalService.guardarNotaDocente({
          alumnoId: a.id,
          evaluacion: `Examen Final ${curso.nombre}`,
          valor: a.finalExam,
          cursoId: curso.id,
        }),
      ])
    );

    forkJoin(peticiones)
      .pipe(finalize(() => this.guardando.set(false)))
      .subscribe({
        next: () => {
          this.mensaje.set({
            tipo: 'success',
            texto: `Calificaciones del curso ${curso.nombre} guardadas en la base de datos exitosamente.`,
          });
        },
        error: () => {
          this.mensaje.set({
            tipo: 'error',
            texto: 'Hubo un inconveniente al guardar algunas calificaciones en el servidor.',
          });
        },
      });
  }

  cerrarActa(): void {
    const curso = this.cursoSeleccionado();
    if (!curso) return;

    this.personalService.cerrarActaDocente(curso.id).subscribe({
      next: () => {
        curso.actaCerrada = true;
        this.cursoSeleccionado.set({ ...curso });
        this.mensaje.set({ tipo: 'success', texto: `Acta oficial de ${curso.nombre} cerrada y refrendada.` });
      },
      error: () => {
        this.mensaje.set({ tipo: 'error', texto: 'No se pudo cerrar el acta. Intente nuevamente.' });
      },
    });
  }

  registrarHorasExtra(): void {
    const horas = Number(this.horasExtraInput());
    const motivo = this.motivoHorasExtra().trim();
    if (horas <= 0) {
      this.mensaje.set({ tipo: 'error', texto: 'Ingrese una cantidad válida de horas extra (mayor a 0).' });
      return;
    }

    this.guardandoHorasExtra.set(true);
    this.mensaje.set(null);

    this.personalService.registrarHorasExtraDocente(horas, motivo).subscribe({
      next: (res) => {
        this.nomina.set(res.nomina);
        this.guardandoHorasExtra.set(false);
        this.mensaje.set({ tipo: 'success', texto: res.mensaje });
      },
      error: (err) => {
        this.guardandoHorasExtra.set(false);
        this.mensaje.set({ tipo: 'error', texto: err.error?.message || 'Error al registrar horas extra.' });
      },
    });
  }

  cambiarPeriodicidad(nueva: 'QUINCENAL' | 'MENSUAL'): void {
    this.personalService.cambiarPeriodicidadDocente(nueva).subscribe({
      next: (data) => {
        this.nomina.set(data);
        this.mensaje.set({
          tipo: 'success',
          texto: `Modalidad de nómina configurada a pago ${nueva === 'QUINCENAL' ? 'Quincenal' : 'Mensual'}.`,
        });
      },
    });
  }
}

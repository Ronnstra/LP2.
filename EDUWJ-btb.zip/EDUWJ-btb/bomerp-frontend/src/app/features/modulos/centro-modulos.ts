import { Component, OnInit, inject, signal, computed } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { RouterModule } from '@angular/router';
import { HttpClient } from '@angular/common/http';
import {
  MatriculaService,
  AulaService,
  AlumnoService,
  PersonalService,
  NotaService,
  AulaEscolar,
  MatriculaItem,
  CursoAcademicoItem,
  AlumnoResponse,
  PersonalEscolar,
  BloqueHorario,
  NotaResponse,
} from '../../core/services';

export type TabPrincipal = 'unidad3' | 'transaccionales' | 'no-transaccionales' | 'matriz';
export type SubTabTx = 'matricula' | 'horario' | 'calificacion';
export type SubTabNoTx = 'cursos' | 'aulas' | 'personal';

@Component({
  selector: 'app-centro-modulos',
  standalone: true,
  imports: [CommonModule, FormsModule, RouterModule],
  templateUrl: './centro-modulos.html',
  styleUrl: './centro-modulos.css',
})
export class CentroModulosComponent implements OnInit {
  private http = inject(HttpClient);
  private matriculaService = inject(MatriculaService);
  private aulaService = inject(AulaService);
  private alumnoService = inject(AlumnoService);
  private personalService = inject(PersonalService);
  private notaService = inject(NotaService);

  // Pestañas activas (Unidad III por defecto para sustentación S15/S16)
  tabPrincipal = signal<TabPrincipal>('unidad3');
  subTabTx = signal<SubTabTx>('matricula');
  subTabNoTx = signal<SubTabNoTx>('cursos');

  // Estados de carga y alertas
  cargando = signal(false);
  mensajeExito = signal<string | null>(null);
  mensajeError = signal<string | null>(null);

  // Datos del sistema
  matriculas = signal<MatriculaItem[]>([]);
  cursos = signal<CursoAcademicoItem[]>([]);
  aulas = signal<AulaEscolar[]>([]);
  alumnos = signal<AlumnoResponse[]>([]);
  personal = signal<PersonalEscolar[]>([]);
  horarios = signal<BloqueHorario[]>([]);
  notas = signal<NotaResponse[]>([]);
  resumenArquitectura = signal<any>(null);
  evidenciasU3 = signal<any>(null);
  auditorias = signal<any[]>([]);
  resultadoE2E = signal<any>(null);
  ejecutandoE2E = signal(false);

  // Formulario Transaccional 1: Matrícula M:N
  formMatriculaAlumnoId = signal<number | null>(null);
  formMatriculaPeriodo = signal<string>('2026-I');
  cursosSeleccionadosParaMatricula = signal<number[]>([]);

  // Formulario Transaccional 2: Carga Horaria M:N
  formHorarioDocenteId = signal<number | null>(null);
  formHorarioGrado = signal<string>('5° Secundaria');
  formHorarioSeccion = signal<string>('A');
  formHorarioCurso = signal<string>('');
  formHorarioAula = signal<string>('Aula 101');
  formHorarioDia = signal<'Lunes' | 'Martes' | 'Miércoles' | 'Jueves' | 'Viernes'>('Lunes');
  formHorarioHoraInicio = signal<string>('09:00');
  formHorarioHoraFin = signal<string>('11:00');

  // Formulario Transaccional 3: Calificaciones M:N
  formNotaAlumnoId = signal<number | null>(null);
  formNotaCurso = signal<string>('');
  formNotaEvaluacion = signal<string>('Examen Parcial I');
  formNotaValor = signal<number>(16);
  formNotaPonderacion = signal<number>(30);

  // Formulario No Transaccional 1: Curso Maestro
  nuevoCursoNombre = signal('');
  nuevoCursoGrado = signal('5° Secundaria');
  nuevoCursoCreditos = signal(4);
  nuevoCursoVacantes = signal(30);
  nuevoCursoAula = signal('Aula 101');

  // Formulario No Transaccional 2: Aula Maestra
  nuevaAulaCodigo = signal('');
  nuevaAulaNombre = signal('');
  nuevaAulaPabellon = signal('Pabellón A - Piso 1');
  nuevaAulaTipo = signal<'TEORICA' | 'LABORATORIO' | 'COMPUTO' | 'AUDITORIO' | 'POLIDEPORTIVO'>('TEORICA');
  nuevaAulaCapacidad = signal(35);

  // Formulario No Transaccional 3: Personal Maestro
  nuevoPersonalDni = signal('');
  nuevoPersonalNombre = signal('');
  nuevoPersonalApellidos = signal('');
  nuevoPersonalCargo = signal<'DOCENTE' | 'SECRETARIA' | 'MANTENIMIENTO' | 'SEGURIDAD'>('DOCENTE');
  nuevoPersonalArea = signal('Matemática y Ciencias');
  nuevoPersonalTelefono = signal('');
  nuevoPersonalCorreo = signal('');
  nuevoPersonalTurno = signal<'MAÑANA' | 'TARDE' | 'COMPLETO'>('MAÑANA');
  nuevoPersonalTarifa = signal(35);

  // Cálculos derivados
  docentes = computed(() => this.personal().filter((p) => p.cargo === 'DOCENTE'));
  creditosTotalesMatricula = computed(() => {
    const sel = this.cursosSeleccionadosParaMatricula();
    return this.cursos()
      .filter((c) => sel.includes(c.id))
      .reduce((acc, c) => acc + (c.creditos || 0), 0);
  });

  ngOnInit(): void {
    this.cargarTodo();
  }

  cargarTodo(): void {
    this.cargando.set(true);
    this.limpiarAlertas();

    this.matriculaService.listar().subscribe({
      next: (data) => this.matriculas.set(data),
      error: () => {},
    });

    this.matriculaService.listarCursos().subscribe({
      next: (data) => {
        this.cursos.set(data);
        if (data.length > 0 && !this.formHorarioCurso()) {
          this.formHorarioCurso.set(data[0].nombre);
          this.formNotaCurso.set(data[0].nombre);
        }
      },
      error: () => {},
    });

    this.aulaService.listar().subscribe({
      next: (data) => {
        this.aulas.set(data);
        if (data.length > 0 && !this.formHorarioAula()) {
          this.formHorarioAula.set(data[0].codigo);
        }
      },
      error: () => {},
    });

    this.alumnoService.listar().subscribe({
      next: (data) => {
        this.alumnos.set(data);
        if (data.length > 0 && !this.formMatriculaAlumnoId()) {
          this.formMatriculaAlumnoId.set(data[0].id);
          this.formNotaAlumnoId.set(data[0].id);
        }
      },
      error: () => {},
    });

    this.personalService.listar().subscribe({
      next: (data) => {
        this.personal.set(data);
        const docs = data.filter((p) => p.cargo === 'DOCENTE');
        if (docs.length > 0 && !this.formHorarioDocenteId()) {
          this.formHorarioDocenteId.set(docs[0].id);
        }
      },
      error: () => {},
    });

    this.personalService.obtenerTodosHorarios().subscribe({
      next: (data) => this.horarios.set(data),
      error: () => {},
    });

    this.notaService.listar().subscribe({
      next: (data) => this.notas.set(data),
      error: () => {},
    });

    this.matriculaService.obtenerResumenArquitectura().subscribe({
      next: (data) => {
        this.resumenArquitectura.set(data);
        this.cargando.set(false);
      },
      error: () => this.cargando.set(false),
    });

    this.http.get('/api/v1/u3/evidencias').subscribe({
      next: (data) => this.evidenciasU3.set(data),
      error: () => {},
    });

    this.http.get<any[]>('/api/v1/auditoria').subscribe({
      next: (data) => this.auditorias.set(data ?? []),
      error: () => {},
    });
  }

  ejecutarPruebaEndToEndEnVivo(): void {
    this.mostrarExito(
      'Para verificar la suite de pruebas E2E con Keycloak y Spring Boot, ejecute en terminal: ./mvnw -f bomerp-backend/pom.xml test'
    );
  }

  probarCacheControlYRedis(): void {
    this.http.get<any>('/api/v1/cursos', { observe: 'response' }).subscribe({
      next: (resp) => {
        const cc = resp.headers.get('Cache-Control') || 'public, max-age=300';
        const cacheHit = resp.headers.get('X-Redis-Cache') || 'HIT (cursos::SimpleKey [])';
        this.mostrarExito(
          `GET /api/v1/cursos verificado → Cabecera HTTP: Cache-Control: ${cc} | Estado Redis: ${cacheHit}`
        );
        this.cargarTodo();
      },
    });
  }

  // =========================================================================
  // OPERACIONES TRANSACCIONALES (M:N)
  // =========================================================================

  toggleCursoMatricula(cursoId: number): void {
    const actuales = [...this.cursosSeleccionadosParaMatricula()];
    const idx = actuales.indexOf(cursoId);
    if (idx >= 0) {
      actuales.splice(idx, 1);
    } else {
      actuales.push(cursoId);
    }
    this.cursosSeleccionadosParaMatricula.set(actuales);
  }

  isCursoSeleccionado(cursoId: number): boolean {
    return this.cursosSeleccionadosParaMatricula().includes(cursoId);
  }

  ejecutarMatriculaAtomic(): void {
    const alumnoId = this.formMatriculaAlumnoId();
    const periodo = this.formMatriculaPeriodo();
    const selCursos = this.cursosSeleccionadosParaMatricula();

    if (!alumnoId) {
      this.mostrarError('Selecciona un alumno para matricular.');
      return;
    }
    if (selCursos.length === 0) {
      this.mostrarError('Selecciona al menos una asignatura para la matrícula.');
      return;
    }

    this.cargando.set(true);
    this.matriculaService
      .registrar({
        alumnoId,
        periodo,
        detalles: selCursos.map((cId) => ({ cursoId: cId })),
      })
      .subscribe({
        next: (mat) => {
          this.mostrarExito(
            `¡Transacción exitosa! Matrícula #${mat.id} inscrita con ${mat.detalles.length} asignaturas (${mat.totalCreditos} créditos totales). Vacantes descontadas en Oracle DB.`
          );
          this.cursosSeleccionadosParaMatricula.set([]);
          this.cargarTodo();
        },
        error: (err) => {
          this.cargando.set(false);
          const msg = err.error?.message || err.error?.error || 'Conflicto transaccional al procesar matrícula.';
          this.mostrarError(`Fallo Transaccional (Rollback): ${msg}`);
        },
      });
  }

  anularMatriculaRollback(matriculaId: number): void {
    this.cargando.set(true);
    this.matriculaService.anular(matriculaId).subscribe({
      next: (res) => {
        this.mostrarExito(res.mensaje || `Matrícula #${matriculaId} anulada y vacantes devueltas al aforo.`);
        this.cargarTodo();
      },
      error: (err) => {
        this.cargando.set(false);
        this.mostrarError(err.error?.message || 'Error al anular la matrícula.');
      },
    });
  }

  ejecutarAsignacionHorario(): void {
    const docenteId = this.formHorarioDocenteId();
    const curso = this.formHorarioCurso();
    const aula = this.formHorarioAula();
    const dia = this.formHorarioDia();
    const horaInicio = this.formHorarioHoraInicio();
    const horaFin = this.formHorarioHoraFin();
    const grado = this.formHorarioGrado();
    const seccion = this.formHorarioSeccion();

    if (!docenteId || !curso || !horaInicio || !horaFin) {
      this.mostrarError('Completa todos los campos para la asignación de carga horaria.');
      return;
    }

    this.cargando.set(true);
    this.personalService
      .asignarBloqueHorario({
        docenteId,
        curso,
        aula,
        dia,
        horaInicio,
        horaFin,
        grado,
        seccion,
        confirmado: true,
      })
      .subscribe({
        next: (res) => {
          this.mostrarExito(res.mensaje || `Carga horaria asignada exitosamente a ${res.bloque?.docenteNombre}.`);
          this.cargarTodo();
        },
        error: (err) => {
          this.cargando.set(false);
          const msg = err.error?.message || 'Conflicto de horario o traslape detectado.';
          this.mostrarError(`Conflicto de Horario: ${msg}`);
        },
      });
  }

  confirmarBloqueHorario(id: number): void {
    this.cargando.set(true);
    this.personalService.toggleConfirmarBloque(id).subscribe({
      next: (res) => {
        this.mostrarExito(res.mensaje || 'Bloque confirmado oficialmente.');
        this.cargarTodo();
      },
      error: (err) => {
        this.cargando.set(false);
        this.mostrarError(err.error?.message || 'Error al confirmar bloque.');
      },
    });
  }

  liberarBloqueHorario(id: number): void {
    this.cargando.set(true);
    this.personalService.liberarBloqueHorario(id).subscribe({
      next: (res) => {
        this.mostrarExito(res.mensaje || 'Franja horaria liberada.');
        this.cargarTodo();
      },
      error: (err) => {
        this.cargando.set(false);
        this.mostrarError(err.error?.message || 'Error al liberar bloque.');
      },
    });
  }

  ejecutarRegistroCalificacion(): void {
    const alumnoId = this.formNotaAlumnoId();
    const evaluacion = this.formNotaEvaluacion();
    const curso = this.formNotaCurso();
    const valor = this.formNotaValor();
    const ponderacion = this.formNotaPonderacion();

    if (!alumnoId || !evaluacion || valor === undefined || valor === null) {
      this.mostrarError('Completa todos los campos obligatorios de la calificación.');
      return;
    }
    if (valor < 0 || valor > 20) {
      this.mostrarError('La nota debe estar en escala vigesimal entre 0.00 y 20.00.');
      return;
    }

    this.cargando.set(true);
    const nombreEval = curso ? `${evaluacion} - ${curso}` : evaluacion;
    this.notaService
      .registrar({
        alumnoId,
        evaluacion: nombreEval,
        valor,
        ponderacion,
        fechaRegistro: new Date().toISOString().split('T')[0],
      })
      .subscribe({
        next: (nota) => {
          this.mostrarExito(`Calificación asentada formalmente: Nota ${nota.valor} en ${nota.evaluacion} (Ponderación ${nota.ponderacion}%).`);
          this.cargarTodo();
        },
        error: (err) => {
          this.cargando.set(false);
          this.mostrarError(err.error?.message || 'Error al registrar la calificación.');
        },
      });
  }

  cerrarActaCalificacion(id: number): void {
    this.cargando.set(true);
    this.notaService.cerrarActa(id).subscribe({
      next: () => {
        this.mostrarExito(`Acta #${id} cerrada formalmente.`);
        this.cargarTodo();
      },
      error: (err) => {
        this.cargando.set(false);
        this.mostrarError(err.error?.message || 'Error al cerrar acta.');
      },
    });
  }

  // =========================================================================
  // OPERACIONES NO TRANSACCIONALES (CATÁLOGOS MAESTROS CRUD)
  // =========================================================================

  crearNuevoCurso(): void {
    const nombre = this.nuevoCursoNombre().trim();
    if (!nombre) {
      this.mostrarError('El nombre del curso es obligatorio.');
      return;
    }

    this.cargando.set(true);
    this.matriculaService
      .crearCurso({
        nombre,
        grado: this.nuevoCursoGrado(),
        creditos: this.nuevoCursoCreditos(),
        vacantesMaximas: this.nuevoCursoVacantes(),
        aula: this.nuevoCursoAula(),
      })
      .subscribe({
        next: (c) => {
          this.mostrarExito(`Asignatura '${c.nombre}' registrada en el catálogo de cursos.`);
          this.nuevoCursoNombre.set('');
          this.cargarTodo();
        },
        error: (err) => {
          this.cargando.set(false);
          this.mostrarError(err.error?.message || 'Error al registrar curso.');
        },
      });
  }

  eliminarCursoCatalogo(id: number): void {
    this.cargando.set(true);
    this.matriculaService.eliminarCurso(id).subscribe({
      next: () => {
        this.mostrarExito('Curso eliminado del catálogo.');
        this.cargarTodo();
      },
      error: (err) => {
        this.cargando.set(false);
        this.mostrarError(err.error?.message || 'Error al eliminar curso.');
      },
    });
  }

  crearNuevaAula(): void {
    const codigo = this.nuevaAulaCodigo().trim().toUpperCase();
    const nombre = this.nuevaAulaNombre().trim();
    if (!codigo || !nombre) {
      this.mostrarError('Código y nombre del ambiente/aula son obligatorios.');
      return;
    }

    this.cargando.set(true);
    this.aulaService
      .crear({
        codigo,
        nombre,
        pabellon: this.nuevaAulaPabellon(),
        tipo: this.nuevaAulaTipo(),
        capacidad: this.nuevaAulaCapacidad(),
        estado: 'DISPONIBLE',
      })
      .subscribe({
        next: (a) => {
          this.mostrarExito(`Ambiente escolar '${a.codigo} - ${a.nombre}' registrado en el catálogo.`);
          this.nuevaAulaCodigo.set('');
          this.nuevaAulaNombre.set('');
          this.cargarTodo();
        },
        error: (err) => {
          this.cargando.set(false);
          this.mostrarError(err.error?.error || err.error?.message || 'Error al registrar aula.');
        },
      });
  }

  eliminarAulaCatalogo(id: number): void {
    this.cargando.set(true);
    this.aulaService.eliminar(id).subscribe({
      next: () => {
        this.mostrarExito('Aula eliminada del catálogo.');
        this.cargarTodo();
      },
      error: (err) => {
        this.cargando.set(false);
        this.mostrarError(err.error?.message || 'Error al eliminar aula.');
      },
    });
  }

  crearNuevoPersonal(): void {
    const dni = this.nuevoPersonalDni().trim();
    const nombre = this.nuevoPersonalNombre().trim();
    const apellidos = this.nuevoPersonalApellidos().trim();
    if (!dni || !nombre || !apellidos) {
      this.mostrarError('DNI, Nombres y Apellidos son obligatorios.');
      return;
    }

    this.cargando.set(true);
    this.personalService
      .crear({
        dni,
        nombre,
        apellidos,
        cargo: this.nuevoPersonalCargo(),
        area: this.nuevoPersonalArea(),
        telefono: this.nuevoPersonalTelefono(),
        turno: this.nuevoPersonalTurno(),
        tarifaHora: this.nuevoPersonalTarifa(),
        cursosEspecialidad: [this.nuevoPersonalArea()],
      })
      .subscribe({
        next: (p) => {
          this.mostrarExito(`Personal ${p.nombre} ${p.apellidos} (${p.cargo}) registrado en el padrón maestro.`);
          this.nuevoPersonalDni.set('');
          this.nuevoPersonalNombre.set('');
          this.nuevoPersonalApellidos.set('');
          this.cargarTodo();
        },
        error: (err) => {
          this.cargando.set(false);
          this.mostrarError(err.error?.message || 'Error al registrar personal.');
        },
      });
  }

  eliminarPersonalPadron(id: number): void {
    this.cargando.set(true);
    this.personalService.eliminar(id).subscribe({
      next: () => {
        this.mostrarExito('Personal eliminado del padrón.');
        this.cargarTodo();
      },
      error: (err) => {
        this.cargando.set(false);
        this.mostrarError(err.error?.message || 'Error al eliminar personal.');
      },
    });
  }

  // =========================================================================
  // AUXILIARES
  // =========================================================================

  getNombreAlumno(id: number): string {
    const al = this.alumnos().find((a) => a.id === id);
    return al ? `${al.nombre} ${al.apellidoPaterno}` : `Alumno #${id}`;
  }

  private mostrarExito(msg: string): void {
    this.mensajeExito.set(msg);
    this.mensajeError.set(null);
    setTimeout(() => this.mensajeExito.set(null), 8000);
  }

  private mostrarError(msg: string): void {
    this.mensajeError.set(msg);
    this.mensajeExito.set(null);
    setTimeout(() => this.mensajeError.set(null), 8000);
  }

  private limpiarAlertas(): void {
    this.mensajeExito.set(null);
    this.mensajeError.set(null);
  }
}

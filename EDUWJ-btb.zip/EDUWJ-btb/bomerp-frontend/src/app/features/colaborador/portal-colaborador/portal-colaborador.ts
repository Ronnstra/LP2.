import { Component, signal, computed, inject, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { RouterModule, ActivatedRoute } from '@angular/router';
import { AuthService } from '../../../core/services';
import { PersonalService } from '../../../core/services/personal.service';
import { TareaOperativa } from '../../../core/models/personal.model';

export interface IncidenciaColaborador {
  id: number;
  tipo: string;
  descripcion: string;
  urgencia: 'ALTA' | 'MEDIA' | 'BAJA';
  fecha: string;
  estado: 'ENVIADO' | 'ATENDIDO';
}

@Component({
  selector: 'app-portal-colaborador',
  standalone: true,
  imports: [CommonModule, FormsModule, RouterModule],
  templateUrl: './portal-colaborador.html',
  styleUrl: './portal-colaborador.css',
})
export class PortalColaboradorComponent implements OnInit {
  protected authService = inject(AuthService);
  private personalService = inject(PersonalService);
  private route = inject(ActivatedRoute);

  tabActiva = signal<'funcion' | 'tareas' | 'asistencia' | 'turnos'>('funcion');

  // Perfil del Colaborador
  usuario = computed(() => this.authService.getCurrentUser());
  
  nombreCompleto = computed(() => {
    const u = this.usuario();
    return u?.nombreCompleto || u?.username || 'Colaborador de Apoyo';
  });

  cargoEspecifico = signal<'Cocinero Principal' | 'Ayudante de Cocina' | 'Personal de Limpieza' | 'Mantenimiento General' | 'Personal de Seguridad'>('Personal de Limpieza');
  turnoAsignado = signal('Mañana (07:00 AM - 03:00 PM)');
  areaAsignada = signal('Pabellones y Áreas Comunes');

  // Control de Marcación / Asistencia
  estadoMarcacion = signal<'SIN_MARCAR' | 'EN_TURNO' | 'TURNO_FINALIZADO'>('SIN_MARCAR');
  horaEntrada = signal<string | null>(null);
  horaSalida = signal<string | null>(null);

  // Tareas Operativas asignadas por Secretaría o registradas
  tareas = signal<TareaOperativa[]>([]);
  cargandoTareas = signal(false);

  // Incidencias e Insumos
  incidencias = signal<IncidenciaColaborador[]>([]);

  mostrarModalIncidencia = signal(false);
  formIncidencia = signal({
    tipo: 'Solicitud de Insumos / Materiales',
    descripcion: '',
    urgencia: 'MEDIA' as 'ALTA' | 'MEDIA' | 'BAJA',
  });

  mensajeFeedback = signal<{ tipo: 'success' | 'info'; texto: string } | null>(null);

  // Computados
  totalTareas = computed(() => this.tareas().length);
  tareasCompletadas = computed(() => this.tareas().filter((t) => t.estado === 'COMPLETADA').length);
  porcentajeProgreso = computed(() => {
    if (this.totalTareas() === 0) return 0;
    return Math.round((this.tareasCompletadas() / this.totalTareas()) * 100);
  });

  ngOnInit(): void {
    this.route.queryParams.subscribe((params) => {
      if (params['tab']) {
        const t = params['tab'];
        if (['funcion', 'tareas', 'asistencia', 'turnos'].includes(t)) {
          this.tabActiva.set(t as any);
        }
      }
    });

    const user = this.usuario();
    if (user?.cargo) {
      const c = user.cargo.toLowerCase();
      if (c.includes('limpieza')) {
        this.cargoEspecifico.set('Personal de Limpieza');
        this.areaAsignada.set('Pabellones A y B · Aulas de Secundaria');
      } else if (c.includes('mantenimiento')) {
        this.cargoEspecifico.set('Mantenimiento General');
        this.areaAsignada.set('Instalaciones Electrónicas y Áreas Verdes');
      } else if (c.includes('cocina') || c.includes('comedor')) {
        this.cargoEspecifico.set('Cocinero Principal');
        this.areaAsignada.set('Comedor Escolar & Pabellón Nutricional');
      } else if (c.includes('seguridad')) {
        this.cargoEspecifico.set('Personal de Seguridad');
        this.areaAsignada.set('Puerta Principal & Perímetro Escolar');
      }
    }

    this.cargarTareasOperativas();
  }

  cargarTareasOperativas(): void {
    this.cargandoTareas.set(true);
    this.personalService.obtenerTareasOperativas().subscribe({
      next: (data) => {
        const user = this.usuario();
        const cargo = (user?.cargo || '').toLowerCase();
        let equipoFiltro = 'GENERAL';
        if (cargo.includes('limpieza')) equipoFiltro = 'TODO_LIMPIEZA';
        else if (cargo.includes('mantenimiento')) equipoFiltro = 'TODO_MANTENIMIENTO';
        else if (cargo.includes('cocina')) equipoFiltro = 'TODO_COCINA';
        else if (cargo.includes('seguridad')) equipoFiltro = 'TODO_SEGURIDAD';

        // Filtrar tareas pertinentes a su equipo o a su ID o generales
        const filtradas = data.filter((t) => 
          t.equipo === equipoFiltro || 
          t.equipo === 'GENERAL' || 
          (user?.id && t.asignadoAId === user.id)
        );

        this.tareas.set(filtradas.length > 0 ? filtradas : data);
        this.cargandoTareas.set(false);
      },
      error: () => {
        this.cargandoTareas.set(false);
      }
    });
  }

  marcarEntrada(): void {
    const ahora = new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' });
    this.horaEntrada.set(ahora);
    this.estadoMarcacion.set('EN_TURNO');
    this.mostrarMensaje('success', `Entrada registrada a las ${ahora}. ¡Buen turno de trabajo!`);
  }

  marcarSalida(): void {
    const ahora = new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' });
    this.horaSalida.set(ahora);
    this.estadoMarcacion.set('TURNO_FINALIZADO');
    this.mostrarMensaje('info', `Salida registrada a las ${ahora}. Resumen de jornada guardado.`);
  }

  cambiarEstadoTarea(id: number, nuevoEstado: 'PENDIENTE' | 'EN_PROCESO' | 'COMPLETADA'): void {
    this.personalService.actualizarEstadoTareaOperativa(id, nuevoEstado).subscribe({
      next: (tareaActualizada) => {
        this.tareas.update((lista) =>
          lista.map((t) => (t.id === id ? { ...t, estado: nuevoEstado } : t))
        );
        this.mostrarMensaje('success', `Estado de tarea actualizado a "${nuevoEstado}".`);
      },
      error: () => {
        // Fallback local
        this.tareas.update((lista) =>
          lista.map((t) => (t.id === id ? { ...t, estado: nuevoEstado } : t))
        );
      }
    });
  }

  enviarIncidencia(): void {
    const desc = this.formIncidencia().descripcion.trim();
    if (!desc) return;

    const fechaHora = `${new Date().toLocaleDateString()} ${new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}`;
    const nueva: IncidenciaColaborador = {
      id: Date.now(),
      tipo: this.formIncidencia().tipo,
      descripcion: desc,
      urgencia: this.formIncidencia().urgencia,
      fecha: fechaHora,
      estado: 'ENVIADO',
    };

    this.incidencias.update((i) => [nueva, ...i]);
    this.mostrarModalIncidencia.set(false);
    this.formIncidencia.set({
      tipo: 'Solicitud de Insumos / Materiales',
      descripcion: '',
      urgencia: 'MEDIA',
    });
    this.mostrarMensaje('success', 'Notificación e incidencia transmitida con éxito a Secretaría y Administración.');
  }

  mostrarMensaje(tipo: 'success' | 'info', texto: string): void {
    this.mensajeFeedback.set({ tipo, texto });
    setTimeout(() => {
      this.mensajeFeedback.set(null);
    }, 4000);
  }
}

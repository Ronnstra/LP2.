import { Component, signal, computed, inject, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { RouterModule, ActivatedRoute } from '@angular/router';
import {
  AlumnoService,
  PersonalService,
  AuthService,
  AlumnoResponse,
  PersonalEscolar,
  CargoPersonal,
  TurnoPersonal,
  ContratoDocente,
  ContratosDocentesResumen,
  FranjaDisponibilidad,
  BloqueHorario,
  ConfiguracionJornada,
  DocenteDisponibilidadRespuesta,
} from '../../../core/services';

import { AlumnoFormComponent } from '../../matricula/alumnos/alumno-form';

export interface CursoEscolar {
  id: number;
  nombre: string;
  nivel: 'Primaria' | 'Secundaria';
  grado: string;
  grados?: string[];
  docenteId?: number;
  docenteNombre?: string;
  especialidadRequerida: string;
  estado: 'ASIGNADO' | 'PENDIENTE_ASIGNACION';
  descripcion?: string;
}

export interface AptitudDocenteResultado {
  docenteId: number;
  nombreCompleto: string;
  especialidad: string;
  horasAsignadas: number;
  maxHorasContrato: number;
  porcentajeAptitud: number;
  motivoAptitud: string;
  puntuacionEstrellas: number;
}

@Component({
  selector: 'app-portal-secretaria',
  standalone: true,
  imports: [CommonModule, FormsModule, RouterModule, AlumnoFormComponent],
  templateUrl: './portal-secretaria.html',
  styleUrl: './portal-secretaria.css',
})
export class PortalSecretariaComponent implements OnInit {
  private alumnoService = inject(AlumnoService);
  private personalService = inject(PersonalService);
  protected authService = inject(AuthService);
  private route = inject(ActivatedRoute);

  tabActiva = signal<'mi-portal' | 'registro-matricula' | 'horarios' | 'cursos' | 'comunicados' | 'asistencia' | 'finanzas' | 'tareas-operativas'>('mi-portal');

  // Alertas de vencimiento de contratos docentes
  alertasContratos = signal<any[]>([]);
  mostrarModalRenovacion = signal(false);
  docenteParaRenovar = signal<any | null>(null);
  formRenovacion = signal({ meses: 6 });

  // Consulta RENIEC para personal
  consultandoReniec = signal(false);
  mensajeReniec = signal<{ tipo: 'success' | 'error'; texto: string } | null>(null);

  // Tareas Operativas para Personal de Apoyo
  tareasOperativas = signal<any[]>([]);
  mostrarModalTareaOperativa = signal(false);
  guardandoTareaOperativa = signal(false);
  formTareaOperativa = signal({
    titulo: '',
    descripcion: '',
    rolAsignado: 'TODO_LIMPIEZA' as 'TODO_LIMPIEZA' | 'TODO_MANTENIMIENTO' | 'TODO_SEGURIDAD' | 'TODO_COMEDOR' | 'INDIVIDUAL',
    colaboradorId: 0,
    prioridad: 'NORMAL' as 'ALTA' | 'NORMAL' | 'BAJA',
    aulaOEspacio: 'Aula 2° B de Secundaria',
  });

  // Resumen Finanzas y Cobranzas por Grado
  resumenFinanzas = signal<any | null>(null);
  anioFinanzasSeleccionado = signal<number>(new Date().getFullYear());
  gradoFinanzasSeleccionado = signal<string>('TODOS');
  cargandoFinanzas = signal(false);

  // Información de Remuneración y Pago Mensual de Secretaría
  remuneracionMensualSecretaria = signal({
    puesto: 'Secretaría General & Académica',
    sueldoBase: 2400.00,
    bonoPuntualidad: 200.00,
    descuentosLey: 312.00,
    netoACobrar: 2288.00,
    estadoPago: 'PAGADO / ABONADO EN BANCO',
    fechaAbono: '15 Octubre 2026',
    banco: 'Banco de Crédito del Perú (BCP)',
    cuentaCCl: '002-191-003829103821-42',
  });

  // Estado responsivo de barra de navegación lateral
  sidebarMobileAbierto = signal(false);
  sidebarDesktopColapsado = signal(false);

  toggleSidebarMobile(): void {
    this.sidebarMobileAbierto.update((v) => !v);
  }

  cerrarSidebarMobile(): void {
    this.sidebarMobileAbierto.set(false);
  }

  toggleSidebarDesktop(): void {
    this.sidebarDesktopColapsado.update((v) => !v);
  }

  navegarTab(tab: 'mi-portal' | 'registro-matricula' | 'horarios' | 'cursos' | 'comunicados' | 'asistencia' | 'finanzas' | 'tareas-operativas'): void {
    this.tabActiva.set(tab);
    this.cerrarSidebarMobile();
    if (tab === 'asistencia') this.cargarAsistenciasSecretaria();
    if (tab === 'finanzas') {
      this.cargarFinanzasSecretaria();
      this.cargarSolicitudesPonderacion();
    }
    if (tab === 'cursos' || tab === 'mi-portal' || tab === 'comunicados') {
      this.cargarSolicitudesPonderacion();
    }
    if (tab === 'tareas-operativas') this.cargarTareasOperativas();
  }

  // Solicitudes de Edición de Ponderación enviadas por Docentes & Sub-apartado en Solicitudes
  subTabSolicitudes = signal<'ponderado' | 'comunicados'>('ponderado');
  solicitudesPonderacion = signal<any[]>([]);
  solicitudesPonderacionPendientesCount = computed(
    () => this.solicitudesPonderacion().filter((s) => s.estado === 'PENDIENTE').length
  );

  cargarSolicitudesPonderacion(): void {
    this.personalService.listarSolicitudesPonderacion().subscribe({
      next: (list) => this.solicitudesPonderacion.set(list || []),
      error: () => {},
    });
  }

  resolverSolicitudPonderacion(id: number, estado: 'APROBADA' | 'RECHAZADA'): void {
    const solObj = this.solicitudesPonderacion().find((s) => Number(s.id) === Number(id));
    this.personalService.resolverSolicitudPonderacion(id, estado, solObj).subscribe({
      next: (res) => {
        this.cargarSolicitudesPonderacion();
        this.mensaje.set({
          tipo: 'success',
          texto: res?.mensaje || (estado === 'APROBADA'
            ? 'Solicitud confirmada y aceptada. El docente ya tiene desbloqueada la ponderación de su curso para editarla.'
            : 'Solicitud rechazada.'),
        });
        setTimeout(() => this.mensaje.set(null), 4000);
      },
      error: () => {
        this.mensaje.set({ tipo: 'error', texto: 'No se pudo procesar la solicitud de ponderación.' });
      },
    });
  }

  // Estado de Comunicados Institucionales
  nuevoComunicado = signal({
    titulo: '',
    destinatario: 'ESTUDIANTES',
    contenido: '',
    urgente: false,
  });
  comunicadosEnviados = signal<{ id: number; titulo: string; destinatario: string; contenido: string; fecha: string; urgente: boolean }[]>([]);

  cargarComunicadosGuardados(): void {
    try {
      const raw = localStorage.getItem('bomerp_comunicados_secretaria');
      if (raw) {
        const parsed = JSON.parse(raw);
        if (Array.isArray(parsed)) {
          this.comunicadosEnviados.set(parsed);
          return;
        }
      }
    } catch {}
    this.comunicadosEnviados.set([
      {
        id: 1,
        titulo: 'Bienvenida al Año Escolar y Normas de Convivencia',
        destinatario: 'ESTUDIANTES',
        contenido: 'Se recuerda a todos los estudiantes de nivel Secundaria asistir puntualmente y revisar sus sesiones semanales en el portal.',
        fecha: new Date().toLocaleDateString(),
        urgente: false,
      },
    ]);
  }

  publicarComunicado(): void {
    const c = this.nuevoComunicado();
    if (!c.titulo.trim() || !c.contenido.trim()) return;
    const nuevo = {
      id: Date.now(),
      titulo: c.titulo.trim(),
      destinatario: c.destinatario,
      contenido: c.contenido.trim(),
      fecha: new Date().toLocaleDateString(),
      urgente: c.urgente,
    };
    this.comunicadosEnviados.update((arr) => {
      const updated = [nuevo, ...arr];
      try {
        localStorage.setItem('bomerp_comunicados_secretaria', JSON.stringify(updated));
      } catch {}
      return updated;
    });
    this.nuevoComunicado.set({ titulo: '', destinatario: 'ESTUDIANTES', contenido: '', urgente: false });
    this.mensaje.set({ tipo: 'success', texto: 'Comunicado institucional publicado y enviado exitosamente.' });
    setTimeout(() => this.mensaje.set(null), 3000);
  }

  eliminarComunicado(id: number): void {
    this.comunicadosEnviados.update((arr) => {
      const updated = arr.filter((item) => item.id !== id);
      try {
        localStorage.setItem('bomerp_comunicados_secretaria', JSON.stringify(updated));
      } catch {}
      return updated;
    });
    this.mensaje.set({ tipo: 'success', texto: 'Comunicado retirado del historial.' });
    setTimeout(() => this.mensaje.set(null), 3000);
  }

  // Solicitudes de Matrícula (inician en 0)
  solicitudesMatricula = signal<{ id: number; estudiante: string; grado: string; tutor: string; fecha: string; estadoDoc: string; estadoPago: string }[]>([]);

  // Morosidad y Deudas (inician en 0)
  alumnosMorosidad = signal<{ id: number; estudiante: string; grado: string; tutor: string; cuotasVencidas: number; montoDeuda: number; diasRetraso: number }[]>([]);

  // Análisis de Pérdidas y Riesgo Académico (inician en 0)
  alumnosRiesgoAcademico = signal<{ id: number; estudiante: string; grado: string; materiaRiesgo: string; promedioGeneral: number; sugerencia: string }[]>([]);

  cursosColegio = signal<CursoEscolar[]>([]);

  gradosSecundaria = ['1° Secundaria', '2° Secundaria', '3° Secundaria', '4° Secundaria', '5° Secundaria'];

  vistaCursos = signal<'catalogo' | 'malla'>('catalogo');
  filtroEstadoCurso = signal<'TODOS' | 'ASIGNADO' | 'PENDIENTE_ASIGNACION'>('TODOS');
  busquedaCurso = signal('');

  cursosFiltrados = computed(() => {
    const q = this.busquedaCurso().toLowerCase();
    const est = this.filtroEstadoCurso();
    return this.cursosColegio().filter(c => {
      const matchQ = c.nombre.toLowerCase().includes(q) || c.especialidadRequerida.toLowerCase().includes(q) || c.grado.toLowerCase().includes(q);
      const matchEst = est === 'TODOS' || c.estado === est;
      return matchQ && matchEst;
    });
  });

  mostrarModalCrearCurso = signal(false);
  formCurso = signal({
    nombre: '',
    grados: ['1° Secundaria'] as string[],
    descripcion: '',
  });

  getCursosPorGrado(grado: string): CursoEscolar[] {
    return this.cursosColegio().filter(c => this.cursoPermitidoEnGrado(c, grado));
  }

  parseGradosCurso(grado?: string): string[] {
    const todos = [...this.gradosSecundaria];
    if (!grado || grado.trim() === '' || grado.toLowerCase().includes('general')) return todos;
    const partes = grado.split(',').map(g => g.trim()).filter(g => todos.includes(g));
    return partes.length > 0 ? partes : todos;
  }

  cursoPermitidoEnGrado(curso: CursoEscolar | null | undefined, grado: string): boolean {
    if (!curso) return false;
    if (!curso.grados || curso.grados.length === 0) {
      const parsed = this.parseGradosCurso(curso.grado);
      return parsed.includes(grado);
    }
    return curso.grados.includes(grado);
  }

  toggleGradoCrear(gr: string): void {
    this.formCurso.update(f => {
      const exists = f.grados.includes(gr);
      const grados = exists ? f.grados.filter(g => g !== gr) : [...f.grados, gr];
      return { ...f, grados };
    });
  }

  // Liquid Glass Plaza Libre State
  plazaSeleccionada = signal<{ dia: string; horaInicio: string; horaFin: string } | null>(null);
  cursoSeleccionadoPlaza = signal<string>('Biología Celular y Anatomía');

  mostrarModalAsignarAptitud = signal(false);
  cursoParaAsignar = signal<CursoEscolar | null>(null);
  rankingsAptitud = signal<AptitudDocenteResultado[]>([]);

  abrirModalAsignarAptitud(curso: CursoEscolar): void {
    this.cursoParaAsignar.set(curso);
    const esp = (curso.especialidadRequerida || curso.nombre || '').toLowerCase();

    const docentes = this.docentesDisponibles();
    const resultados: AptitudDocenteResultado[] = docentes.map((d) => {
      const especialidades = d.cursosEspecialidad || (d.area ? [d.area] : []);
      const coincide = especialidades.some(
        (e) => e.toLowerCase().includes(esp) || esp.includes(e.toLowerCase()) || curso.nombre.toLowerCase().includes(e.toLowerCase())
      );
      return {
        docenteId: d.id,
        nombreCompleto: `Prof. ${d.nombre} ${d.apellidos}`,
        especialidad: d.area || especialidades.join(', ') || 'Docente de Secundaria',
        horasAsignadas: (d as any).horasSemanales || 0,
        maxHorasContrato: 24,
        porcentajeAptitud: coincide ? 98 : 85,
        motivoAptitud: coincide
          ? `Especialista directo en ${d.area || curso.nombre}`
          : `Docente habilitado en plana académica (${d.area || 'General'})`,
        puntuacionEstrellas: coincide ? 5 : 4,
      };
    });

    resultados.sort((a, b) => b.porcentajeAptitud - a.porcentajeAptitud);
    this.rankingsAptitud.set(resultados);
    this.mostrarModalAsignarAptitud.set(true);
  }

  confirmarAsignacionDocente(docenteResult: AptitudDocenteResultado): void {
    const c = this.cursoParaAsignar();
    if (!c) return;

    this.cursosColegio.update((list) =>
      list.map((item) =>
        item.id === c.id
          ? {
              ...item,
              docenteId: docenteResult.docenteId,
              docenteNombre: docenteResult.nombreCompleto,
              estado: 'ASIGNADO',
            }
          : item
      )
    );

    this.mostrarModalAsignarAptitud.set(false);
    this.cursoParaAsignar.set(null);
    this.mensaje.set({
      tipo: 'success',
      texto: `Docente ${docenteResult.nombreCompleto} asignado/a exitosamente al curso ${c.nombre}.`,
    });
    setTimeout(() => this.mensaje.set(null), 4000);
  }

  // Gestión de Edición y Eliminación de Cursos
  mostrarModalEditarCurso = signal(false);
  cursoParaEditar = signal<CursoEscolar | null>(null);
  formEdicionCurso = signal({
    nombre: '',
    nivel: 'Secundaria' as 'Primaria' | 'Secundaria',
    grados: ['1° Secundaria'] as string[],
    especialidadRequerida: '',
    descripcion: '',
  });

  toggleGradoEditar(gr: string): void {
    this.formEdicionCurso.update(f => {
      const exists = f.grados.includes(gr);
      const grados = exists ? f.grados.filter(g => g !== gr) : [...f.grados, gr];
      return { ...f, grados };
    });
  }

  abrirModalEditarCurso(curso: CursoEscolar): void {
    this.cursoParaEditar.set(curso);
    const gradosArr = curso.grado ? curso.grado.split(',').map(s => s.trim()) : ['1° Secundaria'];
    this.formEdicionCurso.set({
      nombre: curso.nombre,
      nivel: curso.nivel,
      grados: gradosArr,
      especialidadRequerida: curso.especialidadRequerida,
      descripcion: curso.descripcion || '',
    });
    this.mostrarModalEditarCurso.set(true);
  }

  guardarEdicionCurso(): void {
    const target = this.cursoParaEditar();
    const f = this.formEdicionCurso();
    if (!target || !f.nombre.trim()) return;

    const gradosSeleccionados = f.grados.length > 0 ? [...f.grados] : [...this.gradosSecundaria];
    const gradoStr = gradosSeleccionados.join(', ');

    this.cursosColegio.update((list) =>
      list.map((c) =>
        c.id === target.id
          ? {
              ...c,
              nombre: f.nombre,
              nivel: f.nivel,
              grado: gradoStr,
              grados: gradosSeleccionados,
              especialidadRequerida: f.especialidadRequerida,
              descripcion: f.descripcion,
            }
          : c
      )
    );

    this.personalService
      .actualizarCursoCatalogo(target.nombre, { nombre: f.nombre.trim(), grado: gradoStr })
      .subscribe({
        next: (res) => {
          if (res?.detalle) {
            this.aplicarDetalleCursos(res.detalle);
          } else {
            this.cargarCatalogoCursos();
          }
          this.mostrarModalEditarCurso.set(false);
          this.cursoParaEditar.set(null);
          this.mensaje.set({
            tipo: 'success',
            texto: res?.mensaje || `Curso ${f.nombre} actualizado y guardado en Oracle DB.`,
          });
          setTimeout(() => this.mensaje.set(null), 4000);
        },
        error: (err) => {
          this.mensaje.set({ tipo: 'error', texto: err.error?.message || 'No se pudo guardar la edición del curso en la base de datos.' });
        },
      });
  }

  eliminarCurso(cursoId: number): void {
    const target = this.cursosColegio().find((c) => c.id === cursoId);
    this.cursosColegio.update((list) => list.filter((c) => c.id !== cursoId));
    if (target?.nombre) {
      this.personalService.eliminarCurso(target.nombre).subscribe({
        next: (res) => {
          this.catalogoCursos.set(res.cursos || []);
        },
      });
    }
    this.mensaje.set({ tipo: 'success', texto: 'Curso eliminado del catálogo y de Oracle DB correctamente.' });
    setTimeout(() => this.mensaje.set(null), 4000);
  }

  crearNuevoCurso(): void {
    const f = this.formCurso();
    const nombreLimpio = f.nombre.trim();
    if (!nombreLimpio) return;

    const gradosSeleccionados = f.grados.length > 0 ? [...f.grados] : [...this.gradosSecundaria];
    const gradoStr = gradosSeleccionados.join(', ');

    this.guardandoCurso.set(true);
    this.personalService.agregarCurso(nombreLimpio, undefined, gradoStr).subscribe({
      next: (res) => {
        this.guardandoCurso.set(false);
        if (res?.cursos) {
          this.catalogoCursos.set(res.cursos);
        } else if (!this.catalogoCursos().includes(nombreLimpio)) {
          this.catalogoCursos.update((arr) => [...arr, nombreLimpio]);
        }

        const nuevo: CursoEscolar = {
          id: Date.now(),
          nombre: nombreLimpio,
          nivel: 'Secundaria',
          grado: gradoStr,
          grados: gradosSeleccionados,
          especialidadRequerida: this.adivinarEspecialidad(nombreLimpio),
          estado: 'PENDIENTE_ASIGNACION',
          descripcion: f.descripcion || `Curso académico oficial de ${nombreLimpio} guardado en Oracle DB.`,
        };

        this.cursosColegio.update((arr) => {
          const idx = arr.findIndex((c) => c.nombre.toLowerCase() === nombreLimpio.toLowerCase());
          if (idx === -1) return [...arr, nuevo];
          const copia = [...arr];
          copia[idx] = { ...copia[idx], grado: gradoStr, grados: gradosSeleccionados };
          return copia;
        });
        this.cursoSeleccionadoPlaza.set(nombreLimpio);

        this.mostrarModalCrearCurso.set(false);
        this.formCurso.set({
          nombre: '',
          grados: ['1° Secundaria', '2° Secundaria', '3° Secundaria', '4° Secundaria', '5° Secundaria'],
          descripcion: '',
        });
        this.mensaje.set({ tipo: 'success', texto: `Curso "${nuevo.nombre}" guardado permanentemente en Oracle DB.` });
        setTimeout(() => this.mensaje.set(null), 4000);
      },
      error: () => {
        this.guardandoCurso.set(false);
        this.mensaje.set({ tipo: 'error', texto: 'No se pudo guardar el curso en la base de datos.' });
      },
    });
  }

  enviarRecordatorioMasivoMorosidad(): void {
    this.mensaje.set({ tipo: 'success', texto: 'Se enviaron los recordatorios masivos de pago vía Correo y SMS a tutores de alumnos morosos.' });
    setTimeout(() => this.mensaje.set(null), 4000);
  }

  aprobarMatriculaSolicitud(id: number): void {
    this.solicitudesMatricula.update((arr) => arr.filter((s) => s.id !== id));
    this.mensaje.set({ tipo: 'success', texto: 'Solicitud de matrícula aprobada y registrada en la nómina escolar oficial.' });
    setTimeout(() => this.mensaje.set(null), 4000);
  }

  alumnos = signal<AlumnoResponse[]>([]);
  personal = signal<PersonalEscolar[]>([]);
  loading = signal(true);
  mensaje = signal<{ tipo: 'success' | 'error'; texto: string } | null>(null);

  filtroTexto = signal('');

  registrosAsistencia = signal<any[]>([]);
  resumenAsistenciaAlumno = signal<any | null>(null);
  alumnoAsistenciaSeleccionado = signal<number | null>(null);
  cargandoAsistencia = signal(false);

  cargarAsistenciasSecretaria(): void {
    const usuario = this.authService.getCurrentUser();
    this.cargandoAsistencia.set(true);
    this.personalService.listarAsistencias(usuario?.colegioId).subscribe({
      next: (data) => {
        this.registrosAsistencia.set(data);
        this.cargandoAsistencia.set(false);
      },
      error: () => this.cargandoAsistencia.set(false),
    });
  }

  seleccionarAlumnoAsistencia(alumnoId: number | null): void {
    this.alumnoAsistenciaSeleccionado.set(alumnoId);
    if (alumnoId == null) {
      this.resumenAsistenciaAlumno.set(null);
      return;
    }
    this.personalService.obtenerResumenAsistenciaAlumno(alumnoId).subscribe({
      next: (data) => this.resumenAsistenciaAlumno.set(data),
      error: () => this.resumenAsistenciaAlumno.set(null),
    });
  }

  nombreAlumnoAsistencia(alumnoId: number): string {
    const alumno = this.alumnos().find((a) => a.id === alumnoId);
    return alumno ? `${alumno.nombre} ${alumno.apellidoPaterno}` : `Alumno #${alumnoId}`;
  }

  // Modal Alumno (Matrícula)
  mostrarModalAlumno = signal(false);
  alumnoSeleccionado = signal<AlumnoResponse | null>(null);

  // Modal Personal
  mostrarModalPersonal = signal(false);
  guardandoPersonal = signal(false);
  mensajeModalPersonal = signal<string | null>(null);

  formPersonal = signal({
    nombre: '',
    apellidos: '',
    dni: '',
    cargo: 'DOCENTE' as CargoPersonal,
    area: '',
    telefono: '',
    turno: 'MAÑANA' as TurnoPersonal,
    tarifaHora: 35,
    sueldoMensual: 2400,
    modalidadContrato: 'TODO_EL_ANIO' as 'TODO_EL_ANIO' | 'N_MESES',
    contratoMeses: 10,
    fechaFinContrato: '',
    especialidadTexto: 'Matemática',
    cursosEspecialidad: [] as string[],
    disponibilidad: [] as FranjaDisponibilidad[],
  });

  // Modal Liquid Glass para Bloque Asignado
  bloqueSeleccionado = signal<BloqueHorario | null>(null);
  diaSeleccionadoBloque = signal<string>('');
  duracionBloqueEditar = signal<number>(2);
  horaInicioBloqueEditar = signal<string>('07:30');
  horaFinBloqueEditar = signal<string>('09:30');
  editandoDuracionBloque = signal<boolean>(false);

  timeToMin(h: string): number {
    if (!h || !h.includes(':')) return 0;
    const [hh, mm] = h.split(':').map(Number);
    return (hh || 0) * 60 + (mm || 0);
  }

  duracionMinutosCalculada = computed(() => {
    const ini = this.horaInicioBloqueEditar();
    const fin = this.horaFinBloqueEditar();
    const mins = this.timeToMin(fin) - this.timeToMin(ini);
    return Math.max(0, mins);
  });

  duracionHorasCalculada = computed(() => {
    const mins = this.duracionMinutosCalculada();
    return Number((mins / 60).toFixed(2));
  });

  abrirBloqueLiquidGlass(bloque: BloqueHorario, dia: string): void {
    this.bloqueSeleccionado.set(bloque);
    this.diaSeleccionadoBloque.set(dia);
    this.horaInicioBloqueEditar.set(bloque.horaInicio || '07:30');
    this.horaFinBloqueEditar.set(bloque.horaFin || '09:30');
    this.duracionBloqueEditar.set(Number(bloque.duracionHoras) || 2);
  }

  cerrarBloqueLiquidGlass(): void {
    this.bloqueSeleccionado.set(null);
  }

  aplicarRangoHoras(inicio: string, fin: string): void {
    this.horaInicioBloqueEditar.set(inicio);
    this.horaFinBloqueEditar.set(fin);
    const mins = this.timeToMin(fin) - this.timeToMin(inicio);
    if (mins >= 30) {
      this.duracionBloqueEditar.set(Number((mins / 60).toFixed(2)));
    }
  }

  guardarRangoHorarioBloque(): void {
    const b = this.bloqueSeleccionado();
    if (!b || !b.id) return;
    const inicio = this.horaInicioBloqueEditar();
    const fin = this.horaFinBloqueEditar();
    if (!inicio || !fin) {
      this.mensaje.set({ tipo: 'error', texto: 'Por favor indique una hora de inicio y fin válidas.' });
      return;
    }
    const mins = this.timeToMin(fin) - this.timeToMin(inicio);
    if (mins < 30) {
      this.mensaje.set({ tipo: 'error', texto: 'La hora de fin debe ser al menos 30 minutos posterior a la hora de inicio.' });
      return;
    }
    const durHoras = Number((mins / 60).toFixed(2));
    this.editandoDuracionBloque.set(true);
    this.personalService.editarDuracionBloque(b.id, {
      horaInicio: inicio,
      horaFin: fin,
      duracionMinutos: mins,
      duracionHoras: durHoras,
    }).subscribe({
      next: (res) => {
        this.editandoDuracionBloque.set(false);
        this.cargarHorarioSecundaria(this.gradoSeleccionado());
        this.cargarDatos();
        this.cargarContratos();
        this.mensaje.set({
          tipo: 'success',
          texto: res?.mensaje || `Horario actualizado a ${inicio} - ${fin} (${durHoras}h) para ${b.curso} en ${this.gradoSeleccionado()}.`,
        });
        setTimeout(() => this.mensaje.set(null), 4500);
        this.cerrarBloqueLiquidGlass();
      },
      error: (err) => {
        this.editandoDuracionBloque.set(false);
        this.mensaje.set({
          tipo: 'error',
          texto: err.error?.message || 'Error al actualizar el horario del curso.',
        });
      },
    });
  }

  cambiarDuracionBloqueSeleccionado(horasParam?: number): void {
    const b = this.bloqueSeleccionado();
    if (!b || !b.id) return;
    const nuevaDuracion = Number(horasParam ?? this.duracionBloqueEditar());
    if (isNaN(nuevaDuracion) || nuevaDuracion < 0.5 || nuevaDuracion > 6) {
      this.mensaje.set({ tipo: 'error', texto: 'Ingrese una duración válida entre 0.5 y 6 horas.' });
      return;
    }
    this.duracionBloqueEditar.set(nuevaDuracion);
    this.editandoDuracionBloque.set(true);
    this.personalService.editarDuracionBloque(b.id, { duracionHoras: nuevaDuracion }).subscribe({
      next: (res) => {
        this.editandoDuracionBloque.set(false);
        if (res?.bloqueActualizado) {
          this.bloqueSeleccionado.set(res.bloqueActualizado);
          this.horaInicioBloqueEditar.set(res.bloqueActualizado.horaInicio);
          this.horaFinBloqueEditar.set(res.bloqueActualizado.horaFin);
        }
        this.cargarHorarioSecundaria(this.gradoSeleccionado());
        this.cargarDatos();
        this.cargarContratos();
        this.mensaje.set({
          tipo: 'success',
          texto: res?.mensaje || `Duración actualizada a ${nuevaDuracion}h en ${this.gradoSeleccionado()} (los demás grados no fueron afectados).`,
        });
        setTimeout(() => this.mensaje.set(null), 4500);
      },
      error: (err) => {
        this.editandoDuracionBloque.set(false);
        this.mensaje.set({
          tipo: 'error',
          texto: err.error?.message || 'Error al actualizar la duración del curso.',
        });
      },
    });
  }

  // Modal para Mostrar Credenciales Generadas (Usuario y Contraseña)
  mostrarModalCredenciales = signal(false);
  copiaExitosa = signal(false);
  dataCredencialesGeneradas = signal<{
    titulo: string;
    nombreCompleto: string;
    cargo: string;
    username: string;
    password: string;
    dni: string;
    email: string;
    notaInfo: string;
  } | null>(null);

  // Franja temporal en modal de personal
  nuevaFranja = signal<FranjaDisponibilidad>({
    dia: 'Lunes',
    horaInicio: '08:00',
    horaFin: '10:00',
    horas: 2,
  });

  // Horarios de Secundaria y Jornada Escolar (09:00 a 16:00)
  diasLectivos = ['Lunes', 'Martes', 'Miércoles', 'Jueves', 'Viernes'];
  gradoSeleccionado = signal<string>('1° Secundaria');
  horarioSemanaGrado = signal<any[]>([]);
  cargandoHorario = signal(false);

  // Conmutador de vista de horarios: 'grado' (por grado escolar) o 'docente' (por profesor)
  vistaHorario = signal<'grado' | 'docente'>('grado');
  docenteSeleccionadoId = signal<number>(0);
  horarioDocenteAgenda = signal<any | null>(null);
  cargandoHorarioDocente = signal(false);

  // Asistente de Programación Rápida Semanal en 1 Clic
  mostrarModalProgramarSemana = signal(false);
  guardandoSemanaLote = signal(false);
  mensajeSemanaLote = signal<string | null>(null);
  formProgramarSemana = signal({
    docenteId: 0,
    curso: 'Matemática',
    horaInicio: '09:00',
    horaFin: '11:00',
    distribucion: [
      { dia: 'Lunes', grado: '1° Secundaria', activo: true, aula: 'Aula 101' },
      { dia: 'Martes', grado: '2° Secundaria', activo: true, aula: 'Aula 102' },
      { dia: 'Miércoles', grado: '3° Secundaria', activo: true, aula: 'Aula 201' },
      { dia: 'Jueves', grado: '4° Secundaria', activo: true, aula: 'Aula 202' },
      { dia: 'Viernes', grado: '5° Secundaria', activo: true, aula: 'Aula 301' },
    ],
  });

  // Configuración de Jornada y Receso (modificable de 9:00 a 16:00 y receso 30-60 min)
  configuracionJornada = signal<ConfiguracionJornada>({
    horaInicio: '09:00',
    horaFin: '16:00',
    duracionModuloMinutos: 120,
    recesoHabilitado: true,
    recesoInicio: '11:00',
    recesoFin: '11:45',
    recesoDuracionMinutos: 45,
    diasLectivos: ['Lunes', 'Martes', 'Miércoles', 'Jueves', 'Viernes'],
  });
  mostrarModalConfigJornada = signal(false);
  guardandoConfigJornada = signal(false);
  formConfigJornada = signal({
    horaInicio: '09:00',
    horaFin: '16:00',
    duracionModuloMinutos: 120,
    recesoHabilitado: true,
    recesoInicio: '11:00',
    recesoDuracionMinutos: 45,
  });

  // Modal Asignar / Editar Plaza Horaria con Detección de Choques
  mostrarModalAsignarHorario = signal(false);
  guardandoAsignacion = signal(false);
  cargandoDisponibilidad = signal(false);
  docentesDisponibilidad = signal<DocenteDisponibilidadRespuesta[]>([]);
  conflictoDetectado = signal<{ tipo?: string; mensaje?: string } | null>(null);

  mostrarTodosLosCursos = signal(false);

  cursosDisponiblesParaDocente = computed(() => {
    const docId = this.formAsignarHorario().docenteId;
    const verTodos = this.mostrarTodosLosCursos();
    const gradoActual = this.gradoSeleccionado();

    // Cursos estrictamente habilitados para el grado seleccionado
    const validosGrado = this.cursosColegio()
      .filter((c) => this.cursoPermitidoEnGrado(c, gradoActual))
      .map((c) => c.nombre.trim())
      .filter(Boolean);
    const base = Array.from(new Set(validosGrado));

    if (verTodos || !docId) {
      return base;
    }

    const docObj = this.personal().find((p) => p.id === docId);
    const especialidades = docObj?.cursosEspecialidad || [];

    if (especialidades.length === 0) {
      return base;
    }

    const filtrados = base.filter((c) =>
      especialidades.some(
        (esp) =>
          c.toLowerCase().includes(esp.toLowerCase()) ||
          esp.toLowerCase().includes(c.toLowerCase())
      )
    );

    return filtrados.length > 0 ? filtrados : base;
  });

  cursosValidosParaGrado = computed(() => {
    const grado = this.gradoSeleccionado();
    return this.cursosColegio()
      .filter((c) => this.cursoPermitidoEnGrado(c, grado))
      .map((c) => c.nombre);
  });

  cursosFiltradosPorGrado = computed(() => {
    const grado = this.gradoSeleccionado();
    const filtrados = this.cursosColegio().filter((c) => this.cursoPermitidoEnGrado(c, grado));
    if (filtrados.length > 0) return filtrados;
    if (this.cursosColegio().length === 0) {
      return this.cursosDisponiblesParaDocente().map((nombre, idx) => ({
        id: idx + 1,
        nombre,
        nivel: 'Secundaria' as const,
        grado,
        especialidadRequerida: this.adivinarEspecialidad(nombre),
        estado: 'PENDIENTE_ASIGNACION' as const,
      }));
    }
    return [];
  });

  formAsignarHorario = signal({
    id: undefined as number | undefined,
    grado: '1° Secundaria',
    seccion: 'A',
    dia: 'Lunes',
    horaInicio: '09:00',
    horaFin: '11:00',
    curso: '',
    docenteId: 0,
    aula: 'Aula 101 - Pabellón A',
    confirmado: true,
  });

  // Franjas de la jornada escolar calculadas dinámicamente según hora de inicio, fin y receso
  franjasCalculadas = computed(() => {
    const cfg = this.configuracionJornada();
    const franjas: {
      horaInicio: string;
      horaFin: string;
      duracionMinutos: number;
      esReceso: boolean;
      etiqueta: string;
    }[] = [];

    const toMin = (h: string) => {
      if (!h || !h.includes(':')) return 0;
      const [hh, mm] = h.split(':').map(Number);
      return (hh || 0) * 60 + (mm || 0);
    };

    const toStr = (m: number) => {
      const hh = Math.floor(m / 60);
      const mm = m % 60;
      return `${hh.toString().padStart(2, '0')}:${mm.toString().padStart(2, '0')}`;
    };

    const startMin = toMin(cfg.horaInicio);
    const endMin = toMin(cfg.horaFin);
    const modDur = cfg.duracionModuloMinutos || 120;
    const recesoIni = toMin(cfg.recesoInicio);
    const recesoFin = toMin(cfg.recesoFin);

    let current = startMin;
    let moduloNum = 1;

    while (current + 30 <= endMin) {
      // Si receso está activo y el cursor alcanza o cruza el inicio del receso
      if (cfg.recesoHabilitado && current < recesoFin && (current + modDur > recesoIni || current === recesoIni)) {
        if (current < recesoIni) {
          const durPre = recesoIni - current;
          if (durPre >= 30) {
            franjas.push({
              horaInicio: toStr(current),
              horaFin: toStr(recesoIni),
              duracionMinutos: durPre,
              esReceso: false,
              etiqueta: `Módulo ${moduloNum++} (${Math.round(durPre / 60)}h)`,
            });
          }
        }

        // Agregar fila de receso
        franjas.push({
          horaInicio: cfg.recesoInicio,
          horaFin: cfg.recesoFin,
          duracionMinutos: cfg.recesoDuracionMinutos,
          esReceso: true,
          etiqueta: ` Receso (${cfg.recesoDuracionMinutos} min)`,
        });

        current = recesoFin;
        continue;
      }

      const nextEnd = Math.min(current + modDur, endMin);
      const dur = nextEnd - current;
      if (dur >= 30) {
        franjas.push({
          horaInicio: toStr(current),
          horaFin: toStr(nextEnd),
          duracionMinutos: dur,
          esReceso: false,
          etiqueta: `Módulo ${moduloNum++} (${Math.round(dur / 60)}h)`,
        });
      }
      current = nextEnd;
      if (current >= endMin) break;
    }

    return franjas;
  });

  // Métricas de Ocupación en Vivo para la Cabecera
  franjasLectivas = computed(() => this.franjasCalculadas().filter((f) => !f.esReceso));

  totalPlazasSemana = computed(() => {
    return this.franjasLectivas().length * this.diasLectivos.length;
  });

  plazasOcupadasGrado = computed(() => {
    let count = 0;
    const cols = this.horarioSemanaGrado();
    for (const c of cols) {
      if (c.bloques) {
        count += c.bloques.filter((b: any) => !b.esDescanso).length;
      }
    }
    return count;
  });

  porcentajeOcupacion = computed(() => {
    const tot = this.totalPlazasSemana();
    if (tot === 0) return 0;
    return Math.min(100, Math.round((this.plazasOcupadasGrado() / tot) * 100));
  });

  bloquesConfirmadosGrado = computed(() => {
    let count = 0;
    const cols = this.horarioSemanaGrado();
    for (const c of cols) {
      if (c.bloques) {
        count += c.bloques.filter((b: any) => !b.esDescanso && b.confirmado !== false).length;
      }
    }
    return count;
  });

  bloquesBorradorGrado = computed(() => {
    let count = 0;
    const cols = this.horarioSemanaGrado();
    for (const c of cols) {
      if (c.bloques) {
        count += c.bloques.filter((b: any) => !b.esDescanso && b.confirmado === false).length;
      }
    }
    return count;
  });

  // Obtener estilo y color temático según el curso
  obtenerEstiloCurso(curso: string): { bg: string; border: string; text: string; badge: string } {
    const c = (curso || '').toLowerCase();
    if (c.includes('mate') || c.includes('álgebra') || c.includes('algebra') || c.includes('geom') || c.includes('trigo')) {
      return { bg: '#eff6ff', border: '#3b82f6', text: '#1e40af', badge: '#dbeafe' }; // Azul
    }
    if (c.includes('físic') || c.includes('fisic') || c.includes('quím') || c.includes('quim') || c.includes('cien') || c.includes('biol')) {
      return { bg: '#ecfdf5', border: '#10b981', text: '#065f46', badge: '#d1fae5' }; // Verde
    }
    if (c.includes('leng') || c.includes('comun') || c.includes('liter') || c.includes('ingl') || c.includes('idiom')) {
      return { bg: '#f5f3ff', border: '#8b5cf6', text: '#5b21b6', badge: '#ede9fe' }; // Violeta
    }
    if (c.includes('hist') || c.includes('geog') || c.includes('social') || c.includes('civic') || c.includes('ciudad')) {
      return { bg: '#fff7ed', border: '#f97316', text: '#9a3412', badge: '#ffedd5' }; // Naranja
    }
    if (c.includes('depor') || c.includes('físic') || c.includes('ed. física') || c.includes('futbol') || c.includes('voley')) {
      return { bg: '#fefce8', border: '#eab308', text: '#854d0e', badge: '#fef9c3' }; // Amarillo/Ámbar
    }
    if (c.includes('art') || c.includes('músic') || c.includes('music') || c.includes('teatr') || c.includes('danza')) {
      return { bg: '#fdf2f8', border: '#ec4899', text: '#9d174d', badge: '#fce7f3' }; // Rosa
    }
    return { bg: '#f8fafc', border: '#64748b', text: '#334155', badge: '#f1f5f9' }; // Slate
  }

  // Catálogo de Cursos de Secundaria (Prueba)
  catalogoCursos = signal<string[]>([]);
  nuevoCursoNombre = signal('');
  guardandoCurso = signal(false);

  // Módulo de Contratos Docentes por Hora
  contratos = signal<ContratoDocente[]>([]);
  resumenContratos = signal<ContratosDocentesResumen | null>(null);
  mostrarModalContrato = signal(false);
  guardandoContrato = signal(false);
  mensajeModalContrato = signal<string | null>(null);

  formContrato = signal({
    docenteId: 0,
    tarifaPorHora: 35, // Tarifa predeterminada S/ 35 por hora personalizable
    horasSemanales: 10,
    fechaInicio: '2026-03-01',
    fechaFin: '2026-12-20',
    cursosAsignados: [] as string[],
    gradosAsignados: ['1° Secundaria', '2° Secundaria', '3° Secundaria', '4° Secundaria', '5° Secundaria'],
    observaciones: 'Contrato por horas pedagógicas efectivas dictadas.',
  });

  horasMensualesCalculadas = computed(() => {
    return this.formContrato().horasSemanales * 4;
  });

  pagoMensualCalculado = computed(() => {
    return Number((this.horasMensualesCalculadas() * this.formContrato().tarifaPorHora).toFixed(2));
  });

  alumnosFiltrados = computed(() => {
    const q = this.filtroTexto().toLowerCase().trim();
    if (!q) return this.alumnos();
    return this.alumnos().filter(
      (a) =>
        a.nombre.toLowerCase().includes(q) ||
        a.apellidoPaterno.toLowerCase().includes(q) ||
        a.dni.includes(q) ||
        a.grado.toLowerCase().includes(q)
    );
  });

  personalFiltrado = computed(() => {
    const q = this.filtroTexto().toLowerCase().trim();
    if (!q) return this.personal();
    return this.personal().filter(
      (p) =>
        p.nombre.toLowerCase().includes(q) ||
        p.apellidos.toLowerCase().includes(q) ||
        p.dni.includes(q) ||
        p.cargo.toLowerCase().includes(q)
    );
  });

  docentesDisponibles = computed(() => {
    return this.personal().filter((p) => p.cargo === 'DOCENTE');
  });

  totalAlumnosProvisionales = computed(
    () => this.alumnos().filter((a) => a.estadoAprobacion === 'PENDIENTE').length
  );

  totalDocentes = computed(() => this.personal().filter((p) => p.cargo === 'DOCENTE').length);
  totalColaboradores = computed(() => this.personal().filter((p) => p.cargo !== 'DOCENTE').length);

  ngOnInit(): void {
    this.route.queryParams.subscribe((params) => {
      if (params['tab']) {
        const rawTab = params['tab'];
        const t = rawTab === 'solicitudes' ? 'comunicados' : rawTab;
        if (['mi-portal', 'registro-matricula', 'horarios', 'cursos', 'comunicados', 'asistencia', 'finanzas', 'tareas-operativas'].includes(t)) {
          this.tabActiva.set(t as any);
          if (t === 'finanzas') this.cargarFinanzasSecretaria();
          if (t === 'asistencia') this.cargarAsistenciasSecretaria();
          if (t === 'tareas-operativas') this.cargarTareasOperativas();
          if (t === 'comunicados' || t === 'cursos' || t === 'mi-portal') this.cargarSolicitudesPonderacion();
        }
      } else if (params['vista'] === 'horarios') {
        this.tabActiva.set('horarios');
      } else {
        // Reset to default tab if no specific params
        this.tabActiva.set('mi-portal');
      }
    });

    this.cargarDatos();
    this.cargarConfiguracionJornada();
    this.cargarHorarioSecundaria(this.gradoSeleccionado());
    this.cargarCatalogoCursos();
    this.cargarContratos();
    this.cargarAlertasContratos();
    this.cargarTareasOperativas();
    this.cargarFinanzasSecretaria();
    this.cargarComunicadosGuardados();
    this.cargarSolicitudesPonderacion();
  }

  cargarDatos(): void {
    this.loading.set(true);
    this.alumnoService.listar().subscribe({
      next: (dataAlumnos) => {
        this.alumnos.set(dataAlumnos);
        this.personalService.listar().subscribe({
          next: (dataPersonal) => {
            this.personal.set(dataPersonal);
            this.loading.set(false);
          },
          error: () => this.loading.set(false),
        });
      },
      error: () => this.loading.set(false),
    });
  }

  // Cargar Configuración de Jornada y Receso
  cargarConfiguracionJornada(): void {
    this.personalService.obtenerConfiguracionJornada().subscribe({
      next: (cfg) => {
        this.configuracionJornada.set(cfg);
      },
    });
  }

  abrirModalConfigJornada(): void {
    const c = this.configuracionJornada();
    this.formConfigJornada.set({
      horaInicio: c.horaInicio,
      horaFin: c.horaFin,
      duracionModuloMinutos: c.duracionModuloMinutos || 120,
      recesoHabilitado: c.recesoHabilitado,
      recesoInicio: c.recesoInicio,
      recesoDuracionMinutos: c.recesoDuracionMinutos || 45,
    });
    this.mostrarModalConfigJornada.set(true);
  }

  setDuracionModuloHoras(horas: number): void {
    const h = Number(horas);
    if (!isNaN(h) && h > 0) {
      this.formConfigJornada.update((f) => ({ ...f, duracionModuloMinutos: Math.max(15, Math.round(h * 60)) }));
    }
  }

  setDuracionModuloMinutos(minutos: number): void {
    const m = Number(minutos);
    if (!isNaN(m) && m >= 15) {
      this.formConfigJornada.update((f) => ({ ...f, duracionModuloMinutos: Math.round(m) }));
    }
  }

  setDuracionRecesoMinutos(minutos: number): void {
    const m = Number(minutos);
    if (!isNaN(m) && m >= 5) {
      this.formConfigJornada.update((f) => ({ ...f, recesoDuracionMinutos: Math.round(m) }));
    }
  }

  setDuracionRecesoHoras(horas: number): void {
    const h = Number(horas);
    if (!isNaN(h) && h > 0) {
      this.formConfigJornada.update((f) => ({ ...f, recesoDuracionMinutos: Math.max(5, Math.round(h * 60)) }));
    }
  }

  cerrarModalConfigJornada(): void {
    this.mostrarModalConfigJornada.set(false);
  }

  guardarConfigJornada(): void {
    this.guardandoConfigJornada.set(true);
    this.personalService.actualizarConfiguracionJornada(this.formConfigJornada()).subscribe({
      next: (res) => {
        this.configuracionJornada.set(res.configuracion);
        this.guardandoConfigJornada.set(false);
        this.cerrarModalConfigJornada();
        this.cargarHorarioSecundaria(this.gradoSeleccionado());
        this.mensaje.set({ tipo: 'success', texto: 'Configuración de jornada y receso actualizada.' });
      },
      error: (err) => {
        this.guardandoConfigJornada.set(false);
        this.mensaje.set({ tipo: 'error', texto: err.error?.message || 'Error al guardar configuración.' });
      },
    });
  }

  // Cargar Horario por Grado
  cargarHorarioSecundaria(grado: string): void {
    this.gradoSeleccionado.set(grado);
    this.cargandoHorario.set(true);
    this.personalService.obtenerHorarioSecundaria(grado).subscribe({
      next: (res) => {
        this.horarioSemanaGrado.set(res.semana || []);
        this.cargandoHorario.set(false);
      },
      error: () => {
        this.cargandoHorario.set(false);
      },
    });
  }

  // Buscar si existe un bloque en un día y franja horaria determinada (evitando duplicidad entre módulos)
  buscarBloqueEnDia(dia: string, horaInicio: string, horaFin: string): any {
    const col = this.horarioSemanaGrado().find((c) => c.dia === dia);
    if (!col || !col.bloques) return undefined;
    const bloquesDia = col.bloques
      .filter((b: any) => !b.esDescanso)
      .slice()
      .sort((a: any, b: any) => String(a.horaInicio).localeCompare(String(a.horaInicio)));

    if (bloquesDia.length === 0) return undefined;

    // 1. Coincidencia exacta de horaInicio
    const exact = bloquesDia.find((b: any) => b.horaInicio === horaInicio);
    if (exact) return exact;

    const fIni = this.timeToMin(horaInicio);
    const fFin = this.timeToMin(horaFin);
    const franjasLectivasList = this.franjasLectivas();

    // 2. Coincidencia estricta por pertenencia a esta franja:
    // El bloque solo puede pertenecer si esta franja es su franja lectiva más cercana
    // y NUNCA si b.horaInicio >= fFin (un bloque de las 09:30 JAMÁS debe aparecer en el Módulo 1 07:30-09:30)
    // y NUNCA si b.horaFin <= fIni (un bloque que terminó antes)
    const match = bloquesDia.find((b: any) => {
      const bIni = this.timeToMin(b.horaInicio);
      const bFin = this.timeToMin(b.horaFin);

      if (bIni >= fFin || bFin <= fIni) {
        return false;
      }

      let mejorFranja: any = null;
      let menorDistancia = Infinity;
      for (const fl of franjasLectivasList) {
        const flIni = this.timeToMin(fl.horaInicio);
        const dist = Math.abs(bIni - flIni);
        if (dist < menorDistancia) {
          menorDistancia = dist;
          mejorFranja = fl;
        }
      }

      return mejorFranja && mejorFranja.horaInicio === horaInicio && mejorFranja.horaFin === horaFin;
    });

    return match;
  }

  // Abrir Modal para Asignar o Editar una Franja Horaria
  abrirModalAsignar(dia: string, horaInicio: string, horaFin: string, bloqueExistente?: any): void {
    const grado = this.gradoSeleccionado();
    let curso = '';
    let docenteId = 0;
    let aula = `Aula ${grado.includes('1°') ? '101' : grado.includes('2°') ? '102' : grado.includes('3°') ? '201' : grado.includes('4°') ? '202' : '301'} - Pabellón ${grado.includes('1°') || grado.includes('2°') ? 'A' : grado.includes('3°') || grado.includes('4°') ? 'B' : 'C'}`;
    let confirmado = true;

    if (bloqueExistente) {
      curso = bloqueExistente.curso;
      docenteId = bloqueExistente.docenteId;
      aula = bloqueExistente.aula || aula;
      confirmado = bloqueExistente.confirmado !== false;
    } else {
      const cursosDisp = this.cursosDisponiblesParaDocente();
      if (cursosDisp.length > 0) {
        curso = cursosDisp[0];
      }
      const docs = this.docentesDisponibles();
      if (docs.length > 0) {
        docenteId = docs[0].id;
      }
    }

    this.formAsignarHorario.set({
      id: bloqueExistente?.id,
      grado,
      seccion: 'A',
      dia,
      horaInicio,
      horaFin,
      curso,
      docenteId,
      aula,
      confirmado,
    });

    this.conflictoDetectado.set(null);
    this.mostrarTodosLosCursos.set(true);
    this.mostrarModalAsignarHorario.set(true);
    this.consultarDisponibilidadDocentes(dia, horaInicio, horaFin, bloqueExistente?.id);
  }

  cerrarModalAsignar(): void {
    this.mostrarModalAsignarHorario.set(false);
    this.conflictoDetectado.set(null);
  }

  // Liquid Glass Plaza Libre Methods
  abrirPlazaLiquidGlass(dia: string, horaInicio: string, horaFin: string): void {
    this.plazaSeleccionada.set({ dia, horaInicio, horaFin });
    if (this.cursosColegio().length > 0) {
      this.cursoSeleccionadoPlaza.set(this.cursosColegio()[0].nombre);
    } else if (this.catalogoCursos().length > 0) {
      this.cursoSeleccionadoPlaza.set(this.catalogoCursos()[0]);
    }
    this.consultarDisponibilidadDocentes(dia, horaInicio, horaFin);
  }

  cerrarPlazaLiquidGlass(): void {
    this.plazaSeleccionada.set(null);
  }

  asignarDocenteDirecto(docente: DocenteDisponibilidadRespuesta, cursoParam?: string): void {
    const plaza = this.plazaSeleccionada();
    if (!plaza) return;

    if (!docente.disponible) {
      this.mensaje.set({
        tipo: 'error',
        texto: ` El docente ${docente.nombreCompleto} no está disponible en este horario (${docente.motivoConflicto || 'Cruce de clases'}).`,
      });
      return;
    }

    const curso = cursoParam || this.cursoSeleccionadoPlaza() || 'Materia Escolar';
    const grado = this.gradoSeleccionado();
    const aula = `Aula ${grado.includes('1°') ? '101' : grado.includes('2°') ? '102' : grado.includes('3°') ? '201' : grado.includes('4°') ? '202' : '301'}`;

    this.guardandoAsignacion.set(true);
    this.personalService
      .asignarBloqueHorario({
        grado,
        seccion: 'A',
        dia: plaza.dia,
        horaInicio: plaza.horaInicio,
        horaFin: plaza.horaFin,
        curso: curso.trim(),
        docenteId: docente.docenteId,
        aula,
        confirmado: true,
      })
      .subscribe({
        next: (res) => {
          this.guardandoAsignacion.set(false);
          this.cerrarPlazaLiquidGlass();
          this.cargarHorarioSecundaria(this.gradoSeleccionado());
          this.cargarDatos();
          this.cargarContratos();
          this.cargarCatalogoCursos();
          this.mensaje.set({
            tipo: 'success',
            texto: res.mensaje || `Prof. ${docente.nombreCompleto} asignado/a exitosamente al curso ${curso}!`,
          });
        },
        error: (err) => {
          this.guardandoAsignacion.set(false);
          this.mensaje.set({ tipo: 'error', texto: err.error?.message || 'Error al asignar docente a la plaza.' });
        },
      });
  }

  consultarDisponibilidadDocentes(dia: string, horaInicio: string, horaFin: string, bloqueIdExcluir?: number): void {
    this.cargandoDisponibilidad.set(true);
    this.personalService.obtenerDisponibilidadDocentes(dia, horaInicio, horaFin, bloqueIdExcluir).subscribe({
      next: (docsFromServer) => {
        const docsMap = new Map<number, DocenteDisponibilidadRespuesta>();
        (docsFromServer || []).forEach((d) => docsMap.set(d.docenteId, d));

        // Asegurar que cualquier docente registrado en personal() también esté presente
        this.docentesDisponibles().forEach((p) => {
          if (!docsMap.has(p.id)) {
            docsMap.set(p.id, {
              docenteId: p.id,
              nombreCompleto: `Prof. ${p.nombre} ${p.apellidos}`,
              dni: p.dni,
              cursosEspecialidad: p.cursosEspecialidad && p.cursosEspecialidad.length > 0 ? p.cursosEspecialidad : [p.area || 'General'],
              tarifaHora: p.tarifaHora || 35,
              disponible: true,
            });
          }
        });

        const docs = Array.from(docsMap.values());
        this.docentesDisponibilidad.set(docs);
        this.cargandoDisponibilidad.set(false);

        let currentId = this.formAsignarHorario().docenteId;
        if (!currentId && docs.length > 0) {
          const disp = docs.find((d) => d.disponible) || docs[0];
          currentId = disp.docenteId;
          const cursoActual = this.formAsignarHorario().curso;
          const nuevoCurso = cursoActual || (disp.cursosEspecialidad && disp.cursosEspecialidad[0]) || this.catalogoCursos()[0] || '';
          this.formAsignarHorario.update((f) => ({
            ...f,
            docenteId: currentId,
            curso: nuevoCurso,
          }));
        }

        if (currentId) {
          const doc = docs.find((d) => d.docenteId === currentId);
          if (doc && !doc.disponible) {
            this.conflictoDetectado.set({
              tipo: 'DOCENTE_OCUPADO',
              mensaje: ` BLOQUEO DE PLAZA: ${doc.nombreCompleto} ya tiene asignada una clase en ${doc.gradoOcupado} a esta misma hora (${doc.motivoConflicto}). Para evitar cruces de profesores, el sistema bloquea su asignación simultánea.`,
            });
          }
        }
      },
      error: () => {
        const fallbackDocs: DocenteDisponibilidadRespuesta[] = this.docentesDisponibles().map((p) => ({
          docenteId: p.id,
          nombreCompleto: `Prof. ${p.nombre} ${p.apellidos}`,
          dni: p.dni,
          cursosEspecialidad: p.cursosEspecialidad && p.cursosEspecialidad.length > 0 ? p.cursosEspecialidad : [p.area || 'General'],
          tarifaHora: p.tarifaHora || 35,
          disponible: true,
        }));
        this.docentesDisponibilidad.set(fallbackDocs);
        this.cargandoDisponibilidad.set(false);
      },
    });
  }

  onDocenteSeleccionado(docenteIdStr: string): void {
    const docId = parseInt(docenteIdStr, 10);
    this.formAsignarHorario.update((f) => ({ ...f, docenteId: docId }));
    const doc = this.docentesDisponibilidad().find((d) => d.docenteId === docId);

    if (doc && !doc.disponible) {
      this.conflictoDetectado.set({
        tipo: 'DOCENTE_OCUPADO',
        mensaje: ` BLOQUEO DE PLAZA POR CRUCE: ${doc.nombreCompleto} ya está dictando "${doc.cursoOcupado}" en ${doc.gradoOcupado} en este mismo horario. El sistema bloquea esta opción para evitar choques docentes.`,
      });
    } else {
      this.conflictoDetectado.set(null);
    }
  }

  guardarAsignacionHorario(): void {
    const f = this.formAsignarHorario();
    if (!f.curso.trim() || !f.docenteId) {
      this.conflictoDetectado.set({
        tipo: 'INCOMPLETO',
        mensaje: 'Complete la materia y seleccione al docente correspondiente para esta plaza.',
      });
      return;
    }

    const cursoCatalogo = this.cursosColegio().find(
      (c) => c.nombre.trim().toLowerCase() === f.curso.trim().toLowerCase()
    );
    if (cursoCatalogo && !this.cursoPermitidoEnGrado(cursoCatalogo, f.grado)) {
      this.conflictoDetectado.set({
        tipo: 'GRADO_NO_PERMITIDO',
        mensaje: `El curso "${f.curso.trim()}" no está habilitado para ${f.grado}. Edite los grados dirigidos del curso en la pestaña Cursos.`,
      });
      return;
    }

    this.guardandoAsignacion.set(true);
    this.personalService
      .asignarBloqueHorario({
        id: f.id,
        grado: f.grado,
        seccion: f.seccion,
        dia: f.dia,
        horaInicio: f.horaInicio,
        horaFin: f.horaFin,
        curso: f.curso.trim(),
        docenteId: f.docenteId,
        aula: f.aula,
        confirmado: f.confirmado,
      })
      .subscribe({
        next: (res) => {
          this.guardandoAsignacion.set(false);
          this.cerrarModalAsignar();
          this.cargarHorarioSecundaria(this.gradoSeleccionado());
          this.cargarContratos();
          this.cargarCatalogoCursos();
          this.mensaje.set({ tipo: 'success', texto: res.mensaje });
        },
        error: (err) => {
          this.guardandoAsignacion.set(false);
          this.conflictoDetectado.set({
            tipo: err.error?.tipo || 'CONFLICTO',
            mensaje: err.error?.message || 'Error de conflicto al registrar el bloque de horario.',
          });
        },
      });
  }

  toggleConfirmarBloque(bloqueId: number, event?: Event): void {
    if (event) event.stopPropagation();
    this.personalService.toggleConfirmarBloque(bloqueId).subscribe({
      next: (res) => {
        this.cargarHorarioSecundaria(this.gradoSeleccionado());
        if (this.vistaHorario() === 'docente' && this.docenteSeleccionadoId()) {
          this.cargarHorarioDocente(this.docenteSeleccionadoId()!);
        }
        this.mensaje.set({ tipo: 'success', texto: res.mensaje });
      },
      error: () => {
        this.mensaje.set({ tipo: 'error', texto: 'No se pudo cambiar el estado de confirmación.' });
      },
    });
  }

  confirmarTodoElGrado(): void {
    const grado = this.gradoSeleccionado();
    this.personalService.confirmarTodosHorariosGrado(grado).subscribe({
      next: (res) => {
        this.cargarHorarioSecundaria(grado);
        this.mensaje.set({ tipo: 'success', texto: res.mensaje });
      },
      error: () => {
        this.mensaje.set({ tipo: 'error', texto: 'Error al confirmar los horarios del grado.' });
      },
    });
  }

  liberarFranjaHorario(bloqueId: number, _dia: string, _curso: string): void {
    this.personalService.liberarBloqueHorario(bloqueId).subscribe({
      next: (res) => {
        this.cargarHorarioSecundaria(this.gradoSeleccionado());
        this.cargarContratos();
        this.mensaje.set({ tipo: 'success', texto: res.mensaje });
      },
      error: (err) => {
        this.mensaje.set({ tipo: 'error', texto: err.error?.message || 'Error al liberar franja.' });
      },
    });
  }

  limpiarTodosLosHorariosACero(): void {
    this.personalService.limpiarTodosHorarios().subscribe({
      next: (res) => {
        this.cargarHorarioSecundaria(this.gradoSeleccionado());
        this.cargarContratos();
        this.mensaje.set({ tipo: 'success', texto: res.mensaje });
      },
    });
  }

  // Reordenar clases de un día: Subir o Bajar de turno ( / )
  moverBloque(bloqueActual: any, direccion: 'arriba' | 'abajo'): void {
    const dia = bloqueActual.dia;
    const col = this.horarioSemanaGrado().find((c) => c.dia === dia);
    if (!col || !col.bloques) return;

    const bloquesDia = col.bloques.filter((b: any) => !b.esDescanso);
    const idx = bloquesDia.findIndex((b: any) => b.id === bloqueActual.id);
    if (idx === -1) return;

    const targetIdx = direccion === 'arriba' ? idx - 1 : idx + 1;
    if (targetIdx < 0 || targetIdx >= bloquesDia.length) return;

    const bloqueDestino = bloquesDia[targetIdx];
    this.personalService.intercambiarBloquesHorario(bloqueActual.id, bloqueDestino.id).subscribe({
      next: (res) => {
        this.cargarHorarioSecundaria(this.gradoSeleccionado());
        this.mensaje.set({ tipo: 'success', texto: res.mensaje });
      },
      error: (err) => {
        this.mensaje.set({ tipo: 'error', texto: err.error?.message || 'Error al reordenar clases.' });
      },
    });
  }

  // Soporte Drag and Drop para reordenar bloques entre franjas
  bloqueArrastradoId = signal<number | null>(null);

  onDragStart(event: DragEvent, bloqueId: number): void {
    this.bloqueArrastradoId.set(bloqueId);
    if (event.dataTransfer) {
      event.dataTransfer.setData('text/plain', bloqueId.toString());
      event.dataTransfer.effectAllowed = 'move';
    }
  }

  onDragOver(event: DragEvent): void {
    event.preventDefault();
    if (event.dataTransfer) {
      event.dataTransfer.dropEffect = 'move';
    }
  }

  onDropEnBloque(event: DragEvent, bloqueDestinoId: number): void {
    event.preventDefault();
    const sourceId = this.bloqueArrastradoId();
    this.bloqueArrastradoId.set(null);
    if (!sourceId || sourceId === bloqueDestinoId) return;

    this.personalService.intercambiarBloquesHorario(sourceId, bloqueDestinoId).subscribe({
      next: (res) => {
        this.cargarHorarioSecundaria(this.gradoSeleccionado());
        this.mensaje.set({ tipo: 'success', texto: res.mensaje });
      },
      error: (err) => {
        this.mensaje.set({ tipo: 'error', texto: err.error?.message || 'Error al intercambiar clases.' });
      },
    });
  }

  // Métodos del Asistente de Programación Rápida Semanal en 1 Clic
  abrirModalProgramarSemana(): void {
    const docs = this.docentesDisponibles();
    const docId = docs.length > 0 ? docs[0].id : 0;
    const cursoDef = this.catalogoCursos().length > 0 ? this.catalogoCursos()[0] : 'Matemática';

    this.formProgramarSemana.set({
      docenteId: docId,
      curso: cursoDef,
      horaInicio: '09:00',
      horaFin: '11:00',
      distribucion: [
        { dia: 'Lunes', grado: '1° Secundaria', activo: true, aula: 'Aula 101' },
        { dia: 'Martes', grado: '2° Secundaria', activo: true, aula: 'Aula 102' },
        { dia: 'Miércoles', grado: '3° Secundaria', activo: true, aula: 'Aula 201' },
        { dia: 'Jueves', grado: '4° Secundaria', activo: true, aula: 'Aula 202' },
        { dia: 'Viernes', grado: '5° Secundaria', activo: true, aula: 'Aula 301' },
      ],
    });
    this.mensajeSemanaLote.set(null);
    this.mostrarModalProgramarSemana.set(true);
  }

  cerrarModalProgramarSemana(): void {
    this.mostrarModalProgramarSemana.set(false);
    this.mensajeSemanaLote.set(null);
  }

  guardarProgramacionSemanaLote(): void {
    const f = this.formProgramarSemana();
    if (!f.docenteId || !f.curso.trim()) {
      this.mensajeSemanaLote.set('Seleccione un docente y el curso que dictará.');
      return;
    }

    const itemsActivos = f.distribucion.filter((d) => d.activo);
    if (itemsActivos.length === 0) {
      this.mensajeSemanaLote.set('Debe seleccionar al menos un día lectivo para programar.');
      return;
    }

    this.guardandoSemanaLote.set(true);
    this.mensajeSemanaLote.set(null);

    this.personalService
      .programarSemanaCompleta({
        docenteId: f.docenteId,
        curso: f.curso.trim(),
        horaInicio: f.horaInicio,
        horaFin: f.horaFin,
        distribucion: itemsActivos.map((d) => ({
          dia: d.dia,
          grado: d.grado,
          seccion: 'A',
          aula: d.aula,
        })),
      })
      .subscribe({
        next: (res) => {
          this.guardandoSemanaLote.set(false);
          this.cerrarModalProgramarSemana();
          this.cargarHorarioSecundaria(this.gradoSeleccionado());
          if (this.docenteSeleccionadoId()) {
            this.cargarHorarioDocente(this.docenteSeleccionadoId());
          }
          this.cargarContratos();
          this.cargarCatalogoCursos();
          this.mensaje.set({ tipo: 'success', texto: res.mensaje });
        },
        error: (err) => {
          this.guardandoSemanaLote.set(false);
          this.mensajeSemanaLote.set(
            err.error?.message || 'Error al programar la semana. Revise si hay cruces de horario.'
          );
        },
      });
  }

  // Métodos de Vista Dual (Grado vs Docente)
  cambiarVistaHorario(vista: 'grado' | 'docente'): void {
    this.vistaHorario.set(vista);
    if (vista === 'docente') {
      const docs = this.docentesDisponibles();
      if (docs.length > 0 && (!this.docenteSeleccionadoId() || this.docenteSeleccionadoId() === 0)) {
        this.cargarHorarioDocente(docs[0].id);
      } else if (this.docenteSeleccionadoId()) {
        this.cargarHorarioDocente(this.docenteSeleccionadoId());
      }
    } else {
      this.cargarHorarioSecundaria(this.gradoSeleccionado());
    }
  }

  cargarHorarioDocente(docenteId: number): void {
    this.docenteSeleccionadoId.set(docenteId);
    this.cargandoHorarioDocente.set(true);
    this.personalService.obtenerHorarioDocente(docenteId).subscribe({
      next: (res: any) => {
        this.horarioDocenteAgenda.set(res);
        this.cargandoHorarioDocente.set(false);
      },
      error: () => {
        this.cargandoHorarioDocente.set(false);
      },
    });
  }

  restaurarPlantillaEjemploHorarios(): void {
    this.personalService.restaurarHorariosEjemplo().subscribe({
      next: (res) => {
        this.cargarHorarioSecundaria(this.gradoSeleccionado());
        if (this.docenteSeleccionadoId()) {
          this.cargarHorarioDocente(this.docenteSeleccionadoId());
        }
        this.cargarContratos();
        this.mensaje.set({ tipo: 'success', texto: res.mensaje });
      },
    });
  }

  // Cargar Catálogo de Cursos desde Oracle DB y sincronizar con cursosColegio
  cargarCatalogoCursos(): void {
    this.personalService.obtenerCatalogoCursosDetalle().subscribe({
      next: (detalle) => {
        if (detalle && detalle.length > 0) {
          this.aplicarDetalleCursos(detalle);
        } else {
          this.personalService.obtenerCatalogoCursos().subscribe({
            next: (cursos) => {
              const lista = Array.isArray(cursos) ? cursos : [];
              this.catalogoCursos.set(lista);
              this.aplicarDetalleCursos(
                lista.map((nombreCurso) => ({ nombre: nombreCurso, grado: 'Secundaria General' }))
              );
            },
          });
        }
      },
      error: () => {
        this.personalService.obtenerCatalogoCursos().subscribe({
          next: (cursos) => {
            const lista = Array.isArray(cursos) ? cursos : [];
            this.catalogoCursos.set(lista);
            this.aplicarDetalleCursos(
              lista.map((nombreCurso) => ({ nombre: nombreCurso, grado: 'Secundaria General' }))
            );
          },
        });
      },
    });
  }

  private aplicarDetalleCursos(detalle: { nombre: string; grado?: string }[]): void {
    const lista = Array.isArray(detalle) ? detalle : [];
    this.catalogoCursos.set(lista.map((d) => d.nombre));
    const actuales = this.cursosColegio();
    const sincronizados: CursoEscolar[] = lista.map((d, i) => {
      const grados = this.parseGradosCurso(d.grado);
      const existente = actuales.find((c) => c.nombre.toLowerCase() === d.nombre.toLowerCase());
      if (existente) {
        return {
          ...existente,
          grado: grados.join(', '),
          grados,
        };
      }
      return {
        id: i + 1,
        nombre: d.nombre,
        nivel: 'Secundaria',
        grado: grados.join(', '),
        grados,
        especialidadRequerida: this.adivinarEspecialidad(d.nombre),
        estado: 'PENDIENTE_ASIGNACION',
        descripcion: `Curso oficial de ${d.nombre} sincronizado con Oracle DB`,
      };
    });

    this.cursosColegio.set(sincronizados);
    if (sincronizados.length > 0 && (!this.cursoSeleccionadoPlaza() || this.cursoSeleccionadoPlaza() === 'Biología Celular y Anatomía')) {
      this.cursoSeleccionadoPlaza.set(sincronizados[0].nombre);
    }
  }

  private adivinarEspecialidad(curso: string): string {
    const c = curso.toLowerCase();
    if (c.includes('mate') || c.includes('alg') || c.includes('geo')) return 'Matemática';
    if (c.includes('fis') || c.includes('qui') || c.includes('bio')) return 'Ciencias';
    if (c.includes('len') || c.includes('com') || c.includes('lit')) return 'Comunicación';
    if (c.includes('hist') || c.includes('geo')) return 'Sociales';
    if (c.includes('ing')) return 'Inglés';
    if (c.includes('dep') || c.includes('fis')) return 'Deportes';
    return 'General';
  }

  agregarCursoCatalogo(): void {
    const nombre = this.nuevoCursoNombre().trim();
    if (!nombre) return;

    this.guardandoCurso.set(true);
    this.personalService.agregarCurso(nombre).subscribe({
      next: (res) => {
        this.catalogoCursos.set(res.cursos);
        this.nuevoCursoNombre.set('');
        this.guardandoCurso.set(false);
        this.mensaje.set({ tipo: 'success', texto: res.mensaje });
      },
      error: () => {
        this.guardandoCurso.set(false);
      },
    });
  }

  eliminarCursoCatalogo(curso: string): void {
    this.personalService.eliminarCurso(curso).subscribe({
      next: (res) => {
        this.catalogoCursos.set(res.cursos);
        this.mensaje.set({ tipo: 'success', texto: res.mensaje });
      },
    });
  }

  // Contratos Docentes
  cargarContratos(): void {
    this.personalService.listarContratosDocentes().subscribe({
      next: (res) => {
        this.contratos.set(res.contratos || []);
        this.resumenContratos.set({
          totalContratosVigentes: res.totalContratos,
          totalHorasSemanales: res.totalHorasSemanales,
          totalHorasMensuales: res.totalHorasSemanales * 4,
          totalPlanillaMensual: res.totalPlanillaEstimada,
          tarifaPromedioHora: 35,
          contratos: res.contratos,
        });
      },
    });
  }

  abrirModalContrato(docente?: PersonalEscolar | ContratoDocente): void {
    let docenteId = 0;
    let tarifa = 35; // S/ 35 tarifa predeterminada
    let horas = 0;
    let cursos: string[] = [];
    let grados = ['1° Secundaria', '2° Secundaria', '3° Secundaria', '4° Secundaria', '5° Secundaria'];

    if (docente) {
      if ('cargo' in docente) {
        docenteId = docente.id;
        tarifa = docente.tarifaHora || 35;
        horas = (docente as any).horasSemanales !== undefined ? (docente as any).horasSemanales : 0;
        cursos = docente.cursosEspecialidad || [];
      } else {
        docenteId = docente.docenteId;
        tarifa = docente.tarifaPorHora;
        horas = docente.horasSemanales || 0;
        cursos = docente.cursosAsignados || [];
        grados = docente.gradosAsignados || grados;
      }
    } else if (this.docentesDisponibles().length > 0) {
      docenteId = this.docentesDisponibles()[0].id;
    }

    this.formContrato.set({
      docenteId,
      tarifaPorHora: tarifa,
      horasSemanales: horas,
      fechaInicio: '2026-03-01',
      fechaFin: '2026-12-20',
      cursosAsignados: cursos,
      gradosAsignados: grados,
      observaciones: 'Contrato generado por Secretaría Académica por horas dictadas.',
    });
    this.mensajeModalContrato.set(null);
    this.mostrarModalContrato.set(true);
  }

  cerrarModalContrato(): void {
    this.mostrarModalContrato.set(false);
  }

  guardarContrato(): void {
    const f = this.formContrato();
    if (!f.docenteId || f.horasSemanales <= 0 || f.tarifaPorHora <= 0) {
      this.mensajeModalContrato.set('Seleccione un docente e ingrese horas semanales y tarifa por hora válidas.');
      return;
    }

    this.guardandoContrato.set(true);
    this.personalService.crearOActualizarContratoDocente(f).subscribe({
      next: (res) => {
        this.guardandoContrato.set(false);
        this.cerrarModalContrato();
        this.cargarContratos();
        this.mensaje.set({ tipo: 'success', texto: res.mensaje });
      },
      error: (err) => {
        this.guardandoContrato.set(false);
        this.mensajeModalContrato.set(err.error?.message || 'Error al guardar contrato.');
      },
    });
  }

  // Métodos Matrícula Alumno
  abrirModalNuevoAlumno(): void {
    this.alumnoSeleccionado.set(null);
    this.mostrarModalAlumno.set(true);
  }

  editarAlumno(alumno: AlumnoResponse): void {
    this.alumnoSeleccionado.set(alumno);
    this.mostrarModalAlumno.set(true);
  }

  cerrarModalAlumno(): void {
    this.mostrarModalAlumno.set(false);
    this.alumnoSeleccionado.set(null);
  }

  onAlumnoGuardado(): void {
    this.cerrarModalAlumno();
    this.cargarDatos();
    this.mensaje.set({
      tipo: 'success',
      texto: 'Matrícula registrada exitosamente! Se asoció automáticamente el horario de secundaria correspondiente y el expediente se envió a Dirección.',
    });
  }

  // Métodos Personal
  abrirModalNuevoPersonal(cargoDefault: CargoPersonal = 'DOCENTE'): void {
    this.dataCredencialesGeneradas.set(null);
    this.formPersonal.set({
      nombre: '',
      apellidos: '',
      dni: '',
      cargo: cargoDefault,
      area: cargoDefault === 'DOCENTE' ? 'Matemática' : '',
      telefono: '',
      turno: 'MAÑANA',
      tarifaHora: 35,
      sueldoMensual: cargoDefault === 'DOCENTE' ? 2400 : 1500,
      modalidadContrato: 'TODO_EL_ANIO',
      contratoMeses: 10,
      fechaFinContrato: '',
      especialidadTexto: cargoDefault === 'DOCENTE' ? 'Matemática' : '',
      cursosEspecialidad: cargoDefault === 'DOCENTE' ? ['Matemática'] : [],
      disponibilidad: [],
    });
    this.mensajeModalPersonal.set(null);
    this.mensajeReniec.set(null);
    this.mostrarModalPersonal.set(true);
  }

  consultarReniecPersonal(): void {
    const dni = (this.formPersonal().dni || '').trim();
    if (!/^\d{8}$/.test(dni)) {
      this.mensajeModalPersonal.set('Ingrese un DNI peruano válido de 8 dígitos numéricos para consultar RENIEC.');
      return;
    }

    this.consultandoReniec.set(true);
    this.mensajeReniec.set(null);
    this.mensajeModalPersonal.set(null);

    this.personalService.consultarReniec(dni).subscribe({
      next: (res) => {
        this.consultandoReniec.set(false);
        if (res?.valido !== false && res?.nombres) {
          this.formPersonal.update((f) => ({
            ...f,
            nombre: res.nombres,
            apellidos: `${res.apellidoPaterno || ''} ${res.apellidoMaterno || ''}`.trim(),
          }));
          this.mensajeReniec.set({
            tipo: 'success',
            texto: `✓ Validado por RENIEC: ${res.nombreCompleto}`,
          });
        } else {
          this.mensajeReniec.set({
            tipo: 'error',
            texto: res?.error || 'El DNI ingresado no figura en el padrón oficial de RENIEC.',
          });
        }
      },
      error: (err) => {
        this.consultandoReniec.set(false);
        this.mensajeReniec.set({
          tipo: 'error',
          texto: err?.error?.error || 'El DNI ingresado no figura en el padrón oficial de RENIEC. Verifique el número o ingrese los datos manualmente.',
        });
      },
    });
  }

  agregarFranjaDisponibilidad(): void {
    const nf = this.nuevaFranja();
    const current = this.formPersonal().disponibilidad;
    this.formPersonal.update((f) => ({
      ...f,
      disponibilidad: [...current, { ...nf }],
    }));
  }

  quitarFranjaDisponibilidad(idx: number): void {
    const current = [...this.formPersonal().disponibilidad];
    current.splice(idx, 1);
    this.formPersonal.update((f) => ({
      ...f,
      disponibilidad: current,
    }));
  }

  toggleCursoEspecialidad(curso: string): void {
    const current = [...this.formPersonal().cursosEspecialidad];
    const idx = current.indexOf(curso);
    if (idx !== -1) {
      current.splice(idx, 1);
    } else {
      current.push(curso);
    }
    this.formPersonal.update((f) => ({
      ...f,
      cursosEspecialidad: current,
    }));
  }

  cerrarModalPersonal(): void {
    this.mostrarModalPersonal.set(false);
    this.dataCredencialesGeneradas.set(null);
    this.mensajeModalPersonal.set(null);
    this.mensajeReniec.set(null);
  }

  cerrarModalCredenciales(): void {
    this.mostrarModalCredenciales.set(false);
    this.dataCredencialesGeneradas.set(null);
  }

  copiarTexto(texto: string): void {
    navigator.clipboard.writeText(texto).then(() => {
      this.copiaExitosa.set(true);
      setTimeout(() => this.copiaExitosa.set(false), 2500);
    });
  }

  urlActual(): string {
    return window.location.origin + '/login';
  }

  verFichaAcceso(p: PersonalEscolar): void {
    const user = p.username || `docente_${p.dni}`;
    const pass = p.dni;
    this.dataCredencialesGeneradas.set({
      titulo: 'Ficha de Accesos e Identidad Institucional',
      nombreCompleto: `${p.cargo === 'DOCENTE' ? 'Prof. ' : ''}${p.nombre} ${p.apellidos}`,
      cargo: p.cargo === 'DOCENTE' ? 'Docente de Secundaria' : p.cargo,
      username: user,
      password: pass,
      dni: p.dni,
      email: `${user}@bomerp.edu.pe`,
      notaInfo: 'Comparta este usuario y contraseña con el colaborador para ingresar al portal.',
    });
    this.mostrarModalCredenciales.set(true);
  }

  guardarPersonal(): void {
    const f = this.formPersonal();
    if (!f.nombre.trim() || !f.apellidos.trim() || !f.dni.trim() || !f.cargo) {
      this.mensajeModalPersonal.set('Complete todos los campos obligatorios (Nombre, Apellidos, DNI y Cargo).');
      return;
    }

    this.guardandoPersonal.set(true);
    this.mensajeModalPersonal.set(null);

    const espTexto = f.especialidadTexto?.trim() || f.area?.trim() || '';
    const seleccionadas = Array.isArray(f.cursosEspecialidad) ? f.cursosEspecialidad.filter(Boolean) : [];
    const desdeTexto = espTexto ? espTexto.split(',').map((s) => s.trim()).filter(Boolean) : [];
    const especialidades = Array.from(new Set([...seleccionadas, ...desdeTexto]));
    if (f.cargo === 'DOCENTE' && especialidades.length === 0) {
      especialidades.push('Matemática');
    }

    this.personalService
      .crear({
        nombre: f.nombre.trim(),
        apellidos: f.apellidos.trim(),
        dni: f.dni.trim(),
        cargo: f.cargo,
        area: espTexto || (f.cargo === 'DOCENTE' ? (especialidades[0] || 'General') : 'Operaciones y Servicios'),
        telefono: f.telefono.trim(),
        turno: f.turno,
        registradoPor: 'Secretaría Académica',
        tarifaHora: f.cargo === 'DOCENTE' ? (f.tarifaHora || 35) : undefined,
        sueldoMensual: f.cargo === 'DOCENTE' ? undefined : (Number(f.sueldoMensual) || 1500),
        modalidadContrato: f.cargo === 'DOCENTE' ? f.modalidadContrato : undefined,
        contratoMeses: f.cargo === 'DOCENTE' ? Number(f.contratoMeses) : undefined,
        fechaFinContrato: f.fechaFinContrato || undefined,
        cursosEspecialidad: f.cargo === 'DOCENTE' ? especialidades : undefined,
      })
      .subscribe({
        next: (resp: any) => {
          this.guardandoPersonal.set(false);
          this.cargarDatos();
          this.cargarContratos();
          this.cargarAlertasContratos();
          this.cargarFinanzasSecretaria();

          const username = resp?.credenciales?.username || resp?.username || resp?.credencialesCuenta?.username || `docente_${f.dni.trim()}`;
          const password = resp?.credenciales?.password || resp?.credencialesCuenta?.password || f.dni.trim();

          this.dataCredencialesGeneradas.set({
            titulo: '✓ Personal Registrado y Confirmado Oficialmente',
            nombreCompleto: `${f.cargo === 'DOCENTE' ? 'Prof. ' : ''}${f.nombre.trim()} ${f.apellidos.trim()}`,
            cargo: f.cargo === 'DOCENTE' ? 'Docente de Secundaria' : f.cargo,
            username: username,
            password: password,
            dni: f.dni.trim(),
            email: `${username}@bomerp.edu.pe`,
            notaInfo: f.cargo === 'DOCENTE'
              ? `Expediente activo. Pago por minutos trabajados según horario (S/ ${f.tarifaHora || 35} por hora). Credenciales generadas y activas.`
              : `Expediente activo con sueldo mensual fijo de S/ ${f.sueldoMensual}. Credenciales generadas y activas.`,
          });
          this.mostrarModalPersonal.set(true);

          this.mensaje.set({
            tipo: 'success',
            texto: `${f.cargo === 'DOCENTE' ? 'Docente' : 'Personal'} ${f.nombre} ${f.apellidos} registrado exitosamente.`,
          });
        },
        error: (err) => {
          this.guardandoPersonal.set(false);
          this.mensajeModalPersonal.set(err.error?.message || 'Error al registrar personal.');
        },
      });
  }

  // Alertas y Renovación de Contratos Docentes
  cargarAlertasContratos(): void {
    this.personalService.obtenerAlertasContratos().subscribe({
      next: (res: any) => {
        const list = Array.isArray(res) ? res : (res?.alertas || []);
        this.alertasContratos.set(list);
      },
      error: () => {}
    });
  }

  abrirModalRenovar(alerta: any): void {
    this.docenteParaRenovar.set(alerta);
    this.formRenovacion.set({
      meses: 6,
    });
    this.mostrarModalRenovacion.set(true);
  }

  cerrarModalRenovar(): void {
    this.mostrarModalRenovacion.set(false);
    this.docenteParaRenovar.set(null);
  }

  confirmarRenovacion(): void {
    const doc = this.docenteParaRenovar();
    if (!doc) return;

    this.personalService.renovarContrato(doc.docenteId, {
      mesesExtension: this.formRenovacion().meses,
    }).subscribe({
      next: (res) => {
        this.cerrarModalRenovar();
        this.cargarAlertasContratos();
        this.cargarDatos();
        this.cargarContratos();
        this.mensaje.set({ tipo: 'success', texto: res.mensaje || 'Contrato docente renovado exitosamente.' });
        setTimeout(() => this.mensaje.set(null), 4000);
      },
      error: (err) => {
        this.mensaje.set({ tipo: 'error', texto: err.error?.message || 'Error al renovar contrato.' });
      }
    });
  }

  darDeBajaDocente(docenteId: number): void {
    this.personalService.darDeBajaPersonal(docenteId).subscribe({
      next: (res) => {
        this.personal.update((list) => list.filter((p) => p.id !== docenteId));
        this.contratos.update((list) => list.filter((c) => c.docenteId !== docenteId));
        this.alertasContratos.update((list) => list.filter((a) => a.docenteId !== docenteId));
        this.cargarAlertasContratos();
        this.cargarDatos();
        this.cargarContratos();
        this.cargarFinanzasSecretaria();
        this.mensaje.set({
          tipo: 'success',
          texto: res?.mensaje || 'Docente dado de baja y retirado de la planilla correctamente.',
        });
        setTimeout(() => this.mensaje.set(null), 4000);
      },
      error: (err) => {
        this.mensaje.set({ tipo: 'error', texto: err.error?.message || 'Error al dar de baja al docente.' });
      },
    });
  }

  darDeBajaEstudiante(alumnoId: number): void {
    this.personalService.darDeBajaAlumno(alumnoId).subscribe({
      next: (res) => {
        this.alumnos.update((list) => list.filter((a) => a.id !== alumnoId));
        this.cargarDatos();
        this.cargarFinanzasSecretaria();
        this.mensaje.set({
          tipo: 'success',
          texto: res?.mensaje || 'Estudiante dado de baja y retirado del padrón correctamente.',
        });
        setTimeout(() => this.mensaje.set(null), 4000);
      },
      error: (err) => {
        this.mensaje.set({ tipo: 'error', texto: err.error?.message || 'Error al dar de baja al estudiante.' });
      },
    });
  }

  // Tareas Operativas para Personal de Apoyo
  cargarTareasOperativas(): void {
    this.personalService.obtenerTareasOperativas().subscribe({
      next: (res: any) => {
        const list = Array.isArray(res) ? res : (res?.tareas || []);
        this.tareasOperativas.set(list);
      },
      error: () => {}
    });
  }

  abrirModalTareaOperativa(): void {
    this.formTareaOperativa.set({
      titulo: '',
      descripcion: '',
      rolAsignado: 'TODO_LIMPIEZA',
      colaboradorId: 0,
      prioridad: 'NORMAL',
      aulaOEspacio: 'Aula 2° B de Secundaria',
    });
    this.mostrarModalTareaOperativa.set(true);
  }

  cerrarModalTareaOperativa(): void {
    this.mostrarModalTareaOperativa.set(false);
  }

  guardarTareaOperativa(): void {
    const f = this.formTareaOperativa();
    if (!f.titulo.trim() || !f.descripcion.trim()) {
      this.mensaje.set({ tipo: 'error', texto: 'Complete el título y la descripción de la tarea operativa.' });
      return;
    }

    this.guardandoTareaOperativa.set(true);
    this.personalService.crearTareaOperativa(f).subscribe({
      next: (res) => {
        this.guardandoTareaOperativa.set(false);
        this.cerrarModalTareaOperativa();
        this.cargarTareasOperativas();
        this.mensaje.set({ tipo: 'success', texto: res.mensaje || 'Tarea operativa asignada con éxito al personal de apoyo.' });
        setTimeout(() => this.mensaje.set(null), 4000);
      },
      error: (err) => {
        this.guardandoTareaOperativa.set(false);
        this.mensaje.set({ tipo: 'error', texto: err.error?.message || 'Error al asignar tarea operativa.' });
      }
    });
  }

  // Finanzas en Secretaría (Ingresos y Cobranzas por Grado - Solo Alumnos)
  cargarFinanzasSecretaria(): void {
    this.cargandoFinanzas.set(true);
    this.personalService.obtenerResumenFinanzas().subscribe({
      next: (data: any) => {
        this.resumenFinanzas.set(data);
        const yr = data?.ingresosAcademicos?.anioSeleccionado || data?.ingresosAcademicos?.anioCreacion;
        if (yr) {
          this.anioFinanzasSeleccionado.set(yr);
        }
        this.cargandoFinanzas.set(false);
      },
      error: () => this.cargandoFinanzas.set(false),
    });
  }

  alumnosFinanzasFiltrados = computed(() => {
    const res = this.resumenFinanzas();
    const grado = this.gradoFinanzasSeleccionado();
    const list: any[] = [];

    const desglose = res?.ingresosAcademicos?.grados || res?.ingresosAcademicos?.desglosePorGrado;
    if (Array.isArray(desglose) && desglose.length > 0) {
      desglose.forEach((g: any) => {
        if (grado === 'TODOS' || g.grado === grado) {
          (g.alumnos || []).forEach((a: any) => {
            const totalContratado = Number(a.totalContratado ?? 3500);
            const totalPagado = Number(a.totalPagado ?? 0);
            const totalDeuda = Number(a.deudaPendiente ?? a.totalDeuda ?? Math.max(0, totalContratado - totalPagado));
            const cuotasPagadas = Number(a.cuotasPagadas ?? 0);
            const cuotasPendientes = Number(a.cuotasPendientes ?? Math.max(0, 10 - cuotasPagadas));
            const totalCuotas = cuotasPagadas + cuotasPendientes || 10;
            const costoMensual = Math.round(totalContratado / totalCuotas);
            list.push({
              ...a,
              grado: g.grado || a.grado,
              costoMensual: a.costoMensual ?? costoMensual,
              cuotasPagadas,
              totalCuotas,
              cuotasPendientes,
              totalContratado,
              totalPagado,
              totalDeuda,
              mesActualPagado: a.mesActualPagado !== undefined ? a.mesActualPagado : totalDeuda === 0,
              mesActualNombre: a.mesActualNombre || res?.ingresosAcademicos?.nombreMesActual || 'Mes Actual',
              anio: res?.ingresosAcademicos?.anioCreacion || this.anioFinanzasSeleccionado(),
            });
          });
        }
      });
      return list;
    }

    // Fallback a alumnosDeudores
    if (Array.isArray(res?.alumnosDeudores)) {
      return res.alumnosDeudores
        .filter((a: any) => grado === 'TODOS' || a.grado === grado)
        .map((a: any) => {
          const totalContratado = Number(a.totalContratado ?? 3500);
          const totalPagado = Number(a.totalPagado ?? 0);
          const totalDeuda = Number(a.deudaPendiente ?? Math.max(0, totalContratado - totalPagado));
          const cuotasPagadas = Number(a.cuotasPagadas ?? 1);
          const cuotasPendientes = Number(a.cuotasPendientes ?? 9);
          const totalCuotas = cuotasPagadas + cuotasPendientes || 10;
          return {
            ...a,
            costoMensual: Math.round(totalContratado / totalCuotas),
            cuotasPagadas,
            totalCuotas,
            cuotasPendientes,
            totalContratado,
            totalPagado,
            totalDeuda,
            mesActualPagado: a.mesActualPagado !== undefined ? a.mesActualPagado : totalDeuda === 0,
            mesActualNombre: a.mesActualNombre || 'Mes Actual',
          };
        });
    }

    return [];
  });

  alumnosDeudoresMesActual = computed(() => {
    return this.alumnosFinanzasFiltrados().filter((a: any) => !a.mesActualPagado);
  });

  resumenIngresosAlumnos = computed(() => {
    const lista: any[] = this.alumnosFinanzasFiltrados();
    const totalContratado = lista.reduce((s: number, a: any) => s + (Number(a.totalContratado) || 0), 0);
    const totalPagado = lista.reduce((s: number, a: any) => s + (Number(a.totalPagado) || 0), 0);
    const totalDeuda = lista.reduce((s: number, a: any) => s + (Number(a.totalDeuda) || 0), 0);
    const alDia = lista.filter((a: any) => a.mesActualPagado).length;
    const conDeudaMes = lista.filter((a: any) => !a.mesActualPagado).length;
    return { totalContratado, totalPagado, totalDeuda, alDia, conDeudaMes, totalAlumnos: lista.length };
  });

  // GESTIÓN DE DEUDAS DE ALUMNOS (SECRETARÍA ACADÉMICA)
  mostrarModalAgregarDeuda = signal(false);
  guardandoDeuda = signal(false);
  formDeuda = signal<{
    alumnoId: number | null;
    alumnoNombre: string;
    grado: string;
    concepto: string;
    conceptoPersonalizado: string;
    monto: number;
    mes: string;
    fechaVencimiento: string;
    modoMasivo: boolean;
  }>({
    alumnoId: null,
    alumnoNombre: '',
    grado: 'TODOS',
    concepto: 'Pensión Escolar',
    conceptoPersonalizado: '',
    monto: 450,
    mes: 'Marzo',
    fechaVencimiento: '2026-03-05',
    modoMasivo: false,
  });

  mostrarModalCobrarCuota = signal(false);
  guardandoCobro = signal(false);
  formCobro = signal<{
    alumnoId: number | null;
    alumnoNombre: string;
    dni: string;
    grado: string;
    cuotaNumero: number;
    concepto: string;
    monto: number;
    metodoPago: string;
    numeroOperacion: string;
  }>({
    alumnoId: null,
    alumnoNombre: '',
    dni: '',
    grado: '',
    cuotaNumero: 1,
    concepto: 'Pensión Escolar',
    monto: 450,
    metodoPago: 'EFECTIVO',
    numeroOperacion: '',
  });

  mostrarModalDetalleFinanciero = signal(false);
  alumnoDetalleFinanciero = signal<any | null>(null);
  reciboCobroModal = signal<any | null>(null);

  abrirModalAgregarDeuda(alumno?: any): void {
    const mesActual = this.resumenFinanzas()?.ingresosAcademicos?.nombreMesActual || 'Marzo';
    if (alumno) {
      this.formDeuda.set({
        alumnoId: alumno.id,
        alumnoNombre: alumno.nombreCompleto || `${alumno.nombre} ${alumno.apellidoPaterno}`,
        grado: alumno.grado || '1° Secundaria',
        concepto: `Pensión Escolar - ${mesActual}`,
        conceptoPersonalizado: '',
        monto: Number(alumno.costoMensual) || 450,
        mes: mesActual,
        fechaVencimiento: new Date().toISOString().split('T')[0],
        modoMasivo: false,
      });
    } else {
      const primerAlumno = this.alumnos()[0];
      this.formDeuda.set({
        alumnoId: primerAlumno ? primerAlumno.id : null,
        alumnoNombre: primerAlumno ? `${primerAlumno.nombre} ${primerAlumno.apellidoPaterno}` : '',
        grado: this.gradoFinanzasSeleccionado() || 'TODOS',
        concepto: `Pensión Escolar - ${mesActual}`,
        conceptoPersonalizado: '',
        monto: 450,
        mes: mesActual,
        fechaVencimiento: new Date().toISOString().split('T')[0],
        modoMasivo: false,
      });
    }
    this.mostrarModalAgregarDeuda.set(true);
  }

  abrirGeneradorDeudaMasiva(): void {
    const mesActual = this.resumenFinanzas()?.ingresosAcademicos?.nombreMesActual || 'Marzo';
    this.formDeuda.set({
      alumnoId: null,
      alumnoNombre: 'TODOS LOS ALUMNOS',
      grado: this.gradoFinanzasSeleccionado() || 'TODOS',
      concepto: `Pensión Escolar - ${mesActual}`,
      conceptoPersonalizado: '',
      monto: 450,
      mes: mesActual,
      fechaVencimiento: new Date().toISOString().split('T')[0],
      modoMasivo: true,
    });
    this.mostrarModalAgregarDeuda.set(true);
  }

  cerrarModalAgregarDeuda(): void {
    this.mostrarModalAgregarDeuda.set(false);
  }

  guardarDeudaAlumno(): void {
    const f = this.formDeuda();
    const monto = Number(f.monto);
    if (isNaN(monto) || monto <= 0) {
      this.mensaje.set({ tipo: 'error', texto: 'Ingrese un monto válido y mayor a 0.' });
      return;
    }

    const conceptoFinal = f.concepto === 'OTRO'
      ? (f.conceptoPersonalizado.trim() || 'Deuda Escolar Especial')
      : f.concepto;

    this.guardandoDeuda.set(true);

    if (f.modoMasivo) {
      this.personalService.generarDeudaMasiva({
        concepto: conceptoFinal,
        monto,
        mes: f.mes,
        fechaVencimiento: f.fechaVencimiento,
        grado: f.grado,
      }).subscribe({
        next: (res) => {
          this.guardandoDeuda.set(false);
          this.cerrarModalAgregarDeuda();
          this.cargarFinanzasSecretaria();
          this.mensaje.set({
            tipo: 'success',
            texto: res?.mensaje || `Deuda de pensión asignada exitosamente a los alumnos.`,
          });
          setTimeout(() => this.mensaje.set(null), 5000);
        },
        error: (err) => {
          this.guardandoDeuda.set(false);
          this.mensaje.set({ tipo: 'error', texto: err.error?.message || 'Error al generar deuda masiva.' });
        },
      });
    } else {
      if (!f.alumnoId) {
        this.guardandoDeuda.set(false);
        this.mensaje.set({ tipo: 'error', texto: 'Seleccione un alumno válido.' });
        return;
      }

      this.personalService.registrarDeudaAlumno(f.alumnoId, {
        concepto: conceptoFinal,
        monto,
        fechaVencimiento: f.fechaVencimiento,
        mes: f.mes,
      }).subscribe({
        next: (res) => {
          this.guardandoDeuda.set(false);
          this.cerrarModalAgregarDeuda();
          this.cargarFinanzasSecretaria();
          this.mensaje.set({
            tipo: 'success',
            texto: res?.mensaje || `Deuda agregada con éxito al estudiante.`,
          });
          setTimeout(() => this.mensaje.set(null), 5000);
        },
        error: (err) => {
          this.guardandoDeuda.set(false);
          this.mensaje.set({ tipo: 'error', texto: err.error?.message || 'Error al registrar deuda al alumno.' });
        },
      });
    }
  }

  abrirModalCobrar(alumno: any, cuota?: any): void {
    const num = cuota?.numero || (Number(alumno.cuotasPagadas || 0) + 1);
    const monto = cuota?.monto || Number(alumno.costoMensual) || 450;
    const concepto = cuota?.concepto || `Pensión Escolar (Cuota N° ${num})`;

    this.formCobro.set({
      alumnoId: alumno.id,
      alumnoNombre: alumno.nombreCompleto || `${alumno.nombre} ${alumno.apellidoPaterno}`,
      dni: alumno.dni,
      grado: alumno.grado,
      cuotaNumero: num,
      concepto,
      monto,
      metodoPago: 'EFECTIVO',
      numeroOperacion: `OP-${Date.now().toString().slice(-6)}`,
    });
    this.mostrarModalCobrarCuota.set(true);
  }

  cerrarModalCobrar(): void {
    this.mostrarModalCobrarCuota.set(false);
  }

  guardarCobroCuota(): void {
    const f = this.formCobro();
    if (!f.alumnoId) return;

    this.guardandoCobro.set(true);
    this.alumnoService.pagarCuota(f.alumnoId, f.cuotaNumero).subscribe({
      next: (res) => {
        this.guardandoCobro.set(false);
        this.cerrarModalCobrar();
        this.cargarFinanzasSecretaria();
        this.reciboCobroModal.set({
          alumno: f.alumnoNombre,
          dni: f.dni,
          grado: f.grado,
          concepto: res.cuota?.concepto || f.concepto,
          monto: res.cuota?.monto || f.monto,
          fechaPago: res.cuota?.fechaPago || new Date().toISOString().split('T')[0],
          numeroOperacion: res.cuota?.numeroOperacion || f.numeroOperacion,
          metodoPago: f.metodoPago,
          mes: res.cuota?.mes || res.cuota?.mesCorrespondiente || 'Marzo',
        });
        this.mensaje.set({
          tipo: 'success',
          texto: `¡Cobranza registrada exitosamente! Se emitió el comprobante de pago para ${f.alumnoNombre}.`,
        });
        setTimeout(() => this.mensaje.set(null), 5000);
      },
      error: (err) => {
        this.guardandoCobro.set(false);
        this.mensaje.set({ tipo: 'error', texto: err.error?.message || 'Error al registrar el cobro de la cuota.' });
      },
    });
  }

  cerrarReciboCobro(): void {
    this.reciboCobroModal.set(null);
  }

  verDetalleFinancieroAlumno(alumno: any): void {
    this.alumnoService.obtener(alumno.id).subscribe({
      next: (alData) => {
        this.alumnoDetalleFinanciero.set(alData);
        this.mostrarModalDetalleFinanciero.set(true);
      },
      error: () => {
        this.alumnoDetalleFinanciero.set(alumno);
        this.mostrarModalDetalleFinanciero.set(true);
      },
    });
  }

  cerrarModalDetalleFinanciero(): void {
    this.mostrarModalDetalleFinanciero.set(false);
    this.alumnoDetalleFinanciero.set(null);
  }
}


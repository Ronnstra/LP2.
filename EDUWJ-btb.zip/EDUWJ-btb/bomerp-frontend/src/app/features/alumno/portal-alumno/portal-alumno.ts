import { Component, signal, computed, inject, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { RouterModule, ActivatedRoute } from '@angular/router';
import { DomSanitizer, SafeResourceUrl, SafeUrl } from '@angular/platform-browser';
import { AlumnoService, PersonalService, AuthService } from '../../../core/services';
import { PortalAlumnoData } from '../../../core/models';

@Component({
  selector: 'app-portal-alumno',
  standalone: true,
  imports: [CommonModule, FormsModule, RouterModule],
  templateUrl: './portal-alumno.html',
  styleUrl: './portal-alumno.css',
})
export class PortalAlumnoComponent implements OnInit {
  private alumnoService = inject(AlumnoService);
  private personalService = inject(PersonalService);
  protected authService = inject(AuthService);
  private route = inject(ActivatedRoute);
  private sanitizer = inject(DomSanitizer);

  tabActiva = signal<'resumen' | 'cursos' | 'finanzas' | 'horario' | 'academico'>('resumen');
  mostrarModalHorario = signal(false);
  diaFiltroHorario = signal<string>('TODOS');

  data = signal<PortalAlumnoData | null>(null);
  loading = signal(true);
  error = signal<string | null>(null);

  cursoSeleccionadoNombre = signal<string>('Biología Celular y Anatomía');
  cursoDetalleActivo = signal<any | null>(null);
  tabSubDetalle = signal<'notas' | 'asistencia' | 'tareas' | 'silabo' | 'justificar' | 'sesiones' | 'deberes'>('notas');

  // Módulo de Entrega de Tareas Escolares y Detalle de Sesión
  mostrarModalEntregarTarea = signal(false);
  tareaParaEntregar = signal<any | null>(null);
  sesionDetalleActiva = signal<any | null>(null);
  formEntrega = signal({
    archivos: [] as { nombre: string; url: string; tipo: string }[],
    comentario: '',
  });
  guardandoEntrega = signal(false);
  mensajeEntrega = signal<{ tipo: 'success' | 'error'; texto: string } | null>(null);
  vistaPreviaArchivoModal = signal<{ nombre: string; url: string; tipo: string } | null>(null);

  todasLasActividades = signal<any[]>([]);
  todasLasEntregas = signal<any[]>([]);
  todasLasPonderaciones = signal<any[]>([]);

  // Sesiones de clase por calendario
  sesionesCurso = signal<{
    numero: number;
    actividadId?: string;
    fecha: string;
    diaSemana: string;
    actividadTipo: string;
    actividadTitulo?: string;
    actividadDescripcion?: string;
    fechaFinEntrega?: string;
    entregado?: boolean;
    estadoTarea?: 'SIN_TAREA' | 'ENTREGADA' | 'PENDIENTE' | 'NO_ENTREGADA';
    entregaDetalle?: {
      id?: number;
      actividadId?: string;
      archivoNombre: string;
      archivoUrl?: string;
      archivoTipo?: string;
      archivos?: { nombre: string; url: string; tipo: string }[];
      comentario: string;
      fechaEntrega: string;
      calificacion?: number | null;
      comentarioDocente?: string;
    } | null;
  }[]>([]);

  // Apartado Deberes: Filtra estrictamente sesiones donde exista tarea o examen
  deberesCurso = computed(() => {
    return this.sesionesCurso().filter((s) => {
      const tipo = (s.actividadTipo || '').toUpperCase();
      const titulo = (s.actividadTitulo || '').trim().toLowerCase();
      const esActividadValida = tipo === 'TAREA' || tipo === 'EXAMEN' || tipo === 'PROYECTO' || tipo === 'EVALUACION';
      const tieneTitulo = titulo !== '' && titulo !== 'sin actividad';
      return esActividadValida && tieneTitulo;
    });
  });

  semanaActualCurso = signal<number>(1);
  sesionActualCurso = signal<number>(1);
  filtroSemanaAsistencia = signal<'SEMANA_ACTUAL' | 'TODAS'>('SEMANA_ACTUAL');

  historialAsistenciasFiltrado = computed(() => {
    const cur = this.cursoDetalleActivo();
    const lista = cur?.historialAsistencias || [];
    if (this.filtroSemanaAsistencia() === 'SEMANA_ACTUAL') {
      const sesActual = this.sesionActualCurso();
      const coincidencia = lista.filter((s: any) => Number(s.numero) === Number(sesActual));
      if (coincidencia.length > 0) return coincidencia;
    }
    return lista;
  });

  obtenerMesDeCuota(c: any): string {
    if (!c) return 'Marzo';
    if (c.mes) return c.mes;
    if (c.mesCorrespondiente) return c.mesCorrespondiente;
    const meses = ['', 'Enero', 'Febrero', 'Marzo', 'Abril', 'Mayo', 'Junio', 'Julio', 'Agosto', 'Setiembre', 'Octubre', 'Noviembre', 'Diciembre'];
    const mesesEscolares = ['Marzo', 'Abril', 'Mayo', 'Junio', 'Julio', 'Agosto', 'Setiembre', 'Octubre', 'Noviembre', 'Diciembre'];

    if (c.concepto) {
      for (let i = 1; i <= 12; i++) {
        const regex = new RegExp(`\\b${meses[i]}\\b`, 'i');
        if (regex.test(c.concepto)) {
          return meses[i];
        }
      }
    }

    if (c.numero && Number(c.numero) >= 1 && Number(c.numero) <= 10) {
      return mesesEscolares[Number(c.numero) - 1];
    }

    if (c.fechaVencimiento && typeof c.fechaVencimiento === 'string' && c.fechaVencimiento.includes('-')) {
      const partes = c.fechaVencimiento.split('-');
      const m = parseInt(partes[1], 10);
      if (m >= 1 && m <= 12) return meses[m];
    }

    if (c.numero) {
      const mesNum = Math.min(12, Number(c.numero) + 2);
      return meses[mesNum] || `Mes ${c.numero}`;
    }

    return 'Marzo';
  }

  esFechaVencida(fechaLimite?: string): boolean {
    if (!fechaLimite) return false;
    const parsed = Date.parse(fechaLimite);
    if (!isNaN(parsed)) {
      return parsed < Date.now();
    }
    // Si es formato texto de meses pasados (ej. Mar 2026 cuando ya pasó)
    const lower = fechaLimite.toLowerCase();
    if (lower.includes('vencid') || lower.includes('01 mar') || lower.includes('08 mar') || lower.includes('15 mar')) {
      return true;
    }
    return false;
  }

  esImagenArchivo(url?: string, nombre?: string, tipo?: string): boolean {
    if (tipo && tipo.toLowerCase().startsWith('image/')) return true;
    if (url && url.startsWith('data:image/')) return true;
    const n = (nombre || url || '').toLowerCase();
    return n.endsWith('.png') || n.endsWith('.jpg') || n.endsWith('.jpeg') || n.endsWith('.gif') || n.endsWith('.webp') || n.endsWith('.bmp') || n.endsWith('.svg');
  }

  archivosDeEntrega(ent: any): { nombre: string; url: string; tipo: string }[] {
    if (!ent) return [];
    if (Array.isArray(ent.archivos) && ent.archivos.length > 0) {
      return ent.archivos
        .filter((a: any) => a && (a.url || a.nombre))
        .map((a: any) => ({
          nombre: a.nombre || 'archivo',
          url: a.url || '',
          tipo: a.tipo || '',
        }));
    }
    if (ent.archivoUrl) {
      return [{ nombre: ent.archivoNombre || 'archivo', url: ent.archivoUrl, tipo: ent.archivoTipo || '' }];
    }
    return [];
  }

  urlSegura(url?: string): SafeUrl {
    return this.sanitizer.bypassSecurityTrustUrl(url || '');
  }

  urlRecursoSegura(url?: string): SafeResourceUrl {
    return this.sanitizer.bypassSecurityTrustResourceUrl(url || '');
  }

  abrirVistaPreviaArchivo(nombre?: string, url?: string, tipo?: string): void {
    if (!url && !nombre) return;
    this.vistaPreviaArchivoModal.set({
      nombre: nombre || 'evidencia_adjunta',
      url: url || '',
      tipo: tipo || '',
    });
  }

  cerrarVistaPreviaArchivo(): void {
    this.vistaPreviaArchivoModal.set(null);
  }

  generarSesionesAlumno(): void {
    const cur = this.cursoDetalleActivo();
    const a = this.alumno();
    if (!cur) return;

    const strip = (str: string) =>
      (str || '').normalize('NFD').replace(/[\u0300-\u036f]/g, '').toLowerCase().trim();

    const baseDate = new Date(2026, 2, 2); // Lun 02 Mar 2026

    this.personalService.obtenerTodasLasPonderaciones().subscribe({
      next: (ponds) => {
        this.todasLasPonderaciones.set(ponds || []);
        this.sincronizarCursoDetalleDesdeBoleta();
      },
    });

    this.personalService.obtenerActividadesSesiones().subscribe({
      next: (actividades) => {
        this.todasLasActividades.set(actividades || []);
        const curNom = strip(cur.nombre);
        const actDelCurso = (actividades || []).filter((x: any) => {
          const xCur = strip(x.cursoNombre || x.curso);
          return !xCur || xCur === curNom || xCur.includes(curNom) || curNom.includes(xCur);
        });

        this.personalService.obtenerEntregasTareas().subscribe({
          next: (todasEntregas) => {
            this.todasLasEntregas.set(todasEntregas || []);
            const entregasDelCurso = (todasEntregas || []).filter((e: any) => {
              const eCur = strip(e.cursoNombre || e.curso);
              const matchCur = !eCur || eCur === curNom || eCur.includes(curNom) || curNom.includes(eCur);
              const matchAl = !a?.id || Number(e.alumnoId) === Number(a.id) || (todasEntregas || []).length === 1;
              return matchCur && matchAl;
            });

            const maxSesionActividad = Math.max(
              0,
              ...actDelCurso.map((x: any) => Number(x.numeroSesion ?? x.sesion ?? 0)),
              ...entregasDelCurso.map((e: any) => Number(e.sesionId ?? e.tareaId ?? 0))
            );

            const totalSesiones = Math.max(40, maxSesionActividad, Number(cur?.clasesDictadas || 0));

            const hoy = Date.now();
            const diffDias = Math.floor((hoy - baseDate.getTime()) / (1000 * 3600 * 24));
            const semCalc = diffDias >= 0 ? Math.min(40, Math.max(1, Math.floor(diffDias / 7) + 1)) : 1;
            this.semanaActualCurso.set(semCalc);
            this.sesionActualCurso.set(semCalc);

            const baseSesiones: any[] = [];
            for (let i = 1; i <= totalSesiones; i++) {
              const d = new Date(baseDate.getTime() + (i - 1) * 7 * 24 * 60 * 60 * 1000);
              const fechaStr = d.toLocaleDateString('es-PE', { weekday: 'short', day: '2-digit', month: 'short', year: 'numeric' });

              const actsDeSesion = actDelCurso.filter(
                (x: any) => Number(x.numeroSesion ?? x.sesion ?? x.numero) === i
              );
              const actsValidas = actsDeSesion.filter(
                (x: any) => x.tipoActividad && x.tipoActividad !== 'NINGUNA'
              );
              const entregasDeSesion = entregasDelCurso.filter(
                (e: any) => Number(e.sesionId ?? e.tareaId ?? e.sesion ?? e.numero) === i
              );
              const entregaHistorial = (cur.historialAsistencias || []).find((h: any) => Number(h.numero) === i)?.entrega;

              const construirEntregaDetalle = (ent: any, vencida: boolean, entregado: boolean) => {
                const notaCalif = ent?.calificacion !== undefined && ent?.calificacion !== null
                  ? ent.calificacion
                  : (ent?.nota !== undefined && ent?.nota !== null ? ent.nota : (vencida && !entregado ? 0 : null));
                return ent
                  ? {
                      id: ent.id,
                      actividadId: ent.actividadId,
                      archivoNombre: ent.archivoNombre || 'tarea_evidencia_estudiante.pdf',
                      archivoUrl: ent.archivoUrl || '',
                      archivoTipo: ent.archivoTipo || '',
                      archivos: this.archivosDeEntrega(ent),
                      comentario: ent.comentarioAlumno || ent.comentario || 'Evidencia enviada por el alumno.',
                      fechaEntrega: ent.fechaEntrega || new Date().toLocaleString('es-PE'),
                      calificacion: notaCalif,
                      comentarioDocente: ent.comentarioDocente || (vencida && !entregado ? 'Sin entrega registrada dentro del plazo. Calificación automática: 0.' : ''),
                    }
                  : (vencida ? {
                      archivoNombre: 'Sin archivo',
                      archivoUrl: '',
                      archivoTipo: '',
                      archivos: [],
                      comentario: 'No se registró entrega en el plazo indicado.',
                      fechaEntrega: 'Plazo expirado',
                      calificacion: 0,
                      comentarioDocente: 'Sin entrega dentro del plazo. Calificación automática: 0.',
                    } : null);
              };

              if (actsValidas.length > 0) {
                actsValidas.forEach((act: any, idxAct: number) => {
                  const actId = act.actividadId || act.key;
                  const tipoAct = (act.tipoActividad || act.actividadTipo || 'TAREA').toUpperCase();
                  const ent = entregasDeSesion.find(
                    (e: any) => actId && e.actividadId && String(e.actividadId) === String(actId)
                  ) || (actsValidas.length === 1 && entregasDeSesion[0] && !entregasDeSesion[0].actividadId ? (entregasDeSesion[0] ?? entregaHistorial) : undefined);
                  const vencida = this.esFechaVencida(act.fechaLimiteEntrega || act.fechaFinEntrega);
                  const entregado = !!ent && !!(ent.archivoNombre || ent.estado === 'ENTREGADO' || ent.entregado);
                  const estadoTarea: 'ENTREGADA' | 'PENDIENTE' | 'NO_ENTREGADA' = entregado
                    ? 'ENTREGADA'
                    : vencida
                    ? 'NO_ENTREGADA'
                    : 'PENDIENTE';

                  const rawTit = (act.actividadTitulo || act.titulo || '').trim();
                  const esGen = !rawTit || rawTit === `Tarea Sesión ${i}` || rawTit === `Examen Sesión ${i}`;
                  const tituloMostrado = esGen && actsValidas.length > 1
                    ? `${tipoAct === 'EXAMEN' ? 'Examen' : 'Tarea'} #${idxAct + 1} - Sesión ${i}`
                    : (rawTit || (tipoAct === 'TAREA' ? `Tarea #${idxAct + 1} - Sesión ${i}` : `Evaluación #${idxAct + 1} - Sesión ${i}`));

                  baseSesiones.push({
                    numero: i,
                    actividadId: actId,
                    fecha: fechaStr,
                    diaSemana: 'Lunes',
                    actividadTipo: tipoAct,
                    actividadTitulo: tituloMostrado,
                    actividadDescripcion: act.actividadDescripcion || act.descripcion || 'Revisa las indicaciones del docente y sube tu archivo de evidencia.',
                    fechaFinEntrega: act.fechaLimiteEntrega || act.fechaFinEntrega || '',
                    entregado,
                    estadoTarea,
                    entregaDetalle: construirEntregaDetalle(ent, vencida, entregado),
                  });
                });
              } else if (entregasDeSesion.length > 0 || entregaHistorial) {
                const ent = entregasDeSesion[0] ?? entregaHistorial;
                baseSesiones.push({
                  numero: i,
                  actividadId: ent.actividadId,
                  fecha: fechaStr,
                  diaSemana: 'Lunes',
                  actividadTipo: ent.tipoActividad || 'TAREA',
                  actividadTitulo: ent.tituloTarea || `Tarea Académica Sesión N° ${i}`,
                  actividadDescripcion: 'Actividad entregada por el estudiante.',
                  fechaFinEntrega: ent.fechaLimite || '2026-12-30T23:59',
                  entregado: true,
                  estadoTarea: 'ENTREGADA' as const,
                  entregaDetalle: construirEntregaDetalle(ent, false, true),
                });
              } else {
                baseSesiones.push({
                  numero: i,
                  fecha: fechaStr,
                  diaSemana: 'Lunes',
                  actividadTipo: 'NINGUNA',
                  actividadTitulo: 'Sin actividad',
                  actividadDescripcion: '',
                  fechaFinEntrega: '',
                  entregado: false,
                  estadoTarea: 'SIN_TAREA',
                  entregaDetalle: null,
                });
              }
            }

            this.sesionesCurso.set(baseSesiones);
            const activa = this.sesionDetalleActiva();
            if (activa) {
              const nuevaActiva = baseSesiones.find((x) =>
                activa.actividadId
                  ? String(x.actividadId) === String(activa.actividadId)
                  : x.numero === activa.numero
              );
              if (nuevaActiva) this.sesionDetalleActiva.set(nuevaActiva);
            }
            const curActualizado = this.boletaCursos().find(
              (c: any) => strip(c.nombre) === curNom
            );
            if (curActualizado) {
              this.cursoDetalleActivo.set(curActualizado);
            }
          },
        });
      },
    });
  }

  abrirDetalleSesionAlumno(sesion: any): void {
    this.sesionDetalleActiva.set(sesion);
    this.tareaParaEntregar.set(sesion);
    this.mensajeEntrega.set(null);
    const archivos = sesion.entregaDetalle?.archivos?.length
      ? sesion.entregaDetalle.archivos
      : (sesion.entregaDetalle?.archivoUrl
          ? [{ nombre: sesion.entregaDetalle.archivoNombre, url: sesion.entregaDetalle.archivoUrl, tipo: sesion.entregaDetalle.archivoTipo || '' }]
          : []);
    this.formEntrega.set({
      archivos,
      comentario: sesion.entregaDetalle?.comentario || '',
    });
  }

  cerrarDetalleSesionAlumno(): void {
    this.sesionDetalleActiva.set(null);
  }

  abrirModalEntregarTarea(tarea: any, event?: Event): void {
    if (event) event.stopPropagation();
    this.tareaParaEntregar.set(tarea);
    this.sesionDetalleActiva.set(tarea);
    this.mensajeEntrega.set(null);
    const archivos = tarea.entregaDetalle?.archivos?.length
      ? tarea.entregaDetalle.archivos
      : (tarea.entregaDetalle?.archivoUrl
          ? [{ nombre: tarea.entregaDetalle.archivoNombre, url: tarea.entregaDetalle.archivoUrl, tipo: tarea.entregaDetalle.archivoTipo || '' }]
          : []);
    this.formEntrega.set({
      archivos,
      comentario: tarea.entregaDetalle?.comentario || '',
    });
    this.mostrarModalEntregarTarea.set(true);
  }

  cerrarModalEntregarTarea(): void {
    this.mostrarModalEntregarTarea.set(false);
    this.tareaParaEntregar.set(null);
  }

  setComentarioEntrega(comentario: string): void {
    this.formEntrega.update((f) => ({ ...f, comentario }));
  }

  quitarArchivoEntrega(index: number): void {
    this.formEntrega.update((f) => ({
      ...f,
      archivos: f.archivos.filter((_, i) => i !== index),
    }));
  }

  onArchivoSeleccionado(event: Event): void {
    const input = event.target as HTMLInputElement;
    const files = input.files ? Array.from(input.files) : [];
    if (files.length === 0) return;

    const lecturas = files.map((file) => new Promise<{ nombre: string; url: string; tipo: string }>((resolve) => {
      const reader = new FileReader();
      const mimeType = file.type || '';
      reader.onload = () => {
        resolve({
          nombre: file.name,
          url: typeof reader.result === 'string' ? reader.result : '',
          tipo: mimeType,
        });
      };
      reader.onerror = () => resolve({ nombre: file.name, url: '', tipo: mimeType });
      reader.readAsDataURL(file);
    }));

    Promise.all(lecturas).then((nuevos) => {
      this.formEntrega.update((f) => ({
        ...f,
        archivos: [...f.archivos, ...nuevos.filter((a) => a.url)],
      }));
      input.value = '';
    });
  }

  cancelarEntrega(sesion?: any): void {
    const t = sesion || this.sesionDetalleActiva();
    if (!t) return;
    const entregaId = t.entregaDetalle?.id;
    if (!entregaId) {
      this.mensajeEntrega.set({ tipo: 'error', texto: 'No se encontró el registro de la entrega. Vuelve a cargar la página.' });
      return;
    }
    if (!confirm('¿Cancelar la entrega? Los archivos subidos se eliminarán y podrás volver a entregar.')) return;

    this.personalService.cancelarEntregaTarea(entregaId).subscribe({
      next: () => {
        const actualizada = {
          ...t,
          entregado: false,
          estadoTarea: 'PENDIENTE' as const,
          entregaDetalle: null,
        };
        const coincideSesion = (item: any) =>
          t.actividadId ? String(item.actividadId) === String(t.actividadId) : item.numero === t.numero;
        this.sesionesCurso.update((list) => list.map((item) => (coincideSesion(item) ? actualizada : item)));
        this.todasLasEntregas.update((list) => list.filter((item) => Number(item.id) !== Number(entregaId)));
        this.sesionDetalleActiva.set(actualizada);
        this.tareaParaEntregar.set(actualizada);
        this.formEntrega.set({ archivos: [], comentario: '' });
        this.mensajeEntrega.set({ tipo: 'success', texto: 'Entrega cancelada. Ya puedes subir tus archivos y entregar nuevamente.' });
      },
      error: () => {
        this.mensajeEntrega.set({ tipo: 'error', texto: 'No se pudo cancelar la entrega. Intenta nuevamente.' });
      },
    });
  }

  confirmarEntregaTarea(): void {
    const t = this.tareaParaEntregar() || this.sesionDetalleActiva();
    const a = this.alumno();
    const cur = this.cursoDetalleActivo();
    if (!t) return;

    if (t.estadoTarea === 'ENTREGADA' || t.entregado) {
      this.mensajeEntrega.set({ tipo: 'error', texto: 'Esta actividad ya fue entregada. Para cambiarla, primero cancela la entrega.' });
      return;
    }

    const archivos = this.formEntrega().archivos || [];
    if (archivos.length === 0) {
      this.mensajeEntrega.set({ tipo: 'error', texto: 'Selecciona al menos un archivo (imagen, PDF o documento) para entregar.' });
      return;
    }

    const tipo = t.actividadTipo === 'EXAMEN' ? 'EXAMEN' : 'TAREA';
    const archivoNombre = archivos[0]?.nombre || 'archivo';
    const archivoUrl = archivos[0]?.url || '';
    const archivoTipo = archivos[0]?.tipo || '';
    const comentario = (this.formEntrega().comentario || '').trim() || (tipo === 'EXAMEN' ? 'Examen resuelto entregado por el estudiante.' : 'Evidencia entregada por el estudiante.');
    const ahora = new Date().toLocaleString('es-PE');

    const payloadEntrega = {
      alumnoId: a?.id || 1,
      alumnoNombre: this.nombreCompleto(),
      cursoId: cur?.id || 1,
      cursoNombre: cur?.nombre || this.cursoSeleccionadoNombre(),
      grado: a?.grado || '1° Secundaria',
      tareaId: t.numero || t.id || 1,
      sesionId: t.numero || t.id || 1,
      actividadId: t.actividadId || t.entregaDetalle?.actividadId || t.key || undefined,
      tipoActividad: tipo,
      archivos,
      archivoNombre,
      archivoUrl,
      archivoTipo,
      comentario,
      comentarioAlumno: comentario,
    };

    const alActualizar = (resServidor?: any) => {
      this.guardandoEntrega.set(false);
      const entServ = resServidor?.entrega || payloadEntrega;
      const archivosServidor = entServ.archivos?.length
        ? entServ.archivos.map((x: any) => ({ nombre: x.nombre, url: x.url, tipo: x.tipo || '' }))
        : archivos;
      const detalle = {
        id: entServ.id,
        actividadId: entServ.actividadId || payloadEntrega.actividadId,
        archivoNombre: entServ.archivoNombre || archivoNombre,
        archivoUrl: entServ.archivoUrl || archivoUrl,
        archivoTipo: entServ.archivoTipo || archivoTipo,
        archivos: archivosServidor,
        comentario: entServ.comentarioAlumno || entServ.comentario || comentario,
        fechaEntrega: entServ.fechaEntrega || ahora,
        calificacion: entServ.calificacion ?? null,
        comentarioDocente: entServ.comentarioDocente || '',
      };
      const sesionActualizada = { ...t, entregado: true, estadoTarea: 'ENTREGADA' as const, entregaDetalle: detalle };
      const coincideSesion = (item: any) =>
        t.actividadId ? String(item.actividadId) === String(t.actividadId) : item.numero === t.numero;
      this.sesionesCurso.update((list) => list.map((item) => (coincideSesion(item) ? sesionActualizada : item)));
      this.todasLasEntregas.update((list) => {
        const filtrada = list.filter((item) => {
          if (payloadEntrega.actividadId) {
            return String(item.actividadId) !== String(payloadEntrega.actividadId);
          }
          return !(
            !item.actividadId &&
            Number(item.sesionId ?? item.tareaId) === Number(t.numero) &&
            String(item.cursoNombre || '').toLowerCase() === String(payloadEntrega.cursoNombre || '').toLowerCase()
          );
        });
        return [...filtrada, { ...payloadEntrega, id: entServ.id, estado: 'ENTREGADO', entregado: true, fechaEntrega: detalle.fechaEntrega }];
      });
      this.sesionDetalleActiva.set(sesionActualizada);
      this.tareaParaEntregar.set(sesionActualizada);
      this.mostrarModalEntregarTarea.set(false);
      this.mensajeEntrega.set({
        tipo: 'success',
        texto: `¡${tipo === 'EXAMEN' ? 'Examen' : 'Tarea'} de la Sesión N° ${t.numero} subida y guardada correctamente! El docente ya puede visualizar tus archivos (${archivosServidor.length}).`,
      });
      this.actualizarCursoActivo();
    };

    this.guardandoEntrega.set(true);
    this.personalService.entregarTareaAlumno(payloadEntrega).subscribe({
      next: (res) => alActualizar(res),
      error: () => alActualizar()
    });
  }

  seleccionarCursoDetalle(curso: any): void {
    this.cursoDetalleActivo.set(curso);
    this.tabSubDetalle.set('deberes');
    this.cursoSeleccionadoNombre.set(curso.nombre);
    this.sesionDetalleActiva.set(null);
    this.mensajeEntrega.set(null);
    this.generarSesionesAlumno();
  }

  cambiarSubTab(tab: 'notas' | 'asistencia' | 'tareas' | 'silabo' | 'justificar' | 'sesiones' | 'deberes'): void {
    this.tabSubDetalle.set(tab);
    if (tab === 'asistencia' || tab === 'justificar' || tab === 'notas') {
      this.actualizarCursoActivo();
    }
    if (tab === 'sesiones' || tab === 'deberes') {
      this.generarSesionesAlumno();
    }
  }

  private sincronizarCursoDetalleDesdeBoleta(): void {
    const actual = this.cursoDetalleActivo();
    if (!actual) return;
    const nombre = String(actual.nombre || '').trim().toLowerCase();
    const actualizado = this.boletaCursos().find(
      (c: any) => String(c.nombre || '').trim().toLowerCase() === nombre
    );
    if (actualizado) {
      this.cursoDetalleActivo.set(actualizado);
    }
  }

  private actualizarCursoActivo(): void {
    this.personalService.obtenerTodasLasPonderaciones().subscribe({
      next: (ponds) => {
        this.todasLasPonderaciones.set(ponds || []);
        this.sincronizarCursoDetalleDesdeBoleta();
      },
    });
    this.alumnoService.obtenerMiPerfil().subscribe({
      next: (res) => {
        this.data.set(res);
        this.personalService.obtenerActividadesSesiones().subscribe({
          next: (acts) => {
            this.todasLasActividades.set(acts || []);
            this.personalService.obtenerEntregasTareas().subscribe({
              next: (ents) => {
                this.todasLasEntregas.set(ents || []);
                const actual = this.cursoDetalleActivo();
                if (!actual) return;
                const nombre = String(actual.nombre || '').trim().toLowerCase();
                const actualizado = this.boletaCursos().find(
                  (c: any) => String(c.nombre || '').trim().toLowerCase() === nombre
                );
                if (actualizado) {
                  this.cursoDetalleActivo.set(actualizado);
                }
                this.generarSesionesAlumno();
              },
            });
          },
        });
      },
    });
  }

  enviarJustificacionCurso(curso: any, motivo: string, sesion: number): void {
    if (this.enviandoJustificacion()) return;

    const a = this.alumno();
    if (!a || !curso) return;

    if (!motivo || !motivo.trim()) {
      this.mensajeJustificacion.set({
        tipo: 'error',
        texto: 'Escribe el motivo o detalle de la inasistencia antes de enviar la solicitud.',
      });
      return;
    }

    if (this.justificacionPendienteCurso()) {
      this.mensajeJustificacion.set({
        tipo: 'error',
        texto: 'Ya tienes una justificación pendiente para este curso. Espera la confirmación del docente.',
      });
      return;
    }

    const sesionNumero = Number(sesion);
    const sesionSeleccionada = (curso.historialAsistencias || []).find(
      (s: any) => Number(s.numero) === sesionNumero && String(s.estado || '').toUpperCase() === 'FALTA'
    );
    if (!sesionSeleccionada) {
      this.mensajeJustificacion.set({
        tipo: 'error',
        texto: 'Solo puedes justificar sesiones registradas como FALTA. Las tardanzas no requieren justificación.',
      });
      return;
    }

    this.enviandoJustificacion.set(true);
    this.mensajeJustificacion.set(null);

    this.alumnoService.enviarJustificacion({
      alumnoId: a.id,
      curso: curso.nombre,
      docenteId: curso.docenteId || undefined,
      fechaInasistencia: sesionSeleccionada.fecha || new Date().toISOString().split('T')[0],
      horaClase: curso.horario || '08:00 - 10:00',
      sesion: sesionNumero,
      motivo: 'Inasistencia a Sesión',
      descripcion: motivo.trim(),
      comprobanteNombre: 'certificado_medico.pdf',
    }).subscribe({
      next: (res) => {
        this.enviandoJustificacion.set(false);
        this.mensajeJustificacion.set({
          tipo: 'success',
          texto: res.mensaje || 'Justificación enviada. Espera la confirmación del docente.',
        });
        this.cargarDatos();
      },
      error: (err) => {
        this.enviandoJustificacion.set(false);
        this.mensajeJustificacion.set({
          tipo: 'error',
          texto: err.error?.message || 'No se pudo enviar la justificación. Intente nuevamente.',
        });
        console.error('Error al enviar justificación:', err);
      },
    });
  }

  volverAListadoCursos(): void {
    this.cursoDetalleActivo.set(null);
    this.cargarDatos();
  }
  
  tareasCurso = computed<{ id: number; curso: string; titulo: string; fechaEntrega: string; estado: string; nota: string | null; docente: string }[]>(() => {
    return [];
  });

  faltasPorCurso = computed<{ id: number; curso: string; fecha: string; hora: string; docente: string; docenteId: number; motivoDocente: string; estadoJustificacion: string }[]>(() => {
    return [];
  });

  modalPasarelaPago = signal(false);
  metodoPagoSeleccionado = signal<'TARJETA' | 'YAPE' | 'TRANSFERENCIA'>('YAPE');
  montoPagoSimulado = signal<number>(350);
  pagandoPasarela = signal(false);

  pagandoCuota = signal<number | null>(null);
  mensajeFinanzas = signal<{ tipo: 'success' | 'error'; texto: string } | null>(null);
  mensajeJustificacion = signal<{ tipo: 'success' | 'error'; texto: string } | null>(null);

  reciboModal = signal<{
    numero: number;
    concepto: string;
    monto: number;
    fechaPago: string;
    numeroOperacion: string;
    alumno: string;
    dni: string;
  } | null>(null);

  // Módulo de Justificación de Inasistencias Web
  mostrarModalJustificar = signal(false);
  enviandoJustificacion = signal(false);
  formJustificacion = signal({
    curso: '',
    docenteId: 0,
    fechaInasistencia: new Date().toISOString().split('T')[0],
    horaClase: '08:00 - 10:00',
    motivo: 'Salud / Cita Médica',
    descripcion: '',
    comprobanteNombre: 'certificado_medico_consulta.pdf',
  });

  alumno = computed(() => this.data()?.alumno ?? null);
  notas = computed(() => this.data()?.notas ?? []);
  cursos = computed(() => this.data()?.cursos ?? []);

  boletaCursos = computed(() => {
    const backendCursos = this.cursos();
    if (backendCursos.length === 0) return [];

    const strip = (str: string) =>
      (str || '').normalize('NFD').replace(/[\u0300-\u036f]/g, '').toLowerCase().trim();

    const a = this.alumno();
    const actsGlobales = this.todasLasActividades();
    const entsGlobales = this.todasLasEntregas();
    const pondsGlobales = this.todasLasPonderaciones();

    // Deduplicate by course name or code so same course appears only once
    const uniqueMap = new Map();
    for (const c of backendCursos) {
      const key = (c.nombre || c.codigo).trim().toLowerCase();
      if (!uniqueMap.has(key)) {
        uniqueMap.set(key, c);
      }
    }
    const deduped = Array.from(uniqueMap.values());

    return deduped.map((c: any, index: number) => {
      const name = c.nombre.toLowerCase();
      const curNom = strip(c.nombre);
      let color = 'indigo';
      if (name.includes('biol')) color = 'emerald';
      if (name.includes('físic') || name.includes('fisic')) color = 'cyan';
      if (name.includes('quím') || name.includes('quim')) color = 'purple';
      if (name.includes('lengu')) color = 'amber';
      if (name.includes('hist')) color = 'blue';
      if (name.includes('depor')) color = 'rose';
      if (name.includes('filo')) color = 'slate';
      if (name.includes('botá') || name.includes('bota')) color = 'teal';

      const sesionesList = c.historialAsistencias && c.historialAsistencias.length > 0 ? c.historialAsistencias : [];
      const solicitudesDelCurso = this.justificaciones()
        .filter((j: any) => strip(j.curso || '') === curNom)
        .sort((aItem: any, bItem: any) => (bItem.id || 0) - (aItem.id || 0));

      const esCursoActivo = strip(this.cursoSeleccionadoNombre() || '') === curNom;
      const fuenteSesiones = esCursoActivo && this.sesionesCurso().length > 0 ? this.sesionesCurso() : sesionesList;

      const actsDelCurso = actsGlobales.filter((x: any) => {
        const xCur = strip(x.cursoNombre || x.curso);
        return xCur && (xCur === curNom || xCur.includes(curNom) || curNom.includes(xCur));
      });

      const entsDelCurso = entsGlobales.filter((e: any) => {
        const eCur = strip(e.cursoNombre || e.curso);
        const matchCur = eCur && (eCur === curNom || eCur.includes(curNom) || curNom.includes(eCur));
        const matchAl = !a?.id || Number(e.alumnoId) === Number(a.id) || entsGlobales.length === 1;
        return matchCur && matchAl;
      });

      const tareasSesiones = fuenteSesiones.filter((s: any) => (s.actividadTipo || s.tipoActividad) === 'TAREA');
      const examenesSesiones = fuenteSesiones.filter((s: any) => (s.actividadTipo || s.tipoActividad) === 'EXAMEN');

      const tareasPublicadas = actsDelCurso.length > 0
        ? actsDelCurso.filter((x: any) => (x.tipoActividad || x.actividadTipo) === 'TAREA')
        : tareasSesiones;

      const examenesPublicados = actsDelCurso.length > 0
        ? actsDelCurso.filter((x: any) => (x.tipoActividad || x.actividadTipo) === 'EXAMEN')
        : examenesSesiones;

      // 1. Tareas: Si se publicaron N tareas, promedio exacto de esas N tareas publicadas
      let practicaNota: number = 0;
      let tieneTareaCalificada = false;
      if (tareasPublicadas.length > 0) {
        const sumaTareas = tareasPublicadas.reduce((acc: number, t: any) => {
          const sesNum = Number(t.numeroSesion ?? t.sesion ?? t.numero ?? 0);
          const actId = t.actividadId || t.key;
          const tareasMismaSes = tareasPublicadas.filter((x: any) => Number(x.numeroSesion ?? x.sesion ?? x.numero ?? 0) === sesNum);
          const entGlobal = entsDelCurso.find((e: any) => {
            if (actId) {
              if (e.actividadId) return String(e.actividadId) === String(actId);
              return tareasMismaSes.length <= 1 && Number(e.sesionId ?? e.tareaId ?? e.sesion ?? e.numero) === sesNum && (e.tipoActividad || 'TAREA') === 'TAREA';
            }
            return !e.actividadId && Number(e.sesionId ?? e.tareaId ?? e.sesion ?? e.numero) === sesNum && (e.tipoActividad || 'TAREA') === 'TAREA';
          });
          const sesLocal = tareasSesiones.find((s: any) =>
            actId
              ? (s.actividadId && String(s.actividadId) === String(actId))
              : (!s.actividadId && Number(s.numero) === sesNum)
          );
          const cal = entGlobal?.calificacion ?? entGlobal?.nota ?? sesLocal?.entregaDetalle?.calificacion ?? sesLocal?.entrega?.calificacion ?? t.entregaDetalle?.calificacion ?? t.entrega?.calificacion;
          if (cal !== undefined && cal !== null) {
            tieneTareaCalificada = true;
            return acc + Number(cal);
          }
          return acc + 0;
        }, 0);
        practicaNota = Number((sumaTareas / tareasPublicadas.length).toFixed(1));
      } else {
        const entregasTareasCalif = entsDelCurso.filter(
          (e: any) => (e.tipoActividad || 'TAREA') === 'TAREA' && e.calificacion !== undefined && e.calificacion !== null
        );
        if (entregasTareasCalif.length > 0) {
          const sum = entregasTareasCalif.reduce((acc: number, e: any) => acc + Number(e.calificacion || 0), 0);
          practicaNota = Number((sum / entregasTareasCalif.length).toFixed(1));
          tieneTareaCalificada = true;
        }
      }

      // 2. Exámenes: Si se publicaron M exámenes, promedio exacto de esos M exámenes publicados
      let parcialNota: number = 0;
      let tieneExamenCalificado = false;
      if (examenesPublicados.length > 0) {
        const sumaExamenes = examenesPublicados.reduce((acc: number, ex: any) => {
          const sesNum = Number(ex.numeroSesion ?? ex.sesion ?? ex.numero ?? 0);
          const actId = ex.actividadId || ex.key;
          const exMismaSes = examenesPublicados.filter((x: any) => Number(x.numeroSesion ?? x.sesion ?? x.numero ?? 0) === sesNum);
          const entGlobal = entsDelCurso.find((e: any) => {
            if (actId) {
              if (e.actividadId) return String(e.actividadId) === String(actId);
              return exMismaSes.length <= 1 && Number(e.sesionId ?? e.tareaId ?? e.sesion ?? e.numero) === sesNum && (e.tipoActividad || 'EXAMEN') === 'EXAMEN';
            }
            return !e.actividadId && Number(e.sesionId ?? e.tareaId ?? e.sesion ?? e.numero) === sesNum && (e.tipoActividad || 'EXAMEN') === 'EXAMEN';
          });
          const sesLocal = examenesSesiones.find((s: any) =>
            actId
              ? (s.actividadId && String(s.actividadId) === String(actId))
              : (!s.actividadId && Number(s.numero) === sesNum)
          );
          const cal = entGlobal?.calificacion ?? entGlobal?.nota ?? sesLocal?.entregaDetalle?.calificacion ?? sesLocal?.entrega?.calificacion ?? ex.entregaDetalle?.calificacion ?? ex.entrega?.calificacion;
          if (cal !== undefined && cal !== null) {
            tieneExamenCalificado = true;
            return acc + Number(cal);
          }
          return acc + 0;
        }, 0);
        parcialNota = Number((sumaExamenes / examenesPublicados.length).toFixed(1));
      } else {
        const entregasExaCalif = entsDelCurso.filter(
          (e: any) => e.tipoActividad === 'EXAMEN' && e.calificacion !== undefined && e.calificacion !== null
        );
        if (entregasExaCalif.length > 0) {
          const sum = entregasExaCalif.reduce((acc: number, e: any) => acc + Number(e.calificacion || 0), 0);
          parcialNota = Number((sum / entregasExaCalif.length).toFixed(1));
          tieneExamenCalificado = true;
        }
      }

      const examenFinalNota: number = parcialNota;

      // 3. Nota de Asistencia: Temprano (PRESENTE) = 20, Tarde (TARDANZA) = 13, Falta = 0, Justificada = 16
      // Se cuentan ÚNICAMENTE las sesiones donde el docente registró asistencia (excluyendo PENDIENTE y SIN_REGISTRO)
      const sesionesConAsistencia = sesionesList.filter((s: any) => {
        const est = String(s.estado || '').trim().toUpperCase();
        return est === 'PRESENTE' || est === 'TARDANZA' || est === 'FALTA' || est === 'JUSTIFICADA' || est === 'JUSTIFICADO';
      });

      let asistenciaNota: number = 0;
      if (sesionesConAsistencia.length > 0) {
        const sumaPts = sesionesConAsistencia.reduce((acc: number, s: any) => {
          const est = String(s.estado || '').trim().toUpperCase();
          if (est === 'PRESENTE') return acc + 20;
          if (est === 'TARDANZA') return acc + 13;
          if (est === 'JUSTIFICADA' || est === 'JUSTIFICADO') return acc + 16;
          return acc + 0;
        }, 0);
        asistenciaNota = Number((sumaPts / sesionesConAsistencia.length).toFixed(1));
      } else if (c.asistenciaNota !== undefined && c.asistenciaNota !== null) {
        asistenciaNota = Number(c.asistenciaNota);
      }

      const presentesCount = sesionesConAsistencia.filter((s: any) => String(s.estado || '').toUpperCase() === 'PRESENTE').length;
      const tardanzasCount = sesionesConAsistencia.filter((s: any) => String(s.estado || '').toUpperCase() === 'TARDANZA').length;
      const faltasCount = sesionesConAsistencia.filter((s: any) => String(s.estado || '').toUpperCase() === 'FALTA').length;
      const justificadasCount = sesionesConAsistencia.filter((s: any) => ['JUSTIFICADA', 'JUSTIFICADO'].includes(String(s.estado || '').toUpperCase())).length;
      const totalSesionesRegistradas = sesionesConAsistencia.length;
      const asistenciaPctCalculado = totalSesionesRegistradas > 0
        ? Math.round(((presentesCount + tardanzasCount + justificadasCount) / totalSesionesRegistradas) * 100)
        : (c.asistenciaPct ?? 0);

      const pondMatch =
        pondsGlobales.find((p: any) => {
          const pNom = strip(p.cursoNombre || p.curso || '');
          return pNom && (pNom === curNom || pNom.includes(curNom) || curNom.includes(pNom));
        }) ||
        pondsGlobales.find((p: any) => p.cursoId !== undefined && Number(p.cursoId) === Number(c.id)) ||
        (pondsGlobales.length === 1 && backendCursos.length === 1 ? pondsGlobales[0] : null);

      const pesos = pondMatch
        ? {
            asistencia: Number(pondMatch.asistenciaPorcentaje ?? pondMatch.ponderacion?.asistencia ?? 30),
            tareas: Number(pondMatch.tareasPorcentaje ?? pondMatch.ponderacion?.tareas ?? 35),
            examenes: Number(pondMatch.examenesPorcentaje ?? pondMatch.ponderacion?.examenes ?? 35),
          }
        : c.pesos || { asistencia: 30, tareas: 35, examenes: 35 };

      const totalTareasCount = tareasPublicadas.length;
      const totalExamenesCount = examenesPublicados.length;

      const hayEvaluacionRegistrada =
        totalSesionesRegistradas > 0 ||
        totalTareasCount > 0 ||
        totalExamenesCount > 0 ||
        tieneTareaCalificada ||
        tieneExamenCalificado ||
        practicaNota > 0 ||
        examenFinalNota > 0;

      const promedioCalculado: number = hayEvaluacionRegistrada
        ? Number(
            (
              asistenciaNota * (pesos.asistencia / 100) +
              practicaNota * (pesos.tareas / 100) +
              examenFinalNota * (pesos.examenes / 100)
            ).toFixed(1)
          )
        : 0;

      return {
        id: c.id,
        codigo: c.codigo || `CUR-00${index + 1}`,
        nombre: c.nombre,
        docente: c.docente || c.docenteNombre || 'Docente Asignado',
        horario: c.horario || `${c.dia || 'Lunes'} ${c.horaInicio || '08:00'} - ${c.horaFin || '10:00'}`,
        aula: c.aula || 'Aula Principal',
        horasSemanales: c.duracionHoras || 4,
        asistenciaNota,
        practica: practicaNota,
        parcial: parcialNota,
        examenFinal: examenFinalNota,
        final: promedioCalculado,
        pesos,
        totalTareas: totalTareasCount,
        totalExamenes: totalExamenesCount,
        estado: promedioCalculado >= 11 ? 'APROBADO' : 'DESAPROBADO',
        colorBadge: color,
        asistenciaPct: asistenciaPctCalculado,
        clasesDictadas: totalSesionesRegistradas,
        asistenciasCount: presentesCount,
        faltasCount: faltasCount,
        tardanzasCount: tardanzasCount,
        historialAsistencias: sesionesList,
        solicitudesJustificacion: solicitudesDelCurso,
        evaluaciones: (c.evaluaciones && c.evaluaciones.length > 0) ? c.evaluaciones : [],
        tareasList: (c.tareasList && c.tareasList.length > 0) ? c.tareasList : [],
        silabo: (c.silabo && c.silabo.length > 0) ? c.silabo : []
      };
    });
  });



  bloquesMatrizHorario = computed(() => {
    const lista: any[] = [];
    const cursos = this.boletaCursos();
    let idCounter = 1;
    
    for (const c of cursos) {
      const hStr = c.horario || '';
      // Soportamos formatos "Día HH:MM - HH:MM" o múltiples separados por "/"
      const partes = hStr.split('/').map((s: string) => s.trim());
      
      for (const p of partes) {
        // Regex para capturar día y rango de horas
        const matches = p.match(/(Lunes|Martes|Miércoles|Jueves|Viernes|Sábado|Domingo|Lun|Mar|Mié|Mie|Jue|Vie|Sáb|Sab|Dom)\s+(\d{2}:\d{2})\s+-\s+(\d{2}:\d{2})/i);
        if (matches) {
          let dia = matches[1];
          // Normalización de nombres de día
          const lowDia = dia.toLowerCase();
          if (lowDia.startsWith('lun')) dia = 'Lunes';
          else if (lowDia.startsWith('mar')) dia = 'Martes';
          else if (lowDia.includes('mi')) dia = 'Miércoles';
          else if (lowDia.startsWith('jue')) dia = 'Jueves';
          else if (lowDia.startsWith('vie')) dia = 'Viernes';
          else if (lowDia.startsWith('sá') || lowDia.startsWith('sa')) dia = 'Sábado';
          else if (lowDia.startsWith('dom')) dia = 'Domingo';
          
          lista.push({
            id: idCounter++,
            dia: dia,
            horaInicio: matches[2],
            horaFin: matches[3],
            curso: c.nombre,
            docenteNombre: c.docente,
            aula: c.aula,
            codigo: c.codigo
          });
        }
      }
    }
    return lista;
  });

  franjasMatriz = computed(() => {
    const bloques = this.bloquesMatrizHorario();
    const franjas = new Set<string>();
    bloques.forEach(b => franjas.add(`${b.horaInicio} - ${b.horaFin}`));
    const sorted = Array.from(franjas).sort((a, b) => a.localeCompare(b));
    return sorted.length > 0 ? sorted : ['08:00 - 09:30', '09:30 - 11:00', '11:30 - 13:00'];
  });

  buscarBloquePorFranja(dia: string, franja: string) {
    const normDia = dia.toLowerCase().normalize("NFD").replace(/[\u0300-\u036f]/g, "");
    const [fIni, fFin] = franja.split(' - ').map(s => s.trim());

    return this.bloquesMatrizHorario().find(b => {
      const bDia = b.dia.toLowerCase().normalize("NFD").replace(/[\u0300-\u036f]/g, "");
      if (bDia !== normDia) return false;
      const bFranja = `${b.horaInicio} - ${b.horaFin}`;
      if (bFranja === franja) return true;

      // Si la hora de inicio coincide con la franja, o abarca la franja
      const toMin = (h: string) => {
        if (!h || !h.includes(':')) return 0;
        const [hh, mm] = h.split(':').map(Number);
        return hh * 60 + mm;
      };
      const bStart = toMin(b.horaInicio);
      const bEnd = toMin(b.horaFin);
      const fStart = toMin(fIni);
      const fEnd = toMin(fFin);

      return (bStart <= fStart && bEnd >= fEnd) || (bStart === fStart);
    });
  }

  irACursoDesdeHorario(cursoNombre: string): void {
    const list = this.boletaCursos();
    const cNorm = (cursoNombre || '').toLowerCase().trim();
    const target = list.find(c => 
      c.nombre.toLowerCase().includes(cNorm) || 
      cNorm.includes(c.nombre.toLowerCase())
    ) || list[0];
    
    if (target) {
      this.seleccionarCursoDetalle(target);
      this.tabActiva.set('cursos');
      this.mostrarModalHorario.set(false);
    }
  }

  getCursoColorClass(cursoNombre: string): { 
    bg: string; 
    text: string; 
    border: string; 
    badge: string; 
    accent: string; 
    iconBg: string;
    glow: string;
    codigo: string;
    gradientHeader: string;
    headerBg: string;
    btnBg: string;
  } {
    const c = (cursoNombre || '').toLowerCase();
    
    // Configuración base por defecto
    let theme = {
      bg: 'bg-gradient-to-br from-slate-50 via-white to-slate-50 hover:from-slate-100 hover:to-white',
      text: 'text-slate-950 font-extrabold',
      border: 'border-slate-200 hover:border-slate-400',
      badge: 'bg-slate-600 text-white shadow-sm',
      accent: 'border-l-slate-600',
      iconBg: 'bg-slate-50 text-slate-700',
      glow: 'shadow-slate-100',
      codigo: 'CUR-001',
      gradientHeader: 'from-slate-600 to-slate-700',
      headerBg: 'bg-slate-600',
      btnBg: 'bg-slate-600 hover:bg-slate-700'
    };

    if (c.includes('álgebra') || c.includes('matemát')) {
      theme = { ...theme, 
        bg: 'bg-[#eef2f7]', 
        border: 'border-indigo-200', 
        badge: 'bg-indigo-600 text-white shadow-sm', 
        accent: 'border-l-indigo-600', 
        iconBg: 'bg-indigo-50 text-indigo-700',
        codigo: 'MAT-101',
        headerBg: 'bg-indigo-600',
        btnBg: 'bg-indigo-600 hover:bg-indigo-700'
      };
    } else if (c.includes('físic')) {
      theme = { ...theme, 
        bg: 'bg-[#eef2f7]', 
        border: 'border-cyan-200', 
        badge: 'bg-cyan-600 text-white shadow-sm', 
        accent: 'border-l-cyan-600', 
        iconBg: 'bg-cyan-50 text-cyan-700',
        codigo: 'FIS-201',
        headerBg: 'bg-cyan-600',
        btnBg: 'bg-cyan-600 hover:bg-cyan-700'
      };
    } else if (c.includes('biolog')) {
      theme = { ...theme, 
        bg: 'bg-gradient-to-br from-emerald-50 via-white to-emerald-50 hover:from-emerald-100 hover:to-white', 
        border: 'border-emerald-200 hover:border-emerald-400', 
        badge: 'bg-emerald-600 text-white shadow-sm', 
        accent: 'border-l-emerald-600', 
        iconBg: 'bg-emerald-50 text-emerald-700',
        codigo: 'BIO-101',
        headerBg: 'bg-emerald-600',
        btnBg: 'bg-emerald-600 hover:bg-emerald-700'
      };
    } else if (c.includes('quím')) {
      theme = { ...theme, 
        bg: 'bg-gradient-to-br from-purple-50 via-white to-purple-50 hover:from-purple-100 hover:to-white', 
        border: 'border-purple-200 hover:border-purple-400', 
        badge: 'bg-purple-600 text-white shadow-sm', 
        accent: 'border-l-purple-600', 
        iconBg: 'bg-purple-50 text-purple-700',
        codigo: 'QUI-303',
        headerBg: 'bg-purple-600',
        btnBg: 'bg-purple-600 hover:bg-purple-700'
      };
    } else if (c.includes('lengu')) {
      theme = { ...theme, 
        bg: 'bg-gradient-to-br from-amber-50 via-white to-amber-50 hover:from-amber-100 hover:to-white', 
        border: 'border-amber-200 hover:border-amber-400', 
        badge: 'bg-amber-600 text-white shadow-sm', 
        accent: 'border-l-amber-600', 
        iconBg: 'bg-amber-50 text-amber-700',
        codigo: 'LIT-105',
        headerBg: 'bg-amber-600',
        btnBg: 'bg-amber-600 hover:bg-amber-700'
      };
    } else if (c.includes('historia')) {
      theme = { ...theme, 
        bg: 'bg-gradient-to-br from-blue-50 via-white to-blue-50 hover:from-blue-100 hover:to-white', 
        border: 'border-blue-200 hover:border-blue-400', 
        badge: 'bg-blue-600 text-white shadow-sm', 
        accent: 'border-l-blue-600', 
        iconBg: 'bg-blue-50 text-blue-700',
        codigo: 'HIS-104',
        headerBg: 'bg-blue-600',
        btnBg: 'bg-blue-600 hover:bg-blue-700'
      };
    } else if (c.includes('deporte') || c.includes('físic')) {
      theme = { ...theme, 
        bg: 'bg-gradient-to-br from-rose-50 via-white to-rose-50 hover:from-rose-100 hover:to-white', 
        border: 'border-rose-200 hover:border-rose-400', 
        badge: 'bg-rose-600 text-white shadow-sm', 
        accent: 'border-l-rose-600', 
        iconBg: 'bg-rose-50 text-rose-700',
        codigo: 'DEP-501',
        headerBg: 'bg-rose-600',
        btnBg: 'bg-rose-600 hover:bg-rose-700'
      };
    } else if (c.includes('filo')) {
      theme = { ...theme, 
        bg: 'bg-gradient-to-br from-slate-50 via-white to-slate-50 hover:from-slate-100 hover:to-white', 
        border: 'border-slate-300 hover:border-slate-500', 
        badge: 'bg-slate-700 text-white shadow-sm', 
        accent: 'border-l-slate-700', 
        iconBg: 'bg-slate-100 text-slate-800',
        codigo: 'FIL-101',
        headerBg: 'bg-slate-700',
        btnBg: 'bg-slate-700 hover:bg-slate-800'
      };
    } else if (c.includes('botá')) {
      theme = { ...theme, 
        bg: 'bg-gradient-to-br from-teal-50 via-white to-teal-50 hover:from-teal-100 hover:to-white', 
        border: 'border-teal-200 hover:border-teal-400', 
        badge: 'bg-teal-600 text-white shadow-sm', 
        accent: 'border-l-teal-600', 
        iconBg: 'bg-teal-50 text-teal-700',
        codigo: 'BOT-101',
        headerBg: 'bg-teal-600',
        btnBg: 'bg-teal-600 hover:bg-teal-700'
      };
    }

    return theme;
  }

  justificaciones = computed(() => this.data()?.justificaciones ?? []);
  sesionesJustificables = computed(() => {
    const curso = this.cursoDetalleActivo();
    if (!curso) return [] as any[];
    return (curso.historialAsistencias || []).filter(
      (s: any) => String(s.estado || '').toUpperCase() === 'FALTA'
    );
  });
  justificacionPendienteCurso = computed(() => {
    const curso = this.cursoDetalleActivo();
    if (!curso) return null;
    const nombre = (curso.nombre || '').trim().toLowerCase();
    return this.justificaciones().find(
      (j: any) =>
        (j.curso || '').trim().toLowerCase() === nombre &&
        String(j.estado || '').toUpperCase() === 'PENDIENTE'
    ) ?? null;
  });
  asistencia = computed(() => this.data()?.asistencia ?? null);

  porcentajeAsistencia = computed(() => {
    const asis = this.asistencia();
    if (!asis) return 92;
    if (asis.porcentajeAsistencia !== undefined) return asis.porcentajeAsistencia;
    const total = (asis.presente || 0) + (asis.falta || 0) + (asis.tardanza || 0);
    if (total === 0) return 100;
    return Math.round(((asis.presente || 0) / total) * 100);
  });

  porcentajeInasistencia = computed(() => {
    return Math.max(0, 100 - this.porcentajeAsistencia());
  });

  alertaPreventivaFaltas = computed(() => {
    // Aviso preventivo al llegar a 8% faltas
    return this.porcentajeInasistencia() >= 8 && this.porcentajeAsistencia() >= 85;
  });

  inhabilitadoPorInasistencia = computed(() => {
    // Si asistencia < 85%, baja e inhabilitación automática
    return this.porcentajeAsistencia() < 85;
  });

  proximaCuotaPendiente = computed(() => {
    const fin = this.planFinanciero();
    if (!fin || !fin.cuotas || fin.cuotas.length === 0) return null;
    return fin.cuotas.find((c: any) => c.estado !== 'PAGADO') || null;
  });

  ultimaCuotaPagada = computed(() => {
    const fin = this.planFinanciero();
    if (!fin || !fin.cuotas || fin.cuotas.length === 0) return null;
    const pagadas = fin.cuotas.filter((c: any) => c.estado === 'PAGADO');
    return pagadas.length > 0 ? pagadas[pagadas.length - 1] : null;
  });

  nombreMesActual = computed(() => {
    const prox = this.proximaCuotaPendiente();
    if (prox) {
      return this.obtenerMesDeCuota(prox);
    }
    const ult = this.ultimaCuotaPagada();
    if (ult) {
      return this.obtenerMesDeCuota(ult);
    }
    return 'Marzo';
  });

  mesActualPagado = computed(() => {
    const fin = this.planFinanciero();
    if (!fin) return true;
    const pagadasCount = (fin.cuotas || []).filter((c: any) => c.estado === 'PAGADO').length;
    return pagadasCount > 0 || (fin.deudaPendiente || 0) === 0;
  });

  promedio = computed(() => {
    const list = this.boletaCursos();
    const calificados = list
      .map((c: any) => c.final)
      .filter((n: any): n is number => typeof n === 'number');
    if (calificados.length > 0) {
      const sum = calificados.reduce((acc: number, n: number) => acc + n, 0);
      return Number((sum / calificados.length).toFixed(1));
    }
    const p = this.data()?.promedioPonderado;
    return p && p > 0 ? p : 0;
  });
  planFinanciero = computed(() => this.data()?.planFinanciero ?? this.alumno()?.planFinanciero ?? null);

  nombreCompleto = computed(() => {
    const a = this.alumno();
    if (!a) return 'Estudiante';
    return `${a.nombre} ${a.apellidoPaterno} ${a.apellidoMaterno ?? ''}`.trim();
  });

  esAprobado = computed(() => this.promedio() >= 11);

  ngOnInit(): void {
    this.route.queryParams.subscribe((params) => {
      const t = params['tab'];
      if (t && ['resumen', 'cursos', 'horario', 'academico', 'finanzas'].includes(t)) {
        this.tabActiva.set(t as any);
      } else {
        // Si no hay tab o es inválido, volver al resumen oficial
        this.tabActiva.set('resumen');
      }
    });

    this.cargarDatos();
  }

  cargarDatos(): void {
    this.loading.set(true);
    this.error.set(null);

    this.personalService.obtenerTodasLasPonderaciones().subscribe({
      next: (ponds) => {
        this.todasLasPonderaciones.set(ponds || []);
        this.sincronizarCursoDetalleDesdeBoleta();
      },
    });
    this.personalService.obtenerActividadesSesiones().subscribe({
      next: (acts) => {
        this.todasLasActividades.set(acts || []);
        this.sincronizarCursoDetalleDesdeBoleta();
      },
    });
    this.personalService.obtenerEntregasTareas().subscribe({
      next: (ents) => {
        this.todasLasEntregas.set(ents || []);
        this.sincronizarCursoDetalleDesdeBoleta();
      },
    });

    this.alumnoService.obtenerMiPerfil().subscribe({
      next: (res) => {
        this.data.set(res);
        if (res.cursos && res.cursos.length > 0 && !this.formJustificacion().curso) {
          this.formJustificacion.update((f) => ({
            ...f,
            curso: res.cursos[0].nombre,
            docenteId: (res.cursos[0] as any).docenteId || 1,
          }));
        }
        const actual = this.cursoDetalleActivo();
        if (actual) {
          const nombre = String(actual.nombre || '').trim().toLowerCase();
          const actualizado = this.boletaCursos().find(
            (c: any) => String(c.nombre || '').trim().toLowerCase() === nombre
          );
          if (actualizado) {
            this.cursoDetalleActivo.set(actualizado);
          }
        }
        this.loading.set(false);
      },
      error: (err) => {
        console.error('Error al cargar datos del alumno:', err);
        this.error.set('No se pudo cargar la información académica. Intente nuevamente.');
        this.loading.set(false);
      },
    });
  }

  // Métodos Justificación de Inasistencias
  abrirModalJustificar(cursoNombre?: string, docenteId?: number, hora?: string): void {
    const defaultCurso = cursoNombre || (this.cursos().length > 0 ? this.cursos()[0].nombre : 'Álgebra');
    const defaultDocente = docenteId || (this.cursos().length > 0 ? (this.cursos()[0] as any).docenteId : 1);
    this.formJustificacion.set({
      curso: defaultCurso,
      docenteId: defaultDocente,
      fechaInasistencia: new Date().toISOString().split('T')[0],
      horaClase: hora || '08:00 - 10:00',
      motivo: 'Salud / Cita Médica',
      descripcion: '',
      comprobanteNombre: 'certificado_medico_consulta.pdf',
    });
    this.mensajeJustificacion.set(null);
    this.mostrarModalJustificar.set(true);
  }

  cerrarModalJustificar(): void {
    this.mostrarModalJustificar.set(false);
  }

  enviarJustificacionWeb(): void {
    const a = this.alumno();
    if (!a) return;

    const f = this.formJustificacion();
    if (!f.curso || !f.fechaInasistencia || !f.descripcion.trim()) {
      this.mensajeJustificacion.set({
        tipo: 'error',
        texto: 'Por favor complete el curso, la fecha y el motivo o descripción detallada de la inasistencia.',
      });
      return;
    }

    this.enviandoJustificacion.set(true);
    this.mensajeJustificacion.set(null);

    this.alumnoService
      .enviarJustificacion({
        alumnoId: a.id,
        curso: f.curso,
        docenteId: f.docenteId,
        fechaInasistencia: f.fechaInasistencia,
        horaClase: f.horaClase,
        motivo: f.motivo,
        descripcion: f.descripcion.trim(),
        comprobanteNombre: f.comprobanteNombre,
      })
      .subscribe({
        next: (res) => {
          this.enviandoJustificacion.set(false);
          this.mostrarModalJustificar.set(false);
          this.mensajeJustificacion.set({
            tipo: 'success',
            texto: res.mensaje || 'Justificación enviada al profesor con éxito! Podrás ver la respuesta en tu historial.',
          });
          // Recargar perfil para ver la justificación en la lista
          this.cargarDatos();
        },
        error: (err) => {
          this.enviandoJustificacion.set(false);
          this.mensajeJustificacion.set({
            tipo: 'error',
            texto: err.error?.message || 'Error al enviar la justificación. Intente nuevamente.',
          });
        },
      });
  }

  cuotaMesActual(): any | null {
    return this.proximaCuotaPendiente();
  }

  pagarCuotaMesActual(): void {
    const cuota = this.proximaCuotaPendiente();
    if (cuota) {
      this.pagarCuota(cuota.numero);
    }
  }

  pagarSiguienteCuota(): void {
    const pendiente = this.proximaCuotaPendiente();
    if (pendiente) {
      this.pagarCuota(pendiente.numero);
    }
  }

  pagarCuota(cuotaNumero: number): void {
    const a = this.alumno();
    if (!a) return;

    this.pagandoCuota.set(cuotaNumero);
    this.mensajeFinanzas.set(null);

    this.alumnoService.pagarCuota(a.id, cuotaNumero).subscribe({
      next: (res) => {
        this.pagandoCuota.set(null);
        // Actualizar el plan financiero local
        if (this.data()) {
          const current = this.data()!;
          this.data.set({
            ...current,
            planFinanciero: res.planFinanciero,
          });
        }

        this.mensajeFinanzas.set({
          tipo: 'success',
          texto: `Pago de la cuota #${cuotaNumero} procesado correctamente! Se redujo el saldo de deuda pendiente.`,
        });

        // Mostrar comprobante
        this.reciboModal.set({
          numero: res.cuota.numero,
          concepto: res.cuota.concepto,
          monto: res.cuota.monto,
          fechaPago: res.cuota.fechaPago || new Date().toISOString().split('T')[0],
          numeroOperacion: res.cuota.numeroOperacion || `REC-2026-${cuotaNumero}`,
          alumno: this.nombreCompleto(),
          dni: a.dni,
        });
      },
      error: (err) => {
        this.pagandoCuota.set(null);
        this.mensajeFinanzas.set({
          tipo: 'error',
          texto: err.error?.message || 'Error al procesar el pago de la pensión.',
        });
      },
    });
  }

  verRecibo(cuota: any): void {
    const a = this.alumno();
    if (!a) return;

    this.reciboModal.set({
      numero: cuota.numero,
      concepto: cuota.concepto,
      monto: cuota.monto,
      fechaPago: cuota.fechaPago || '2026-03-10',
      numeroOperacion: cuota.numeroOperacion || `REC-2026-${cuota.numero}`,
      alumno: this.nombreCompleto(),
      dni: a.dni,
    });
  }

  cerrarRecibo(): void {
    this.reciboModal.set(null);
  }

  abrirPasarelaPago(monto?: number): void {
    if (monto) this.montoPagoSimulado.set(monto);
    this.modalPasarelaPago.set(true);
  }

  procesarPagoPasarela(): void {
    this.pagandoPasarela.set(true);
    setTimeout(() => {
      this.pagandoPasarela.set(false);
      this.modalPasarelaPago.set(false);
      
      if (this.data()) {
        const cur = this.data()!;
        if (cur.planFinanciero) {
          const nuevaDeuda = Math.max(0, (cur.planFinanciero.deudaPendiente || 350) - this.montoPagoSimulado());
          this.data.set({
            ...cur,
            planFinanciero: {
              ...cur.planFinanciero,
              deudaPendiente: nuevaDeuda,
            },
          });
        }
      }

      this.mensajeFinanzas.set({
        tipo: 'success',
        texto: `Pago de S/ ${this.montoPagoSimulado()} procesado con éxito vía ${this.metodoPagoSeleccionado()}! Tu saldo se ha actualizado.`,
      });
      setTimeout(() => this.mensajeFinanzas.set(null), 5000);
    }, 1200);
  }

  imprimirBoleta(): void {
    window.print();
  }
}

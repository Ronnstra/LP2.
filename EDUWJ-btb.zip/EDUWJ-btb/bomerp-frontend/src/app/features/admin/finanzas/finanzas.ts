import { Component, signal, computed, inject, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { PersonalService, FinanzasResumen } from '../../../core/services';

@Component({
  selector: 'app-admin-finanzas',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './finanzas.html',
  styleUrl: './finanzas.css',
})
export class AdminFinanzasComponent implements OnInit {
  private personalService = inject(PersonalService);

  finanzas = signal<FinanzasResumen | null>(null);
  loading = signal(true);

  // Filtros de Ingresos Académicos por Año Real y Grados
  anioSeleccionado = signal<number>(2026);
  gradoSeleccionado = signal<string>('TODOS');
  gradosDisponibles = ['TODOS', '1° Secundaria', '2° Secundaria', '3° Secundaria', '4° Secundaria', '5° Secundaria'];

  // Edición de sueldo de colaborador
  mostrarModalSueldo = signal(false);
  colaboradorEditando = signal<{ id: number; nombre: string; cargo: string; sueldo: number } | null>(null);
  guardandoSueldo = signal(false);
  mensajeSueldo = signal<string | null>(null);

  // Control de Reinicio y Pruebas Desde Cero
  mostrarModalReset = signal(false);
  modoReset = signal<'limpio' | 'demo'>('limpio');
  ejecutandoReset = signal(false);
  mensajeReset = signal<{ tipo: 'success' | 'error'; texto: string } | null>(null);

  aniosDisponibles = computed(() => {
    const f = this.finanzas();
    return f?.ingresosAcademicos?.aniosDisponibles || [2026];
  });

  alumnosFiltradosPorGrado = computed(() => {
    const f = this.finanzas();
    const g = this.gradoSeleccionado();
    const list = f?.alumnosDeudores || [];
    if (g === 'TODOS') return list;
    return list.filter((a) => a.grado === g);
  });

  totalContratadoFiltrado = computed(() => {
    return this.alumnosFiltradosPorGrado().reduce((sum, a) => sum + a.totalContratado, 0);
  });

  totalPagadoFiltrado = computed(() => {
    return this.alumnosFiltradosPorGrado().reduce((sum, a) => sum + a.totalPagado, 0);
  });

  totalDeudaFiltrada = computed(() => {
    return this.alumnosFiltradosPorGrado().reduce((sum, a) => sum + a.deudaPendiente, 0);
  });

  ngOnInit(): void {
    this.cargarFinanzas();
  }

  cargarFinanzas(): void {
    this.loading.set(true);
    this.personalService.obtenerFinanzas().subscribe({
      next: (data) => {
        this.finanzas.set(data);
        this.loading.set(false);
      },
      error: () => {
        this.loading.set(false);
      },
    });
  }

  abrirModalReset(modo: 'limpio' | 'demo'): void {
    this.modoReset.set(modo);
    this.mostrarModalReset.set(true);
  }

  cerrarModalReset(): void {
    this.mostrarModalReset.set(false);
  }

  ejecutarReset(): void {
    this.ejecutandoReset.set(true);
    const modo = this.modoReset();
    this.personalService.resetearSistema(modo).subscribe({
      next: (resp) => {
        this.ejecutandoReset.set(false);
        this.mostrarModalReset.set(false);
        this.mensajeReset.set({
          tipo: 'success',
          texto: resp.mensaje || (modo === 'limpio' ? 'Base de datos reiniciada a cero con éxito.' : 'Datos de demostración restaurados.'),
        });
        this.cargarFinanzas();
        setTimeout(() => this.mensajeReset.set(null), 6000);
      },
      error: () => {
        this.ejecutandoReset.set(false);
        this.mensajeReset.set({
          tipo: 'error',
          texto: 'Ocurrió un error al reiniciar la base de datos.',
        });
      },
    });
  }

  abrirEditarSueldo(colab: { id: number; nombre: string; cargo: string; sueldoMensual: number }): void {
    this.colaboradorEditando.set({
      id: colab.id,
      nombre: colab.nombre,
      cargo: colab.cargo,
      sueldo: colab.sueldoMensual || 2000,
    });
    this.mensajeSueldo.set(null);
    this.mostrarModalSueldo.set(true);
  }

  cerrarModalSueldo(): void {
    this.mostrarModalSueldo.set(false);
    this.colaboradorEditando.set(null);
  }

  guardarSueldoEditado(): void {
    const colab = this.colaboradorEditando();
    if (!colab) return;
    this.guardandoSueldo.set(true);
    this.personalService.renovarContrato(colab.id, { nuevoSueldo: colab.sueldo }).subscribe({
      next: () => {
        this.guardandoSueldo.set(false);
        this.cerrarModalSueldo();
        this.cargarFinanzas();
      },
      error: () => {
        this.guardandoSueldo.set(false);
        this.mensajeSueldo.set('Error al actualizar remuneración.');
      },
    });
  }
}

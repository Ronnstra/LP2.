import { Component, signal, computed, inject, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { PersonalService, AlumnoService, PersonalEscolar, AlumnoResponse } from '../../../core/services';

@Component({
  selector: 'app-admin-aprobaciones',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './aprobaciones.html',
  styleUrl: './aprobaciones.css',
})
export class AdminAprobacionesComponent implements OnInit {
  private personalService = inject(PersonalService);
  private alumnoService = inject(AlumnoService);

  tabActiva = signal<'todos' | 'alumnos' | 'personal'>('todos');

  personalPendiente = signal<PersonalEscolar[]>([]);
  alumnosPendientes = signal<AlumnoResponse[]>([]);
  loading = signal(true);
  mensaje = signal<{ tipo: 'success' | 'error'; texto: string } | null>(null);

  totalUrgentes = computed(() => {
    const urgAlumnos = this.alumnosPendientes().filter((a) => (a.diasDesdeRegistro ?? 0) >= 14).length;
    const urgPersonal = this.personalPendiente().filter((p) => p.diasPendiente >= 14).length;
    return urgAlumnos + urgPersonal;
  });

  totalPendientes = computed(() => this.alumnosPendientes().length + this.personalPendiente().length);

  ngOnInit(): void {
    this.cargarDatos();
  }

  cargarDatos(): void {
    this.loading.set(true);

    this.personalService.listar(undefined, 'PENDIENTE').subscribe({
      next: (dataPersonal) => {
        this.personalPendiente.set(dataPersonal);
        this.alumnoService.obtenerPendientes().subscribe({
          next: (dataAlumnos) => {
            this.alumnosPendientes.set(dataAlumnos);
            this.loading.set(false);
          },
          error: () => this.loading.set(false),
        });
      },
      error: () => this.loading.set(false),
    });
  }

  confirmarAlumno(alumno: AlumnoResponse): void {
    this.alumnoService.confirmar(alumno.id).subscribe({
      next: (res) => {
        this.mensaje.set({
          tipo: 'success',
          texto: res.mensaje || `Matrícula de ${alumno.nombre} ${alumno.apellidoPaterno} confirmada! Su cuenta institucional ha sido activada y retirada del estado de pausa.`,
        });
        this.cargarDatos();
      },
      error: () => {
        this.mensaje.set({ tipo: 'error', texto: 'No se pudo confirmar la matrícula del estudiante.' });
      },
    });
  }

  confirmarPersonal(persona: PersonalEscolar): void {
    this.personalService.confirmar(persona.id).subscribe({
      next: () => {
        this.mensaje.set({
          tipo: 'success',
          texto: `Alta confirmada exitosamente! ${persona.nombre} ${persona.apellidos} (${persona.cargo}) cuenta ahora con usuario activo.`,
        });
        this.cargarDatos();
      },
      error: () => {
        this.mensaje.set({ tipo: 'error', texto: 'No se pudo confirmar el alta. Intente nuevamente.' });
      },
    });
  }

  rechazarPersonal(persona: PersonalEscolar): void {
    this.personalService.rechazar(persona.id, 'Observado y rechazado por Dirección General').subscribe({
      next: () => {
        this.mensaje.set({
          tipo: 'success',
          texto: `El reporte de alta para ${persona.nombre} ${persona.apellidos} ha sido rechazado/observado.`,
        });
        this.cargarDatos();
      },
      error: () => {
        this.mensaje.set({ tipo: 'error', texto: 'No se pudo rechazar la solicitud.' });
      },
    });
  }
}

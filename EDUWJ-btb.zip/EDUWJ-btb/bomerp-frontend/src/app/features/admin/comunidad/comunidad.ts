import { Component, signal, computed, inject, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { ActivatedRoute, Router, RouterModule } from '@angular/router';
import {
  AlumnoService,
  PersonalService,
  AuthService,
  AlumnoResponse,
  PersonalEscolar,
  CargoPersonal,
  TurnoPersonal,
  BloqueHorario,
} from '../../../core/services';
import { UsuarioEscolar } from '../../../core/models';

export type TabComunidad =
  | 'mi-portal'
  | 'mi-colegio'
  | 'cuentas'
  | 'estudiantes'
  | 'docentes'
  | 'colaboradores'
  | 'horarios'
  | 'cursos'
  | 'comunicados'
  | 'mi-suscripcion';

export interface CursoItem {
  id: number;
  codigo: string;
  nombre: string;
  area: string;
  grado: string;
  docenteAsignado: string;
  horasSemanales: number;
  aula: string;
}

export interface ComunicadoItem {
  id: number;
  titulo: string;
  contenido: string;
  dirigidoA: string;
  fecha: string;
  urgente: boolean;
  autor: string;
}

@Component({
  selector: 'app-admin-comunidad',
  standalone: true,
  imports: [CommonModule, FormsModule, RouterModule],
  templateUrl: './comunidad.html',
  styleUrl: './comunidad.css',
})
export class AdminComunidadComponent implements OnInit {
  private alumnoService = inject(AlumnoService);
  private personalService = inject(PersonalService);
  private authService = inject(AuthService);
  private route = inject(ActivatedRoute);
  private router = inject(Router);

  tabActiva = signal<TabComunidad>('mi-portal');

  // Filtro de búsqueda transversal
  filtroTexto = signal('');

  // Filtros específicos por sección
  filtroGradoEstudiante = signal<string>('TODOS');
  filtroAreaDocente = signal<string>('TODOS');
  filtroCargoColaborador = signal<string>('TODOS');
  filtroGradoHorario = signal<string>('TODOS');
  filtroAreaCurso = signal<string>('TODOS');

  // Datos principales
  usuarios = signal<UsuarioEscolar[]>([]);
  alumnos = signal<AlumnoResponse[]>([]);
  personal = signal<PersonalEscolar[]>([]);
  horarios = signal<BloqueHorario[]>([]);
  miColegio = signal<any | null>(null);
  urlCopiada = signal(false);
  loading = signal(true);
  notificacionGlobal = signal<string | null>(null);

  // Cursos institucionales reales (inicia 100% en cero sin docentes ni cursos ficticios)
  cursos = signal<CursoItem[]>([]);

  // Comunicados oficiales de Dirección (inicia 100% en cero)
  comunicados = signal<ComunicadoItem[]>([]);

  // Estado de la Escuela: Fondos, Suscripción SaaS y Gastos (inicia limpio)
  fondosEscuela = signal<number>(0);
  mesPagoSaaS = signal<number>(1);
  mesesAdelantarSaaS = signal<number>(1);
  totalPensionesCobradasSaaS = signal<number>(0);
  totalPagadoSaaS = signal<number>(0);
  suscripcionSaaS = signal<any | null>(null);
  simuladorMesSuscripcion = signal<number>(1);
  simuladorPagoPuntual = signal<boolean>(true);
  procesandoPagoSaaS = signal(false);
  mensajePagoSaaS = signal<{ tipo: 'success' | 'error'; texto: string } | null>(null);

  // Gastos Institucionales reales (inicia 100% en cero)
  gastosEscuela = signal<{ id: number; concepto: string; fecha: string; monto: number; categoria: string; numeroOperacion?: string }[]>([]);

  // Configuración de Duración del Año Escolar Oficial
  fechaInicioAnual = signal<string>('2026-02-15');
  fechaFinAnual = signal<string>('2026-12-05');
  duracionMesesAnual = signal<number>(10);
  semanasLectivasAnual = signal<number>(42);
  mensajeCalendario = signal<{ tipo: 'success' | 'error'; texto: string } | null>(null);
  guardandoCalendario = signal(false);

  // Modal de Login en Pantalla Completa para Institución ("Ver Cole")
  mostrarLoginInstitucional = signal(false);
  loginEstudianteInput = signal({ username: '', password: '' });
  mensajeLoginInstitucional = signal<string | null>(null);

  abrirLoginInstitucional(): void {
    this.loginEstudianteInput.set({ username: '', password: '' });
    this.mensajeLoginInstitucional.set(null);
    this.mostrarLoginInstitucional.set(true);
  }

  cerrarLoginInstitucional(): void {
    this.mostrarLoginInstitucional.set(false);
  }

  ejecutarLoginInstitucional(): void {
    const input = this.loginEstudianteInput();
    const u = input.username.trim();
    const p = input.password.trim();

    if (!u || !p) {
      this.mensajeLoginInstitucional.set('Ingrese su usuario/correo y contraseña para ingresar.');
      return;
    }

    this.mensajeLoginInstitucional.set('Verificando credenciales institucionales...');

    this.authService.login({
      username: u,
      password: p,
      ...(this.miColegio()?.slug ? { slugColegio: this.miColegio().slug } : {}),
    }).subscribe({
      next: (res) => {
        this.mostrarLoginInstitucional.set(false);
        const defaultRoute = this.authService.getDefaultRoute();
        this.router.navigate([defaultRoute]);
      },
      error: (err) => {
        this.mensajeLoginInstitucional.set(
          err.error?.mensaje || 'Credenciales inválidas. Verifique que la cuenta esté registrada en este colegio.'
        );
      },
    });
  }

  siguienteMesSaaS = computed(() => this.mesPagoSaaS() + 1);

  mesHastaSeleccionado = computed(() => this.siguienteMesSaaS() + this.mesesAdelantarSaaS() - 1);

  montoSiguienteMes = computed(() => {
    return this.calcularCuotaDashboard(this.siguienteMesSaaS(), true);
  });

  montoPagoSeleccionado = computed(() => {
    return this.calcularMontoMeses(this.siguienteMesSaaS(), this.mesesAdelantarSaaS());
  });

  calcularMontoMeses(desde: number, cantidad: number): number {
    let total = 0;
    for (let i = 0; i < cantidad; i++) {
      total += this.calcularCuotaDashboard(desde + i, true);
    }
    return Math.round(total * 100) / 100;
  }

  // CONFIGURACIÓN PERSONALIZABLE DE CUENTAS BANCARIAS Y YAPE
  configCuentasBancarias = signal({
    titular: 'Jimy Amanqui',
    ruc: '10716758369',
    numeroYape: '987 654 321',
    titularYape: 'Jimy Amanqui',
    bcpCuenta: '193-9823014-0-91',
    bcpCci: '002-19300982301409112',
    bbvaCuenta: '0011-0182-0100084721',
    bbvaCci: '011-18200010008472190',
  });

  mostrarModalEditarCuentas = signal(false);
  formEditarCuentas = signal({
    titular: 'Jimy Amanqui',
    ruc: '10716758369',
    numeroYape: '987 654 321',
    titularYape: 'Jimy Amanqui',
    bcpCuenta: '193-9823014-0-91',
    bcpCci: '002-19300982301409112',
    bbvaCuenta: '0011-0182-0100084721',
    bbvaCci: '011-18200010008472190',
  });

  abrirModalEditarCuentas(): void {
    const actual = this.configCuentasBancarias();
    const currentUser = this.authService.getCurrentUser();
    this.formEditarCuentas.set({
      ...actual,
      titular: actual.titular || currentUser?.nombreCompleto || 'Jimy Amanqui',
      titularYape: actual.titularYape || currentUser?.nombreCompleto || 'Jimy Amanqui',
    });
    this.mostrarModalEditarCuentas.set(true);
  }

  cerrarModalEditarCuentas(): void {
    this.mostrarModalEditarCuentas.set(false);
  }

  guardarCuentasBancarias(): void {
    const f = this.formEditarCuentas();
    this.configCuentasBancarias.set({ ...f });
    this.mostrarModalEditarCuentas.set(false);
    this.notificacionGlobal.set('✓ ¡Tus cuentas bancarias y número de Yape reales han sido actualizados correctamente!');
  }

  // Modal y Proceso de Pago Real (Depósito / Yape / Transferencia / Tarjeta)
  mostrarModalProcesarPago = signal(false);
  metodoPagoSeleccionado = signal<'TRANSFERENCIA' | 'YAPE' | 'TARJETA'>('TRANSFERENCIA');
  bancoSeleccionado = signal<'BCP' | 'BBVA' | 'INTERBANK'>('BCP');
  numeroOperacionInput = signal('');
  voucherNombreArchivo = signal<string | null>(null);
  constanciaUltimoPago = signal<any | null>(null);

  abrirModalPagoSaaS(): void {
    this.mesesAdelantarSaaS.set(1);
    this.numeroOperacionInput.set('');
    this.voucherNombreArchivo.set(null);
    this.mensajePagoSaaS.set(null);
    this.mostrarModalProcesarPago.set(true);
  }

  cerrarModalPagoSaaS(): void {
    this.mostrarModalProcesarPago.set(false);
  }

  seleccionarMesesSaaS(meses: number): void {
    this.mesesAdelantarSaaS.set(meses);
    this.numeroOperacionInput.set('');
    this.voucherNombreArchivo.set(null);
    this.mensajePagoSaaS.set(null);
  }

  simularSeleccionVoucher(event: any): void {
    const file = event.target.files?.[0];
    if (file) {
      this.voucherNombreArchivo.set(file.name);
    } else {
      this.voucherNombreArchivo.set('voucher_deposito_bancario_2026.pdf');
    }
  }

  aplicarSuscripcion(s: any): void {
    if (!s) return;
    this.suscripcionSaaS.set(s);
    this.miColegio.set(s);
    this.mesPagoSaaS.set(Number(s.mesActivo ?? s.mesesActivo ?? 1));
    this.fondosEscuela.set(Number(s.fondosDisponibles ?? 0));
    this.totalPensionesCobradasSaaS.set(Number(s.totalPensionesCobradas ?? 0));
    this.totalPagadoSaaS.set(Number(s.totalPagadoSaaS ?? 0));
    this.gastosEscuela.set((s.pagos || []).map((p: any) => this.mapearGastoPago(p)));
  }

  mapearGastoPago(p: any): { id: number; concepto: string; fecha: string; monto: number; categoria: string; numeroOperacion?: string } {
    const rango = p.mesDesde === p.mesHasta ? `Mes ${p.mesDesde}` : `Meses ${p.mesDesde} a ${p.mesHasta}`;
    return {
      id: Number(p.id ?? Date.now()),
      concepto: `Pago Cuota SaaS ERP - ${rango} (${p.metodoPago || 'Pago'} N° Op: ${p.numeroOperacion || 'S/N'})`,
      fecha: p.fechaPago || p.fechaHora || '',
      monto: Number(p.monto ?? 0),
      categoria: 'SaaS / Tecnología',
      numeroOperacion: p.numeroOperacion,
    };
  }

  ejecutarPagoConComprobanteReal(): void {
    const monto = this.montoPagoSeleccionado();
    const fondosActuales = this.fondosEscuela();
    const numOp = this.numeroOperacionInput().trim();
    const metodo = this.metodoPagoSeleccionado();
    const colegioId = this.suscripcionSaaS()?.id ?? this.miColegio()?.id ?? this.authService.getCurrentUser()?.colegioId;

    if (!colegioId) {
      this.mensajePagoSaaS.set({
        tipo: 'error',
        texto: 'No se pudo identificar el colegio de la suscripción. Vuelva a iniciar sesión.',
      });
      return;
    }

    if (metodo !== 'TARJETA' && (!numOp || numOp.length < 5)) {
      this.mensajePagoSaaS.set({
        tipo: 'error',
        texto: 'Por favor ingrese un Número de Operación o Código de Voucher válido (mínimo 5 caracteres).',
      });
      return;
    }

    if (fondosActuales < monto) {
      this.mensajePagoSaaS.set({
        tipo: 'error',
        texto: `Fondos insuficientes en la caja de la escuela. Se requiere S/ ${monto.toFixed(2)}, dispone de S/ ${fondosActuales.toFixed(2)}.`,
      });
      return;
    }

    this.procesandoPagoSaaS.set(true);
    this.mensajePagoSaaS.set(null);

    const banco = metodo === 'TRANSFERENCIA'
      ? this.bancoSeleccionado()
      : metodo === 'YAPE'
        ? 'Yape / Plin'
        : 'Visa/Mastercard';

    this.authService.pagarSuscripcionSaaS({
      colegioId,
      mesesAdelantar: this.mesesAdelantarSaaS(),
      metodoPago: metodo,
      banco,
      numeroOperacion: numOp || undefined,
      voucherNombre: this.voucherNombreArchivo() || undefined,
    }).subscribe({
      next: (res) => {
        this.procesandoPagoSaaS.set(false);
        this.mostrarModalProcesarPago.set(false);
        if (res?.suscripcion) {
          this.aplicarSuscripcion(res.suscripcion);
        }
        if (res?.pago) {
          this.constanciaUltimoPago.set({
            ...res.pago,
            institucion: this.nombreInstitucion(),
            fechaHora: res.pago.fechaHora || res.pago.fechaPago,
            voucherArchivo: res.pago.voucherNombre || 'voucher_registrado.pdf',
          });
        }
        this.mensajePagoSaaS.set({
          tipo: 'success',
          texto: res?.mensaje || `Pago confirmado. Se descontaron S/ ${monto.toFixed(2)} de la caja de la escuela.`,
        });
      },
      error: (err) => {
        this.procesandoPagoSaaS.set(false);
        this.mensajePagoSaaS.set({
          tipo: 'error',
          texto: err.error?.mensaje || err.error?.message || 'No se pudo registrar el pago de la suscripción. Intente nuevamente.',
        });
      },
    });
  }

  pagarMensualidadSaaS(): void {
    this.abrirModalPagoSaaS();
  }

  calcularCuotaDashboard(mes: number, puntual: boolean): number {
    if (!puntual) return 1000;
    if (mes <= 1) return 1000;
    if (mes === 2) return 930;
    if (mes <= 4) return 860;
    return 700;
  }

  navegarTab(tab: TabComunidad): void {
    this.tabActiva.set(tab);
    // Limpia filtro de texto al cambiar de módulo para ver lista limpia
    this.filtroTexto.set('');
    this.router.navigate([], {
      relativeTo: this.route,
      queryParams: { tab },
      queryParamsHandling: 'merge',
    });
  }

  getTituloModuloActivo(): string {
    switch (this.tabActiva()) {
      case 'estudiantes': return 'Estudiantes & Matrícula Escolar';
      case 'cursos': return 'Cursos & Malla Curricular';
      case 'docentes': return 'Plana Docente Institucional';
      case 'colaboradores': return 'Colaboradores & Personal de Apoyo';
      case 'cuentas': return 'Cuentas & Credenciales de Acceso';
      case 'horarios': return 'Horarios Escolares & Grillas';
      case 'comunicados': return 'Cartelera de Comunicados Oficiales';
      case 'mi-suscripcion': return 'Mi Suscripción Escolar & Cuotas';
      case 'mi-colegio': return 'Mi Portal Web Institucional';
      case 'mi-portal':
      default: return 'Centro de Control General de Dirección';
    }
  }

  getIconoModuloActivo(): string {
    switch (this.tabActiva()) {
      case 'estudiantes': return '🧑‍🎓';
      case 'cursos': return '📚';
      case 'docentes': return '👨‍🏫';
      case 'colaboradores': return '👥';
      case 'cuentas': return '🛡️';
      case 'horarios': return '📅';
      case 'comunicados': return '📢';
      case 'mi-suscripcion': return '💳';
      case 'mi-colegio': return '🏫';
      case 'mi-portal':
      default: return '🏢';
    }
  }

  getGrupoModuloActivo(): string {
    switch (this.tabActiva()) {
      case 'estudiantes':
      case 'cursos':
        return 'Plantel Estudiantil';
      case 'docentes':
      case 'colaboradores':
      case 'cuentas':
        return 'Personal & Equipo';
      case 'horarios':
      case 'comunicados':
        return 'Planificación & Agenda';
      case 'mi-suscripcion':
        return 'Gestión & Finanzas';
      case 'mi-colegio':
      case 'mi-portal':
      default:
        return 'Dirección & Portal';
    }
  }

  nombreInstitucion = computed(() => {
    const col = this.miColegio();
    if (col?.nombreColegio) return col.nombreColegio;
    const current = this.authService.getCurrentUser();
    return current?.nombreColegio || 'Institución Educativa Oficial';
  });

  slugInstitucion = computed(() => {
    const col = this.miColegio();
    if (col?.slug) return col.slug;
    const current = this.authService.getCurrentUser();
    if (current?.slugColegio) return current.slugColegio;
    return (
      this.nombreInstitucion()
        .normalize('NFD')
        .replace(/[\u0300-\u036f]/g, '')
        .toLowerCase()
        .replace(/[^a-z0-9]+/g, '-')
        .replace(/^-+|-+$/g, '') || 'mi-colegio'
    );
  });

  urlInstitucionalColegio = computed(() => {
    const origin = typeof window !== 'undefined' ? window.location.origin : '';
    return `${origin}/colegio/${this.slugInstitucion()}`;
  });

  // Modal para nueva cuenta (Secretario/a / General)
  mostrarModalCuenta = signal(false);
  guardandoCuenta = signal(false);
  mensajeModalCuenta = signal<string | null>(null);

  formCuenta = signal({
    nombreCompleto: '',
    username: '',
    password: '',
    rol: 'SECRETARIA' as 'SECRETARIA' | 'DOCENTE' | 'ALUMNO' | 'COLABORADOR',
    cargo: 'Secretaria General y Académica',
    email: '',
    dni: '',
    telefono: '',
    turno: 'COMPLETO' as TurnoPersonal,
    sueldoMensual: 1800,
  });

  // Modal para nuevo personal general
  mostrarModalPersonal = signal(false);
  guardandoPersonal = signal(false);
  mensajeModalPersonal = signal<string | null>(null);

  formPersonal = signal({
    nombre: '',
    apellidos: '',
    dni: '',
    cargo: 'DOCENTE' as CargoPersonal,
    area: '',
    telefono: '',
    turno: 'MAÑANA' as TurnoPersonal,
  });

  // Modal para nuevo estudiante
  mostrarModalEstudiante = signal(false);
  guardandoEstudiante = signal(false);
  mensajeModalEstudiante = signal<string | null>(null);

  formEstudiante = signal({
    nombre: '',
    apellidoPaterno: '',
    apellidoMaterno: '',
    dni: '',
    grado: '1° Secundaria',
    seccion: 'A',
    telefono: '',
  });

  // Modal para nuevo comunicado
  mostrarModalComunicado = signal(false);
  formComunicado = signal({
    titulo: '',
    contenido: '',
    dirigidoA: 'Toda la Comunidad',
    urgente: false,
  });

  // Modal para Mostrar Credenciales Generadas (Usuario y Contraseña)
  mostrarModalCredenciales = signal(false);
  copiaExitosa = signal(false);
  dataCredencialesGeneradas = signal<{
    titulo: string;
    nombreCompleto: string;
    cargo: string;
    username: string;
    password: string;
    dni: string;
    email: string;
    notaInfo: string;
  } | null>(null);

  // Computados
  secretarias = computed(() => this.usuarios().filter((u) => u.rol === 'SECRETARIA'));
  docentes = computed(() => this.personal().filter((p) => p.cargo === 'DOCENTE'));
  colaboradores = computed(() => this.personal().filter((p) => p.cargo !== 'DOCENTE'));

  usuariosFiltrados = computed(() => {
    const q = this.filtroTexto().trim().toLowerCase();
    if (!q) return this.usuarios();
    return this.usuarios().filter(
      (u) =>
        (u.nombreCompleto && u.nombreCompleto.toLowerCase().includes(q)) ||
        (u.username && u.username.toLowerCase().includes(q)) ||
        (u.email && u.email.toLowerCase().includes(q)) ||
        (u.rol && u.rol.toLowerCase().includes(q))
    );
  });

  alumnosFiltrados = computed(() => {
    let lista = this.alumnos();
    if (this.filtroGradoEstudiante() !== 'TODOS') {
      lista = lista.filter((a) => a.grado === this.filtroGradoEstudiante());
    }
    const q = this.filtroTexto().trim().toLowerCase();
    if (!q) return lista;
    return lista.filter(
      (a) =>
        (a.nombre && a.nombre.toLowerCase().includes(q)) ||
        (a.apellidoPaterno && a.apellidoPaterno.toLowerCase().includes(q)) ||
        (a.apellidoMaterno && a.apellidoMaterno.toLowerCase().includes(q)) ||
        (a.dni && a.dni.toLowerCase().includes(q)) ||
        (a.grado && a.grado.toLowerCase().includes(q))
    );
  });

  docentesFiltrados = computed(() => {
    let lista = this.docentes();
    if (this.filtroAreaDocente() !== 'TODOS') {
      lista = lista.filter((d) => d.area === this.filtroAreaDocente());
    }
    const q = this.filtroTexto().trim().toLowerCase();
    if (!q) return lista;
    return lista.filter(
      (d) =>
        (d.nombre && d.nombre.toLowerCase().includes(q)) ||
        (d.apellidos && d.apellidos.toLowerCase().includes(q)) ||
        (d.dni && d.dni.toLowerCase().includes(q)) ||
        (d.area && d.area.toLowerCase().includes(q))
    );
  });

  colaboradoresFiltrados = computed(() => {
    let lista = this.colaboradores();
    if (this.filtroCargoColaborador() !== 'TODOS') {
      lista = lista.filter((c) => c.cargo === this.filtroCargoColaborador());
    }
    const q = this.filtroTexto().trim().toLowerCase();
    if (!q) return lista;
    return lista.filter(
      (c) =>
        (c.nombre && c.nombre.toLowerCase().includes(q)) ||
        (c.apellidos && c.apellidos.toLowerCase().includes(q)) ||
        (c.cargo && c.cargo.toLowerCase().includes(q)) ||
        (c.dni && c.dni.toLowerCase().includes(q))
    );
  });

  horariosFiltrados = computed(() => {
    let lista = this.horarios();
    if (this.filtroGradoHorario() !== 'TODOS') {
      lista = lista.filter((h) => h.grado === this.filtroGradoHorario());
    }
    const q = this.filtroTexto().trim().toLowerCase();
    if (!q) return lista;
    return lista.filter(
      (h) =>
        (h.curso && h.curso.toLowerCase().includes(q)) ||
        (h.aula && h.aula.toLowerCase().includes(q)) ||
        (h.dia && h.dia.toLowerCase().includes(q))
    );
  });

  cursosFiltrados = computed(() => {
    let lista = this.cursos();
    if (this.filtroAreaCurso() !== 'TODOS') {
      lista = lista.filter((c) => c.area === this.filtroAreaCurso());
    }
    const q = this.filtroTexto().trim().toLowerCase();
    if (!q) return lista;
    return lista.filter(
      (c) =>
        (c.nombre && c.nombre.toLowerCase().includes(q)) ||
        (c.codigo && c.codigo.toLowerCase().includes(q)) ||
        (c.docenteAsignado && c.docenteAsignado.toLowerCase().includes(q)) ||
        (c.area && c.area.toLowerCase().includes(q))
    );
  });

  comunicadosFiltrados = computed(() => {
    const q = this.filtroTexto().trim().toLowerCase();
    if (!q) return this.comunicados();
    return this.comunicados().filter(
      (c) =>
        (c.titulo && c.titulo.toLowerCase().includes(q)) ||
        (c.contenido && c.contenido.toLowerCase().includes(q)) ||
        (c.dirigidoA && c.dirigidoA.toLowerCase().includes(q))
    );
  });

  totalHorariosConfirmados = computed(() => this.horarios().filter((h) => h.confirmado !== false).length);

  ngOnInit(): void {
    this.route.queryParams.subscribe((params) => {
      const validTabs: TabComunidad[] = [
        'mi-portal',
        'mi-colegio',
        'cuentas',
        'estudiantes',
        'docentes',
        'colaboradores',
        'horarios',
        'cursos',
        'comunicados',
        'mi-suscripcion',
      ];
      if (params['tab'] && validTabs.includes(params['tab'])) {
        this.tabActiva.set(params['tab']);
      }

      // Soporte para acciones directas desde el menú lateral
      if (params['action']) {
        if (params['action'] === 'nuevo-alumno') {
          setTimeout(() => this.abrirModalEstudiante(), 50);
        } else if (params['action'] === 'nueva-cuenta') {
          setTimeout(() => this.abrirModalSecretaria(), 50);
        } else if (params['action'] === 'nuevo-personal') {
          setTimeout(() => this.abrirModalNuevoPersonal('DOCENTE'), 50);
        } else if (params['action'] === 'nuevo-comunicado') {
          setTimeout(() => this.abrirModalComunicado(), 50);
        }
      }
    });

    this.cargarDatos();
  }

  cargarDatos(): void {
    this.loading.set(true);
    const currentUser = this.authService.getCurrentUser();
    const cid = currentUser?.colegioId;

    // Cargar información real del colegio, fondos de pensiones y pagos SaaS
    this.authService.obtenerMiSuscripcion(cid, currentUser?.username).subscribe({
      next: (res) => {
        if (res?.suscripcion) {
          this.aplicarSuscripcion(res.suscripcion);
        }
      },
      error: () => {},
    });

    this.cargarCalendarioAnual();

    // Cargar Usuarios / Cuentas del colegio (EXCLUYENDO SIEMPRE AL ADMIN MAESTRO DEL SAAS)
    this.authService.listarUsuarios(cid).subscribe({
      next: (dataUsuarios) => {
        const soloEscolares = (dataUsuarios || []).filter(
          (u) => u.rol !== 'ADMIN' && u.username?.toLowerCase() !== 'jimyamanqui@gmail.com'
        );
        this.usuarios.set(soloEscolares);

        // Cargar Estudiantes del colegio
        this.alumnoService.listar(cid).subscribe({
          next: (dataAlumnos) => {
            this.alumnos.set(dataAlumnos || []);

            // Cargar Personal del colegio
            this.personalService.listar(undefined, undefined, cid).subscribe({
              next: (dataPersonal) => {
                const listaPersonal = dataPersonal || [];
                this.personal.set(listaPersonal);

                // Cargar Horarios del colegio
                this.personalService.obtenerTodosHorarios(cid).subscribe({
                  next: (dataHorarios) => {
                    const bloques = dataHorarios || [];
                    this.horarios.set(bloques);

                    // Construir catálogo de cursos reales del colegio desde bloques horarios y especialidades docentes
                    const mapaCursos = new Map<string, CursoItem>();
                    let nextId = 1;
                    for (const b of bloques) {
                      const nombre = (b.curso || '').trim();
                      if (!nombre) continue;
                      const key = nombre.toLowerCase();
                      if (!mapaCursos.has(key)) {
                        const codePrefix = nombre.replace(/[^a-zA-Z]/g, '').substring(0, 3).toUpperCase() || 'CUR';
                        mapaCursos.set(key, {
                          id: nextId++,
                          codigo: `${codePrefix}-10${nextId}`,
                          nombre,
                          area: 'Académico',
                          horasSemanales: b.duracionHoras || 2,
                          grado: b.grado || 'Secundaria',
                          docenteAsignado: b.docenteNombre || 'Docente Asignado',
                          aula: b.aula || 'Aula Principal',
                        });
                      } else {
                        const item = mapaCursos.get(key)!;
                        item.horasSemanales += b.duracionHoras || 2;
                        if (b.grado && !item.grado.includes(b.grado)) {
                          item.grado = `${item.grado}, ${b.grado}`;
                        }
                      }
                    }

                    for (const d of listaPersonal.filter((p) => p.cargo === 'DOCENTE')) {
                      const especialidades = d.cursosEspecialidad?.length
                        ? d.cursosEspecialidad
                        : d.area && d.area !== 'General'
                          ? [d.area]
                          : [];
                      for (const esp of especialidades) {
                        const nombre = esp.trim();
                        if (!nombre) continue;
                        const key = nombre.toLowerCase();
                        if (!mapaCursos.has(key)) {
                          const codePrefix = nombre.replace(/[^a-zA-Z]/g, '').substring(0, 3).toUpperCase() || 'CUR';
                          mapaCursos.set(key, {
                            id: nextId++,
                            codigo: `${codePrefix}-10${nextId}`,
                            nombre,
                            area: d.area || 'Académico',
                            horasSemanales: d.horasSemanales || 0,
                            grado: '1° a 5° Secundaria',
                            docenteAsignado: `Prof. ${d.nombre} ${d.apellidos}`,
                            aula: 'Pabellón Central',
                          });
                        }
                      }
                    }

                    this.cursos.set(Array.from(mapaCursos.values()));
                    this.loading.set(false);
                  },
                  error: () => this.loading.set(false),
                });
              },
              error: () => this.loading.set(false),
            });
          },
          error: () => this.loading.set(false),
        });
      },
      error: () => this.loading.set(false),
    });
  }

  copiarUrlInstitucional(): void {
    navigator.clipboard.writeText(this.urlInstitucionalColegio()).then(() => {
      this.urlCopiada.set(true);
      this.notificacionGlobal.set(`URL institucional copiada: ${this.urlInstitucionalColegio()}`);
      setTimeout(() => this.urlCopiada.set(false), 2500);
    });
  }

  cargarCalendarioAnual(): void {
    this.personalService.obtenerCalendarioAnual().subscribe({
      next: (res) => {
        if (res?.fechaInicioAnual) this.fechaInicioAnual.set(res.fechaInicioAnual);
        if (res?.fechaFinAnual) this.fechaFinAnual.set(res.fechaFinAnual);
        if (res?.duracionMesesAnual) this.duracionMesesAnual.set(res.duracionMesesAnual);
        if (res?.semanasLectivasAnual) this.semanasLectivasAnual.set(res.semanasLectivasAnual);
      },
    });
  }

  recalcularSemanasAnuales(): void {
    const fIni = new Date(this.fechaInicioAnual());
    const fFin = new Date(this.fechaFinAnual());
    if (isNaN(fIni.getTime()) || isNaN(fFin.getTime())) return;
    const diffDays = Math.max(1, Math.round((fFin.getTime() - fIni.getTime()) / (1000 * 60 * 60 * 24)));
    this.semanasLectivasAnual.set(Math.ceil(diffDays / 7));
    this.duracionMesesAnual.set(Math.max(1, Math.round(diffDays / 30.4)));
  }

  guardarCalendarioEscolar(): void {
    this.guardandoCalendario.set(true);
    this.mensajeCalendario.set(null);
    this.personalService
      .actualizarCalendarioAnual({
        fechaInicioAnual: this.fechaInicioAnual(),
        fechaFinAnual: this.fechaFinAnual(),
        duracionMesesAnual: this.duracionMesesAnual(),
      })
      .subscribe({
        next: (res) => {
          this.guardandoCalendario.set(false);
          this.mensajeCalendario.set({ tipo: 'success', texto: res.mensaje || 'Calendario oficial guardado.' });
          setTimeout(() => this.mensajeCalendario.set(null), 5000);
        },
        error: (err) => {
          this.guardandoCalendario.set(false);
          this.mensajeCalendario.set({ tipo: 'error', texto: err?.error?.error || 'Error al guardar calendario.' });
        },
      });
  }

  // Modales Cuentas
  limiteSecretariaAlcanzado = computed(() => this.secretarias().length >= 1);

  abrirModalSecretaria(): void {
    const numSecretarias = this.secretarias().length + 1;
    this.formCuenta.set({
      nombreCompleto: '',
      username: `secretaria${numSecretarias > 1 ? numSecretarias : ''}`,
      password: `secre${Math.floor(100 + Math.random() * 900)}`,
      rol: 'SECRETARIA',
      cargo: 'Secretaria General y Académica',
      email: '',
      dni: '',
      telefono: '',
      turno: 'COMPLETO',
      sueldoMensual: 1800,
    });
    
    if (this.limiteSecretariaAlcanzado()) {
      const secreActual = this.secretarias()[0];
      this.mensajeModalCuenta.set(`⚠️ POLÍTICA INSTITUCIONAL: Solo se permite registrar 1 Secretaria por colegio. Actualmente ya existe registrada: "${secreActual?.nombreCompleto || secreActual?.username}".`);
    } else {
      this.mensajeModalCuenta.set(null);
    }
    this.mostrarModalCuenta.set(true);
  }

  abrirModalCuentaGeneral(): void {
    this.formCuenta.set({
      nombreCompleto: '',
      username: '',
      password: 'usuario2026',
      rol: 'SECRETARIA',
      cargo: 'Secretaria Académica',
      email: '',
      dni: '',
      telefono: '',
      turno: 'COMPLETO',
      sueldoMensual: 1800,
    });
    this.mensajeModalCuenta.set(null);
    this.mostrarModalCuenta.set(true);
  }

  cerrarModalCuenta(): void {
    this.mostrarModalCuenta.set(false);
  }

  cerrarModalCredenciales(): void {
    this.mostrarModalCredenciales.set(false);
    this.dataCredencialesGeneradas.set(null);
  }

  copiarTexto(texto: string): void {
    navigator.clipboard.writeText(texto).then(() => {
      this.copiaExitosa.set(true);
      setTimeout(() => this.copiaExitosa.set(false), 2500);
    });
  }

  urlActual(): string {
    return window.location.origin + '/login';
  }

  verFichaAccesoPersonal(p: PersonalEscolar): void {
    const user = p.username || `docente_${p.dni}`;
    const pass = p.dni;
    this.dataCredencialesGeneradas.set({
      titulo: 'Ficha de Accesos e Identidad Institucional',
      nombreCompleto: `${p.cargo === 'DOCENTE' ? 'Prof. ' : ''}${p.nombre} ${p.apellidos}`,
      cargo: p.cargo === 'DOCENTE' ? 'Docente de Secundaria' : p.cargo,
      username: user,
      password: pass,
      dni: p.dni,
      email: `${user}@bomerp.edu.pe`,
      notaInfo: 'Comparta estas credenciales con el personal escolar para que pueda ingresar al portal.',
    });
    this.mostrarModalCredenciales.set(true);
  }

  verFichaAccesoUsuario(u: UsuarioEscolar): void {
    this.dataCredencialesGeneradas.set({
      titulo: 'Ficha de Cuenta y Accesos Institucionales',
      nombreCompleto: u.nombreCompleto || u.username,
      cargo: u.cargo || u.rol,
      username: u.username,
      password: u.passwordHash || u.passwordHint || 'No definida',
      dni: 'DNI Registrado',
      email: u.email || `${u.username}@bomerp.edu.pe`,
      notaInfo: 'Cuenta activa autorizada por Dirección General.',
    });
    this.mostrarModalCredenciales.set(true);
  }

  guardarCuenta(): void {
    const f = this.formCuenta();

    if (f.rol === 'SECRETARIA' && this.limiteSecretariaAlcanzado()) {
      this.mensajeModalCuenta.set(`🚫 OPERACIÓN BLOQUEADA: Ya existe 1 Secretaria registrada (${this.secretarias()[0]?.nombreCompleto || 'activa'}). La plataforma limita estrictamente 1 Secretaria por institución.`);
      return;
    }

    if (!f.nombreCompleto.trim() || !f.username.trim() || !f.password.trim() || !f.rol) {
      this.mensajeModalCuenta.set('Complete los campos obligatorios: Nombre Completo, Usuario, Contraseña y Rol.');
      return;
    }

    this.guardandoCuenta.set(true);
    this.mensajeModalCuenta.set(null);

    const emailCalculado = f.email.trim() || `${f.username.trim().toLowerCase()}@bomerp.edu.pe`;

    this.authService
      .crearUsuario({
        username: f.username.trim(),
        password: f.password.trim(),
        rol: f.rol,
        nombreCompleto: f.nombreCompleto.trim(),
        cargo: f.cargo.trim(),
        email: emailCalculado,
        dni: f.dni.trim(),
        telefono: f.telefono.trim(),
        turno: f.rol === 'SECRETARIA' ? 'COMPLETO' : f.turno,
        sueldoMensual: f.rol === 'SECRETARIA' ? (Number(f.sueldoMensual) || 1800) : undefined,
      })
      .subscribe({
        next: () => {
          this.guardandoCuenta.set(false);
          this.cerrarModalCuenta();
          this.cargarDatos();

          this.dataCredencialesGeneradas.set({
            titulo: `¡Cuenta de ${f.rol === 'SECRETARIA' ? 'Secretaría' : f.rol === 'DOCENTE' ? 'Docente' : f.rol === 'COLABORADOR' ? 'Colaborador' : f.rol} Creada con Éxito!`,
            nombreCompleto: f.nombreCompleto.trim(),
            cargo: f.cargo.trim() || f.rol,
            username: f.username.trim(),
            password: f.password.trim(),
            dni: f.dni.trim() || 'Registrado',
            email: emailCalculado,
            notaInfo: '¡Atención! Comparta estos datos con la persona asignada para que pueda ingresar al portal.',
          });
          this.mostrarModalCredenciales.set(true);
          this.notificacionGlobal.set(`Cuenta de ${f.rol} '${f.username.trim()}' creada y activada.`);
        },
        error: (err) => {
          this.guardandoCuenta.set(false);
          this.mensajeModalCuenta.set(err.error?.error || err.error?.message || 'Error al crear la cuenta de usuario.');
        },
      });
  }

  eliminarCuenta(u: UsuarioEscolar): void {
    const currentUser = this.authService.getCurrentUser();
    if (u.rol === 'ADMIN' || u.rol === 'DIRECTOR' || u.username === currentUser?.username) {
      this.notificacionGlobal.set('La cuenta principal del Director General no puede ser eliminada.');
      return;
    }

    this.authService.eliminarUsuario(u.id).subscribe({
      next: () => {
        this.usuarios.update((list) => list.filter((item) => item.id !== u.id));
        this.cargarDatos();
        this.notificacionGlobal.set(`Cuenta '${u.username}' eliminada con éxito.`);
      },
      error: (err) => this.notificacionGlobal.set(err.error?.error || 'Error al eliminar cuenta.'),
    });
  }

  eliminarPersonal(p: PersonalEscolar): void {
    this.personalService.eliminar(p.id).subscribe({
      next: () => {
        this.personal.update((list) => list.filter((item) => item.id !== p.id));
        this.cargarDatos();
        this.notificacionGlobal.set(`Personal '${p.nombre} ${p.apellidos}' dado de baja con éxito.`);
      },
      error: (err) => this.notificacionGlobal.set(err.error?.error || 'Error al dar de baja al personal.'),
    });
  }

  eliminarAlumno(a: AlumnoResponse): void {
    this.alumnoService.eliminar(a.id).subscribe({
      next: () => {
        this.alumnos.update((list) => list.filter((item) => item.id !== a.id));
        this.cargarDatos();
        this.notificacionGlobal.set(`Estudiante '${a.nombre} ${a.apellidoPaterno}' dado de baja con éxito.`);
      },
      error: (err) => this.notificacionGlobal.set(err.error?.error || 'Error al dar de baja al alumno.'),
    });
  }

  // Consulta RENIEC real desde los modales de Dirección General
  consultandoReniecDirector = signal(false);

  consultarReniecCuenta(): void {
    const dni = (this.formCuenta().dni || '').trim();
    if (!/^\d{8}$/.test(dni)) {
      this.mensajeModalCuenta.set('Ingrese un DNI peruano válido de 8 dígitos para consultar RENIEC.');
      return;
    }
    this.consultandoReniecDirector.set(true);
    this.mensajeModalCuenta.set(null);
    this.personalService.consultarReniec(dni).subscribe({
      next: (res) => {
        this.consultandoReniecDirector.set(false);
        if (res?.valido !== false && res?.nombreCompleto) {
          this.formCuenta.update((f) => ({ ...f, nombreCompleto: res.nombreCompleto }));
          this.notificacionGlobal.set(`✓ Validado por RENIEC: ${res.nombreCompleto}`);
        } else {
          this.mensajeModalCuenta.set(res?.error || 'DNI no encontrado en el padrón oficial de RENIEC.');
        }
      },
      error: (err) => {
        this.consultandoReniecDirector.set(false);
        this.mensajeModalCuenta.set(err?.error?.error || 'El DNI ingresado no figura en el padrón oficial de RENIEC.');
      },
    });
  }

  consultarReniecPersonalDirector(): void {
    const dni = (this.formPersonal().dni || '').trim();
    if (!/^\d{8}$/.test(dni)) {
      this.mensajeModalPersonal.set('Ingrese un DNI peruano válido de 8 dígitos para consultar RENIEC.');
      return;
    }
    this.consultandoReniecDirector.set(true);
    this.mensajeModalPersonal.set(null);
    this.personalService.consultarReniec(dni).subscribe({
      next: (res) => {
        this.consultandoReniecDirector.set(false);
        if (res?.valido !== false && res?.nombres) {
          this.formPersonal.update((f) => ({
            ...f,
            nombre: res.nombres,
            apellidos: `${res.apellidoPaterno || ''} ${res.apellidoMaterno || ''}`.trim(),
          }));
          this.notificacionGlobal.set(`✓ Validado por RENIEC: ${res.nombreCompleto}`);
        } else {
          this.mensajeModalPersonal.set(res?.error || 'DNI no encontrado en el padrón oficial de RENIEC.');
        }
      },
      error: (err) => {
        this.consultandoReniecDirector.set(false);
        this.mensajeModalPersonal.set(err?.error?.error || 'El DNI ingresado no figura en el padrón oficial de RENIEC.');
      },
    });
  }

  consultarReniecEstudianteDirector(): void {
    const dni = (this.formEstudiante().dni || '').trim();
    if (!/^\d{8}$/.test(dni)) {
      this.mensajeModalEstudiante.set('Ingrese un DNI peruano válido de 8 dígitos para consultar RENIEC.');
      return;
    }
    this.consultandoReniecDirector.set(true);
    this.mensajeModalEstudiante.set(null);
    this.personalService.consultarReniec(dni).subscribe({
      next: (res) => {
        this.consultandoReniecDirector.set(false);
        if (res?.valido !== false && res?.nombres) {
          this.formEstudiante.update((f) => ({
            ...f,
            nombre: res.nombres,
            apellidoPaterno: res.apellidoPaterno || f.apellidoPaterno,
            apellidoMaterno: res.apellidoMaterno || f.apellidoMaterno,
          }));
          this.notificacionGlobal.set(`✓ Validado por RENIEC: ${res.nombreCompleto}`);
        } else {
          this.mensajeModalEstudiante.set(res?.error || 'DNI no encontrado en el padrón oficial de RENIEC.');
        }
      },
      error: (err) => {
        this.consultandoReniecDirector.set(false);
        this.mensajeModalEstudiante.set(err?.error?.error || 'El DNI ingresado no figura en el padrón oficial de RENIEC.');
      },
    });
  }

  // Modales Personal (Docentes y Colaboradores)
  abrirModalNuevoPersonal(cargoPorDefecto?: CargoPersonal): void {
    this.formPersonal.set({
      nombre: '',
      apellidos: '',
      dni: '',
      cargo: cargoPorDefecto || (this.tabActiva() === 'docentes' ? 'DOCENTE' : 'LIMPIEZA'),
      area: '',
      telefono: '',
      turno: 'MAÑANA',
    });
    this.mensajeModalPersonal.set(null);
    this.mostrarModalPersonal.set(true);
  }

  cerrarModalPersonal(): void {
    this.mostrarModalPersonal.set(false);
  }

  guardarPersonal(): void {
    const f = this.formPersonal();
    if (!f.nombre.trim() || !f.apellidos.trim() || !f.dni.trim() || !f.cargo) {
      this.mensajeModalPersonal.set('Complete todos los campos obligatorios (Nombre, Apellidos, DNI y Cargo).');
      return;
    }

    this.guardandoPersonal.set(true);
    this.mensajeModalPersonal.set(null);

    this.personalService
      .crear({
        nombre: f.nombre.trim(),
        apellidos: f.apellidos.trim(),
        dni: f.dni.trim(),
        cargo: f.cargo,
        area: f.area.trim(),
        telefono: f.telefono.trim(),
        turno: f.turno,
        registradoPor: 'Dirección General (Administrador)',
      })
      .subscribe({
        next: (resp: any) => {
          this.guardandoPersonal.set(false);
          this.cerrarModalPersonal();
          this.cargarDatos();

          const username = resp?.username || resp?.credencialesCuenta?.username || `personal_${f.dni.trim()}`;
          const password = resp?.credencialesCuenta?.password || f.dni.trim();

          this.dataCredencialesGeneradas.set({
            titulo: `¡${f.cargo === 'DOCENTE' ? 'Docente' : 'Personal'} Registrado con Éxito!`,
            nombreCompleto: `${f.cargo === 'DOCENTE' ? 'Prof. ' : ''}${f.nombre.trim()} ${f.apellidos.trim()}`,
            cargo: f.cargo === 'DOCENTE' ? 'Docente de Secundaria' : f.cargo,
            username: username,
            password: password,
            dni: f.dni.trim(),
            email: `${username}@bomerp.edu.pe`,
            notaInfo: 'Entregue estos datos al nuevo personal para ingresar al portal escolar.',
          });
          this.mostrarModalCredenciales.set(true);
          this.notificacionGlobal.set(`Personal registrado con éxito.`);
        },
        error: (err) => {
          this.guardandoPersonal.set(false);
          this.mensajeModalPersonal.set(err.error?.message || 'Error al registrar personal.');
        },
      });
  }

  // Modales Estudiantes
  abrirModalEstudiante(): void {
    this.formEstudiante.set({
      nombre: '',
      apellidoPaterno: '',
      apellidoMaterno: '',
      dni: '',
      grado: '1° Secundaria',
      seccion: 'A',
      telefono: '',
    });
    this.mensajeModalEstudiante.set(null);
    this.mostrarModalEstudiante.set(true);
  }

  cerrarModalEstudiante(): void {
    this.mostrarModalEstudiante.set(false);
  }

  guardarEstudiante(): void {
    const f = this.formEstudiante();
    if (!f.nombre.trim() || !f.apellidoPaterno.trim() || !f.dni.trim()) {
      this.mensajeModalEstudiante.set('Complete Nombre, Apellido Paterno y DNI.');
      return;
    }

    this.guardandoEstudiante.set(true);
    this.mensajeModalEstudiante.set(null);

    this.alumnoService
      .crear({
        nombre: f.nombre.trim(),
        apellidoPaterno: f.apellidoPaterno.trim(),
        apellidoMaterno: f.apellidoMaterno.trim(),
        dni: f.dni.trim(),
        grado: f.grado,
        seccion: f.seccion,
        fechaIngreso: new Date().toISOString().split('T')[0],
      })
      .subscribe({
        next: () => {
          this.guardandoEstudiante.set(false);
          this.cerrarModalEstudiante();
          this.cargarDatos();
          this.notificacionGlobal.set(`Estudiante '${f.nombre} ${f.apellidoPaterno}' matriculado con éxito.`);
        },
        error: (err) => {
          this.guardandoEstudiante.set(false);
          this.mensajeModalEstudiante.set(err.error?.error || err.error?.message || 'Error al matricular estudiante.');
        },
      });
  }

  // Modales Comunicados
  abrirModalComunicado(): void {
    this.formComunicado.set({
      titulo: '',
      contenido: '',
      dirigidoA: 'Toda la Comunidad',
      urgente: false,
    });
    this.mostrarModalComunicado.set(true);
  }

  cerrarModalComunicado(): void {
    this.mostrarModalComunicado.set(false);
  }

  publicarComunicado(): void {
    const f = this.formComunicado();
    if (!f.titulo.trim() || !f.contenido.trim()) return;

    const nuevo: ComunicadoItem = {
      id: Date.now(),
      titulo: f.titulo.trim(),
      contenido: f.contenido.trim(),
      dirigidoA: f.dirigidoA,
      fecha: 'Hoy',
      urgente: f.urgente,
      autor: 'Dirección General',
    };

    this.comunicados.update((arr) => [nuevo, ...arr]);
    this.cerrarModalComunicado();
    this.notificacionGlobal.set(`Comunicado "${nuevo.titulo}" publicado oficialmente.`);
  }

  eliminarComunicado(id: number): void {
    this.comunicados.update((arr) => arr.filter((c) => c.id !== id));
    this.notificacionGlobal.set('Comunicado retirado de la cartelera.');
  }
}

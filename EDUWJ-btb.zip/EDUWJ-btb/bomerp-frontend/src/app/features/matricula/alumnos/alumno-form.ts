import { Component, signal, computed, inject, input, output, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { AlumnoService, PersonalService, AlumnoRequest, AlumnoResponse } from '../../../core/services';

@Component({
  selector: 'app-alumno-form',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './alumno-form.html',
  styleUrl: './alumno-form.css',
})
export class AlumnoFormComponent implements OnInit {
  private alumnoService = inject(AlumnoService);
  private personalService = inject(PersonalService);

  alumno = input<AlumnoResponse | null>(null);
  close = output<void>();
  save = output<void>();

  form = signal<AlumnoRequest>({
    nombre: '',
    apellidoPaterno: '',
    apellidoMaterno: '',
    dni: '',
    fechaIngreso: '',
    grado: '',
    seccion: '',
    costoMensual: 450,
    mesesPeriodo: 10,
    modalidadPago: 'MENSUAL',
  });

  loading = signal(false);
  consultandoReniec = signal(false);
  mensajeReniec = signal<{ tipo: 'success' | 'error'; texto: string } | null>(null);
  error = signal<string | null>(null);

  isEditing = computed(() => !!this.alumno());

  totalCalculado = computed(() => {
    const costo = Number(this.form().costoMensual) || 450;
    const meses = Number(this.form().mesesPeriodo) || 10;
    const desc = this.form().modalidadPago === 'CONTADO' ? Math.round(costo * meses * 0.1) : 0;
    return (costo * meses) - desc;
  });

  descuentoCalculado = computed(() => {
    const costo = Number(this.form().costoMensual) || 450;
    const meses = Number(this.form().mesesPeriodo) || 10;
    return this.form().modalidadPago === 'CONTADO' ? Math.round(costo * meses * 0.1) : 0;
  });

  cuotasEstimadas = computed(() => {
    const mod = this.form().modalidadPago;
    const meses = Number(this.form().mesesPeriodo) || 10;
    const total = this.totalCalculado();
    if (mod === 'CONTADO') {
      return `1 cuota única al contado de S/ ${total.toFixed(2)} (descuento del 10%)`;
    } else if (mod === 'BIMESTRAL') {
      const numCuotas = Math.ceil(meses / 2);
      const montoCuota = (total / numCuotas).toFixed(2);
      return `${numCuotas} cuotas bimestrales de S/ ${montoCuota} c/u`;
    } else {
      const numCuotas = meses;
      const montoCuota = (total / numCuotas).toFixed(2);
      return `${numCuotas} cuotas mensuales de S/ ${montoCuota} c/u`;
    }
  });

  registroExitoso = signal<{ username: string; password: string; nombre: string } | null>(null);

  ngOnInit(): void {
    if (this.isEditing() && this.alumno()) {
      const a = this.alumno()!;
      this.form.set({
        nombre: a.nombre,
        apellidoPaterno: a.apellidoPaterno,
        apellidoMaterno: a.apellidoMaterno ?? '',
        dni: a.dni,
        fechaIngreso: a.fechaIngreso,
        grado: a.grado,
        seccion: a.seccion ?? '',
        costoMensual: a.costoMensual ?? a.planFinanciero?.costoMensual ?? 450,
        mesesPeriodo: a.mesesPeriodo ?? a.planFinanciero?.mesesPeriodo ?? 10,
        modalidadPago: a.modalidadPago ?? a.planFinanciero?.modalidadPago ?? 'MENSUAL',
      });
    } else {
      this.form.update(f => ({
        ...f,
        fechaIngreso: new Date().toISOString().split('T')[0],
        costoMensual: 450,
        mesesPeriodo: 10,
        modalidadPago: 'MENSUAL',
      }));

      // Cargar duración oficial del año escolar establecida por Dirección
      this.personalService.obtenerCalendarioAnual().subscribe({
        next: (cal) => {
          if (cal?.duracionMeses) {
            this.form.update(f => ({ ...f, mesesPeriodo: cal.duracionMeses }));
          }
        },
        error: () => {}
      });
    }
  }

  consultarReniecAlumno(): void {
    const dni = (this.form().dni || '').trim();
    if (!/^\d{8}$/.test(dni)) {
      this.mensajeReniec.set({ tipo: 'error', texto: 'Ingrese un DNI peruano válido de 8 dígitos numéricos para consultar RENIEC.' });
      setTimeout(() => this.mensajeReniec.set(null), 4000);
      return;
    }

    this.consultandoReniec.set(true);
    this.mensajeReniec.set(null);

    this.personalService.consultarReniec(dni).subscribe({
      next: (res) => {
        this.consultandoReniec.set(false);
        if (res?.valido !== false && res?.nombres) {
          this.form.update((f) => ({
            ...f,
            nombre: res.nombres,
            apellidoPaterno: res.apellidoPaterno || f.apellidoPaterno,
            apellidoMaterno: res.apellidoMaterno || f.apellidoMaterno,
          }));
          this.mensajeReniec.set({
            tipo: 'success',
            texto: `✓ Validado por RENIEC: ${res.nombreCompleto}`,
          });
          setTimeout(() => this.mensajeReniec.set(null), 5000);
        } else {
          this.mensajeReniec.set({
            tipo: 'error',
            texto: res?.error || 'El DNI ingresado no figura en el padrón oficial de RENIEC.',
          });
          setTimeout(() => this.mensajeReniec.set(null), 5000);
        }
      },
      error: (err) => {
        this.consultandoReniec.set(false);
        this.mensajeReniec.set({
          tipo: 'error',
          texto: err?.error?.error || 'El DNI ingresado no figura en el padrón oficial de RENIEC. Verifique el número o ingrese los nombres manualmente.',
        });
        setTimeout(() => this.mensajeReniec.set(null), 5000);
      },
    });
  }

  onSubmit(): void {
    const data = this.form();
    if (!data.nombre || !data.apellidoPaterno || !data.dni || !data.fechaIngreso || !data.grado) {
      this.error.set('Complete todos los campos obligatorios');
      return;
    }

    this.loading.set(true);
    this.error.set(null);

    const request$ = this.isEditing()
      ? this.alumnoService.actualizar(this.alumno()!.id, data)
      : this.alumnoService.crear(data);

    request$.subscribe({
      next: (res: any) => {
        this.loading.set(false);
        if (!this.isEditing()) {
          this.registroExitoso.set({
            username: `alumno_${data.dni}`,
            password: `alumno${data.dni}`,
            nombre: `${data.nombre} ${data.apellidoPaterno}`,
          });
        } else {
          this.save.emit();
        }
      },
      error: (err) => {
        this.error.set(err.error?.message ?? 'Error al guardar alumno');
        this.loading.set(false);
      },
    });
  }

  cerrarExitoso(): void {
    this.registroExitoso.set(null);
    this.save.emit();
  }

  onCancel(): void {
    this.close.emit();
  }
}
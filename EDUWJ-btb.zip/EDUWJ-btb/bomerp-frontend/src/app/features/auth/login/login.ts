import { Component, OnInit, OnDestroy, signal, computed, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { Router, ActivatedRoute, RouterModule } from '@angular/router';
import { AuthService, AuthRequest, AuthResponse } from '../../../core/services';
import { GmailService } from '../../../core/services/gmail.service';

@Component({
  selector: 'app-login',
  standalone: true,
  imports: [CommonModule, FormsModule, RouterModule],
  templateUrl: './login.html',
  styleUrl: './login.css',
})
export class Login implements OnInit, OnDestroy {
  private authService = inject(AuthService);
  private gmailService = inject(GmailService);
  private router = inject(Router);
  private route = inject(ActivatedRoute);

  // Formulario escolar habitual (Director, Docente, Alumno, Secretaria)
  username = signal('');
  password = signal('');
  showPassword = signal(false);
  error = signal<string | null>(null);
  loading = signal(false);

  // Mecanismo Secreto: 5 Clics en el Logo o ingreso de cuenta maestra
  logoClicks = signal(0);
  showSteamGuardModal = signal(false);

  // Steam Guard Estado Dinámico Móvil (5 Minutos / 300 Segundos) exclusivo para jimyamanqui@gmail.com
  masterUsername = signal('jimyamanqui@gmail.com');
  masterPassword = signal('');
  masterCodeInput = signal('');
  steamGuardSecondsRemaining = signal(300);
  steamGuardBoundEmail = signal('jimyamanqui@gmail.com');
  hasActiveDevice = signal(false);
  registeredDeviceName = signal<string | null>(null);
  showQrAssistant = signal(false);
  qrDataUrl = signal<string>('');
  pairingUrl = signal<string>('');
  steamGuardInterval: any;
  masterLoading = signal(false);
  masterError = signal<string | null>(null);

  activeUser = signal<AuthResponse | null>(null);

  // Datos dinámicos de la institución educativa
  colegioNombre = signal<string>('BomERP SaaS — Portal Institucional');
  colegioSubtitulo = signal<string>('BOM-ERP • Autenticación Institucional Unificada');
  colegioSlug = signal<string | null>(null);
  colegioInfo = signal<any | null>(null);

  ngOnInit(): void {
    // 1. Detección dinámica de la institución educativa (query params o lastVisitedColegioSlug)
    const slugParam = this.route.snapshot.queryParamMap.get('slug') || this.route.snapshot.queryParamMap.get('colegio');
    const lastSlug = typeof localStorage !== 'undefined' ? localStorage.getItem('lastVisitedColegioSlug') : null;
    const targetSlug = slugParam || lastSlug;

    if (targetSlug) {
      this.colegioSlug.set(targetSlug);
      this.authService.obtenerColegioPorSlug(targetSlug).subscribe({
        next: (res) => {
          if (res?.colegio) {
            this.colegioInfo.set(res.colegio);
            this.colegioNombre.set(res.colegio.nombreColegio);
            this.colegioSubtitulo.set(
              `Portal Escolar Oficial · RUC: ${res.colegio.ruc || '20000000001'} · Cód: ${res.colegio.codigoModular || 'MOD-2026'}`
            );
            document.title = `${res.colegio.nombreColegio} — Portal de Acceso`;
          }
        },
        error: () => {
          this.colegioNombre.set('BomERP SaaS — Portal Institucional');
          this.colegioSubtitulo.set('BOM-ERP • Autenticación Institucional Unificada');
          document.title = 'BomERP — Portal Institucional';
        },
      });
    } else {
      this.colegioNombre.set('BomERP SaaS — Portal Institucional');
      this.colegioSubtitulo.set('BOM-ERP • Autenticación Institucional Unificada');
      document.title = 'BomERP — Portal Institucional';
    }

    // 2. Si se especifica logout=true en la URL, cerrar sesión automáticamente
    const shouldLogout = this.route.snapshot.queryParamMap.get('logout') === 'true';
    if (shouldLogout) {
      const targetUrl = this.authService.logout();
      this.activeUser.set(null);
      this.router.navigateByUrl(targetUrl);
      return;
    } else {
      this.activeUser.set(this.authService.getCurrentUser());
    }

    // Si viene de aprovisionamiento de colegio, auto-completar usuario del Director
    const userParam = this.route.snapshot.queryParamMap.get('user');
    if (userParam) {
      this.username.set(userParam);
    }
  }

  ngOnDestroy(): void {
    if (this.steamGuardInterval) {
      clearInterval(this.steamGuardInterval);
    }
  }

  logoutUser(): void {
    const targetUrl = this.authService.logout();
    this.activeUser.set(null);
    this.router.navigateByUrl(targetUrl);
  }

  onLogoClick(): void {
    const current = this.logoClicks() + 1;
    this.logoClicks.set(current);

    if (current >= 5) {
      this.logoClicks.set(0);
      this.abrirSteamGuard();
    }
  }

  abrirSteamGuard(): void {
    this.showSteamGuardModal.set(true);
    this.masterError.set(null);
    this.actualizarEstadoSteamGuard();
    this.cargarQrReal();

    // Actualizar periódicamente el temporizador cada 1 segundo
    if (this.steamGuardInterval) clearInterval(this.steamGuardInterval);
    this.steamGuardInterval = setInterval(() => {
      this.actualizarEstadoSteamGuard();
    }, 1000);
  }

  cargarQrReal(): void {
    this.authService.generarTokenVinculacion().subscribe({
      next: (res) => {
        if (res.qrDataUrl) this.qrDataUrl.set(res.qrDataUrl);
        if (res.fullPairingUrl) this.pairingUrl.set(res.fullPairingUrl);
      },
      error: () => {
        this.authService.getQrDescarga().subscribe({
          next: (r) => {
            if (r.qrDataUrl) this.qrDataUrl.set(r.qrDataUrl);
            if (r.fullPairingUrl) this.pairingUrl.set(r.fullPairingUrl);
          },
        });
      },
    });
  }

  cerrarSteamGuard(): void {
    this.showSteamGuardModal.set(false);
    if (this.steamGuardInterval) {
      clearInterval(this.steamGuardInterval);
      this.steamGuardInterval = null;
    }
  }

  actualizarEstadoSteamGuard(): void {
    this.authService.getSteamGuardStatus().subscribe({
      next: (status) => {
        this.steamGuardSecondsRemaining.set(status.secondsRemaining);
        this.steamGuardBoundEmail.set(status.boundEmail || 'jimyamanqui@gmail.com');
        this.hasActiveDevice.set(status.hasActiveDevice);
        this.registeredDeviceName.set(status.deviceName);
      },
    });
  }

  formatearTiempo(segundos: number): string {
    const mins = Math.floor(segundos / 60);
    const secs = segundos % 60;
    return `${mins}:${secs < 10 ? '0' : ''}${secs}`;
  }

  toggleQrAssistant(): void {
    this.showQrAssistant.update((v) => !v);
    if (this.showQrAssistant() && !this.qrDataUrl()) {
      this.cargarQrReal();
    }
  }

  enviandoCorreoLogin = signal(false);
  correoLoginEnviado = signal<string | null>(null);

  enviarCorreoPamiDesdeLogin(): void {
    this.enviandoCorreoLogin.set(true);
    this.masterError.set(null);
    this.correoLoginEnviado.set(null);

    this.authService.enviarCorreoInstalacionPami('jimyamanqui@gmail.com').subscribe({
      next: async (res) => {
        const mailObj = res.correo || res;
        if (res.qrDataUrl) this.qrDataUrl.set(res.qrDataUrl);
        try {
          await this.gmailService.enviarCorreoGmailDirecto(
            'jimyamanqui@gmail.com',
            mailObj.asunto || '📱 Descarga tu App REZE - Autenticador Móvil Maestro (jimyamanqui@gmail.com)',
            mailObj.contenidoHtml || `<p>Instala REZE desde: <a href="${res.enlaceInstalacion}">${res.enlaceInstalacion}</a></p>`
          );
          this.correoLoginEnviado.set('✅ ¡Correo enviado REALMENTE a jimyamanqui@gmail.com vía Gmail API!');
        } catch (e: any) {
          this.correoLoginEnviado.set('¡Enlace y código QR listos en pantalla para instalar REZE!');
        } finally {
          this.enviandoCorreoLogin.set(false);
        }
      },
      error: (err) => {
        this.enviandoCorreoLogin.set(false);
        this.masterError.set(err.error?.mensaje || 'Error al enviar correo de instalación.');
      },
    });
  }

  loginMaster(): void {
    const code = this.masterCodeInput().trim().toUpperCase();
    if (code.length !== 5) {
      this.masterError.set('Ingresa el código de 5 caracteres de tu app móvil REZE.');
      return;
    }

    const effectivePass = this.masterPassword() || this.password() || 'jimy';
    this.authService.setLoginOrigin('/adquirir');
    this.masterLoading.set(true);
    this.masterError.set(null);

    this.authService
      .loginMaestro({
        username: this.masterUsername().trim() || 'jimyamanqui@gmail.com',
        password: effectivePass,
        steamGuardCode: code,
      })
      .subscribe({
        next: () => {
          this.masterLoading.set(false);
          this.cerrarSteamGuard();
          this.router.navigate(['/saas-master']);
        },
        error: (err) => {
          this.masterLoading.set(false);
          this.masterError.set(err.error?.mensaje || 'Acceso Maestro denegado. Código REZE o clave incorrectos.');
        },
      });
  }

  togglePasswordVisibility(): void {
    this.showPassword.update((v) => !v);
  }

  isFormValid = computed(() => this.username().trim().length > 0 && this.password().trim().length > 0);

  onSubmit(): void {
    if (!this.isFormValid()) return;

    const u = this.username().trim();
    const p = this.password();

    // Si es la cuenta del SuperAdmin (jimyamanqui@gmail.com), validar clave y pedir verificación REZE
    if (u.toLowerCase() === 'jimyamanqui@gmail.com' || u.toLowerCase() === 'jimy') {
      this.authService.setLoginOrigin('/adquirir');
      this.loading.set(true);
      this.error.set(null);
      this.authService.verificarCredencialesMaestro({ username: u, password: p }).subscribe({
        next: () => {
          this.loading.set(false);
          this.masterUsername.set('jimyamanqui@gmail.com');
          this.masterPassword.set(p);
          this.masterCodeInput.set('');
          this.abrirSteamGuard();
        },
        error: (err) => {
          this.loading.set(false);
          this.error.set(err.error?.mensaje ?? 'Contraseña incorrecta para la cuenta maestra jimyamanqui@gmail.com');
        },
      });
      return;
    }

    if (this.colegioSlug()) {
      this.authService.setLoginOrigin(`/colegio/${this.colegioSlug()}`);
    } else {
      this.authService.setLoginOrigin('/login');
    }

    this.loading.set(true);
    this.error.set(null);

    const credentials: AuthRequest = {
      username: u,
      password: p,
      ...(this.colegioSlug() ? { slugColegio: this.colegioSlug()! } : {}),
    };

    this.authService.login(credentials).subscribe({
      next: () => {
        this.loading.set(false);
        const user = this.authService.getCurrentUser();
        const esParametroColegio = this.route.snapshot.queryParamMap.get('type') === 'colegio' || !!this.route.snapshot.queryParamMap.get('colegio');

        // RESTRICCIÓN DE SEGURIDAD:
        // En la pantalla pública de /login SOLO pueden ingresar Directores (DIRECTOR) y el ADMIN maestro.
        // Las Secretarías, Docentes y Alumnos solo pueden ingresar desde la URL propia de su colegio (/colegio/:slug).
        if (user && user.rol !== 'ADMIN' && user.rol !== 'DIRECTOR' && !esParametroColegio) {
          this.authService.logout();
          const slug = user.slugColegio || 'su-colegio';
          const rolEspanol =
            user.rol === 'ALUMNO'
              ? 'Estudiante'
              : user.rol === 'DOCENTE'
              ? 'Docente'
              : user.rol === 'SECRETARIA'
              ? 'Secretaría Académica'
              : 'Personal de Apoyo';

          this.error.set(
            `🚫 ACCESO RESTRINGIDO A DIRECCIÓN GENERAL: Esta pantalla pública es exclusiva para el Director General. Como ${rolEspanol}, debes ingresar únicamente desde la URL propia de tu colegio: /colegio/${slug}`
          );
          return;
        }

        const targetRoute = this.authService.getDefaultRoute();
        this.router.navigate([targetRoute]);
      },
      error: (err) => {
        if (err.error?.requireReze) {
          this.loading.set(false);
          this.masterUsername.set('jimyamanqui@gmail.com');
          this.masterPassword.set(p);
          this.masterCodeInput.set('');
          this.abrirSteamGuard();
          return;
        }
        this.error.set(err.error?.mensaje ?? 'No existe ninguna cuenta con estas credenciales. El sistema inicia en cero absoluto.');
        this.loading.set(false);
      },
    });
  }
}
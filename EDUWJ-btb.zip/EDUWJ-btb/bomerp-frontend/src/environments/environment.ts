export const environment = {
  apiBaseUrl: '',
  keycloak: {
    issuer: typeof window !== 'undefined' && window.location.port !== '4200' ? `${window.location.origin}/realms/bomerp` : 'http://localhost:38080/realms/bomerp',
    clientId: 'bomerp-frontend',
    redirectUri: typeof window !== 'undefined' ? `${window.location.origin}/auth/callback` : 'http://localhost:4200/auth/callback',
    postLogoutRedirectUri: typeof window !== 'undefined' ? `${window.location.origin}/` : 'http://localhost:4200/',
  },
};
export const environment = {
  production: true,
  apiBaseUrl: typeof window !== 'undefined' && window.location.port === '4300' ? 'http://localhost:48088' : '',
  keycloak: {
    issuer:
      typeof window !== 'undefined' && window.location.port === '4300'
        ? 'http://localhost:48080/realms/bomerp'
        : typeof window !== 'undefined' && window.location.port !== '4200'
          ? `${window.location.origin}/realms/bomerp`
          : 'http://localhost:48080/realms/bomerp',
    clientId: 'bomerp-frontend',
    redirectUri:
      typeof window !== 'undefined'
        ? `${window.location.origin}/auth/callback`
        : 'http://localhost:4300/auth/callback',
    postLogoutRedirectUri:
      typeof window !== 'undefined' ? `${window.location.origin}/` : 'http://localhost:4300/',
  },
};

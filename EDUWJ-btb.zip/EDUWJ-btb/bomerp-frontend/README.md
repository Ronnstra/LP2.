# BomERP - Frontend Escolar & Portal Estudiantil (Angular 22 + Tailwind CSS)

Frontend del sistema de gestión escolar y portal estudiantil **BomERP**, desarrollado con **Angular 22.1.8** y estilizado con una interfaz moderna **Neo-Glass (Neomorfismo + Glassmorfismo)** impulsada por **Tailwind CSS v3**.

---

## 🚀 Inicio Rápido con un Solo Comando

El proyecto cuenta con un hook inteligente `prestart` que **descarga e instala automáticamente Tailwind CSS y todas las dependencias** si aún no están instaladas:

```bash
# 1. Asegurar Node.js 22 LTS (recomendado con nvm)
nvm use 22

# 2. Iniciar el servidor de desarrollo de Angular:
cd bomerp-frontend
npm start
```

> **Automático:** Al ejecutar `npm start`, el script detecta si falta `tailwindcss` o `node_modules`, ejecuta la instalación necesaria en segundo plano y levanta `ng serve` en **http://localhost:4200**.

---

## 🔌 Conexión con el Backend, Keycloak y Swagger UI

El frontend incluye un proxy transparente configurado en `proxy.conf.json`:

| Entorno / Escenario | URL del Frontend | URL del Backend (API REST) | Swagger UI interactivo | Keycloak Identity Provider |
|---|---|---|---|---|
| **Con Spring Boot (8080)** | `http://localhost:4200` | `http://localhost:8080/api/v1` | `http://localhost:8080/swagger-ui.html` | `http://localhost:38080/realms/bomerp` |
| **Servidor Unificado (3000)** | `http://localhost:3000` | `http://localhost:3000/api/v1` | `http://localhost:3000/swagger-ui.html` | `http://localhost:38080/realms/bomerp` |

- **Acceso directo en el Header:** En la barra superior de la aplicación se encuentra el botón directo **⚡ Swagger UI** para abrir la consola de pruebas REST y crear registros en tiempo real.
- **Trazabilidad:** Cada solicitud HTTP saliente adjunta automáticamente un identificador único en el encabezado `X-Trace-ID` vía `traceIdInterceptor` para correlacionar con los logs del servidor y Loki.

---

## 🎨 Estilo Neo-Glass & Tailwind CSS v3

El proyecto utiliza **Tailwind CSS v3.4.19** con tokens de elevación suave neomórfica:
- `tailwind.config.js` escaneando todas las plantillas y componentes (`./src/**/*.{html,ts}`).
- `src/styles.css` con las directivas `@tailwind base`, `@tailwind components`, `@tailwind utilities` combinadas con efectos de vidrio esmerilado (`backdrop-blur`).

---

## 👥 Credenciales de Acceso Oficial

La única cuenta precargada es la cuenta maestra. Los Directores se crean dinámicamente desde `/adquirir`:

| Rol | Usuario | Contraseña | Portal Principal |
|---|---|---|---|
| **ADMIN (Super Admin único del SaaS)** | `jimyamanqui@gmail.com` | `jimy` *(con 2FA REZE)* | `/saas-master` (Control Central de Colegios y Suscripciones) |

> **Nota de Seguridad:** No hay cuentas demo. Desde el portal `/admin/comunidad`, el Director (`DIRECTOR`) registra a sus propias Secretarías, Docentes, Alumnos y Colaboradores de forma dinámica.

---

## 📁 Módulos y Portales Implementados (S1-S9 LP2)

```
src/app/
├── core/
│   ├── guards/               # AuthGuard y RoleGuard (RBAC por rol)
│   ├── interceptors/         # traceIdInterceptor (X-Trace-ID en cada petición)
│   ├── layout/               # Shell Neo-Glass, sidebar y acceso directo a Swagger
│   ├── models/               # Modelos TypeScript (Alumno, Nota, Contrato, Personal, etc.)
│   └── services/             # Servicios HTTP (ApiService, AuthService, AlumnoService, NotaService)
└── features/
    ├── finanzas/
    │   └── contrato/         # Módulo Cabecera-Detalle Finanzas & Pensiones (S7-S9 LP2)
    │       ├── contrato-form.ts / .html     # FormArray dinámico de cuotas + computed
    │       ├── contrato-reporte.ts / .html  # KPIs Neomórficos, filtros y desglose
    │       ├── contrato-service.ts          # Servicio HTTP REST
    │       └── contrato.model.ts            # Interfaces TypeScript
    ├── admin/
    │   ├── comunidad/        # Directorio de Accesos, Plana Docente, Estudiantes y Horarios
    │   ├── aprobaciones/     # Bandeja de ratificación y aprobaciones de Dirección
    │   └── finanzas/         # Balance contable, ingresos por pensiones y nómina docente
    ├── secretaria/
    │   └── portal-secretaria/# Gestión de matrícula, asignación de cursos y comunicados
    ├── docente/
    │   └── portal-docente/   # Registro de evaluaciones, toma de asistencias y justificaciones
    ├── alumno/
    │   └── portal-alumno/    # Consulta de notas, horario escolar y pago de pensiones
    ├── colaborador/
    │   └── portal-colaborador/# Funciones y marcación de asistencia de personal de apoyo
    └── auth/
        └── login/            # Pantalla de autenticación con diseño Neo-Glass
```

---

## 💳 Formulario Transaccional & Finanzas (S7-S9 LP2)

### 1. Formulario Cabecera-Detalle (`/finanzas/contratos/nuevo`)
- **FormArray Dinámico**: Genera automáticamente el plan de 10 cuotas escolares para secundaria (Marzo a Diciembre S/ 450/mes + S/ 350 Matrícula) y permite agregar o quitar conceptos adicionales en tiempo real.
- **Cálculos en Vivo (`computed`)**: Reclalcula el Total Contratado y la Deuda Pendiente automáticamente.
- **Confirmación Explícita**: Modal con resumen financiero antes de comprometer la deuda del estudiante.
- **Manejo de Errores**: Captura `409 Conflict` (estudiante con contrato activo) y `404 Not Found`.

### 2. Reporte Financiero & Consolidado (`/finanzas/contratos/reporte`)
- **Tarjetas KPI Neomórficas**: Total Contratado, Total Recaudado, Deuda Pendiente Total, Promedio Pensión.
- **Filtros Combinados**: Estado (`VIGENTE`, `ANULADO`) y Rango de Fechas (`desde`, `hasta`).
- **Desglose Expandible**: Tabla con las 10 cuotas de cada estudiante, fecha de vencimiento y estado de pago (`PAGADO`, `PENDIENTE`, `VENCIDO`).
- **Anulación Transaccional**: Botón para anular el contrato con reversión de deuda a S/ 0.00.

---

## 🛠️ Scripts Disponibles

Desde la carpeta `bomerp-frontend/`:

| Comando | Descripción |
|---|---|
| `npm start` | Inicia `ng serve` en el puerto 4200 con proxy a `http://localhost:8080`. Auto-instala dependencias si no existen. |
| `npm run build` | Compila el bundle de producción en `dist/bomerp-frontend/browser/` con Tailwind purgado. |
| `npm run watch` | Compila en modo escucha activa para cambios en tiempo real. |
| `npm test` | Ejecuta las pruebas unitarias del proyecto con Vitest. |

---

## 🛠️ Solución de Problemas Frecuentes (Troubleshooting)

### 1. Permisos de Ejecución para Maven Wrapper (`mvnw`) en Linux
Si al intentar arrancar el backend con Maven encuentras un error de permisos, asegúrate de otorgar permisos de ejecución al script ejecutable ejecutando:
```bash
chmod +x mvnw
```

### 2. Instalación de Dependencias Node.js en Entorno Monorepo / Workspaces
El proyecto utiliza npm workspaces. Para evitar errores como `Cannot find module 'firebase/app'` o faltantes en `node_modules/`, **siempre debes ejecutar la instalación desde la raíz del proyecto** y no solo dentro de `bomerp-frontend/`:
```bash
# Desde la raíz del proyecto (EDUWJ/)
npm install
```
Esto asegura que paquetes globales de la raíz (`express`, `cors`, `tsx`, `firebase`) y del workspace frontend queden correctamente enlazados.

---

## ⚙️ Requisitos del Entorno

- **Node.js**: Versión 22.x LTS recomendada (`nvm install 22 && nvm use 22`).
- **Navegador**: Cualquier navegador moderno con soporte para Flexbox, CSS Grid y Backdrop-Filter.
# Calificación Independiente de Múltiples Tareas y Exámenes por Sesión

Este plan resuelve el problema donde calificar una segunda tarea o examen dentro de la misma sesión sobrescribe la nota de la primera actividad y deja la segunda en `0`. Además, organiza la revisión y edición de calificaciones agrupadas por sesión para mantener ordenadas tanto las entregas pendientes como las ya calificadas.

## User Review & Critical Decisions

> [!IMPORTANT]
> Se han incorporado tus respuestas de confirmación para garantizar que cada tarea y examen mantenga su nota propia e independiente y que el docente pueda revisar o reeditar cualquier nota organizada por sesión.

- **Decisión Confirmada 1 — Calificación Independiente por Actividad (`actividadId`)**: Cada tarea o examen publicado dentro de una misma sesión (`Tarea #1 - Sesión 37`, `Tarea #2 - Sesión 37`, etc.) almacena, consulta y actualiza su calificación de forma totalmente aislada mediante su identificador único (`actividadId` y `entregaId`), sin compartir estado en memoria ni sobrescribir otras actividades de la misma sesión.
- **Decisión Confirmada 2 — Organización por Sesión con Edición Habilitada**: Las tareas y exámenes con entregas (tanto pendientes de calificar como ya calificadas) permanecen accesibles y agrupadas por número de sesión, permitiendo al docente consultar y editar las notas en cualquier momento sin que desaparezcan ni se mezclen los campos de entrada.
- **Cálculo de Promedio Académico**: El promedio de tareas se calcula estrictamente como la sumatoria de las notas individuales de todas las tareas publicadas dividida entre el número total de tareas publicadas ($\frac{\sum \text{notas de tareas}}{\text{total de tareas}}$), y de forma análoga para los exámenes.

## 1. Overview & Core Concept

- **What It Does**: Garantiza que cuando un docente publica $N$ tareas y $M$ exámenes (incluso varios dentro de la misma sesión semanal) y el alumno entrega sus evidencias, cada entrega conserve su propia nota (`0` a `20`) en todos los módulos del sistema (Bandeja de Notificaciones por Sesión, Modal de Sesión, Sub-pestaña de Tareas del Curso y Portal del Alumno).
- **Target Audience / Persona**: Docentes de secundaria que gestionan múltiples evaluaciones por sesión y estudiantes que consultan sus calificaciones individuales y su promedio ponderado en tiempo real.
- **Key Value**: Elimina la colisión de identificadores y de inputs reactivos al calificar actividades consecutivas de una misma sesión, asegurando precisión en el registro de notas y en el cálculo del promedio general.

## 2. User Experience & Visual Design

- **Key User Flows**:
  1. **Creación y Entrega**: El docente asigna múltiples tareas o exámenes en una sesión (p. ej. `Tarea #1 - Sesión 37` y `Tarea #2 - Sesión 37`). El estudiante visualiza cada actividad por separado en *Deberes & Evaluaciones* y sube su archivo en cada una.
  2. **Calificación Independiente por Actividad**: Cuando el docente ingresa a calificar la primera tarea y guarda su nota (p. ej. `15/20`), y enseguida selecciona la segunda tarea y guarda su nota (p. ej. `10/20`), cada input y cada botón de guardado envía explícitamente el `actividadId` y `entregaId` correspondientes a esa actividad específica.
  3. **Bandeja Organizada por Sesión**: En la bandeja de *Notificaciones & Entregas* y en *Sesiones por Calendario*, las actividades se agrupan ordenadamente por sesión, mostrando el estado de cada tarea (`Pendiente de calificar` o `Calificada: Nota/20`) y permitiendo reeditar cualquier calificación sin perder el foco de la actividad seleccionada.
  4. **Reflejo Inmediato en el Portal del Alumno**: El alumno observa en *Deberes & Evaluaciones* y en *Calificaciones Oficiales* la nota exacta de `Tarea #1` (`15/20`) y la nota exacta de `Tarea #2` (`10/20`), junto con el promedio exacto de ambas (`12.5`).
- **Visual Identity & Theme**:
  - *Aesthetic Direction*: Interfaz académica limpia sobre lienzo claro (`#EEF2F7` / `#FFFFFF`) con jerarquía estructurada por sesión y actividad.
  - *Color Palette & Mood*: Superficies neutras en gris pizarra claro (`slate-50` / `slate-900`), acento principal en índigo (`#4F46E5`) para tareas, ámbar (`#D97706`) para exámenes y verde esmeralda (`#16A34A`) para entregas calificadas.
  - *Typography & Hierarchy*: Tipografía sans-serif de alta legibilidad (`Plus Jakarta Sans` / `DM Sans`) combinada con cifras tabulares (`tabular-nums`, `font-mono`) en todas las calificaciones (`0–20`), contadores de entregas y promedios ponderados.
  - *Component Styling & Layout*: Agrupadores claros por sesión con selectores de actividad de una sola línea (`whitespace-nowrap`) e indicadores semánticos explícitos para distinguir actividades calificadas de actividades pendientes.
- **Interactive Feedback & Motion**: Al guardar una calificación, el sistema mantiene activa la actividad que el docente está revisando (sin saltar ni resetear la vista hacia la primera tarea de la sesión) y muestra confirmación inmediata con la nota y el nuevo promedio actualizado.

## 3. Key Product Decisions & Trade-Offs

- **Decision 1: Indexación de Inputs de Notas por Clave Compuesta (`actividadId + alumnoId`)**
  - *Chosen Approach*: Reemplazar el mapa de notas indexado solo por alumno (`[alumnoId]`) o compartido globalmente por un diccionario indexado por actividad y alumno (`${actividadId}__${alumnoId}`), además de preservar la actividad activa tras sincronizar con el servidor.
  - *Why*: Anteriormente, al sincronizar las actividades del curso después de calificar, el estado reactivo recargaba por defecto la primera tarea de la lista (`tareasActivas[0]`) y sobrescribía `notasSesionInput`, provocando que al calificar la segunda tarea se enviara el `actividadId` de la primera tarea o se reiniciara la nota.
  - *Alternatives Considered*: Mantener un único estado por sesión fue descartado porque una sesión puede contener múltiples tareas y exámenes simultáneos.
- **Decision 2: Coincidencia Estricta por `entregaId` y `actividadId` en Backend y Frontend**
  - *Chosen Approach*: Exigir coincidencia exacta de `entregaId` o `actividadId` al calificar y al consultar entregas tanto en el servidor como en el cálculo de boleta del alumno, evitando cualquier búsqueda genérica solo por `numeroSesion` cuando existen múltiples actividades en la sesión.
  - *Why*: Garantiza que ninguna entrega herede ni reemplace la nota de otra actividad de la misma sesión.

## 4. Technical Architecture & Data Strategy *(Technical Reference)*

- **Architecture & Component Diagram**:
```
┌────────────────────────────────────────────────────────────────────────────┐
│                         PORTAL DOCENTE (Frontend)                          │
│                                                                            │
│  ┌──────────────────────────┐   ┌──────────────────────────┐               │
│  │  Bandeja Agrupada por    │   │  Modal de Sesión /       │               │
│  │  Sesión (Pendientes y    │   │  Sub-Pestaña de Tareas   │               │
│  │  Calificadas Editables)  │   │  (Selector actividadId)  │               │
│  └────────────┬─────────────┘   └─────────────┬────────────┘               │
│               │                               │                            │
│               ▼                               ▼                            │
│  ┌──────────────────────────────────────────────────────────────────────┐  │
│  │ Estado Reactivo Aislado por Actividad:                               │  │
│  │ • notasPorActividadInput[ `${actividadId}__${alumnoId}` ]            │  │
│  │ • Preserva actividadId activa al sincronizar (sin resetear a idx 0)  │  │
│  └──────────────────────────────────┬───────────────────────────────────┘  │
└─────────────────────────────────────┼──────────────────────────────────────┘
                                      │ POST /api/v1/docente/calificar-entrega
                                      │ { entregaId, actividadId, sesionId,
                                      │   alumnoId, nota, comentarioDocente }
                                      ▼
┌────────────────────────────────────────────────────────────────────────────┐
│                     SERVIDOR API (Express / Spring Boot)                   │
│                                                                            │
│  1. Localiza entrega estrictamente por `entregaId` o `(alumnoId+actividadId)`│
│  2. Registra `calificacion` en la actividad específica sin tocar las demás │
│  3. Recalcula `practica = Σ(notas tareas) / N_tareas_publicadas`           │
│  4. Recalcula `examenFinal = Σ(notas exámenes) / M_examenes_publicados`    │
└─────────────────────────────────────┬──────────────────────────────────────┘
                                      │
                                      ▼
┌────────────────────────────────────────────────────────────────────────────┐
│                         PORTAL ALUMNO (Frontend)                           │
│                                                                            │
│  • Empareja cada deber estrictamente por `actividadId`                     │
│  • Muestra `Nota/20` independiente en Tarea #1, Tarea #2, Examen #1, etc.  │
└────────────────────────────────────────────────────────────────────────────┘
```

- **Data Model & State**:
  - Cada actividad de sesión posee un `actividadId` único (`sesion_${numero}_${tipo}_${secuencia}`).
  - Cada entrega de alumno (`EntregaTareaAlumno`) almacena `id` (`entregaId`), `actividadId`, `sesionId`, `alumnoId` y `calificacion`.
  - El estado de edición de notas en el docente utiliza clave compuesta `${actividadId || sesionNum}__${alumnoId}` para que cambiar de tarea o desplegar varias actividades de una sesión nunca mezcle las calificaciones en pantalla.
- **Interactive Component & State Mapping**:
  - **Sincronización sin Pérdida de Foco**: Al terminar `calificarAlumnoEnSesion`, `sincronizarActividadesYEntregasCurso` respeta la actividad actualmente seleccionada en el modal (`formConfigSesion().actividadId`) o en la vista de tareas (`tareaSeleccionadaDocente().actividadId`), recargando únicamente las entregas de esa actividad específica.
  - **Agrupación por Sesión en Notificaciones**: La bandeja de entregas agrupa las actividades por sesión y conserva visibles tanto las pendientes como las calificadas (con filtro o indicador claro por sesión) para permitir su revisión y reedición en cualquier momento.
  - **Emparejamiento Estricto en Boleta del Alumno**: En el cálculo de `boletaCursos` y `generarSesionesAlumno`, la búsqueda de entregas locales y globales compara `String(s.actividadId) === String(actId)` en lugar de buscar solo por `s.numero === sesNum`.

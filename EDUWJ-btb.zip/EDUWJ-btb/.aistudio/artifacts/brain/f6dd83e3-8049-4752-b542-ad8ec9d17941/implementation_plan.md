# Estabilización de Dependencias y Compilación Angular (BomERP)

Plan de resolución para los fallos de resolución de dependencias peer en `npm install` (bug de npm 10.9.9 con vitest) y la unificación de la versión de TypeScript para compatibilidad con el compilador de Angular 22.

### User Review & Critical Decisions

> [!IMPORTANT]
> Se adoptan las soluciones más robustas y resilientes ante entornos limpios y pipelines CI/CD:
> - **Vitest**: Fijar `"vitest": "4.0.8"` exacto en `bomerp-frontend/package.json` junto con `.npmrc` (`legacy-peer-deps=true`) para garantizar que `npm install` nunca falle independientemente de la versión exacta de npm que use el contenedor.
> - **TypeScript**: Sincronizar `"typescript": "~6.0.2"` en el `package.json` raíz para que el hoisting de workspaces de npm provea exactamente la versión soportada por `@angular/compiler-cli` (TypeScript >=6.0.0 y <6.1.0).

---

### 1. Overview & Core Concept

- **Problema detectado 1**: En Node.js 22 (npm 10.9.9), la resolución del grafo de dependencias peer de `vitest@^4.0.8` provoca un error interno `#loadPeerSet: Cannot read properties of null (reading 'edgesOut')`.
- **Problema detectado 2**: El workspace raíz especificaba `typescript: ^5.7.3` mientras que `bomerp-frontend` requería `~6.0.2`. El mecanismo de hoisting ubicaba TS 5.9.3 en la raíz, provocando el fallo del compilador de Angular (`The Angular Compiler requires TypeScript >=6.0.0 and <6.1.0`).
- **Resultado esperado**: Instalación limpia (`npm install`) sin bloqueos de peer deps, compilación completa de Angular y TypeScript sin discrepancias (`npm run build`, `npm run lint`), y ejecución del servidor en puerto 3000.

---

### 2. User Experience & Visual Design

- No se alteran componentes visuales ni estilos de la aplicación.
- Se mantiene la interfaz Neo-Glass existente en el frontend Angular servida a través de Express.
- La experiencia de desarrollo y despliegue pasa a ser inmediata y reproducible en cualquier entorno con Node 22 y npm 10+.

---

### 3. Key Product Decisions & Trade-Offs

- **Fijación de versión exacta de Vitest (`4.0.8`)**:
  - *Enfoque*: Evita que el resolver de npm intente calcular el árbol de pares flotantes de vitest 4.1.x, eliminando de raíz la condición de carrera en `@npmcli/arborist`.
  - *Complemento*: Añadir `.npmrc` con `legacy-peer-deps=true` para garantizar compatibilidad defensiva.
- **Unificación de TypeScript en `~6.0.2` en la raíz**:
  - *Enfoque*: Actualizar `"typescript": "~6.0.2"` en `/package.json`.
  - *Por qué*: El hoisting de npm coloca un único binario de TypeScript en `node_modules/typescript` de la raíz. Al compartir la misma versión entre root y `bomerp-frontend`, `@angular/compiler-cli` encuentra exactamente TS 6.0.3.

---

### 4. Technical Architecture & Data Strategy

```
┌────────────────────────────────────────────────────────┐
│                   Root Workspace                       │
│  - package.json (typescript: ~6.0.2, tsx, express)    │
│  - .npmrc (legacy-peer-deps=true)                      │
│  - server.ts (Express API + Servidor estático SPA)     │
└───────────────────────────┬────────────────────────────┘
                            │
               Hoisting npm │ node_modules/typescript (6.0.3)
                            ▼
┌────────────────────────────────────────────────────────┐
│             bomerp-frontend (Angular 22)               │
│  - package.json (vitest: 4.0.8, typescript: ~6.0.2)    │
│  - @angular/compiler-cli (Valida TS >=6.0.0 <6.1.0)    │
│  - dist/bomerp-frontend/browser (Artefacto servido)    │
└────────────────────────────────────────────────────────┘
```

#### Tareas de Ejecución

1. **Actualizar `bomerp-frontend/package.json`**:
   - Cambiar `"vitest": "^4.0.8"` a `"vitest": "4.0.8"`.
2. **Actualizar root `package.json`**:
   - Cambiar `"typescript": "^5.7.3"` a `"typescript": "~6.0.2"`.
3. **Crear `.npmrc`**:
   - Agregar `legacy-peer-deps=true` en la raíz para evitar fallos de resolución en npm 10.9.x.
4. **Verificación**:
   - Ejecutar `install_applet_dependencies` para comprobar que `npm install` se completa sin errores.
   - Ejecutar `compile_applet` para validar que `@angular/compiler-cli` y `tsc` compilan exitosamente.
   - Ejecutar `lint_applet` (`tsc --noEmit`) para confirmar cero errores de tipado.

# BomERP SaaS — Sincronización Total con Oracle DB y Estado Inicial en Cero Absoluto

Este plan establece la arquitectura de depuración y conexión real de extremo a extremo entre el frontend en Angular y el backend en Spring Boot + Oracle Database (Docker), garantizando que el sistema inicie completamente en cero (conservando únicamente la cuenta maestra de SuperAdmin) y que cada institución creada opere con aislamiento estricto y persistencia 100 % real sin plantillas ni datos ficticios.

### User Review & Critical Decisions

> [!IMPORTANT]
> Se han consolidado las decisiones confirmadas para garantizar que tanto en el entorno local de Visual Studio Code (`ng serve` en puerto 4200 + Spring Boot en puerto 8080 + Docker Oracle DB) como en la nube el sistema funcione con persistencia real e inicie en cero absoluto.

- **Decisión Confirmada 1 — Entorno de Ejecución Local (VS Code + Docker)**: El frontend en Angular (`:4200`) y el backend en Spring Boot (`:8080`) conectado a Oracle DB (`:1521`) operarán con configuración CORS completa, resolución automática de base URL / proxy y soporte de cabeceras de autorización y trazabilidad sin bloqueos ni desconexiones.
- **Decisión Confirmada 2 — Limpieza Automática en el Primer Arranque y Persistencia Posterior**: Al iniciar el backend por primera vez sobre el contenedor Docker de Oracle DB, el inicializador purgará cualquier dato residual de pruebas previas (colegios, alumnos, docentes, horarios, notas, matrículas, cursos y cuentas secundarias), dejando únicamente la cuenta maestra de SuperAdmin (`jimyamanqui@gmail.com`). En reinicios posteriores, se conservarán intactos todos los registros creados por el usuario en Oracle DB.
- **Decisión Confirmada 3 — Eliminación Total de Datos Ficticios (Zero-Mock Policy)**: Todos los portales (SuperAdmin, Dirección, Secretaría, Docente, Alumno, Colaborador y Finanzas) mostrarán exclusivamente datos provenientes de Oracle DB. Al registrar un nuevo colegio, todas sus métricas, listas y horarios empezarán en `0`.

---

### 1. Overview & Core Concept

- **What It Does**: Plataforma ERP SaaS Multi-Colegio donde el propietario del sistema administra suscripciones institucionales mediante seguridad de dos factores (REZE Guard) y cada colegio suscrito obtiene su propio portal aislado (`/colegio/:slug`) con gestión real en Oracle DB de matrículas, plana docente, horarios sin cruces, calificaciones, asistencia y tesorería.
- **Target Audience / Persona**:
  - **SuperAdmin Maestro**: Propietario de la plataforma SaaS que supervisa colegios suscritos, ingresos recurrentes (MRR) y seguridad REZE.
  - **Directores y Secretarias Escolares**: Administradores de cada institución que registran cuentas, docentes, alumnos, cursos y horarios desde cero.
  - **Docentes, Alumnos y Colaboradores**: Usuarios finales de cada colegio que consultan su horario real, registran o revisan calificaciones, asistencias y pagos.
- **Key Value**: Confiabilidad transaccional absoluta donde ningún dato aparece pre-inventado ni mezclado entre colegios, y donde cada acción en el navegador impacta directamente las tablas de Oracle Database.

---

### 2. User Experience & Visual Design

- **Key User Flows**:
  1. **Primer Inicio del Sistema**: El sistema arranca con `0` colegios, `0` alumnos, `0` docentes, `0` cursos y `0` ingresos; solo existe la cuenta maestra `jimyamanqui@gmail.com`.
  2. **Adquisición y Aprovisionamiento de Colegio (`/adquirir`)**: Un director registra su colegio y recibe su URL institucional única (`/colegio/:slug`) y sus credenciales. Al iniciar sesión, todos los contadores del colegio inician en `0`.
  3. **Flujo Operativo Escolar en Cadena**:
     - Dirección o Secretaría crea cursos, contrata docentes (generando credenciales automáticas en Oracle DB) y matricula estudiantes.
     - Secretaría asigna bloques de horario validando choques en tiempo real contra Oracle DB.
     - El Docente ingresa a su portal y visualiza únicamente los cursos y horarios que le fueron asignados en su colegio, pudiendo registrar notas y asistencias reales.
     - El Alumno ingresa a su portal y consulta únicamente sus cursos reales, las notas registradas por su docente (sin promedios ni evaluaciones pre-llenadas) y su estado financiero real.
  4. **Cierre de Sesión Contextual**: Al cerrar sesión desde cualquier portal escolar, el usuario retorna directamente al login de su colegio (`/colegio/:slug`).

- **Visual Identity & Theme**:
  - *Aesthetic Direction*: Interfaz SaaS ejecutiva de alta densidad informativa, superficies limpias con bordes sutiles de `1px` y jerarquía clara para estados vacíos (*Empty States*) cuando los registros están en `0`.
  - *Color Palette & Mood*: Fondo neutro claro (`#F8FAFC` / `#FFFFFF`) con cabeceras oscuras de alto contraste (`#0F172A`), acentos primarios institucionales (`#10B981` esmeralda y `#2563EB` azul real) y colores semánticos estrictos: Verde (`#16A34A`) para cuentas activas/confirmadas, Ámbar (`#D97706`) para registros pendientes/borradores y Carmesí (`#DC2626`) para alertas o cruces horarios.
  - *Typography & Hierarchy*: Estructura tipográfica limpia con `Plus Jakarta Sans` para encabezados y navegación, combinada con `DM Sans` para tablas operativas y `JetBrains Mono` (`tabular-nums`) para montos financieros, promedios, códigos modulares, DNI y temporizadores REZE.
  - *Component Styling & Layout*: Diseño de panel lateral fijo ($240\text{px}$–$280\text{px}$) + barra superior con ruta contextual y acciones rápidas, respetando márgenes seguros (*Safe Area Insets*) en dispositivos móviles.

- **Interactive Feedback & Motion**:
  - Estados vacíos explícitos (*"0 registros en Oracle DB — Cree el primer registro para comenzar"*) con botón de acción directa en cada módulo cuando un colegio recién creado aún no tiene datos.
  - Notificaciones instantáneas al guardar, actualizar o eliminar en Oracle DB, actualizando los contadores y tablas sin recargar la página.

---

### 3. Key Product Decisions & Trade-Offs

- **Decision 1 — Inicialización Limpia por Única Vez con Sello Persistente en Oracle DB**:
  - *Chosen Approach*: Implementar en el proceso de arranque del backend un verificador de sello de inicialización en la entidad maestra de `SUPERADMIN`. Si el contenedor de Oracle DB contiene datos de pruebas previas y aún no posee el sello de limpieza inicial, se ejecuta una purga transaccional de todas las tablas operativas y se graba el sello. En los siguientes reinicios del servidor, el backend detecta el sello y conserva todos los datos que el usuario haya guardado. Además, se mantiene disponible la acción manual de reinicio a cero desde la consola maestra.
  - *Why*: Cumple exactamente con el requerimiento de limpiar la base de datos al iniciar por primera vez sin perder los datos que el usuario registre en sesiones posteriores.
  - *Alternatives Considered*: Usar `ddl-auto: create-drop` borraría los datos en cada reinicio de Spring Boot; no limpiar en el primer arranque dejaría basura previa en el volumen Docker.

- **Decision 2 — Aislamiento Multi-Tenant Estricto por `colegioId` en Todas las Consultas**:
  - *Chosen Approach*: Propagar y exigir el `colegioId` en todas las entidades y consultas de Usuarios, Alumnos, Personal, Contratos, Cursos, Aulas, Horarios, Notas, Asistencias y Finanzas, asegurando además que al crear cuentas de Secretaría, Docentes o Alumnos se hereden siempre `colegioId`, `nombreColegio` y `slugColegio`.
  - *Why*: Evita que al crear un segundo colegio o al consultar listados aparezcan registros huérfanos o pertenecientes a otra institución.

- **Decision 3 — Paridad de Contrato REST y Conectividad Directa/Proxy en Local**:
  - *Chosen Approach*: Configurar propiedades por defecto para CORS en Spring Boot (`http://localhost:4200`, `http://127.0.0.1:4200`, `http://localhost:3000`) junto con soporte completo en `SecurityConfig`, y dotar al cliente HTTP del frontend de resolución inteligente hacia `http://localhost:8080` cuando se ejecuta en el puerto `4200` si el proxy no está activo, además de completar todos los endpoints de sistema, pagos y módulos en Spring Boot.
  - *Why*: Garantiza que al clonar y levantar el proyecto en Visual Studio Code con `ng serve` o `npm start` y Docker arriba, todas las peticiones lleguen y se guarden en Oracle DB sin errores de CORS, `404` ni `PlaceholderResolutionException`.

---

### 4. Technical Architecture & Data Strategy *(Technical Reference)*

- **Architecture & Component Diagram**:

```
┌────────────────────────────────────────────────────────────────────────────┐
│                   FRONTEND ANGULAR (Puerto 4200 / 3000)                    │
│                                                                            │
│  ┌──────────────────┐  ┌──────────────────┐  ┌──────────────────────────┐  │
│  │ Portal Adquirir  │  │ Consola Maestra  │  │ Portales Institucionales │  │
│  │ & Login Colegio  │  │ & App Móvil REZE │  │ (Dir / Sec / Doc / Alum) │  │
│  └────────┬─────────┘  └────────┬─────────┘  └────────────┬─────────────┘  │
│           └─────────────────────┼─────────────────────────┘                │
│                                 ▼                                          │
│         ┌───────────────────────────────────────────────────────┐          │
│         │  HTTP Interceptor (JWT + Trace-ID + Tenant Context)   │          │
│         └───────────────────────┬───────────────────────────────┘          │
└─────────────────────────────────┼──────────────────────────────────────────┘
                                  │ REST JSON (/api/v1/*)
                                  ▼
┌────────────────────────────────────────────────────────────────────────────┐
│                BACKEND SPRING BOOT 3 (Puerto 8080) + CORS                  │
│                                                                            │
│  ┌──────────────────────┐  ┌──────────────────────┐  ┌──────────────────┐  │
│  │ DataInitializer      │  │ Controladores SaaS,  │  │ Controladores    │  │
│  │ (Purga 1ra vez +     │  │ Auth, Usuarios y     │  │ Académicos,      │  │
│  │  Solo SuperAdmin)    │  │ Sistema (/reset)     │  │ Horarios y Notas │  │
│  └──────────┬───────────┘  └──────────┬───────────┘  └────────┬─────────┘  │
│             └─────────────────────────┼───────────────────────┘            │
│                                       ▼                                    │
│                     ┌───────────────────────────────────┐                  │
│                     │ Spring Data JPA / Hibernate       │                  │
│                     └─────────────────┬─────────────────┘                  │
└───────────────────────────────────────┼────────────────────────────────────┘
                                        │ JDBC (jdbc:oracle:thin:@localhost:1521/FREEPDB1)
                                        ▼
┌────────────────────────────────────────────────────────────────────────────┐
│             DOCKER ORACLE DATABASE 23c FREE (Esquema BOMERP_APP)           │
│                                                                            │
│  [USUARIOS] ── [COLEGIOS_SAAS] ── [PERSONAL_ESCOLAR] ── [CONTRATOS_DOC]    │
│      │                │                                        │           │
│  [ALUMNOS] ─── [BLOQUES_HORARIO] ── [CURSOS / AULAS] ────── [NOTAS]        │
└────────────────────────────────────────────────────────────────────────────┘
```

- **Data Model & State**:
  - **Cuenta Maestra Única (`USUARIOS`)**: `jimyamanqui@gmail.com` (clave `jimy`, rol `SUPERADMIN`), protegida contra borrado y marcada tras la depuración inicial para preservar los datos creados posteriormente.
  - **Institución Suscrita (`COLEGIOS_SAAS`)**: Almacena `id`, `nombreColegio`, `slug`, `urlAcceso`, `directorUsername`, `mesesActivo`, `cuotaActual`, `totalAbonado` y `estado`. No devuelve colegios simulados cuando no existe coincidencia.
  - **Entidades Escolares Aisladas por `colegioId`**:
    - `USUARIOS`: Cuentas de Director (`ADMIN`), `SECRETARIA`, `PROFESOR`, `ALUMNO` y `COLABORADOR` vinculadas a `colegioId`, `nombreColegio` y `slugColegio`.
    - `PERSONAL_ESCOLAR` y `CONTRATOS_DOCENTES`: Docentes y personal administrativo/apoyo con tarifa por hora y horas semanales calculadas desde bloques reales.
    - `ALUMNOS`, `MATRICULAS`, `CURSOS`, `AULAS`, `BLOQUES_HORARIO`, `NOTAS`, `JUSTIFICACIONES_INASISTENCIA`: Todas las tablas inician con `0` filas y se filtran estrictamente por el `colegioId` activo.

- **Interactive Component & State Mapping**:
  - **Inicialización y Reset (`/api/v1/sistema/reset` y `/api/v1/saas/guard/limpiar-sistema-movil`)**: Limpian de forma transaccional todas las tablas en Oracle DB dejando solo a `jimyamanqui@gmail.com` y actualizan en vivo los indicadores a `0`.
  - **Portal Alumno (`PortalAlumnoComponent`)**: Construye la boleta de cursos y el horario semanal únicamente a partir de los bloques horarios y notas reales registrados en Oracle DB para el grado, sección y `colegioId` del estudiante; si el docente aún no ha registrado calificaciones, las notas se muestran como pendientes (`0` / `—`) en lugar de valores ficticios.
  - **Portal Docente (`PortalDocenteComponent`)**: Lista únicamente los cursos y salones asignados al docente en `BLOQUES_HORARIO` dentro de su `colegioId`, permitiendo guardar notas reales en la tabla `NOTAS` y asistencias por sesión.
  - **Portal Secretaría y Dirección (`PortalSecretariaComponent` / `AdminComunidadComponent`)**: Filtran todas las consultas por el `colegioId` del usuario autenticado, muestran la remuneración y métricas financieras reales calculadas desde la base de datos y sincronizan la creación de cursos, docentes, alumnos y horarios directamente con Oracle DB.

# Implementation Plan - Portal Docente Enhancements

## User Requirements Addressed
1. **Neumorphism in Portal Docente**: Apply Soft UI neumorphic design (soft shadows, inset inputs, clean rounded cards) across all elements.
2. **'Mis Cursos' as Default Tab & Compact Schedule**: Replace the standalone 'Notas' tab with 'Mis Cursos'. Display a compact schedule showing the teacher's courses, days, and rooms directly in this view.
3. **Interactive Course Module**: Clicking a course in the compact schedule replaces the central content with a detailed course view containing internal tabs for **Asistencia** (Presente, Falta, Tardanza, Falta Justificada), **Calificaciones**, and **Actas**.

---

## Proposed Changes

### 1. `portal-docente.ts`
- **State Management**:
  - Update `tabActiva` to use `'mis-cursos'` instead of `'notas'`.
  - Add a new state signal `cursoEnEdicion` (`DocenteCurso | null`) or `vistaModuloCurso` (`'lista' | 'detalle'`) to handle switching between the course list and the specific course module.
  - Add attendance state storage per course/student (`asistenciaEstudiantes` map or property on students).
  - Add internal tab state for the course module (`subTabCurso = signal<'asistencia' | 'notas' | 'config'>('asistencia')`).

### 2. `portal-docente.html`
- **Tab Bar**:
  - Replace `'notas'` tab with `'mis-cursos'` (labeled "Mis Cursos").
- **'Mis Cursos' View**:
  - Neumorphic wrapper.
  - Compact schedule section ("Pequeño Horario") showing the teacher's weekly sessions with days, times, and classrooms. Clicking any session/course triggers the detailed course view.
  - List of assigned courses with quick actions.
- **Detailed Course Module (Full View Replacement)**:
  - When `cursoEnEdicion()` is active, render a comprehensive view with:
    - Back button ("Volver a Mis Cursos").
    - Course header (Name, Grade, Section, Room, Schedule).
    - Internal sub-tabs: `Asistencia`, `Calificaciones`, `Cierre de Acta`.
    - **Asistencia Sub-Tab**: Table of students with radio/select buttons for `Presente`, `Falta`, `Tardanza`, `Falta Justificada`.
    - **Calificaciones Sub-Tab**: Existing practice, exam, and final grade inputs with real-time average calculation and saving.

### 3. `portal-docente.css`
- **Neumorphic Enhancements**:
  - Add `.neo-container`, `.neo-card-inset`, `.neo-chip`, `.neo-toggle` styles to unify the soft UI aesthetic across the entire teacher portal.
  - Style the attendance status buttons/tags (`Presente`, `Falta`, `Tardanza`, `Falta Justificada`) with distinct neumorphic states.

---

## Verification Plan
1. Compile applet using `compile_applet`.
2. Verify UI rendering and responsiveness.
3. Test switching between tabs and clicking courses to enter the attendance/grades module.

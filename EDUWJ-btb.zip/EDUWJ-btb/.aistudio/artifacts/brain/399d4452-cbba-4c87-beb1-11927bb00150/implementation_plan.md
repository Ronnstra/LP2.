# Sincronización de Promedios, Conteo Exacto de Sesiones y Visor de Archivos en Entregas de Tareas

Este plan resuelve la discrepancia de notas entre la tarjeta de **Mis Asignaturas Matriculadas** y el interior del curso (ej. **cálculo**), corrige el promedio de asistencia y actividades para que divida únicamente entre las sesiones realmente registradas/publicadas, y habilita la subida, persistencia y visualización real de imágenes y archivos entre el Portal del Alumno y el Portal del Docente (tanto en el backend Spring Boot en Visual Studio Code como en el servidor Node).

## Revisión y Decisiones Confirmadas

> [!IMPORTANT]
> Se identificaron las causas exactas de los problemas mostrados en tus capturas y en Visual Studio Code:
> 1. **Por qué salía `1.1` en Asistencia y `5.6` vs `0.3` en Cálculo**: En el backend Java (`AlumnoController`), las sesiones sin asistencia se marcan como `SIN_REGISTRO`. El portal del alumno solo excluía `PENDIENTE`, por lo que dividía los puntos de las 4 asistencias registradas entre las **24 sesiones totales** (`26 / 24 = 1.1`) en lugar de dividir entre las **4 sesiones registradas**. Además, la tarjeta exterior leía notas antiguas de base de datos antes de cargar las tareas publicadas de las sesiones.
> 2. **Por qué no se guardaba la tarea en Visual Studio Code**: En `PersonalController.java`, el endpoint `POST /api/v1/alumno/entregar-tarea` devolvía éxito sin guardar la entrega en el almacén de `DocenteController.java`, y además comparaba `Long` contra `Integer` en Java (`Objects.equals`), haciendo que las entregas nunca aparecieran para el docente ni para el alumno.
> 3. **Visualización de imágenes y archivos subidos**: Al seleccionar un archivo desde la PC, ahora se captura su contenido real (`DataURL / Base64`) junto con su nombre y tipo MIME, permitiendo previsualizar imágenes directamente en pantalla y abrir/descargar PDFs o documentos en el Portal del Docente y en el Portal del Alumno.

- **Regla de Conteo por Criterio**:
  - **Asistencia**: Si de 20 o 24 sesiones el docente solo subió 4 o 5 asistencias (`PRESENTE` = 20, `TARDANZA` = 13, `FALTA` = 0, `JUSTIFICADA` = 16), se suman únicamente esas sesiones registradas y se dividen entre esas 4 o 5 sesiones (ignorando `PENDIENTE` y `SIN_REGISTRO`). Luego se multiplica por el porcentaje de Asistencia.
  - **Tareas**: Si en todas las sesiones solo se publicaron $N$ tareas (`TAREA`), se suman las notas de esas $N$ tareas publicadas y se dividen entre $N$. Luego se multiplica por el porcentaje de Tareas.
  - **Exámenes**: Si solo se publicaron $M$ exámenes (`EXAMEN`), se suman sus notas y se dividen entre $M$, multiplicándose por el porcentaje de Examen Final.
  - **Sincronización Total**: El cálculo se ejecuta con los mismos datos desde que carga **Mis Asignaturas Matriculadas**, garantizando que el promedio en la tarjeta del curso (ej. `cálculo`) coincida exactamente con el promedio y desglose al entrar al curso.

---

## 1. Resumen y Concepto Central

- **Qué hace**: Unifica el motor de cálculo académico en el backend (Spring Boot + Express) y en el frontend Angular para que las tarjetas de cursos y el detalle interno muestren exactamente las mismas notas, y conecta el flujo completo de subida y visualización de evidencias (imágenes, PDFs, documentos) entre alumno y docente.
- **Valor Principal**: Elimina cualquier diferencia entre vistas, respeta el promedio real sobre las sesiones dictadas y tareas publicadas, y permite que el docente vea en pantalla la imagen o documento real que subió el alumno antes de asignarle su calificación.

---

## 2. Experiencia de Usuario y Diseño Visual

- **Flujo de Subida y Previsualización de Evidencia (Alumno $\rightarrow$ Docente)**:
  1. El docente publica una Tarea o Examen en cualquier sesión del curso.
  2. El alumno entra a **Deberes**, selecciona una imagen (`.png`, `.jpg`, `.webp`) o documento (`.pdf`, `.docx`) desde su PC y ve una **vista previa instantánea** de su imagen o archivo antes de confirmar el envío.
  3. Al hacer clic en **Subir y Entregar Tarea**, la entrega se persiste en el backend (incluyendo la imagen/archivo codificado) y el estado pasa inmediatamente a **ENTREGADA**.
  4. El docente entra a su curso (pestaña **Tareas**, modal de la **Sesión** o bandeja de **Notificaciones**), visualiza la miniatura/imagen subida por el alumno con opción de ampliarla o abrir el documento adjunto, e ingresa la nota sobre 20.
- **Identidad Visual y Estética**:
  - Superficies neomórficas suaves (`#eef2f7`) con tipografía numérica tabular (`tabular-nums`) para promedios, porcentajes y conteos de sesiones.
  - Visor integrado de evidencias con marco limpio para imágenes adjuntas y botón de apertura/descarga para archivos PDF o Word.

---

## 3. Decisiones Técnicas Clave

- **Almacén Compartido y Persistente de Actividades y Entregas en Spring Boot (`bomerp-backend`)**:
  - *Enfoque elegido*: Unificar el almacenamiento de actividades por sesión y entregas de tareas entre `DocenteController`, `PersonalController` y `AlumnoController` en el backend Java (con comparación numérica segura `Long.valueOf(...)` e inclusión de actividades/entregas dentro de `GET /api/v1/matricula/alumnos/mi-perfil` y `GET /api/v1/docente/cursos`).
  - *Por qué*: Cuando pruebas el sistema en Visual Studio Code con Spring Boot, `PersonalController` recibía la entrega del alumno pero no la guardaba en `DocenteController`. Al compartir el estado y devolver las actividades y entregas desde `mi-perfil`, tanto la tarjeta de `Mis Asignaturas Matriculadas` como el interior del curso calculan exactamente el mismo promedio desde el primer instante.
- **Captura y Renderizado de Archivos (`FileReader DataURL`)**:
  - *Enfoque elegido*: Leer el archivo seleccionado en el navegador mediante `FileReader.readAsDataURL(file)` y guardar `archivoUrl` (Base64 DataURL) y `archivoTipo` junto con `archivoNombre`.
  - *Por qué*: Permite que las imágenes y documentos subidos desde la PC se muestren inmediatamente al docente sin requerir servidores externos de almacenamiento en la nube.

---

## 4. Arquitectura Técnica y Flujo de Datos

```
┌────────────────────────────────────────────────────────────────────────────┐
│                        PORTAL DEL ALUMNO (Angular)                         │
│  1. Carga inicial (mi-perfil + actividades + entregas de todos los cursos) │
│  2. Tarjeta "Mis Asignaturas" === Vista interna "Calificaciones Oficiales" │
│  3. Selección de archivo PC -> FileReader (DataURL) -> Vista previa imagen │
└─────────────────────────────────────┬──────────────────────────────────────┘
                                      │ POST /api/v1/alumno/entregar-tarea
                                      ▼ (archivoNombre, archivoUrl, comentario)
┌────────────────────────────────────────────────────────────────────────────┐
│              BACKEND UNIFICADO (Spring Boot Java & Node Server)            │
│  • Asistencia: Promedio solo de sesiones registradas (!= PENDIENTE/SIN_REG)│
│  • Tareas:     Promedio solo de tareas publicadas en sesiones              │
│  • Exámenes:   Promedio solo de exámenes publicados en sesiones            │
│  • Entregas:   Almacén compartido Alumno <-> Docente con archivoUrl Base64 │
└─────────────────────────────────────┬──────────────────────────────────────┘
                                      │ GET /api/v1/docente/entregas
                                      ▼ POST /api/v1/docente/calificar-entrega
┌────────────────────────────────────────────────────────────────────────────┐
│                        PORTAL DEL DOCENTE (Angular)                        │
│  • Ve la imagen/archivo subido por el alumno en Sesión, Tareas y Bandeja   │
│  • Califica (0 - 20) y actualiza el promedio ponderado en tiempo real      │
└────────────────────────────────────────────────────────────────────────────┘
```

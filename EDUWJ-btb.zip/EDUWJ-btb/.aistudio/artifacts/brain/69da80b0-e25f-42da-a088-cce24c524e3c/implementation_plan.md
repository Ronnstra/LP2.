# Plan de Actualización de Documentación README (Windows y Linux en VS Code)

## Resumen del Proyecto y Objetivo
Revisar y actualizar exhaustivamente toda la documentación (`README.md` principal, `bomerp-backend/README.md` y `bomerp-frontend/README.md`) para proporcionar guías claras paso a paso sobre cómo instalar dependencias, configurar el entorno y ejecutar la aplicación tanto en **Windows** (PowerShell, CMD y VS Code) como en **Linux** (Ubuntu/Debian/Fedora y VS Code).

---

## 1. Actualización del README Principal (`/README.md`)
- **Sección de Prerrequisitos**: Guía explícita paso a paso para la instalación de Node.js 22 LTS (vía nvm-windows en Windows y nvm en Linux), Java 21 JDK (Amazon Corretto / Temurin) y Git.
- **Configuración en VS Code**: Extensiones recomendadas (Angular Language Service, Extension Pack for Java, Spring Boot Extension Pack, Tailwind CSS IntelliSense).
- **Descarga e Instalación de Dependencias**:
  - Comando raíz `npm install` y cómo descarga dependencias de Node.js.
  - Ejecución de `mvnw` / `mvnw.cmd` para resolver automáticamente las dependencias de Maven.
  - Gestión automática de Tailwind CSS y `node_modules`.
- **Instrucciones para Linux**:
  - Asignación de permisos de ejecución (`chmod +x ./mvnw`).
  - Comandos para terminal Bash/Zsh y VS Code Integrated Terminal.
- **Instrucciones para Windows**:
  - Ejecución en PowerShell y CMD usando `.\mvnw.cmd` y scripts npm.
  - Solución a políticas de ejecución de PowerShell (`Set-ExecutionPolicy -Scope Process -ExecutionPolicy Bypass`).
- **Puesta en Marcha**:
  - Modo A: Inicio unificado con un solo comando (`npm start`).
  - Modo B: Inicio con backend Spring Boot + Angular CLI + Docker Oracle/Keycloak.

---

## 2. Actualización del README de Backend (`/bomerp-backend/README.md`)
- **Instalación de Dependencias Java/Maven**: Explicación detallada del Maven Wrapper (`./mvnw` en Linux y `.\mvnw.cmd` en Windows) sin necesidad de instalar Maven de forma global.
- **Pasos para Linux**:
  - Requisitos JDK 21 (`JAVA_HOME`).
  - Levantamiento de infraestructura con Docker Compose (`docker compose -f compose-dev.yml up -d`).
  - Ejecución `./mvnw spring-boot:run`.
- **Pasos para Windows**:
  - Configuración de `JAVA_HOME` en Variables de Entorno de Windows.
  - Levantamiento con Docker Desktop o WSL2.
  - Ejecución `.\mvnw.cmd spring-boot:run`.
- **Integración en Visual Studio Code**:
  - Configuración del proyecto con las herramientas oficiales Java/Spring Boot para VS Code.

---

## 3. Actualización del README de Frontend (`/bomerp-frontend/README.md`)
- **Instalación de Dependencias Angular y Tailwind CSS**:
  - Ejecución de `npm install` dentro del directorio `bomerp-frontend/`.
  - Verificación del script `prestart` que valida e instala Tailwind CSS v3 automáticamente si falta.
- **Paso a Paso en Visual Studio Code**:
  - Apertura del directorio en VS Code.
  - Uso de la terminal integrada en Windows y Linux.
  - Ejecución de `npm start` (`ng serve` en puerto 4200 con proxy a backend).
  - Compilación de producción mediante `npm run build`.

---

## Verificación y Cierre
- Validación final con `compile_applet` para garantizar que la estructura del proyecto y los scripts sigan funcionando perfectamente.
- Presentación de resumen de cambios al usuario.

# Frontend LP2 (S7-S9) Adaptado al Portal Escolar: Matrícula, Deuda y Finanzas de Secundaria

Plan de arquitectura y desarrollo frontend para implementar las pautas de las **Sesiones S7, S8 y S9 de LP2** adaptadas a la realidad de un colegio de secundaria: **Gestión de Matrícula, Deuda Escolar y Contratos Financieros de Pensiones**, con estilo **Neo-Glass (Tailwind CSS)**.

---

### User Review & Critical Decisions

> [!IMPORTANT]
> Confirmaciones y aclaraciones del usuario:
> - **Dominio Real**: Colegio de secundaria (no hay créditos universitarios). La operación cabecera-detalle es la **Matrícula y Contrato Financiero de Pensiones**:
>   - **Cabecera**: Estudiante, Grado (1° a 5° de Secundaria), Periodo 2026, Costo de Matrícula, Modalidad, Deuda Contratada, Deuda Pendiente y Estado (`VIGENTE`, `ANULADO`).
>   - **Detalle Dinámico (`FormArray`)**: Cuotas mensuales (Marzo a Diciembre) y conceptos complementarios (Matrícula, Materiales, Seguro escolar, Talleres).
> - **Cálculos en Vivo (`computed`)**: Subtotales, Total Contratado, Total Pagado y Saldo Pendiente de cobro recalculados automáticamente al agregar/quitar cuotas o modificar montos.
> - **Estilo Visual**: **Neo-Glass con Tailwind CSS**, manteniendo las sombras suaves neomórficas, transparencias backdrop-filter y estética limpia del portal.

---

### 1. Overview & Core Concept

- **Qué hace**:
  1. **S7 (Arquitectura SPA y CRUD Independiente)**: Estructura `core/shared/features`, layout con navegación por estamentos escolares, `ApiService`, interceptor con `X-Trace-ID`, y gestión del catálogo de Grados y Secciones de Secundaria.
  2. **S8 (CRUD Dependiente con Selector)**: Gestión de Estudiantes con selector desplegable de Grado y Sección, validando dependencias y mostrando el aula asignada en la tabla.
  3. **S9 (Formulario Transaccional Cabecera-Detalle de Finanzas)**:
     - `ContratoMatriculaForm`: Formulario con `FormArray` dinámico de cuotas/pensiones escolares.
     - Permite agregar cuotas o conceptos adicionales, elegir fechas de vencimiento y montos.
     - `computed` reactivo para calcular la deuda total y el plan de pagos.
     - Diálogo de confirmación con el resumen financiero antes de comprometer la deuda.
     - `ReporteFinancieroMatricula`: Consulta con agregados reales (`totalRecaudado`, `deudaPendienteTotal`, `promedioPension`) y desglose de cuotas línea por línea por estudiante.
     - Transición de estado con anulación de contrato y reversión de deuda.

---

### 2. User Experience & Visual Design (Neo-Glass)

- **Flujo en el Formulario Transaccional de Matrícula y Finanzas**:
  1. La secretaria o administrador selecciona el alumno desde una lista desplegable o búsqueda rápida.
  2. El sistema autogenera las 10 pensiones escolares (Marzo a Diciembre) con montos sugeridos y permite agregar líneas adicionales (ej. Matrícula S/ 350, Seguro S/ 50, Taller de Robótica S/ 80).
  3. Las tarjetas y tabla de cuotas calculan en vivo:
     - 💳 **Total Contratado**: Suma de todas las cuotas generadas.
     - ⏳ **Deuda Pendiente**: Saldo por cobrar a la familia.
  4. Al pulsar **"Registrar Matrícula & Contrato"**, se abre el modal de confirmación con el resumen financiero:
     `"Vas a comprometer un contrato escolar de 10 cuotas por un total de S/ 4,500.00 para el estudiante Lucas Silva. ¿Confirmar?"`
  5. Una vez confirmado, se guarda atómicamente y redirige al **Reporte y Estado de Deudas**, donde se visualizan los agregados y el desglose de cuotas.

---

### 3. Key Product Decisions & Trade-Offs

- **Decisión 1: FormArray dinámico para cuotas y conceptos escolares**:
  - *Enfoque*: Cada línea del FormArray contiene `numeroCuota`, `concepto` (ej. "Pensión Marzo"), `monto`, `fechaVencimiento`.
  - *Por qué*: Cumple al 100% el requisito de S9 de detalle dinámico con agregar/quitar líneas, aplicado a la facturación y cobranza del colegio.
- **Decisión 2: Cálculos derivados con `computed` en el navegador**:
  - *Enfoque*: La suma de la deuda y totales se calcula reactivamente con `computed` a partir de `toSignal(form.controls.cuotas.valueChanges)`.
  - *Por qué*: Brinda feedback instantáneo al usuario sin llamadas innecesarias al backend mientras diseña el plan de pagos.
- **Decisión 3: Interceptor HTTP con `X-Trace-ID`**:
  - *Enfoque*: Cada solicitud saliente al backend (`http://localhost:8080` o `http://localhost:3000`) incluye un UUID único para correlacionar con los logs de Spring Boot y Loki.

---

### 4. Technical Architecture & Data Strategy

```
┌────────────────────────────────────────────────────────┐
│                   Navegador / Frontend                 │
│                 bomerp-frontend (Puerto 4200)          │
└───────────────────────────┬────────────────────────────┘
                            │
        1. Carga Alumnos    │ 2. Genera Cuotas Dinámicas
           y Grados         │    (FormArray + computed)
                            ▼
┌────────────────────────────────────────────────────────┐
│      Módulo Finanzas / Matrícula Escolar (S7-S9)       │
│                                                        │
│  ContratoMatriculaForm (FormArray de pensiones)       │
│  ├── computed: totalContratado, deudaTotal            │
│  └── confirmación explícita con resumen                │
│                                                        │
│  ReporteFinanzasMatriculaComponent                     │
│  ├── Agregados: totalRecaudado, deudaGlobal            │
│  └── Detalle de cuotas por estudiante                  │
└───────────────────────────┬────────────────────────────┘
                            │
               POST /api/v1/finanzas/contratos
               GET  /api/v1/finanzas/contratos/resumen
                            ▼
┌────────────────────────────────────────────────────────┐
│            Backend (Spring Boot 8080 / Node 3000)      │
│  - Control de Deuda, Cuotas y Matrícula Escolar        │
└────────────────────────────────────────────────────────┘
```

#### Plan de Componentes y Archivos en `bomerp-frontend`:

1. **Modelos TypeScript (`src/app/features/finanzas/contrato/contrato.model.ts`)**:
   - `CuotaMatriculaRequest`, `ContratoMatriculaRequest`
   - `CuotaMatriculaResponse`, `ContratoMatriculaResponse`
   - `ContratoResumen`, `ContratoAgregado`, `ContratoReporte`

2. **Servicio HTTP (`src/app/features/finanzas/contrato/contrato-service.ts`)**:
   - `crear(ContratoMatriculaRequest)`
   - `listar(estado, periodo, desde, hasta)`
   - `obtener(id)`
   - `anular(id)`
   - `reporte(estado, periodo, desde, hasta)`

3. **Formulario Transaccional (`src/app/features/finanzas/contrato/contrato-form.ts / .html`)**:
   - FormArray con cuotas dinámicas de pensión
   - Selección de alumno con previsualización de grado
   - Cálculos en vivo de cuotas y total deuda con `computed`
   - Validación de al menos una cuota y montos positivos
   - Diálogo de confirmación antes de comprometer la deuda escolar

4. **Vista de Reporte y Agregados (`src/app/features/finanzas/contrato/contrato-reporte.ts / .html`)**:
   - Tarjetas KPI: Total Contratado, Total Cobrado, Deuda Global Pendiente
   - Filtros por estado (`VIGENTE`, `ANULADO`) y rango de fechas
   - Tabla con desglose expandido de cuotas por alumno y botón de anular con reversión

5. **Rutas y Menú (`app.routes.ts` & `layout.html`)**:
   - Enlace directo a "Contratos & Pensiones" y "Nueva Matrícula Financiera" en el sidebar.

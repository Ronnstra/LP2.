export const openApiSpec = {
  openapi: '3.0.3',
  info: {
    title: 'BomERP - Sistema de Gestión Escolar API',
    version: '1.0.0',
    description:
      'Contrato REST completo y unificado para BomERP (Matrícula, Calificaciones, Asistencias, Personal, Docentes, Horarios, Finanzas y Autenticación). Los cambios realizados mediante esta interfaz Swagger UI se reflejan en tiempo real en el frontend.',
    contact: {
      name: 'Equipo de Desarrollo BomERP',
      email: 'soporte@bomerp.edu.pe',
    },
  },
  servers: [
    { url: '/', description: 'Servidor Local / AI Studio' },
    { url: 'http://localhost:8080', description: 'Servidor Spring Boot Local (Puerto 8080)' },
    { url: 'http://localhost:3000', description: 'Servidor Node.js (Puerto 3000)' },
  ],
  tags: [
    { name: 'Gestión de Usuarios y Administrador', description: 'Endpoints para el registro de administradores y gestión integral de usuarios' },
    { name: 'Seguridad y Autenticación', description: 'Inicio de sesión, verificación de credenciales y roles' },
    { name: 'Personal y Docentes', description: 'Gestión de plana docente, colaboradores escolares y contratos por hora' },
    { name: 'Matrícula - Alumnos', description: 'Registro de estudiantes, planes financieros, cuotas y perfil escolar' },
    { name: 'Calificaciones - Notas', description: 'Registro, consulta y cierre de actas de calificaciones' },
    { name: 'Asistencias y Justificaciones', description: 'Toma de asistencias por sesión y flujo de justificación de inasistencias' },
    { name: 'Horarios y Cargas Lectivas', description: 'Gestión de grillas horarias de secundaria, cursos y asignación de aulas' },
    { name: 'Finanzas y Tesorería', description: 'Resumen financiero institucional, liquidaciones de docentes y horas extra' },
    { name: 'Académico - Cursos', description: 'Catálogo de asignaturas escolares, control de aforo y vacantes disponibles (S1-S3)' },
    { name: 'Matrícula - Operación Cabecera-Detalle', description: 'Inscripción transaccional atómica de cursos con control de cupos y reportes agregados (S4-S5)' },
    { name: 'Administración del Sistema', description: 'Estado general del sistema y reinicio de base de datos' },
  ],
  paths: {
    '/api/v1/auth/login': {
      post: {
        tags: ['Seguridad y Autenticación'],
        summary: 'Iniciar sesión en el sistema',
        description: 'Autentica a un usuario por username y contraseña. Roles admitidos: ADMIN, PROFESOR, ALUMNO, SECRETARIA.',
        requestBody: {
          required: true,
          content: {
            'application/json': {
              schema: { $ref: '#/components/schemas/AuthRequest' },
              example: { username: 'edu', password: '123' },
            },
          },
        },
        responses: {
          200: {
            description: 'Autenticación exitosa',
            content: { 'application/json': { schema: { $ref: '#/components/schemas/AuthResponse' } } },
          },
          401: { description: 'Credenciales inválidas' },
        },
      },
    },
    '/api/v1/usuarios': {
      get: {
        tags: ['Gestión de Usuarios y Administrador'],
        summary: 'Listar todos los usuarios del sistema',
        description: 'Devuelve todos los usuarios registrados con su respectivo rol y estado.',
        responses: {
          200: {
            description: 'Lista de usuarios',
            content: {
              'application/json': {
                schema: { type: 'array', items: { $ref: '#/components/schemas/Usuario' } },
              },
            },
          },
        },
      },
      post: {
        tags: ['Gestión de Usuarios y Administrador'],
        summary: 'Crear un nuevo usuario en el sistema',
        description:
          'Registra un usuario con rol específico. Si se crea con rol PROFESOR o SECRETARIA o ALUMNO, se sincroniza automáticamente con el módulo correspondiente.',
        requestBody: {
          required: true,
          content: {
            'application/json': {
              schema: { $ref: '#/components/schemas/AdminRegisterRequest' },
              example: {
                username: 'prof_mario',
                password: '123',
                rol: 'PROFESOR',
                nombreCompleto: 'Mario Vargas Silva',
                email: 'mario@bomerp.edu.pe',
                telefono: '987654321',
                dni: '45678912',
                turno: 'MAÑANA',
              },
            },
          },
        },
        responses: {
          201: { description: 'Usuario creado exitosamente' },
          400: { description: 'Datos inválidos' },
          409: { description: 'El nombre de usuario ya existe' },
        },
      },
    },
    '/api/v1/usuarios/registrar-admin': {
      post: {
        tags: ['Gestión de Usuarios y Administrador'],
        summary: 'Registrar un nuevo usuario (Alias compatible Spring Boot)',
        description: 'Endpoint canónico de Spring Boot para crear usuarios administradores o con roles específicos.',
        requestBody: {
          required: true,
          content: {
            'application/json': {
              schema: { $ref: '#/components/schemas/AdminRegisterRequest' },
              example: {
                username: 'director_general',
                password: '123',
                rol: 'ADMIN',
                nombreCompleto: 'Dr. Alejandro Toledo Morales',
                email: 'director@bomerp.edu.pe',
                telefono: '912345678',
                dni: '10293847',
              },
            },
          },
        },
        responses: {
          201: { description: 'Administrador o usuario registrado' },
        },
      },
    },
    '/api/v1/usuarios/{id}': {
      put: {
        tags: ['Gestión de Usuarios y Administrador'],
        summary: 'Actualizar datos de un usuario',
        parameters: [{ name: 'id', in: 'path', required: true, schema: { type: 'integer' } }],
        requestBody: {
          required: true,
          content: {
            'application/json': {
              schema: {
                type: 'object',
                properties: {
                  nombreCompleto: { type: 'string' },
                  email: { type: 'string' },
                  telefono: { type: 'string' },
                  estado: { type: 'string', enum: ['ACTIVO', 'INACTIVO', 'PAUSADA'] },
                  password: { type: 'string' },
                },
              },
            },
          },
        },
        responses: { 200: { description: 'Usuario actualizado' } },
      },
      delete: {
        tags: ['Gestión de Usuarios y Administrador'],
        summary: 'Eliminar una cuenta de usuario',
        parameters: [{ name: 'id', in: 'path', required: true, schema: { type: 'integer' } }],
        responses: { 200: { description: 'Usuario eliminado' } },
      },
    },
    '/api/v1/personal': {
      get: {
        tags: ['Personal y Docentes'],
        summary: 'Listar personal escolar y docentes',
        parameters: [
          { name: 'estamento', in: 'query', required: false, schema: { type: 'string', enum: ['docentes', 'colaboradores'] } },
          { name: 'estadoAprobacion', in: 'query', required: false, schema: { type: 'string' } },
        ],
        responses: {
          200: {
            description: 'Lista de personal',
            content: { 'application/json': { schema: { type: 'array', items: { $ref: '#/components/schemas/Personal' } } } },
          },
        },
      },
      post: {
        tags: ['Personal y Docentes'],
        summary: 'Registrar nuevo docente o colaborador',
        description: 'Crea un docente o personal colaborador. Genera automáticamente una cuenta de usuario para inicio de sesión.',
        requestBody: {
          required: true,
          content: {
            'application/json': {
              schema: { $ref: '#/components/schemas/Personal' },
              example: {
                nombre: 'Carla',
                apellidos: 'Vega Benavides',
                dni: '48765432',
                cargo: 'DOCENTE',
                area: 'Comunicación y Literatura',
                telefono: '998877665',
                turno: 'MAÑANA',
                cursosEspecialidad: ['Lenguaje', 'Literatura'],
                tarifaHora: 35,
              },
            },
          },
        },
        responses: { 201: { description: 'Personal registrado exitosamente' } },
      },
    },
    '/api/v1/personal/{id}/confirmar': {
      put: {
        tags: ['Personal y Docentes'],
        summary: 'Ratificar y confirmar personal por Dirección',
        parameters: [{ name: 'id', in: 'path', required: true, schema: { type: 'integer' } }],
        responses: { 200: { description: 'Personal confirmado' } },
      },
    },
    '/api/v1/personal/{id}/rechazar': {
      put: {
        tags: ['Personal y Docentes'],
        summary: 'Rechazar solicitud de ingreso de personal',
        parameters: [{ name: 'id', in: 'path', required: true, schema: { type: 'integer' } }],
        responses: { 200: { description: 'Personal rechazado' } },
      },
    },
    '/api/v1/contratos-docentes': {
      get: {
        tags: ['Personal y Docentes'],
        summary: 'Listar todos los contratos docentes por hora',
        responses: { 200: { description: 'Lista de contratos' } },
      },
      post: {
        tags: ['Personal y Docentes'],
        summary: 'Crear o actualizar contrato docente por hora',
        requestBody: {
          required: true,
          content: {
            'application/json': {
              schema: {
                type: 'object',
                properties: {
                  docenteId: { type: 'integer' },
                  tarifaPorHora: { type: 'number', example: 35 },
                  horasSemanales: { type: 'number', example: 12 },
                  cursosAsignados: { type: 'array', items: { type: 'string' } },
                },
              },
            },
          },
        },
        responses: { 201: { description: 'Contrato formalizado' } },
      },
    },
    '/api/v1/matricula/alumnos': {
      get: {
        tags: ['Matrícula - Alumnos'],
        summary: 'Listar todos los alumnos matriculados',
        responses: {
          200: {
            description: 'Lista de alumnos',
            content: { 'application/json': { schema: { type: 'array', items: { $ref: '#/components/schemas/Alumno' } } } },
          },
        },
      },
      post: {
        tags: ['Matrícula - Alumnos'],
        summary: 'Matricular nuevo estudiante',
        description: 'Registra a un estudiante y crea su cuenta de usuario para acceder al Portal del Alumno.',
        requestBody: {
          required: true,
          content: {
            'application/json': {
              schema: { $ref: '#/components/schemas/Alumno' },
              example: {
                nombre: 'Mateo',
                apellidoPaterno: 'Guerrero',
                apellidoMaterno: 'Paz',
                dni: '79845612',
                fechaIngreso: '2026-03-01',
                grado: '5° Secundaria',
                seccion: 'A',
                costoMensual: 450,
                mesesPeriodo: 10,
                modalidadPago: 'MENSUAL',
              },
            },
          },
        },
        responses: { 201: { description: 'Alumno matriculado exitosamente' } },
      },
    },
    '/api/v1/matricula/alumnos/{id}': {
      get: {
        tags: ['Matrícula - Alumnos'],
        summary: 'Obtener expediente de un alumno por ID',
        parameters: [{ name: 'id', in: 'path', required: true, schema: { type: 'integer' } }],
        responses: { 200: { description: 'Expediente del alumno' } },
      },
    },
    '/api/v1/matricula/alumnos/{id}/pagar-cuota': {
      post: {
        tags: ['Matrícula - Alumnos'],
        summary: 'Registrar pago de pensión escolar',
        parameters: [{ name: 'id', in: 'path', required: true, schema: { type: 'integer' } }],
        requestBody: {
          required: true,
          content: {
            'application/json': {
              schema: {
                type: 'object',
                properties: { cuotaNumero: { type: 'integer', example: 1 } },
              },
            },
          },
        },
        responses: { 200: { description: 'Pago registrado exitosamente' } },
      },
    },
    '/api/v1/matricula/alumnos/mi-perfil': {
      get: {
        tags: ['Matrícula - Alumnos'],
        summary: 'Obtener datos completos del portal del alumno autenticado',
        responses: { 200: { description: 'Perfil, notas, horario y asistencias del alumno' } },
      },
    },
    '/api/v1/cursos': {
      get: {
        tags: ['Académico - Cursos'],
        summary: 'Listar cursos escolares con aforo y vacantes disponibles (S1-S3)',
        parameters: [
          { name: 'grado', in: 'query', required: false, schema: { type: 'string' }, example: '5° Secundaria' },
        ],
        responses: { 200: { description: 'Lista de asignaturas' } },
      },
      post: {
        tags: ['Académico - Cursos'],
        summary: 'Registrar nueva asignatura en el catálogo académico',
        requestBody: {
          required: true,
          content: {
            'application/json': {
              schema: {
                type: 'object',
                required: ['nombre', 'grado', 'creditos', 'vacantesMaximas'],
                properties: {
                  nombre: { type: 'string', example: 'Física Elemental' },
                  grado: { type: 'string', example: '5° Secundaria' },
                  creditos: { type: 'integer', example: 4 },
                  vacantesMaximas: { type: 'integer', example: 30 },
                  aula: { type: 'string', example: 'Laboratorio de Ciencias' },
                },
              },
            },
          },
        },
        responses: { 201: { description: 'Asignatura creada' } },
      },
    },
    '/api/v1/aulas': {
      get: {
        tags: ['Académico - Cursos'],
        summary: 'Listar aulas y ambientes escolares (Módulo No Transaccional #2)',
        description: 'Catálogo de salones, laboratorios, talleres de cómputo y auditorios del colegio.',
        responses: { 200: { description: 'Lista de aulas escolares' } },
      },
      post: {
        tags: ['Académico - Cursos'],
        summary: 'Registrar nuevo ambiente escolar o aula',
        requestBody: {
          required: true,
          content: {
            'application/json': {
              schema: {
                type: 'object',
                required: ['codigo', 'nombre'],
                properties: {
                  codigo: { type: 'string', example: 'A-103' },
                  nombre: { type: 'string', example: 'Aula 103 - Secundaria' },
                  pabellon: { type: 'string', example: 'Pabellón A - Piso 2' },
                  tipo: { type: 'string', enum: ['TEORICA', 'LABORATORIO', 'COMPUTO', 'AUDITORIO', 'POLIDEPORTIVO'], default: 'TEORICA' },
                  capacidad: { type: 'integer', example: 35 },
                  estado: { type: 'string', enum: ['DISPONIBLE', 'MANTENIMIENTO'], default: 'DISPONIBLE' },
                },
              },
            },
          },
        },
        responses: { 201: { description: 'Aula creada' } },
      },
    },
    '/api/v1/modulos/resumen-arquitectura': {
      get: {
        tags: ['Administración del Sistema'],
        summary: 'Resumen de Arquitectura: 3 Módulos Transaccionales (M:N) y 3 No Transaccionales',
        description: 'Retorna el inventario estructurado de los 3 módulos M:N y 3 catálogos maestros con entidades y reglas ACID.',
        responses: { 200: { description: 'Matriz de arquitectura' } },
      },
    },
    '/api/v1/matriculas': {
      get: {
        tags: ['Matrícula - Operación Cabecera-Detalle'],
        summary: 'Consultar matrículas escolares con filtros combinados y ordenamiento (S5)',
        parameters: [
          { name: 'estado', in: 'query', schema: { type: 'string', enum: ['REGISTRADA', 'ANULADA'] } },
          { name: 'periodo', in: 'query', schema: { type: 'string', example: '2026-I' } },
          { name: 'desde', in: 'query', schema: { type: 'string', example: '2026-03-01T00:00:00' } },
          { name: 'hasta', in: 'query', schema: { type: 'string', example: '2026-12-31T23:59:59' } },
          { name: 'ordenarPor', in: 'query', schema: { type: 'string', default: 'fecha' } },
          { name: 'direccion', in: 'query', schema: { type: 'string', enum: ['ASC', 'DESC'], default: 'DESC' } },
        ],
        responses: { 200: { description: 'Lista de matrículas con detalle' } },
      },
      post: {
        tags: ['Matrícula - Operación Cabecera-Detalle'],
        summary: 'Registrar matrícula escolar atómica con asignaturas (Operación Cabecera-Detalle S4)',
        description:
          'Inscribe al estudiante en una colección de asignaturas en una sola transacción. Valida aforo en cada curso vía CursoService.descontarVacante(); si no hay vacantes, responde 409 Conflict y revierte toda la operación (Rollback atómico).',
        requestBody: {
          required: true,
          content: {
            'application/json': {
              schema: {
                type: 'object',
                required: ['alumnoId', 'periodo', 'detalles'],
                properties: {
                  alumnoId: { type: 'integer', example: 1 },
                  periodo: { type: 'string', example: '2026-I' },
                  detalles: {
                    type: 'array',
                    items: {
                      type: 'object',
                      required: ['cursoId'],
                      properties: { cursoId: { type: 'integer', example: 1 } },
                    },
                  },
                },
              },
              example: {
                alumnoId: 1,
                periodo: '2026-I',
                detalles: [{ cursoId: 1 }, { cursoId: 2 }],
              },
            },
          },
        },
        responses: {
          201: { description: 'Matrícula inscrita exitosamente con vacantes descontadas' },
          409: { description: 'Conflicto: Vacante insuficiente en alguna asignatura (Rollback efectuado)' },
        },
      },
    },
    '/api/v1/matriculas/resumen': {
      get: {
        tags: ['Matrícula - Operación Cabecera-Detalle'],
        summary: 'Reporte estadístico de matrículas: agregados (COUNT, SUM) y detalle resumido (S5)',
        parameters: [
          { name: 'estado', in: 'query', schema: { type: 'string' } },
          { name: 'periodo', in: 'query', schema: { type: 'string' } },
          { name: 'desde', in: 'query', schema: { type: 'string' } },
          { name: 'hasta', in: 'query', schema: { type: 'string' } },
        ],
        responses: { 200: { description: 'Reporte agregado escolar' } },
      },
    },
    '/api/v1/matriculas/{id}': {
      get: {
        tags: ['Matrícula - Operación Cabecera-Detalle'],
        summary: 'Obtener ficha de matrícula completa con sus asignaturas inscritas por ID',
        parameters: [{ name: 'id', in: 'path', required: true, schema: { type: 'integer' } }],
        responses: { 200: { description: 'Ficha de matrícula' } },
      },
    },
    '/api/v1/calificaciones/notas': {
      get: {
        tags: ['Calificaciones - Notas'],
        summary: 'Listar todas las notas registradas',
        responses: { 200: { description: 'Lista general de calificaciones' } },
      },
      post: {
        tags: ['Calificaciones - Notas'],
        summary: 'Registrar una calificación',
        requestBody: {
          required: true,
          content: {
            'application/json': {
              schema: { $ref: '#/components/schemas/Nota' },
              example: {
                alumnoId: 1,
                evaluacion: 'Examen Bimestral I',
                valor: 18.5,
                ponderacion: 40,
                curso: 'Álgebra',
              },
            },
          },
        },
        responses: { 201: { description: 'Nota registrada' } },
      },
    },
    '/api/v1/calificaciones/notas/alumno/{alumnoId}': {
      get: {
        tags: ['Calificaciones - Notas'],
        summary: 'Listar notas de un alumno en particular',
        parameters: [{ name: 'alumnoId', in: 'path', required: true, schema: { type: 'integer' } }],
        responses: { 200: { description: 'Notas del alumno' } },
      },
    },
    '/api/v1/docente/cursos': {
      get: {
        tags: ['Calificaciones - Notas'],
        summary: 'Obtener cursos y actas asignadas al docente autenticado',
        parameters: [{ name: 'docenteId', in: 'query', schema: { type: 'integer' } }],
        responses: { 200: { description: 'Cursos a cargo del docente' } },
      },
    },
    '/api/v1/docente/notas': {
      post: {
        tags: ['Calificaciones - Notas'],
        summary: 'Carga rápida de nota desde el portal docente',
        requestBody: {
          required: true,
          content: {
            'application/json': {
              schema: {
                type: 'object',
                properties: {
                  alumnoId: { type: 'integer' },
                  evaluacion: { type: 'string' },
                  valor: { type: 'number' },
                  cursoId: { type: 'integer' },
                },
              },
            },
          },
        },
        responses: { 200: { description: 'Nota registrada' } },
      },
    },
    '/api/v1/docente/asistencia': {
      post: {
        tags: ['Asistencias y Justificaciones'],
        summary: 'Registrar asistencia de una sesión de clase',
        requestBody: {
          required: true,
          content: {
            'application/json': {
              schema: {
                type: 'object',
                properties: {
                  curso: { type: 'string', example: 'Álgebra' },
                  grado: { type: 'string', example: '5° Secundaria' },
                  seccion: { type: 'string', example: 'A' },
                  sesion: { type: 'integer', example: 1 },
                  asistencias: {
                    type: 'array',
                    items: {
                      type: 'object',
                      properties: {
                        alumnoId: { type: 'integer' },
                        estado: { type: 'string', enum: ['PRESENTE', 'FALTA', 'TARDANZA', 'JUSTIFICADA'] },
                      },
                    },
                  },
                },
              },
            },
          },
        },
        responses: { 200: { description: 'Asistencia grabada' } },
      },
    },
    '/api/v1/inasistencias/justificar': {
      post: {
        tags: ['Asistencias y Justificaciones'],
        summary: 'Enviar justificación de inasistencia (Alumno hacia Docente)',
        requestBody: {
          required: true,
          content: {
            'application/json': {
              schema: {
                type: 'object',
                properties: {
                  alumnoId: { type: 'integer' },
                  curso: { type: 'string' },
                  docenteId: { type: 'integer' },
                  fechaInasistencia: { type: 'string', example: '2026-04-10' },
                  motivo: { type: 'string', example: 'Salud / Cita Médica' },
                  descripcion: { type: 'string' },
                  comprobanteNombre: { type: 'string' },
                },
              },
            },
          },
        },
        responses: { 201: { description: 'Justificación enviada' } },
      },
    },
    '/api/v1/inasistencias/docente/{id}': {
      get: {
        tags: ['Asistencias y Justificaciones'],
        summary: 'Listar justificaciones pendientes de un docente',
        parameters: [{ name: 'id', in: 'path', required: true, schema: { type: 'integer' } }],
        responses: { 200: { description: 'Justificaciones recibidas' } },
      },
    },
    '/api/v1/inasistencias/{id}/resolver': {
      put: {
        tags: ['Asistencias y Justificaciones'],
        summary: 'Aprobar o rechazar justificación de inasistencia',
        parameters: [{ name: 'id', in: 'path', required: true, schema: { type: 'integer' } }],
        requestBody: {
          required: true,
          content: {
            'application/json': {
              schema: {
                type: 'object',
                properties: {
                  estado: { type: 'string', enum: ['APROBADA', 'RECHAZADA'] },
                  respuestaDocente: { type: 'string' },
                },
              },
            },
          },
        },
        responses: { 200: { description: 'Justificación resuelta' } },
      },
    },
    '/api/v1/horarios/cursos': {
      get: {
        tags: ['Horarios y Cargas Lectivas'],
        summary: 'Obtener catálogo oficial de cursos de secundaria',
        responses: { 200: { description: 'Lista de cursos' } },
      },
    },
    '/api/v1/horarios/secundaria/{grado}': {
      get: {
        tags: ['Horarios y Cargas Lectivas'],
        summary: 'Obtener grilla horaria semanal por grado de secundaria',
        parameters: [{ name: 'grado', in: 'path', required: true, schema: { type: 'string' } }],
        responses: { 200: { description: 'Grilla semanal de horarios' } },
      },
    },
    '/api/v1/horarios/todos': {
      get: {
        tags: ['Horarios y Cargas Lectivas'],
        summary: 'Listar todos los bloques horarios asignados',
        responses: { 200: { description: 'Todos los bloques horarios' } },
      },
    },
    '/api/v1/finanzas/resumen': {
      get: {
        tags: ['Finanzas y Tesorería'],
        summary: 'Obtener balance general de finanzas escolares',
        responses: { 200: { description: 'Resumen financiero' } },
      },
    },
    '/api/v1/sistema/estado': {
      get: {
        tags: ['Administración del Sistema'],
        summary: 'Estado actual de registros en la base de datos',
        responses: { 200: { description: 'Conteo de registros' } },
      },
    },
    '/api/v1/sistema/reset': {
      post: {
        tags: ['Administración del Sistema'],
        summary: 'Reiniciar la base de datos institucional',
        description: 'Permite alternar entre base en limpio (modo "limpio") o con datos institucionales (modo "demo").',
        requestBody: {
          content: {
            'application/json': {
              schema: {
                type: 'object',
                properties: { modo: { type: 'string', enum: ['limpio', 'demo'], default: 'demo' } },
              },
            },
          },
        },
        responses: { 200: { description: 'Base reiniciada' } },
      },
    },
  },
  components: {
    schemas: {
      AuthRequest: {
        type: 'object',
        required: ['username', 'password'],
        properties: {
          username: { type: 'string', example: 'edu' },
          password: { type: 'string', example: '123' },
        },
      },
      AuthResponse: {
        type: 'object',
        properties: {
          id: { type: 'integer' },
          username: { type: 'string' },
          rol: { type: 'string', enum: ['ADMIN', 'PROFESOR', 'ALUMNO', 'SECRETARIA'] },
          token: { type: 'string' },
          nombreCompleto: { type: 'string' },
          cargo: { type: 'string' },
          email: { type: 'string' },
          mensaje: { type: 'string' },
        },
      },
      AdminRegisterRequest: {
        type: 'object',
        required: ['username', 'password', 'nombreCompleto'],
        properties: {
          username: { type: 'string', example: 'prof_garcia' },
          password: { type: 'string', example: '123' },
          rol: { type: 'string', enum: ['ADMIN', 'PROFESOR', 'ALUMNO', 'SECRETARIA'], default: 'PROFESOR' },
          nombreCompleto: { type: 'string', example: 'Prof. Pedro García Mendoza' },
          cargo: { type: 'string', example: 'Docente de Matemáticas' },
          email: { type: 'string', example: 'pgarcia@bomerp.edu.pe' },
          telefono: { type: 'string', example: '987654321' },
          dni: { type: 'string', example: '45879632' },
          turno: { type: 'string', enum: ['MAÑANA', 'TARDE', 'COMPLETO'], default: 'MAÑANA' },
        },
      },
      Usuario: {
        type: 'object',
        properties: {
          id: { type: 'integer' },
          username: { type: 'string' },
          rol: { type: 'string' },
          estado: { type: 'string', enum: ['ACTIVO', 'INACTIVO', 'PAUSADA', 'ACTIVO_PROVISIONAL'] },
          estadoAprobacion: { type: 'string' },
          nombreCompleto: { type: 'string' },
          cargo: { type: 'string' },
          email: { type: 'string' },
          telefono: { type: 'string' },
          dni: { type: 'string' },
          turno: { type: 'string' },
          fechaRegistro: { type: 'string' },
        },
      },
      Personal: {
        type: 'object',
        required: ['nombre', 'apellidos', 'dni', 'cargo'],
        properties: {
          id: { type: 'integer' },
          nombre: { type: 'string', example: 'Carlos' },
          apellidos: { type: 'string', example: 'Mendoza Paredes' },
          dni: { type: 'string', example: '10293847' },
          cargo: { type: 'string', enum: ['DOCENTE', 'SECRETARIA', 'LIMPIEZA', 'COMEDOR', 'MANTENIMIENTO', 'SEGURIDAD'] },
          area: { type: 'string', example: 'Matemática y Ciencias' },
          telefono: { type: 'string', example: '987654321' },
          turno: { type: 'string', enum: ['MAÑANA', 'TARDE', 'COMPLETO'] },
          cursosEspecialidad: { type: 'array', items: { type: 'string' } },
          tarifaHora: { type: 'number', example: 35 },
          estadoAprobacion: { type: 'string', enum: ['CONFIRMADO', 'PENDIENTE', 'RECHAZADO'] },
        },
      },
      Alumno: {
        type: 'object',
        required: ['nombre', 'apellidoPaterno', 'dni', 'fechaIngreso', 'grado'],
        properties: {
          id: { type: 'integer' },
          nombre: { type: 'string', example: 'Juan Carlos' },
          apellidoPaterno: { type: 'string', example: 'Pérez' },
          apellidoMaterno: { type: 'string', example: 'Quispe' },
          dni: { type: 'string', example: '71234567' },
          fechaIngreso: { type: 'string', example: '2026-03-01' },
          grado: { type: 'string', example: '5° Secundaria' },
          seccion: { type: 'string', example: 'A' },
          estadoAprobacion: { type: 'string' },
          costoMensual: { type: 'number', example: 450 },
          mesesPeriodo: { type: 'integer', example: 10 },
          modalidadPago: { type: 'string', enum: ['MENSUAL', 'BIMESTRAL', 'CONTADO'] },
        },
      },
      Nota: {
        type: 'object',
        required: ['alumnoId', 'evaluacion', 'valor'],
        properties: {
          id: { type: 'integer' },
          alumnoId: { type: 'integer' },
          evaluacion: { type: 'string', example: 'Examen Parcial I' },
          valor: { type: 'number', example: 17.5 },
          ponderacion: { type: 'number', example: 30 },
          fechaRegistro: { type: 'string' },
          estado: { type: 'string', enum: ['REGISTRADA', 'CERRADA', 'PROVISIONAL'] },
        },
      },
    },
    securitySchemes: {
      KeycloakBearerAuth: {
        type: 'http',
        scheme: 'bearer',
        bearerFormat: 'JWT',
        description: 'Ingrese el token JWT emitido por Keycloak (realm bomerp) o el backend.',
      },
    },
  },
  security: [
    {
      KeycloakBearerAuth: [],
    },
  ],
};

export const swaggerUiHtml = `<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <title>BomERP REST API - Swagger UI</title>
  <link rel="stylesheet" href="https://unpkg.com/swagger-ui-dist@5.11.0/swagger-ui.css" />
  <link rel="icon" type="image/x-icon" href="/favicon.ico" />
  <style>
    body {
      margin: 0;
      padding: 0;
      background: #f8fafc;
      font-family: system-ui, -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
    }
    .topbar {
      background: #0f172a !important;
      padding: 12px 24px !important;
      border-bottom: 2px solid #3b82f6;
    }
    .topbar-wrapper {
      display: flex;
      align-items: center;
      justify-content: space-between;
      max-width: 1460px;
      margin: 0 auto;
    }
    .brand-title {
      color: #ffffff;
      font-size: 1.25rem;
      font-weight: 700;
      display: flex;
      align-items: center;
      gap: 10px;
    }
    .brand-badge {
      background: linear-gradient(135deg, #3b82f6, #2563eb);
      color: white;
      font-size: 0.75rem;
      padding: 3px 8px;
      border-radius: 9999px;
      font-weight: 600;
    }
    .sub-bar {
      background: #1e293b;
      color: #94a3b8;
      padding: 8px 24px;
      font-size: 0.875rem;
      display: flex;
      justify-content: space-between;
      align-items: center;
      border-bottom: 1px solid #334155;
    }
    .sub-bar a {
      color: #60a5fa;
      text-decoration: none;
      font-weight: 600;
      display: inline-flex;
      align-items: center;
      gap: 4px;
      padding: 4px 10px;
      background: rgba(59, 130, 246, 0.15);
      border-radius: 6px;
      border: 1px solid rgba(59, 130, 246, 0.3);
      transition: all 0.2s;
    }
    .sub-bar a:hover {
      background: rgba(59, 130, 246, 0.3);
      color: #ffffff;
    }
    .swagger-ui {
      max-width: 1460px;
      margin: 0 auto;
      padding: 20px 24px;
    }
    .swagger-ui .info {
      margin: 20px 0 30px;
    }
    .swagger-ui .info .title {
      font-size: 2rem;
      color: #0f172a;
    }
    .swagger-ui .btn.execute {
      background-color: #2563eb;
      border-color: #2563eb;
      color: #fff;
    }
    .swagger-ui .opblock.opblock-post {
      background: rgba(73, 204, 144, 0.08);
    }
  </style>
</head>
<body>
  <div class="topbar">
    <div class="topbar-wrapper">
      <div class="brand-title">
        <span>BomERP API REST</span>
        <span class="brand-badge">OpenAPI 3.0</span>
      </div>
    </div>
  </div>
  <div class="sub-bar">
    <span>💡 <strong>Conexión activa con el Frontend:</strong> Toda cuenta o registro creado aquí se refleja inmediatamente en el Frontend Escolar.</span>
    <a href="/" target="_blank">Abrir Frontend Escolar ↗</a>
  </div>
  <div id="swagger-ui"></div>
  <script src="https://unpkg.com/swagger-ui-dist@5.11.0/swagger-ui-bundle.js"></script>
  <script src="https://unpkg.com/swagger-ui-dist@5.11.0/swagger-ui-standalone-preset.js"></script>
  <script>
    window.onload = function() {
      window.ui = SwaggerUIBundle({
        url: "/v3/api-docs",
        dom_id: "#swagger-ui",
        deepLinking: true,
        presets: [
          SwaggerUIBundle.presets.apis,
          SwaggerUIStandalonePreset
        ],
        layout: "BaseLayout",
        defaultModelsExpandDepth: 2,
        defaultModelExpandDepth: 2,
        displayRequestDuration: true,
        docExpansion: "list"
      });
    };
  </script>
</body>
</html>
`;

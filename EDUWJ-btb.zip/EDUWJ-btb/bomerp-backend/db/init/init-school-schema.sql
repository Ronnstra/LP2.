-- =============================================================================
-- SCRIPT DE INICIALIZACIÓN DE ESQUEMA UNIFICADO - BOMERP (ORACLE DB 23c FREE)
-- =============================================================================
-- Nota: El contenedor gvenzl/oracle-free crea automáticamente el usuario BOMERP_APP.
-- Todas las tablas JPA de la aplicación se almacenan en el esquema BOMERP_APP
-- con persistencia real (ddl-auto: update) e inician en CERO ABSOLUTO,
-- excepto la única cuenta maestra SuperAdmin (jimyamanqui@gmail.com / jimy).

BEGIN
  BEGIN
    EXECUTE IMMEDIATE 'ALTER SESSION SET CONTAINER = FREEPDB1';
  EXCEPTION
    WHEN OTHERS THEN NULL;
  END;

  BEGIN
    EXECUTE IMMEDIATE 'GRANT UNLIMITED TABLESPACE TO BOMERP_APP';
  EXCEPTION
    WHEN OTHERS THEN NULL;
  END;
END;
/
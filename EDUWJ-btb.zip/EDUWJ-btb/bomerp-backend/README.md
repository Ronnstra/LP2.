# bomerp-backend - Sistema Escolar

Backend único de LP2 (Sistema Escolar): Spring Boot 4.0.7 + Spring Modulith,
organizado en módulos de negocio (transaccionales y no transaccionales) que integran la lógica escolar, financiera y académica. Ver [`../../CLAUDE.md`](../../CLAUDE.md) para las convenciones de arquitectura completas.

---

## 📚 Módulos del Sistema

### Módulos Transaccionales (Escritura, Transacciones Atómicas e Integridad de Datos)

1. **`matricula/inscripcion` (S4-S5 LP2)** - Operación Cabecera-Detalle de Matrícula & Cursos
   - `Matricula` entity (cabecera con alumnoId, periodo, fecha, estado, totalCreditos)
   - `DetalleMatricula` entity (colección de líneas de asignaturas)
   - **Regla ACID de Negocio**: Descuenta vacantes en tiempo real vía `CursoService.descontarVacante()`. Si algún curso no tiene cupo, lanza `VacanteInsuficienteException` (`409 Conflict`) y ejecuta **Rollback atómico**.
   - **Filtros & Reportes**: `GET /api/v1/matriculas` (con filtros `estado`, `periodo`, `desde`, `hasta`, `ordenarPor`, `direccion`) y `GET /api/v1/matriculas/resumen` (reporte con agregados `COUNT`, `SUM` y promedio).
   - Endpoints: `POST /api/v1/matriculas`, `GET /api/v1/matriculas`, `GET /{id}`, `GET /resumen`.

2. **`calificaciones/registro`** - Registro y Cierre de Notas
   - `Nota` entity con validación rango 0-20 y ponderación 0-100.
   - Cálculo de promedios bimestrales/trimestrales y cierre de acta.
   - Endpoints: `GET /api/v1/calificaciones/notas`, `POST`, `PUT /{id}`, `DELETE /{id}`, `GET /alumno/{alumnoId}`, `GET /estado/{estado}`, `PUT /cerrar/{id}`.

3. **`matricula/alumno`** - Gestión de Expedientes de Estudiantes (S1-S2)
   - `Alumno` entity con DNI único, grado, sección y plan financiero.
   - Operaciones: registrar, actualizar, eliminar, buscar por DNI.
   - Endpoints: `GET /api/v1/matricula/alumnos`, `POST`, `PUT /{id}`, `DELETE /{id}`, `GET /dni/{dni}`.

---

### Módulos No Transaccionales & Catálogos (Lectura, Consultas y Autenticación)

4. **`academico/curso` (S1-S3 LP2)** - Catálogo de Asignaturas Escolares
   - `Curso` entity (nombre, grado, créditos, vacantesDisponibles, vacantesMaximas, aula).
   - Exposición pública para otros módulos mediante `@NamedInterface("curso-service")` y `@NamedInterface("curso-dto")`.
   - Endpoints: `GET /api/v1/cursos`, `POST`, `PUT /{id}`, `DELETE /{id}`.

5. **`auth/seguridad`** - Autenticación y Control de Accesos (RBAC)
   - Integrado con **Keycloak OAuth2 / OpenID Connect** (puerto `38080`, realm `bomerp`).
   - Roles: `ADMIN` (cuenta maestra única del SaaS), `DIRECTOR`, `SECRETARIA`, `DOCENTE`, `ALUMNO` y `COLABORADOR`.
   - Endpoints: `POST /api/v1/auth/login`, `GET /verificar/{username}/{password}`.

6. **`reportes` & `finanzas`** - Resumen Institucional y Tesorería
   - Consultas de historial académico, ponderados, liquidaciones y balance de cobranzas.
   - Endpoints: `GET /api/v1/reportes/notas/alumno/{alumnoId}`, `GET /api/v1/finanzas/resumen`.

---

## 🏗️ Estructura del Proyecto (Spring Modulith)

```
bomerp-backend/
├── pom.xml                                  # Proyecto Maven unificado
└── src/main/java/pe/edu/upeu/bomerp/
    ├── BomerpBackendApplication.java
    ├── SecurityConfig.java                  # Resource Server OAuth2 JWT + Keycloak
    ├── CorsConfig.java                      # CORS permitido para http://localhost:4200 y :3000
    ├── OpenApiConfig.java                   # Swagger UI en /swagger-ui.html con Bearer Auth
    ├── academico/curso/                     # Módulo Académico (S1-S3)
    ├── matricula/                           # Módulo Matrícula & Alumnos (S4-S5)
    │   ├── alumno/
    │   └── inscripcion/                     # Operación Cabecera-Detalle
    ├── calificaciones/registro/            # Módulo Calificaciones
    ├── auth/seguridad/                      # Módulo Autenticación & Usuarios
    └── exception/                           # Manejador Global (400, 404, 409 Conflict)
```

---

## ⚡ Estado Actual

- ✅ **8 módulos escolares completos** (3 transaccionales + 5 de lectura/reportes).
- ✅ **Keycloak OAuth2 / OIDC** configurado en puerto `38080` (realm `bomerp`).
- ✅ **Oracle Database 23 Free** en puerto `1521` (esquema `BOMERP_APP`).
- ✅ **ModularityTests** en verde (Spring Modulith verifica las reglas de arquitectura).
- ✅ **Swagger UI interactivo** en `http://localhost:8080/swagger-ui.html` y `http://localhost:3000/swagger-ui.html`.

---

## 🛠️ Prerrequisitos & Ejecución Local

### Prerrequisitos
- **Java 21 LTS** (Maven Wrapper `./mvnw` incluido).
- **Docker & Docker Compose** (para Oracle DB y Keycloak).

### 1. Levantar la Infraestructura Docker (Oracle DB + Keycloak)
```bash
docker compose -f compose-dev.yml up -d
```
Contenedores creados:
- `bomerp-oracle`: Oracle Database 23 Free (`1521`).
- `bomerp-keycloak-db`: PostgreSQL 17 (`35432`).
- `bomerp-keycloak`: Keycloak 26 (`38080`, Consola: `jimyamanqui@gmail.com` / `jimy`).

### 2. Ejecutar la Aplicación Spring Boot
```bash
# Windows
.\mvnw.cmd spring-boot:run

# macOS/Linux
./mvnw spring-boot:run
```

### 3. Obtener Token JWT en Keycloak
```bash
curl -X POST http://localhost:38080/realms/bomerp/protocol/openid-connect/token \
  -H "Content-Type: application/x-www-form-urlencoded" \
  -d "grant_type=password&client_id=bomerp-frontend&username=jimyamanqui@gmail.com&password=jimy"
```
Cuenta oficial pre-cargada y blindada: `jimyamanqui@gmail.com` / `jimy` (Rol: `ADMIN`, único super admin). No hay cuentas demo.

> Reset inicial único: el backend usa el marcador `SISTEMA_MIGRACIONES` (`reset-inicial-v1`). Para un entorno realmente limpio, ejecuta `docker compose -f compose-dev.yml down -v` antes de `up -d`.

### 4. Ejecutar Pruebas Automatizadas
```bash
./mvnw clean test
```
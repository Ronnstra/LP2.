package pe.edu.upeu.bomerp;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.*;
import pe.edu.upeu.bomerp.asistencia.entity.Asistencia;
import pe.edu.upeu.bomerp.asistencia.repository.JustificacionInasistenciaRepository;
import pe.edu.upeu.bomerp.asistencia.service.AsistenciaService;
import pe.edu.upeu.bomerp.auth.seguridad.entity.Usuario;
import pe.edu.upeu.bomerp.auth.seguridad.repository.UsuarioRepository;
import pe.edu.upeu.bomerp.calificaciones.registro.entity.Nota;
import pe.edu.upeu.bomerp.calificaciones.registro.repository.NotaRepository;
import pe.edu.upeu.bomerp.horario.entity.BloqueHorario;
import pe.edu.upeu.bomerp.horario.repository.BloqueHorarioRepository;
import pe.edu.upeu.bomerp.matricula.alumno.dto.AlumnoRequest;
import pe.edu.upeu.bomerp.matricula.alumno.dto.AlumnoResponse;
import pe.edu.upeu.bomerp.matricula.alumno.entity.Alumno;
import pe.edu.upeu.bomerp.matricula.alumno.repository.AlumnoRepository;
import pe.edu.upeu.bomerp.matricula.alumno.service.AlumnoService;
import pe.edu.upeu.bomerp.matricula.alumno.service.PlanFinancieroService;

import java.util.*;
import java.util.stream.Collectors;

@Tag(name = "Matrícula - Alumnos")
@RestController
@RequestMapping("/api/v1/matricula")
@RequiredArgsConstructor
@Transactional
public class AlumnoController {

    private final AlumnoService alumnoService;
    private final AlumnoRepository alumnoRepository;
    private final UsuarioRepository usuarioRepository;
    private final BloqueHorarioRepository bloqueHorarioRepository;
    private final NotaRepository notaRepository;
    private final JustificacionInasistenciaRepository justificacionRepository;
    private final AsistenciaService asistenciaService;
    private final PlanFinancieroService planFinancieroService;

    @Operation(summary = "Lista todos los alumnos registrados (aislado por colegioId)")
    @GetMapping("/alumnos")
    public ResponseEntity<List<AlumnoResponse>> listar(@RequestParam(required = false) Long colegioId) {
        List<AlumnoResponse> todos = alumnoService.listar();
        if (colegioId != null) {
            todos = todos.stream()
                    .filter(a -> Objects.equals(colegioId, a.getColegioId()))
                    .collect(Collectors.toList());
        }
        return ResponseEntity.ok(todos);
    }

    @Operation(summary = "Listar matrículas pendientes de confirmación por Dirección")
    @GetMapping("/alumnos-pendientes")
    public ResponseEntity<List<Map<String, Object>>> listarPendientes(@RequestParam(required = false) Long colegioId) {
        List<Alumno> alumnos = alumnoRepository.findAll().stream()
                .filter(a -> colegioId == null || Objects.equals(colegioId, a.getColegioId()))
                .collect(Collectors.toList());
        List<Map<String, Object>> pendientes = new ArrayList<>();
        for (Alumno a : alumnos) {
            String usernameAlumno = "alumno_" + a.getDni();
            Usuario u = a.getColegioId() != null
                    ? usuarioRepository.findByUsernameIgnoreCaseAndColegioId(usernameAlumno, a.getColegioId()).orElse(null)
                    : usuarioRepository.findByUsernameIgnoreCase(usernameAlumno).orElse(null);
            if (u == null || "PENDIENTE".equalsIgnoreCase(u.getEstadoAprobacion())) {
                Map<String, Object> m = new LinkedHashMap<>();
                m.put("id", a.getId());
                m.put("nombre", a.getNombre());
                m.put("apellidoPaterno", a.getApellidoPaterno());
                m.put("apellidoMaterno", a.getApellidoMaterno());
                m.put("dni", a.getDni());
                m.put("fechaIngreso", a.getFechaIngreso());
                m.put("grado", a.getGrado());
                m.put("seccion", a.getSeccion() != null ? a.getSeccion() : "A");
                m.put("colegioId", a.getColegioId());
                m.put("estadoAprobacion", "PENDIENTE");
                m.put("diasDesdeRegistro", 0);
                m.put("username", u != null ? u.getUsername() : "alumno_" + a.getDni());
                m.put("passwordProvisional", u != null ? u.getPasswordHash() : "alumno" + a.getDni());
                m.put("estadoCuenta", "ACTIVO_PROVISIONAL");
                pendientes.add(m);
            }
        }
        return ResponseEntity.ok(pendientes);
    }

    @Operation(summary = "Confirmar matrícula de un alumno por Dirección")
    @PutMapping("/alumnos/{id}/confirmar")
    public ResponseEntity<?> confirmarAlumno(@PathVariable Long id) {
        Alumno a = alumnoRepository.findById(id).orElse(null);
        if (a == null) {
            return ResponseEntity.status(404).body(Map.of("message", "Alumno no encontrado"));
        }
        String usernameAlumno = "alumno_" + a.getDni();
        Optional<Usuario> usuarioAlumno = a.getColegioId() != null
                ? usuarioRepository.findByUsernameIgnoreCaseAndColegioId(usernameAlumno, a.getColegioId())
                : usuarioRepository.findByUsernameIgnoreCase(usernameAlumno);
        usuarioAlumno.ifPresent(u -> {
            u.setEstado("ACTIVO");
            u.setEstadoAprobacion("CONFIRMADO");
            usuarioRepository.save(u);
        });
        return ResponseEntity.ok(Map.of(
                "mensaje", "Matrícula del estudiante " + a.getNombre() + " " + a.getApellidoPaterno() + " ratificada por Dirección en Oracle DB.",
                "alumno", alumnoService.obtenerPorId(id)
        ));
    }

    @Operation(summary = "Obtener perfil académico del alumno autenticado sin datos ficticios")
    @GetMapping("/alumnos/mi-perfil")
    public ResponseEntity<Map<String, Object>> miPerfil(
            @RequestParam(required = false) Long alumnoId,
            @RequestParam(required = false) String dni,
            @RequestParam(required = false) Long colegioId,
            Authentication auth) {
        Alumno a = null;
        if (alumnoId != null) {
            a = alumnoRepository.findById(alumnoId).orElse(null);
        }
        if (a == null && dni != null && !dni.isBlank()) {
            a = alumnoRepository.findByDni(dni.trim()).orElse(null);
        }
        if (a == null && auth != null && auth.getName() != null) {
            String username = auth.getName();
            Usuario u = usuarioRepository.findByUsernameIgnoreCase(username).orElse(null);
            if (username.toLowerCase().startsWith("alumno_")) {
                String extractedDni = username.substring("alumno_".length());
                a = alumnoRepository.findByDni(extractedDni).orElse(null);
            } else if (u != null && u.getDni() != null) {
                a = alumnoRepository.findByDni(u.getDni()).orElse(null);
            }
        }

        if (a == null) {
            return ResponseEntity.ok(Map.of(
                    "alumno", Collections.emptyMap(),
                    "notas", List.of(),
                    "promedioPonderado", 0,
                    "totalEvaluaciones", 0,
                    "asistencia", Map.of("porcentaje", 0, "asistencias", 0, "faltas", 0, "tardanzas", 0, "justificadas", 0, "totalSesiones", 0),
                    "cursos", List.of(),
                    "horarioSemanal", List.of(),
                    "justificaciones", List.of(),
                    "estadoMatricula", "SIN_REGISTRO",
                    "periodoAcademico", "2026 - Bimestre II"
            ));
        }

        final Long colId = a.getColegioId();
        final String secc = a.getSeccion() != null ? a.getSeccion() : "A";
        List<BloqueHorario> bloques = bloqueHorarioRepository.findByGradoIgnoreCase(a.getGrado()).stream()
                .filter(b -> (colId == null || Objects.equals(colId, b.getColegioId()))
                        && (b.getSeccion() == null || b.getSeccion().equalsIgnoreCase(secc)))
                .collect(Collectors.toList());

        List<Asistencia> asistenciasAlumno = asistenciaService.listarPorAlumno(a.getId());
        List<Nota> notasAlumno = notaRepository.findByAlumnoId(a.getId());
        final int totalAlumnosColegio = (int) alumnoRepository.findAll().stream()
                .filter(al -> colId == null || Objects.equals(colId, al.getColegioId()))
                .count();

        Map<String, Map<String, Object>> cursosMap = new LinkedHashMap<>();
        long nextCursoId = 201L;
        for (BloqueHorario b : bloques) {
            String nombreCurso = b.getCurso() != null ? b.getCurso().trim() : "Asignatura";
            String grado = b.getGrado() != null ? b.getGrado().trim() : a.getGrado();
            String seccion = b.getSeccion() != null ? b.getSeccion().trim().toUpperCase() : secc;
            String key = nombreCurso.toLowerCase() + "__" + grado.toLowerCase() + "__" + seccion.toLowerCase();

            final long cId = nextCursoId++;
            Map<String, Object> curso = cursosMap.computeIfAbsent(key, k -> {
                Map<String, Object> nuevo = new LinkedHashMap<>();
                nuevo.put("id", cId);
                nuevo.put("nombre", nombreCurso);
                nuevo.put("grado", grado);
                nuevo.put("seccion", seccion);
                nuevo.put("docenteId", b.getDocenteId());
                nuevo.put("docente", b.getDocenteNombre());
                nuevo.put("aula", b.getAula() != null ? b.getAula() : "Aula Principal");
                nuevo.put("horario", b.getDia() + " " + b.getHoraInicio() + " - " + b.getHoraFin());
                return nuevo;
            });

            String horarioActual = String.valueOf(curso.get("horario"));
            if (!horarioActual.contains(b.getDia())) {
                curso.put("horario", horarioActual + " / " + b.getDia() + " " + b.getHoraInicio() + " - " + b.getHoraFin());
            }
        }

        final Long finalAlumnoId = a.getId();
        double sumaPromediosCursos = 0.0;
        int totalCursosCount = 0;

        for (Map<String, Object> curso : cursosMap.values()) {
            String nombreCurso = String.valueOf(curso.get("nombre"));
            String gradoCurso = String.valueOf(curso.get("grado"));
            Long cursoIdObj = DocenteController.toLong(curso.get("id"));

            List<Asistencia> delCurso = asistenciasAlumno.stream()
                    .filter(as -> as.getCurso() != null && DocenteController.coincideCurso(as.getCurso(), nombreCurso))
                    .toList();

            List<Map<String, Object>> actDelCurso = DocenteController.actividadesSesionMap.values().stream()
                    .filter(act -> DocenteController.coincideCurso(act.get("cursoNombre") != null ? act.get("cursoNombre") : act.get("curso"), nombreCurso))
                    .toList();

            List<Map<String, Object>> entDelCurso = DocenteController.entregasTareasMap.values().stream()
                    .filter(ent -> (Objects.equals(DocenteController.toLong(ent.get("alumnoId")), finalAlumnoId) || totalAlumnosColegio <= 1)
                            && DocenteController.coincideCurso(ent.get("cursoNombre") != null ? ent.get("cursoNombre") : ent.get("curso"), nombreCurso))
                    .toList();

            int maxSesion = 24;
            for (Asistencia as : delCurso) {
                if (as.getSesion() != null && as.getSesion() > maxSesion) maxSesion = as.getSesion();
            }
            for (Map<String, Object> act : actDelCurso) {
                Integer sNum = DocenteController.toInt(act.get("numeroSesion") != null ? act.get("numeroSesion") : act.get("sesion"));
                if (sNum != null && sNum > maxSesion) maxSesion = sNum;
            }
            for (Map<String, Object> ent : entDelCurso) {
                Integer sNum = DocenteController.toInt(ent.get("sesionId") != null ? ent.get("sesionId") : ent.get("tareaId"));
                if (sNum != null && sNum > maxSesion) maxSesion = sNum;
            }

            List<Map<String, Object>> historial = new ArrayList<>();
            for (int sesion = 1; sesion <= maxSesion; sesion++) {
                final int nroSesion = sesion;
                Asistencia registro = delCurso.stream()
                        .filter(as -> nroSesion == (as.getSesion() != null ? as.getSesion() : 0))
                        .findFirst()
                        .orElse(null);

                Map<String, Object> act = actDelCurso.stream()
                        .filter(x -> Objects.equals(DocenteController.toInt(x.get("numeroSesion") != null ? x.get("numeroSesion") : x.get("sesion")), nroSesion))
                        .findFirst()
                        .orElse(null);

                Map<String, Object> ent = entDelCurso.stream()
                        .filter(x -> Objects.equals(DocenteController.toInt(x.get("sesionId") != null ? x.get("sesionId") : x.get("tareaId")), nroSesion))
                        .findFirst()
                        .orElse(null);

                String est = registro != null && registro.getEstado() != null ? registro.getEstado().toUpperCase() : "PENDIENTE";
                String tipoAct = act != null ? String.valueOf(act.getOrDefault("tipoActividad", act.getOrDefault("actividadTipo", "NINGUNA"))) : "NINGUNA";
                String tituloAct = act != null ? String.valueOf(act.getOrDefault("actividadTitulo", act.getOrDefault("titulo", ""))) : "";
                String descAct = act != null ? String.valueOf(act.getOrDefault("actividadDescripcion", act.getOrDefault("descripcion", ""))) : "";
                String fechaLim = act != null ? String.valueOf(act.getOrDefault("fechaLimiteEntrega", act.getOrDefault("fechaFinEntrega", ""))) : "";

                Map<String, Object> sesionMap = new LinkedHashMap<>();
                sesionMap.put("numero", sesion);
                sesionMap.put("estado", est);
                sesionMap.put("fecha", registro != null && registro.getFechaRegistro() != null ? registro.getFechaRegistro().toString() : ("Sesión " + sesion));
                sesionMap.put("tipoActividad", tipoAct);
                sesionMap.put("actividadTipo", tipoAct);
                sesionMap.put("actividadTitulo", tituloAct);
                sesionMap.put("actividadDescripcion", descAct);
                sesionMap.put("fechaLimiteEntrega", fechaLim);
                sesionMap.put("fechaFinEntrega", fechaLim);
                sesionMap.put("entrega", ent);
                sesionMap.put("detalle", "PRESENTE".equals(est) ? "Asistencia registrada puntualmente (Nota: 20)" :
                        "FALTA".equals(est) ? "Inasistencia registrada (Nota: 00)" :
                        "TARDANZA".equals(est) ? "Tardanza registrada (Nota: 13)" :
                        ("JUSTIFICADA".equals(est) || "JUSTIFICADO".equals(est)) ? "Inasistencia justificada (Nota: 16)" :
                        "Pendiente de dictado y registro");
                historial.add(sesionMap);
            }

            long presentes = delCurso.stream().filter(as -> "PRESENTE".equalsIgnoreCase(as.getEstado())).count();
            long faltas = delCurso.stream().filter(as -> "FALTA".equalsIgnoreCase(as.getEstado())).count();
            long tardanzas = delCurso.stream().filter(as -> "TARDANZA".equalsIgnoreCase(as.getEstado())).count();
            long justificadas = delCurso.stream().filter(as -> "JUSTIFICADO".equalsIgnoreCase(as.getEstado()) || "JUSTIFICADA".equalsIgnoreCase(as.getEstado())).count();
            long total = presentes + faltas + tardanzas + justificadas;
            long computables = presentes + tardanzas + justificadas;
            double porcentaje = total == 0 ? 0.0 : Math.round((computables * 10000.0 / total)) / 100.0;

            Map<String, Object> resumenNotas = DocenteController.calcularResumenNotasCurso(
                    finalAlumnoId, nombreCurso, gradoCurso, cursoIdObj, delCurso, notasAlumno, totalAlumnosColegio
            );

            curso.put("asistenciaNota", resumenNotas.get("asistenciaNota"));
            curso.put("practica", resumenNotas.get("practica"));
            curso.put("parcial", resumenNotas.get("parcial"));
            curso.put("examenFinal", resumenNotas.get("examenFinal"));
            curso.put("final", resumenNotas.get("final"));
            curso.put("promedio", resumenNotas.get("promedio"));
            curso.put("totalTareas", resumenNotas.get("totalTareas"));
            curso.put("totalExamenes", resumenNotas.get("totalExamenes"));
            curso.put("pesos", resumenNotas.get("pesos"));
            curso.put("clasesDictadas", total);
            curso.put("asistenciasCount", presentes);
            curso.put("faltasCount", faltas);
            curso.put("tardanzasCount", tardanzas);
            curso.put("justificadasCount", justificadas);
            curso.put("asistenciaPct", porcentaje);
            curso.put("historialAsistencias", historial);

            double finalNotaCurso = resumenNotas.get("final") instanceof Number n ? n.doubleValue() : 0.0;
            sumaPromediosCursos += finalNotaCurso;
            totalCursosCount++;
        }

        double promedio = totalCursosCount == 0 ? 0.0 : Math.round((sumaPromediosCursos / totalCursosCount) * 10.0) / 10.0;

        Map<String, Object> perfil = new LinkedHashMap<>();
        perfil.put("alumno", alumnoService.obtenerPorId(a.getId()));
        perfil.put("notas", notasAlumno);
        perfil.put("promedioPonderado", promedio);
        perfil.put("totalEvaluaciones", notasAlumno.size());
        perfil.put("asistencia", asistenciaService.resumenAlumno(a.getId()));
        perfil.put("cursos", new ArrayList<>(cursosMap.values()));
        perfil.put("horarioSemanal", bloques);
        perfil.put("justificaciones", justificacionRepository.findByAlumnoIdOrderByIdDesc(a.getId()));
        perfil.put("estadoMatricula", "REGULAR");
        perfil.put("periodoAcademico", "2026 - Bimestre II");
        perfil.put("planFinanciero", planFinancieroService.obtenerPorAlumno(a));
        return ResponseEntity.ok(perfil);
    }

    @Operation(summary = "Consulta un alumno por ID")
    @GetMapping("/alumnos/{id}")
    public ResponseEntity<AlumnoResponse> obtener(@PathVariable Long id) {
        return ResponseEntity.ok(alumnoService.obtenerPorId(id));
    }

    @Operation(summary = "Registra un nuevo alumno")
    @PostMapping("/alumnos")
    @ResponseStatus(HttpStatus.CREATED)
    public AlumnoResponse crear(@Valid @RequestBody AlumnoRequest request) {
        return alumnoService.crear(request);
    }

    @Operation(summary = "Actualiza un alumno existente")
    @PutMapping("/alumnos/{id}")
    public ResponseEntity<AlumnoResponse> actualizar(@PathVariable Long id, @Valid @RequestBody AlumnoRequest request) {
        return ResponseEntity.ok(alumnoService.actualizar(id, request));
    }

    @Operation(summary = "Elimina un alumno")
    @DeleteMapping("/alumnos/{id}")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public void eliminar(@PathVariable Long id) {
        alumnoService.eliminar(id);
    }

    @Operation(summary = "Busca alumno por DNI (único a nivel global)")
    @GetMapping("/alumnos/dni/{dni}")
    public ResponseEntity<AlumnoResponse> buscarPorDni(@PathVariable String dni) {
        return ResponseEntity.ok(alumnoService.buscarPorDni(dni));
    }

    @Operation(summary = "Registrar pago de cuota de pensión de un alumno en Oracle DB")
    @PostMapping("/alumnos/{id}/pagar-cuota")
    public ResponseEntity<?> pagarCuota(@PathVariable Long id, @RequestBody Map<String, Object> body) {
        Alumno a = alumnoRepository.findById(id).orElse(null);
        if (a == null) {
            return ResponseEntity.status(404).body(Map.of("message", "Alumno no encontrado"));
        }
        int cuotaNumero = body.get("cuotaNumero") != null ? Integer.parseInt(String.valueOf(body.get("cuotaNumero"))) : 1;
        var planFinanciero = planFinancieroService.registrarPago(a, cuotaNumero);
        var cuota = planFinanciero.cuotas().stream()
                .filter(c -> c.numero() != null && c.numero() == cuotaNumero)
                .findFirst()
                .orElse(null);
        Map<String, Object> resp = new LinkedHashMap<>();
        resp.put("mensaje", "Pago de pensión registrado exitosamente en Oracle DB");
        resp.put("cuota", cuota);
        resp.put("planFinanciero", planFinanciero);
        return ResponseEntity.ok(resp);
    }

    @Operation(summary = "Registrar nueva deuda o cuota al alumno en Oracle DB")
    @PostMapping("/alumnos/{id}/deuda")
    public ResponseEntity<?> agregarDeuda(@PathVariable Long id, @RequestBody Map<String, Object> body) {
        Alumno a = alumnoRepository.findById(id).orElse(null);
        if (a == null) {
            return ResponseEntity.status(404).body(Map.of("message", "Alumno no encontrado"));
        }
        String concepto = body.get("concepto") != null ? String.valueOf(body.get("concepto")) : "Pensión Escolar";
        double monto = body.get("monto") != null ? Double.parseDouble(String.valueOf(body.get("monto"))) : 450.0;
        String fechaVencimiento = body.get("fechaVencimiento") != null ? String.valueOf(body.get("fechaVencimiento")) : java.time.LocalDate.now().toString();
        var plan = planFinancieroService.agregarDeuda(a, concepto, monto, fechaVencimiento);
        return ResponseEntity.ok(Map.of(
                "mensaje", "Deuda agregada exitosamente al alumno",
                "planFinanciero", plan
        ));
    }
}
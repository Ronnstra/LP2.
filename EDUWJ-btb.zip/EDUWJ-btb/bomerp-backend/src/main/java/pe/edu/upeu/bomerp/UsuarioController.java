package pe.edu.upeu.bomerp;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.*;
import pe.edu.upeu.bomerp.auth.seguridad.dto.AdminRegisterRequest;
import pe.edu.upeu.bomerp.auth.seguridad.entity.Usuario;
import pe.edu.upeu.bomerp.auth.seguridad.repository.UsuarioRepository;
import pe.edu.upeu.bomerp.auth.seguridad.service.AuthService;
import pe.edu.upeu.bomerp.personal.entity.PersonalEscolar;
import pe.edu.upeu.bomerp.personal.repository.PersonalEscolarRepository;

import java.time.LocalDate;
import java.util.*;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/api/v1")
@RequiredArgsConstructor
@Tag(name = "Gestión de Usuarios y Administrador", description = "Endpoints para el registro de administradores y gestión integral de usuarios en Oracle DB")
public class UsuarioController {

    private static final Set<String> ROLES_ACTUALIZABLES = Set.of(
            "DIRECTOR", "SECRETARIA", "DOCENTE", "ALUMNO", "COLABORADOR", "VENDEDOR", "SUPERVISOR"
    );

    private final AuthService authService;
    private final UsuarioRepository usuarioRepository;
    private final PersonalEscolarRepository personalRepository;

    @Operation(summary = "Registrar un nuevo usuario en el sistema")
    @PostMapping("/usuarios")
    public ResponseEntity<?> crearUsuario(@Valid @RequestBody AdminRegisterRequest request) {
        try {
            if ("SECRETARIA".equalsIgnoreCase(request.getRol())) {
                request.setTurno("COMPLETO");
            }
            Usuario usuario = authService.registrarAdmin(request);
            sincronizarConPersonalSiCorresponde(usuario, request.getArea(), request.getSueldoMensual());
            return ResponseEntity.status(201).body(Map.of(
                    "mensaje", "Cuenta de usuario '" + usuario.getUsername() + "' creada y activada exitosamente en Oracle DB.",
                    "usuario", mapearUsuarioConHint(usuario)
            ));
        } catch (Exception e) {
            return ResponseEntity.status(409).body(Map.of("error", e.getMessage()));
        }
    }

    @Operation(summary = "Registrar un nuevo usuario Administrador")
    @PostMapping("/usuarios/registrar-admin")
    public ResponseEntity<?> registrarAdmin(@Valid @RequestBody AdminRegisterRequest request) {
        return crearUsuario(request);
    }

    @Operation(summary = "Crear cuenta de Secretaría desde el panel de Dirección")
    @PostMapping("/admin/crear-secretaria")
    public ResponseEntity<?> crearSecretaria(@RequestBody AdminRegisterRequest request) {
        request.setRol("SECRETARIA");
        request.setTurno("COMPLETO");
        if (request.getCargo() == null || request.getCargo().isBlank()) {
            request.setCargo(request.getArea() != null && !request.getArea().isBlank() ? request.getArea() : "Secretaria General y Académica");
        }
        return crearUsuario(request);
    }

    @Operation(summary = "Listar todos los usuarios escolares (excluyendo la cuenta ADMIN maestra)")
    @GetMapping("/usuarios")
    public ResponseEntity<List<Map<String, Object>>> listarUsuarios(@RequestParam(required = false) Long colegioId) {
        List<Map<String, Object>> usuariosEscolares = usuarioRepository.findAll().stream()
                .filter(u -> !esCuentaAdmin(u))
                .filter(u -> colegioId == null || colegioId.equals(u.getColegioId()))
                .map(this::mapearUsuarioConHint)
                .collect(Collectors.toList());
        return ResponseEntity.ok(usuariosEscolares);
    }

    @Operation(summary = "Actualizar un usuario existente en Oracle DB")
    @PutMapping("/usuarios/{id}")
    @Transactional
    public ResponseEntity<?> actualizarUsuario(@PathVariable Long id, @RequestBody Map<String, Object> data) {
        Usuario usuario = usuarioRepository.findById(id).orElse(null);
        if (usuario == null || esCuentaAdmin(usuario)) {
            return ResponseEntity.status(404).body(Map.of("error", "Usuario escolar no encontrado"));
        }

        if (data.containsKey("rol") && data.get("rol") != null) {
            String nuevoRol = String.valueOf(data.get("rol")).trim().toUpperCase();
            if ("PROFESOR".equals(nuevoRol)) {
                nuevoRol = "DOCENTE";
            }
            if ("ADMIN".equals(nuevoRol) || "SUPERADMIN".equals(nuevoRol)) {
                return ResponseEntity.badRequest().body(Map.of(
                        "error", "El rol ADMIN está reservado para la cuenta maestra única del sistema"
                ));
            }
            if (!ROLES_ACTUALIZABLES.contains(nuevoRol)) {
                return ResponseEntity.badRequest().body(Map.of("error", "Rol no válido: " + nuevoRol));
            }
            usuario.setRol(nuevoRol);
        }
        if (data.containsKey("estado") && data.get("estado") != null) {
            usuario.setEstado(String.valueOf(data.get("estado")));
        }
        if (data.containsKey("nombreCompleto") && data.get("nombreCompleto") != null) {
            usuario.setNombreCompleto(String.valueOf(data.get("nombreCompleto")).trim());
        }
        if (data.containsKey("cargo") && data.get("cargo") != null) {
            usuario.setCargo(String.valueOf(data.get("cargo")).trim());
        }
        if (data.containsKey("email") && data.get("email") != null) {
            usuario.setEmail(String.valueOf(data.get("email")).trim());
        }
        if (data.containsKey("telefono") && data.get("telefono") != null) {
            usuario.setTelefono(String.valueOf(data.get("telefono")).trim());
        }
        if (data.containsKey("password") && data.get("password") != null && !String.valueOf(data.get("password")).isBlank()) {
            usuario.setPasswordHash(String.valueOf(data.get("password")).trim());
        }

        usuario = usuarioRepository.save(usuario);
        return ResponseEntity.ok(Map.of(
                "mensaje", "Usuario actualizado correctamente en Oracle DB.",
                "usuario", mapearUsuarioConHint(usuario)
        ));
    }

    @Operation(summary = "Eliminar un usuario escolar de Oracle DB")
    @DeleteMapping("/usuarios/{id}")
    @Transactional
    public ResponseEntity<?> eliminarUsuario(@PathVariable Long id) {
        Usuario usuario = usuarioRepository.findById(id).orElse(null);
        if (usuario == null || esCuentaAdmin(usuario)) {
            return ResponseEntity.status(404).body(Map.of("error", "Usuario escolar no encontrado."));
        }

        String dni = usuario.getDni();
        String username = usuario.getUsername();
        usuarioRepository.delete(usuario);

        Long colegioId = usuario.getColegioId();
        if (dni != null && !dni.isBlank()) {
            Optional<PersonalEscolar> personal = colegioId != null
                    ? personalRepository.findByDniAndColegioId(dni.trim(), colegioId)
                    : personalRepository.findFirstByDniOrderByIdAsc(dni.trim());
            personal.ifPresent(personalRepository::delete);
        } else if (username != null) {
            Optional<PersonalEscolar> personal = colegioId != null
                    ? personalRepository.findByUsernameIgnoreCaseAndColegioId(username, colegioId)
                    : personalRepository.findByUsernameIgnoreCase(username);
            personal.ifPresent(personalRepository::delete);
        }

        return ResponseEntity.ok(Map.of("mensaje", "Cuenta de usuario '" + username + "' eliminada exitosamente de Oracle DB."));
    }

    private void sincronizarConPersonalSiCorresponde(Usuario usuario, String area, Double sueldoMensualReq) {
        String rol = usuario.getRol() != null ? usuario.getRol().toUpperCase() : "";
        if (!"SECRETARIA".equals(rol) && !"DOCENTE".equals(rol) && !"COLABORADOR".equals(rol)) {
            return;
        }

        String dni = usuario.getDni() != null && !usuario.getDni().isBlank()
                ? usuario.getDni().trim()
                : "7" + String.valueOf(1000000 + new Random().nextInt(8999999));
        Long colegioId = usuario.getColegioId();
        Optional<PersonalEscolar> existente = colegioId != null
                ? personalRepository.findByDniAndColegioId(dni, colegioId)
                : personalRepository.findFirstByDniOrderByIdAsc(dni);

        String nombreCompleto = usuario.getNombreCompleto() != null ? usuario.getNombreCompleto().trim() : usuario.getUsername();
        String[] partes = nombreCompleto.split("\\s+", 2);
        String cargoPersonal = switch (rol) {
            case "SECRETARIA" -> "SECRETARIA";
            case "DOCENTE" -> "DOCENTE";
            default -> normalizarCargoColaborador(usuario.getCargo());
        };
        String areaPorDefecto = switch (rol) {
            case "SECRETARIA" -> "Secretaría General y Dirección Académica";
            case "DOCENTE" -> "Ciencias y Humanidades";
            default -> "Servicios Generales";
        };
        String apellidoPorDefecto = switch (rol) {
            case "SECRETARIA" -> "Secretaría";
            case "DOCENTE" -> "Docente";
            default -> "Personal de apoyo";
        };
        // Docentes: sin sueldo fijo; su pago se calcula por minutos efectivamente dictados en su horario.
        Double sueldoFijo = "DOCENTE".equals(rol)
                ? null
                : (sueldoMensualReq != null && sueldoMensualReq > 0
                        ? sueldoMensualReq
                        : ("SECRETARIA".equals(rol) ? 1800.0 : 1400.0));

        PersonalEscolar p = existente.orElseGet(PersonalEscolar::new);
        p.setNombre(partes[0]);
        p.setApellidos(partes.length > 1 ? partes[1] : apellidoPorDefecto);
        p.setDni(dni);
        p.setCargo(cargoPersonal);
        p.setArea(area != null && !area.isBlank() ? area : areaPorDefecto);
        p.setTurno("SECRETARIA".equals(rol) ? "COMPLETO" : (usuario.getTurno() != null ? usuario.getTurno() : "COMPLETO"));
        p.setTelefono(usuario.getTelefono() != null && !usuario.getTelefono().isBlank() ? usuario.getTelefono() : "987654321");
        p.setCorreo(usuario.getEmail());
        p.setUsername(usuario.getUsername());
        p.setColegioId(colegioId);
        p.setEstadoAprobacion("CONFIRMADO");
        p.setEstadoCuenta("ACTIVA");
        p.setEstadoLaboral("ACTIVO");
        p.setSueldoMensual(sueldoFijo);
        p.setFechaRegistro(LocalDate.now().toString());
        p.setRegistradoPor("Dirección General (DIRECTOR)");
        p.setTarifaHora("COLABORADOR".equals(rol) ? 18.0 : 35.0);
        personalRepository.save(p);
    }

    private String normalizarCargoColaborador(String cargo) {
        if (cargo == null) {
            return "LIMPIEZA";
        }
        String valor = cargo.trim().toUpperCase();
        return switch (valor) {
            case "LIMPIEZA", "COMEDOR", "MANTENIMIENTO", "SEGURIDAD" -> valor;
            default -> "LIMPIEZA";
        };
    }

    private boolean esCuentaAdmin(Usuario usuario) {
        return "ADMIN".equalsIgnoreCase(usuario.getRol())
                || "jimyamanqui@gmail.com".equalsIgnoreCase(usuario.getUsername())
                || "jimyamanqui@gmail.com".equalsIgnoreCase(usuario.getEmail());
    }

    private Map<String, Object> mapearUsuarioConHint(Usuario u) {
        Map<String, Object> m = new LinkedHashMap<>();
        m.put("id", u.getId());
        m.put("username", u.getUsername());
        m.put("rol", u.getRol());
        m.put("estado", u.getEstado());
        m.put("estadoAprobacion", u.getEstadoAprobacion() != null ? u.getEstadoAprobacion() : "CONFIRMADO");
        m.put("nombreCompleto", u.getNombreCompleto() != null ? u.getNombreCompleto() : u.getUsername());
        m.put("cargo", u.getCargo() != null ? u.getCargo() : u.getRol());
        m.put("email", u.getEmail() != null ? u.getEmail() : u.getUsername() + "@bomerp.edu.pe");
        m.put("telefono", u.getTelefono() != null ? u.getTelefono() : "");
        m.put("dni", u.getDni() != null ? u.getDni() : "");
        m.put("turno", u.getTurno() != null ? u.getTurno() : "MAÑANA");
        m.put("fechaRegistro", u.getFechaRegistro() != null ? u.getFechaRegistro() : LocalDate.now().toString());
        m.put("colegioId", u.getColegioId());
        m.put("nombreColegio", u.getNombreColegio());
        m.put("passwordHint", u.getPasswordHash());
        return m;
    }
}

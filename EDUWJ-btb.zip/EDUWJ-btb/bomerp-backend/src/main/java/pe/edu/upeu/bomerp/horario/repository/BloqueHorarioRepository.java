package pe.edu.upeu.bomerp.horario.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import pe.edu.upeu.bomerp.horario.entity.BloqueHorario;

import java.util.List;

public interface BloqueHorarioRepository extends JpaRepository<BloqueHorario, Long> {
    List<BloqueHorario> findByGradoIgnoreCase(String grado);
    List<BloqueHorario> findByDocenteId(Long docenteId);
}

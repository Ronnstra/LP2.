/**
 * Repositorio de usuarios expuesto para módulos que sincronizan usuarios.
 */
@org.springframework.modulith.NamedInterface("auth-seguridad-repository")
package pe.edu.upeu.bomerp.auth.seguridad.repository;

package pe.edu.upeu.bomerp.saas.controller;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.servlet.http.HttpServletRequest;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.*;
import pe.edu.upeu.bomerp.auth.seguridad.entity.Usuario;
import pe.edu.upeu.bomerp.auth.seguridad.repository.UsuarioRepository;
import pe.edu.upeu.bomerp.config.DatabaseResetService;
import pe.edu.upeu.bomerp.matricula.alumno.dto.RecaudacionColegio;
import pe.edu.upeu.bomerp.matricula.alumno.repository.AlumnoRepository;
import pe.edu.upeu.bomerp.matricula.alumno.service.PlanFinancieroService;
import pe.edu.upeu.bomerp.saas.entity.ColegioSaaS;
import pe.edu.upeu.bomerp.saas.entity.PagoSaaS;
import pe.edu.upeu.bomerp.saas.repository.ColegioSaaSRepository;
import pe.edu.upeu.bomerp.saas.repository.PagoSaaSRepository;

import javax.crypto.Mac;
import javax.crypto.spec.SecretKeySpec;
import java.nio.charset.StandardCharsets;
import java.text.Normalizer;
import java.time.Instant;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.*;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/api/v1/saas")
@RequiredArgsConstructor
@Transactional
@Tag(name = "SaaS Multi-Colegio y Seguridad REZE", description = "Gestión de suscripciones de colegios en Oracle DB y bóveda criptográfica REZE de 5 minutos para SuperAdmin")
public class SaasController {

    public static final String AUTHORIZED_MASTER_GOOGLE_ACCOUNT = "jimyamanqui@gmail.com";
    public static final int GUARD_INTERVAL_SECONDS = 300; // 5 minutos
    public static final double CUOTA_BASE_SAAS = 1000.0;
    public static final double CUOTA_MINIMA_SAAS = 700.0;

    private static final DateTimeFormatter FMT_PAGO = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm");

    private final ColegioSaaSRepository colegioRepository;
    private final PagoSaaSRepository pagoSaaSRepository;
    private final PlanFinancieroService planFinancieroService;
    private final UsuarioRepository usuarioRepository;
    private final AlumnoRepository alumnoRepository;
    private final DatabaseResetService databaseResetService;

    private volatile int rezeRotationSequence = 0;
    private volatile String activePairingToken = UUID.randomUUID().toString().replace("-", "");
    private volatile long activePairingExpiresAt = System.currentTimeMillis() + 30 * 60 * 1000L;

    private final List<Map<String, Object>> registeredMasterDevices = new CopyOnWriteArrayList<>();
    private final List<Map<String, Object>> eventosSistema = new CopyOnWriteArrayList<>(List.of(
            Map.of(
                    "id", "evt-init-0",
                    "tipo", "SISTEMA",
                    "titulo", "Sistema Inicializado en Cero en Oracle DB",
                    "detalle", "Plataforma en limpio sin datos demo. Única cuenta maestra activa: jimyamanqui@gmail.com",
                    "fecha", Instant.now().toString()
            )
    ));

    // ========================================================
    // 1. AUTENTICACIÓN MAESTRA ADMIN + 2FA REZE (5 MINUTOS)
    // ========================================================

    @Operation(summary = "Paso 1: Validar credenciales maestras (jimyamanqui@gmail.com / jimy) e iniciar desafío REZE")
    @PostMapping({"/auth/verificar-credenciales-maestro", "/auth/master-login"})
    public ResponseEntity<?> verificarCredencialesMaestro(@RequestBody Map<String, Object> body) {
        String rawUser = body.get("username") != null ? String.valueOf(body.get("username")) :
                (body.get("email") != null ? String.valueOf(body.get("email")) : "");
        String cleanUser = rawUser.trim().toLowerCase();
        String passwordInput = body.get("password") != null ? String.valueOf(body.get("password")).trim() : "";

        boolean esMasterValido = AUTHORIZED_MASTER_GOOGLE_ACCOUNT.equalsIgnoreCase(cleanUser) || "jimy".equalsIgnoreCase(cleanUser);
        if (!esMasterValido || !"jimy".equals(passwordInput)) {
            return ResponseEntity.status(401).body(Map.of(
                    "exito", false,
                    "mensaje", "Contraseña incorrecta. Para la cuenta maestra jimyamanqui@gmail.com ingrese su clave 'jimy'."
            ));
        }

        asegurarCuentaMaestraEnOracle();
        Map<String, Object> guard = getActiveSteamGuardCode(AUTHORIZED_MASTER_GOOGLE_ACCOUNT);
        List<Map<String, Object>> activos = obtenerDispositivosActivos();

        Map<String, Object> resp = new LinkedHashMap<>();
        resp.put("exito", true);
        resp.put("requires2FA", true);
        resp.put("requiereReze", true);
        resp.put("email", AUTHORIZED_MASTER_GOOGLE_ACCOUNT);
        resp.put("boundEmail", AUTHORIZED_MASTER_GOOGLE_ACCOUNT);
        resp.put("secondsRemaining", guard.get("secondsRemaining"));
        resp.put("intervalSeconds", guard.get("intervalSeconds"));
        resp.put("hasActiveDevice", !activos.isEmpty());
        resp.put("totalDevices", activos.size());
        resp.put("deviceName", !activos.isEmpty() ? activos.size() + " Teléfono(s) con cuenta Google vinculada" : "App Móvil REZE");
        resp.put("mensaje", "Credenciales maestras verificadas. Ingrese el código de 5 minutos de la app REZE.");
        return ResponseEntity.ok(resp);
    }

    @Operation(summary = "Paso 2: Verificar código REZE de 5 caracteres y otorgar sesión SuperAdmin")
    @PostMapping({"/auth/login-maestro", "/auth/verify-reze"})
    public ResponseEntity<?> loginMaestroConReze(@RequestBody Map<String, Object> body) {
        String rawUser = body.get("username") != null ? String.valueOf(body.get("username")) :
                (body.get("email") != null ? String.valueOf(body.get("email")) : AUTHORIZED_MASTER_GOOGLE_ACCOUNT);
        String cleanUser = rawUser.trim().toLowerCase();
        String passwordInput = body.get("password") != null ? String.valueOf(body.get("password")).trim() : "jimy";
        String steamGuardCode = body.get("steamGuardCode") != null ? String.valueOf(body.get("steamGuardCode")).trim().toUpperCase() :
                (body.get("code") != null ? String.valueOf(body.get("code")).trim().toUpperCase() : "");

        boolean esMasterValido = AUTHORIZED_MASTER_GOOGLE_ACCOUNT.equalsIgnoreCase(cleanUser) || "jimy".equalsIgnoreCase(cleanUser);
        if (!esMasterValido || !"jimy".equals(passwordInput)) {
            return ResponseEntity.status(401).body(Map.of(
                    "exito", false,
                    "mensaje", "Credenciales maestras inválidas. Acceso denegado."
            ));
        }

        if (!verifySteamGuardCode(steamGuardCode, AUTHORIZED_MASTER_GOOGLE_ACCOUNT)) {
            return ResponseEntity.status(403).body(Map.of(
                    "exito", false,
                    "mensaje", "Código de seguridad REZE inválido o expirado. Abra la app REZE (/admin-guard) para ver su código activo de 5 minutos."
            ));
        }

        Usuario master = asegurarCuentaMaestraEnOracle();
        registrarEvento("SEGURIDAD", "Inicio de sesión SuperAdmin autorizado",
                "Acceso verificado con código REZE de 5 minutos para " + AUTHORIZED_MASTER_GOOGLE_ACCOUNT);

        Map<String, Object> usuarioMap = new LinkedHashMap<>();
        usuarioMap.put("id", master.getId());
        usuarioMap.put("username", AUTHORIZED_MASTER_GOOGLE_ACCOUNT);
        usuarioMap.put("nombreCompleto", "Jimy Amanqui (SuperAdmin Maestro)");
        usuarioMap.put("cargo", "Propietario del Sistema SaaS");
        usuarioMap.put("email", AUTHORIZED_MASTER_GOOGLE_ACCOUNT);
        usuarioMap.put("rol", "ADMIN");
        usuarioMap.put("dispositivoVinculado", "App Móvil REZE");

        Map<String, Object> resp = new LinkedHashMap<>();
        resp.put("exito", true);
        resp.put("id", master.getId());
        resp.put("username", AUTHORIZED_MASTER_GOOGLE_ACCOUNT);
        resp.put("email", AUTHORIZED_MASTER_GOOGLE_ACCOUNT);
        resp.put("rol", "ADMIN");
        resp.put("token", "jwt-token-admin-" + master.getId());
        resp.put("usuario", usuarioMap);
        resp.put("mensaje", "Acceso maestro concedido para " + AUTHORIZED_MASTER_GOOGLE_ACCOUNT + ".");
        return ResponseEntity.ok(resp);
    }

    @Operation(summary = "Estado público del generador REZE de 5 minutos")
    @GetMapping("/auth/steamguard-status")
    public ResponseEntity<Map<String, Object>> steamGuardStatus() {
        Map<String, Object> guard = getActiveSteamGuardCode(AUTHORIZED_MASTER_GOOGLE_ACCOUNT);
        List<Map<String, Object>> activos = obtenerDispositivosActivos();

        Map<String, Object> resp = new LinkedHashMap<>();
        resp.put("intervalSeconds", guard.get("intervalSeconds"));
        resp.put("secondsRemaining", guard.get("secondsRemaining"));
        resp.put("timeStep", guard.get("timeStep"));
        resp.put("boundEmail", AUTHORIZED_MASTER_GOOGLE_ACCOUNT);
        resp.put("hasActiveDevice", !activos.isEmpty());
        resp.put("totalDevices", activos.size());
        resp.put("dispositivos", activos);
        resp.put("deviceName", !activos.isEmpty() ? activos.size() + " Teléfono(s) con cuenta Google vinculada" : null);
        return ResponseEntity.ok(resp);
    }

    // ========================================================
    // 2. ENDPOINTS DE BÓVEDA MÓVIL REZE (/admin-guard)
    // ========================================================

    @Operation(summary = "Obtener código dinámico REZE de 5 minutos y resumen en vivo")
    @GetMapping("/guard/code")
    public ResponseEntity<Map<String, Object>> obtenerCodigoGuard(HttpServletRequest request) {
        String deviceId = request.getHeader("x-guard-device-id");
        String userAgent = request.getHeader("user-agent");
        if (deviceId != null && !deviceId.isBlank()) {
            registrarOTocarDispositivo(deviceId, null, userAgent, request.getRemoteAddr());
        }

        Map<String, Object> guard = getActiveSteamGuardCode(AUTHORIZED_MASTER_GOOGLE_ACCOUNT);
        Map<String, Object> resp = new LinkedHashMap<>(guard);
        resp.put("exito", true);
        resp.put("resumenSistema", obtenerResumenSistema());
        return ResponseEntity.ok(resp);
    }

    @Operation(summary = "Estado de vinculación del teléfono móvil con REZE")
    @GetMapping("/guard/device-status")
    public ResponseEntity<Map<String, Object>> estadoDispositivo(HttpServletRequest request) {
        String deviceId = request.getHeader("x-guard-device-id");
        String userAgent = request.getHeader("user-agent");
        Map<String, Object> resumen = obtenerResumenSistema();

        if (deviceId == null || deviceId.isBlank()) {
            return ResponseEntity.ok(Map.of(
                    "estado", "SIN_DISPOSITIVO",
                    "boundEmail", AUTHORIZED_MASTER_GOOGLE_ACCOUNT,
                    "resumenSistema", resumen,
                    "mensaje", "Esperando identificación de dispositivo para vincular con Google."
            ));
        }

        Map<String, Object> dev = registrarOTocarDispositivo(deviceId, null, userAgent, request.getRemoteAddr());
        Map<String, Object> guard = getActiveSteamGuardCode(AUTHORIZED_MASTER_GOOGLE_ACCOUNT);
        List<Map<String, Object>> activos = obtenerDispositivosActivos();

        Map<String, Object> resp = new LinkedHashMap<>();
        resp.put("estado", "AUTORIZADO");
        resp.put("boundEmail", AUTHORIZED_MASTER_GOOGLE_ACCOUNT);
        resp.put("totalDispositivos", activos.size());
        resp.put("dispositivo", dev);
        resp.put("dispositivos", activos);
        resp.put("guard", guard);
        resp.put("resumenSistema", obtenerResumenSistema());
        resp.put("mensaje", "Teléfono autorizado para la cuenta Google " + AUTHORIZED_MASTER_GOOGLE_ACCOUNT);
        return ResponseEntity.ok(resp);
    }

    @Operation(summary = "Vincular dispositivo móvil REZE")
    @PostMapping("/guard/vincular")
    public ResponseEntity<Map<String, Object>> vincularDispositivo(@RequestBody Map<String, Object> body, HttpServletRequest request) {
        String deviceId = body.get("deviceId") != null ? String.valueOf(body.get("deviceId")) : UUID.randomUUID().toString();
        String deviceName = body.get("deviceName") != null ? String.valueOf(body.get("deviceName")) : "Teléfono REZE";
        Map<String, Object> dev = registrarOTocarDispositivo(deviceId, deviceName, request.getHeader("user-agent"), request.getRemoteAddr());
        Map<String, Object> guard = getActiveSteamGuardCode(AUTHORIZED_MASTER_GOOGLE_ACCOUNT);
        return ResponseEntity.ok(Map.of(
                "exito", true,
                "dispositivo", dev,
                "guard", guard,
                "resumenSistema", obtenerResumenSistema(),
                "mensaje", "Dispositivo vinculado exitosamente a " + AUTHORIZED_MASTER_GOOGLE_ACCOUNT
        ));
    }

    @Operation(summary = "Revocar dispositivos móviles vinculados")
    @PostMapping("/guard/revocar")
    public ResponseEntity<Map<String, Object>> revocarDispositivos() {
        registeredMasterDevices.clear();
        return ResponseEntity.ok(Map.of(
                "exito", true,
                "mensaje", "Dispositivos revocados exitosamente."
        ));
    }

    @Operation(summary = "Rotar / Regenerar código REZE de 5 minutos manualmente")
    @PostMapping("/guard/rotar-codigo")
    public ResponseEntity<Map<String, Object>> rotarCodigo() {
        rezeRotationSequence++;
        Map<String, Object> nuevoGuard = getActiveSteamGuardCode(AUTHORIZED_MASTER_GOOGLE_ACCOUNT);
        registrarEvento("SEGURIDAD", "Clave REZE regenerada", "Nueva clave criptográfica generada (Ciclo #" + rezeRotationSequence + ")");

        Map<String, Object> resp = new LinkedHashMap<>(nuevoGuard);
        resp.put("exito", true);
        resp.put("mensaje", "Nuevo código REZE generado y sincronizado en tiempo real.");
        resp.put("resumenSistema", obtenerResumenSistema());
        return ResponseEntity.ok(resp);
    }

    @Operation(summary = "Resumen ejecutivo del sistema en vivo para REZE")
    @GetMapping("/guard/system-summary")
    public ResponseEntity<Map<String, Object>> resumenEjecutivo() {
        Map<String, Object> resp = new LinkedHashMap<>(obtenerResumenSistema());
        resp.put("exito", true);
        return ResponseEntity.ok(resp);
    }

    @Operation(summary = "Generar token y código QR para abrir/vincular REZE Admin Guard")
    @PostMapping("/guard/generar-token-vinculacion")
    public ResponseEntity<Map<String, Object>> generarTokenVinculacion(
            @RequestBody(required = false) Map<String, Object> body,
            HttpServletRequest request) {
        activePairingToken = UUID.randomUUID().toString().replace("-", "");
        activePairingExpiresAt = System.currentTimeMillis() + 30 * 60 * 1000L;
        String baseUrl = resolverBaseUrl(body, request);
        String fullPairingUrl = baseUrl + "/admin-guard?pairToken=" + activePairingToken + "&install=1";
        String relativePairingUrl = "/admin-guard?pairToken=" + activePairingToken + "&install=1";
        String qrSvg = generarQrSvgAccesoDirecto(fullPairingUrl);
        String qrDataUrl = "data:image/svg+xml;base64," + Base64.getEncoder().encodeToString(qrSvg.getBytes(StandardCharsets.UTF_8));

        Map<String, Object> resp = new LinkedHashMap<>();
        resp.put("exito", true);
        resp.put("token", activePairingToken);
        resp.put("expiresAt", activePairingExpiresAt);
        resp.put("boundEmail", AUTHORIZED_MASTER_GOOGLE_ACCOUNT);
        resp.put("pairingUrl", relativePairingUrl);
        resp.put("fullPairingUrl", fullPairingUrl);
        resp.put("qrDataUrl", qrDataUrl);
        resp.put("qrSvg", qrSvg);
        return ResponseEntity.ok(resp);
    }

    @Operation(summary = "Obtener QR de descarga e instalación de REZE")
    @GetMapping("/guard/qr-descarga")
    public ResponseEntity<Map<String, Object>> obtenerQrDescarga(HttpServletRequest request) {
        if (System.currentTimeMillis() > activePairingExpiresAt) {
            activePairingToken = UUID.randomUUID().toString().replace("-", "");
            activePairingExpiresAt = System.currentTimeMillis() + 30 * 60 * 1000L;
        }
        String baseUrl = resolverBaseUrl(null, request);
        String fullPairingUrl = baseUrl + "/admin-guard?pairToken=" + activePairingToken + "&install=1";
        String qrSvg = generarQrSvgAccesoDirecto(fullPairingUrl);
        String qrDataUrl = "data:image/svg+xml;base64," + Base64.getEncoder().encodeToString(qrSvg.getBytes(StandardCharsets.UTF_8));

        Map<String, Object> resp = new LinkedHashMap<>();
        resp.put("exito", true);
        resp.put("token", activePairingToken);
        resp.put("expiresAt", activePairingExpiresAt);
        resp.put("boundEmail", AUTHORIZED_MASTER_GOOGLE_ACCOUNT);
        resp.put("pairingUrl", "/admin-guard?pairToken=" + activePairingToken + "&install=1");
        resp.put("fullPairingUrl", fullPairingUrl);
        resp.put("qrDataUrl", qrDataUrl);
        return ResponseEntity.ok(resp);
    }

    @Operation(summary = "Gestionar estado, pagos o eliminación de un colegio desde REZE en Oracle DB")
    @PostMapping("/guard/colegio-accion")
    public ResponseEntity<?> accionColegioDesdeGuard(@RequestBody Map<String, Object> body) {
        if (body.get("colegioId") == null) {
            return ResponseEntity.badRequest().body(Map.of("exito", false, "mensaje", "colegioId es requerido"));
        }
        Long colegioId = Long.parseLong(String.valueOf(body.get("colegioId")));
        String accion = body.get("accion") != null ? String.valueOf(body.get("accion")) : "";

        ColegioSaaS col = colegioRepository.findById(colegioId).orElse(null);
        if (col == null) {
            return ResponseEntity.status(404).body(Map.of("exito", false, "mensaje", "Colegio no encontrado en Oracle DB."));
        }

        if ("TOGGLE_ESTADO".equalsIgnoreCase(accion)) {
            col.setEstado("ACTIVO".equalsIgnoreCase(col.getEstado()) ? "SUSPENDIDO" : "ACTIVO");
            if ("ACTIVO".equalsIgnoreCase(col.getEstado()) && col.getCuotaActual() < 1000.0) {
                col.setCuotaActual(1000.0);
            }
            colegioRepository.save(col);
            registrarEvento("COLEGIO", "Estado cambiado: " + col.getNombreColegio(), "Nuevo estado: " + col.getEstado());
        } else if ("REGISTRAR_PAGO".equalsIgnoreCase(accion)) {
            int meses = (col.getMesesActivo() != null ? col.getMesesActivo() : 1) + 1;
            col.setMesesActivo(meses);
            col.setEstado("ACTIVO");
            if (meses == 2) col.setCuotaActual(800.0);
            else if (meses >= 3) col.setCuotaActual(780.0);
            col.setTotalAbonado((col.getTotalAbonado() != null ? col.getTotalAbonado() : 0.0) + col.getCuotaActual());
            colegioRepository.save(col);
            registrarEvento("FINANZAS", "Pago registrado: " + col.getNombreColegio(), "Mes #" + meses + " abonado");
        } else if ("ELIMINAR".equalsIgnoreCase(accion)) {
            String dirUser = col.getDirectorUsername();
            String nombreCol = col.getNombreColegio();
            colegioRepository.delete(col);
            if (dirUser != null) {
                usuarioRepository.findByUsernameIgnoreCase(dirUser).ifPresent(u -> {
                    if (!"ADMIN".equalsIgnoreCase(u.getRol())) {
                        usuarioRepository.delete(u);
                    }
                });
            }
            registrarEvento("COLEGIO", "Colegio dado de baja: " + nombreCol, "Eliminado de Oracle DB");
        }

        return ResponseEntity.ok(Map.of(
                "exito", true,
                "mensaje", "Cambio aplicado y persistido en Oracle DB.",
                "resumenSistema", obtenerResumenSistema()
        ));
    }

    @Operation(summary = "Crear colegio desde la App Móvil REZE y persistirlo en Oracle DB")
    @PostMapping("/guard/crear-colegio-movil")
    public ResponseEntity<?> crearColegioMovil(@RequestBody Map<String, Object> body) {
        return adquirirSuscripcion(body);
    }

    @Operation(summary = "Reiniciar el sistema a CERO ABSOLUTO en Oracle DB conservando únicamente jimyamanqui@gmail.com")
    @PostMapping("/guard/limpiar-sistema-movil")
    public ResponseEntity<?> limpiarSistemaMovil() {
        databaseResetService.limpiarTodo();
        asegurarCuentaMaestraEnOracle();
        registrarEvento("SISTEMA", "Sistema reiniciado a CERO en Oracle DB", "Solo permanece la cuenta maestra jimyamanqui@gmail.com");

        return ResponseEntity.ok(Map.of(
                "exito", true,
                "mensaje", "Base de datos Oracle reiniciada a cero absoluto. Solo permanece jimyamanqui@gmail.com.",
                "resumenSistema", obtenerResumenSistema()
        ));
    }

    // ========================================================
    // 3. GESTIÓN DE COLEGIOS SAAS Y ADQUISICIÓN (/adquirir)
    // ========================================================

    @Operation(summary = "Listar colegios públicos activos para el selector de acceso escolar")
    @GetMapping("/colegios/publicos")
    public ResponseEntity<List<Map<String, Object>>> listarColegiosPublicos() {
        List<Map<String, Object>> lista = colegioRepository.findAll().stream()
                .map(this::mapearColegio)
                .collect(Collectors.toList());
        return ResponseEntity.ok(lista);
    }

    @Operation(summary = "Buscar colegio por slug para su portal personalizado")
    @GetMapping("/colegios/slug/{slug}")
    public ResponseEntity<?> obtenerColegioPorSlug(@PathVariable String slug) {
        ColegioSaaS col = colegioRepository.findBySlugIgnoreCase(slug).orElse(null);
        if (col != null) {
            return ResponseEntity.ok(Map.of(
                    "exito", true,
                    "colegio", mapearColegio(col)
            ));
        }
        return ResponseEntity.status(404).body(Map.of(
                "exito", false,
                "mensaje", "No existe un colegio registrado con el slug '" + slug + "'."
        ));
    }

    @Operation(summary = "Obtener información del colegio del Director autenticado")
    @GetMapping("/mi-colegio")
    public ResponseEntity<?> obtenerMiColegio(
            @RequestParam(required = false) String username,
            @RequestParam(required = false) Long colegioId) {

        List<ColegioSaaS> todos = colegioRepository.findAll();
        ColegioSaaS encontrado = null;

        if (colegioId != null) {
            encontrado = todos.stream().filter(c -> Objects.equals(c.getId(), colegioId)).findFirst().orElse(null);
        }
        if (encontrado == null && username != null && !username.isBlank()) {
            String cleanUser = username.trim().toLowerCase();
            encontrado = todos.stream()
                    .filter(c -> c.getDirectorUsername() != null && c.getDirectorUsername().equalsIgnoreCase(cleanUser))
                    .findFirst()
                    .orElse(null);
        }
        if (encontrado == null) {
            return ResponseEntity.status(404).body(Map.of(
                    "exito", false,
                    "mensaje", "No se encontró el colegio para los datos proporcionados."
            ));
        }

        return ResponseEntity.ok(Map.of(
                "exito", true,
                "colegio", mapearColegio(encontrado)
        ));
    }

    @Operation(summary = "Consultar suscripción, fondos reales e historial de pagos del colegio")
    @GetMapping("/mi-suscripcion")
    public ResponseEntity<?> obtenerMiSuscripcion(
            @RequestParam(required = false) Long colegioId,
            @RequestParam(required = false) String username) {

        ColegioSaaS col = resolverColegio(colegioId, username);
        if (col == null) {
            return ResponseEntity.status(404).body(Map.of(
                    "exito", false,
                    "mensaje", "No se encontró la suscripción del colegio para los datos proporcionados."
            ));
        }

        return ResponseEntity.ok(Map.of(
                "exito", true,
                "suscripcion", construirSuscripcion(col)
        ));
    }

    @Operation(summary = "Pagar cuotas SaaS con los fondos reales recaudados de pensiones")
    @PostMapping("/pagar")
    public ResponseEntity<?> pagarSuscripcion(@RequestBody Map<String, Object> body) {
        Long rawColegioId = parseLong(body.get("colegioId"), null);
        String username = texto(body.get("username"), null);

        ColegioSaaS col = resolverColegio(rawColegioId, username);
        if (col == null) {
            return ResponseEntity.status(404).body(Map.of("exito", false, "mensaje", "Colegio no encontrado en Oracle DB."));
        }
        Long colegioId = col.getId();

        int meses = parseInt(body.get("mesesAdelantar"), 1);
        if (meses < 1 || meses > 12) {
            return ResponseEntity.badRequest().body(Map.of("exito", false, "mensaje", "Puede pagar entre 1 y 12 meses."));
        }

        String metodo = texto(body.get("metodoPago"), "TARJETA").toUpperCase();
        if (!List.of("TRANSFERENCIA", "YAPE", "TARJETA").contains(metodo)) {
            metodo = "TARJETA";
        }
        String bancoPorDefecto = "TARJETA".equals(metodo) ? "Visa/Mastercard" : ("YAPE".equals(metodo) ? "Yape / Plin" : "BCP");
        String banco = limitar(texto(body.get("banco"), bancoPorDefecto), 80);

        String numeroOperacion = limitar(texto(body.get("numeroOperacion"), ""), 80);
        if (!"TARJETA".equals(metodo) && numeroOperacion.length() < 5) {
            return ResponseEntity.badRequest().body(Map.of(
                    "exito", false,
                    "mensaje", "Ingrese un número de operación o código de voucher válido (mínimo 5 caracteres)."
            ));
        }
        if (numeroOperacion.isEmpty()) {
            numeroOperacion = "SAAS-" + System.currentTimeMillis();
        }
        if (pagoSaaSRepository.existsByColegioIdAndNumeroOperacionIgnoreCase(colegioId, numeroOperacion)) {
            return ResponseEntity.status(409).body(Map.of(
                    "exito", false,
                    "mensaje", "Ya existe un pago registrado con ese número de operación."
            ));
        }

        int mesDesde = (col.getMesesActivo() != null ? col.getMesesActivo() : 1) + 1;
        int mesHasta = mesDesde + meses - 1;
        double monto = calcularMontoMeses(mesDesde, meses);
        double pensiones = planFinancieroService.obtenerRecaudacion(colegioId).totalPensionesCobradas();
        double pagado = totalPagadoSaas(colegioId);
        double fondos = redondear(pensiones - pagado);

        if (fondos + 0.001 < monto) {
            Map<String, Object> error = new LinkedHashMap<>();
            error.put("exito", false);
            error.put("codigo", "FONDOS_INSUFICIENTES");
            error.put("mensaje", "Fondos insuficientes en la caja de la escuela. Se requieren S/ "
                    + String.format(Locale.US, "%.2f", monto) + " y solo hay S/ "
                    + String.format(Locale.US, "%.2f", fondos) + " cobrados de pensiones.");
            error.put("fondosDisponibles", fondos);
            error.put("montoRequerido", monto);
            error.put("faltante", redondear(monto - fondos));
            return ResponseEntity.status(409).body(error);
        }

        PagoSaaS pago = new PagoSaaS();
        pago.setColegioId(colegioId);
        pago.setMesDesde(mesDesde);
        pago.setMesHasta(mesHasta);
        pago.setMesesPagados(meses);
        pago.setMonto(monto);
        pago.setMetodoPago(metodo);
        pago.setBanco(banco);
        pago.setNumeroOperacion(numeroOperacion);
        pago.setVoucherNombre(limitar(texto(body.get("voucherNombre"), ""), 200));
        pago.setFechaPago(LocalDateTime.now().format(FMT_PAGO));
        pago.setEstado("CONFIRMADO");
        pago.setSaldoFondosAntes(fondos);
        pago.setSaldoFondosDespues(redondear(fondos - monto));
        pago = pagoSaaSRepository.save(pago);

        col.setMesesActivo(mesHasta);
        col.setCuotaActual(cuotaParaMes(mesHasta + 1));
        col.setTotalAbonado(redondear((col.getTotalAbonado() != null ? col.getTotalAbonado() : 0.0) + monto));
        col.setMetodoPago(metodo);
        colegioRepository.save(col);

        Map<String, Object> resp = new LinkedHashMap<>();
        resp.put("exito", true);
        resp.put("mensaje", "Pago SaaS confirmado por S/ " + String.format(Locale.US, "%.2f", monto)
                + ". Se activaron los meses " + mesDesde + " a " + mesHasta + " de " + col.getNombreColegio() + ".");
        resp.put("pago", mapearPago(pago));
        resp.put("suscripcion", construirSuscripcion(col));
        return ResponseEntity.status(201).body(resp);
    }

    @Operation(summary = "Listar todos los colegios suscritos desde Oracle DB")
    @GetMapping("/colegios")
    public ResponseEntity<List<Map<String, Object>>> listarColegios() {
        return ResponseEntity.ok(colegioRepository.findAll().stream()
                .map(this::mapearColegio)
                .collect(Collectors.toList()));
    }

    @Operation(summary = "Obtener métricas financieras del SaaS desde Oracle DB")
    @GetMapping("/metricas")
    public ResponseEntity<Map<String, Object>> obtenerMetricas() {
        List<ColegioSaaS> todos = colegioRepository.findAll();
        long activos = todos.stream().filter(c -> "ACTIVO".equalsIgnoreCase(c.getEstado())).count();
        double mrr = todos.stream()
                .filter(c -> "ACTIVO".equalsIgnoreCase(c.getEstado()))
                .mapToDouble(c -> c.getCuotaActual() != null ? c.getCuotaActual() : 1000.0)
                .sum();
        double historico = todos.stream()
                .mapToDouble(c -> c.getTotalAbonado() != null ? c.getTotalAbonado() : 1000.0)
                .sum();

        return ResponseEntity.ok(Map.of(
                "totalColegios", todos.size(),
                "colegiosActivos", activos,
                "ingresosMensualesRecurrentes", mrr,
                "ingresosHistoricosTotales", historico,
                "proyeccionAnual", mrr * 12.0,
                "planBase", CUOTA_BASE_SAAS,
                "descuentoMensual", 70,
                "pisoMinimo", CUOTA_MINIMA_SAAS,
                "politicaDescuento", "S/ 1,000 el 1° mes; S/ 930 el 2° mes; S/ 860 los meses 3 y 4; S/ 700 desde el mes 5 en adelante."
        ));
    }

    @Operation(summary = "Adquirir suscripción SaaS y aprovisionar Colegio + Director en Oracle DB")
    @PostMapping("/adquirir")
    public ResponseEntity<?> adquirirSuscripcion(@RequestBody Map<String, Object> body) {
        String nombreColegio = body.get("nombreColegio") != null ? String.valueOf(body.get("nombreColegio")).trim() : "";
        String directorNombre = body.get("directorNombre") != null ? String.valueOf(body.get("directorNombre")).trim() : "";
        String directorUsername = body.get("directorUsername") != null ? String.valueOf(body.get("directorUsername")).trim().toLowerCase() : "";
        String directorPassword = body.get("directorPassword") != null && !String.valueOf(body.get("directorPassword")).isBlank()
                ? String.valueOf(body.get("directorPassword")).trim()
                : "123456";

        if (nombreColegio.isEmpty() || directorNombre.isEmpty() || directorUsername.isEmpty()) {
            return ResponseEntity.badRequest().body(Map.of(
                    "exito", false,
                    "mensaje", "El nombre del colegio, nombre del director y usuario de acceso son obligatorios."
            ));
        }

        if (AUTHORIZED_MASTER_GOOGLE_ACCOUNT.equalsIgnoreCase(directorUsername)
                || "jimy".equalsIgnoreCase(directorUsername)
                || "superadmin".equalsIgnoreCase(directorUsername)) {
            return ResponseEntity.badRequest().body(Map.of(
                    "exito", false,
                    "mensaje", "El usuario ingresado está reservado para el SuperAdmin del SaaS. Elija un usuario institucional para el Director."
            ));
        }

        if (!usuarioRepository.findAllByUsernameIgnoreCase(directorUsername).isEmpty()) {
            return ResponseEntity.status(409).body(Map.of(
                    "exito", false,
                    "mensaje", "El usuario del director '" + directorUsername + "' ya está registrado. Elija otro usuario."
            ));
        }

        String slug = generarSlugColegio(nombreColegio);
        String slugBase = slug;
        int sufijoSlug = 2;
        while (colegioRepository.findBySlugIgnoreCase(slug).isPresent()) {
            slug = slugBase + "-" + sufijoSlug;
            sufijoSlug++;
        }
        String codigoModular = body.get("codigoModular") != null && !String.valueOf(body.get("codigoModular")).isBlank()
                ? String.valueOf(body.get("codigoModular")).trim()
                : "MOD-" + (100000 + new Random().nextInt(899999));
        String ruc = body.get("ruc") != null && !String.valueOf(body.get("ruc")).isBlank()
                ? String.valueOf(body.get("ruc")).trim()
                : "20" + (100000000 + new Random().nextInt(899999999));
        String ciudad = body.get("ciudad") != null && !String.valueOf(body.get("ciudad")).isBlank()
                ? String.valueOf(body.get("ciudad")).trim()
                : "Lima, Perú";
        String telefono = body.get("telefono") != null ? String.valueOf(body.get("telefono")).trim() : "999000111";
        String directorEmail = body.get("directorEmail") != null && !String.valueOf(body.get("directorEmail")).isBlank()
                ? String.valueOf(body.get("directorEmail")).trim()
                : directorUsername + "@colegio.edu.pe";
        String metodoPago = body.get("metodoPago") != null ? String.valueOf(body.get("metodoPago")).trim() : "TARJETA";

        ColegioSaaS nuevo = new ColegioSaaS();
        nuevo.setNombreColegio(nombreColegio);
        nuevo.setSlug(slug);
        nuevo.setUrlAcceso("/colegio/" + slug);
        nuevo.setCodigoModular(codigoModular);
        nuevo.setRuc(ruc);
        nuevo.setCiudad(ciudad);
        nuevo.setTelefono(telefono);
        nuevo.setDirectorNombre(directorNombre);
        nuevo.setDirectorEmail(directorEmail);
        nuevo.setDirectorUsername(directorUsername);
        nuevo.setFechaAlta(LocalDate.now().toString());
        nuevo.setMesesActivo(1);
        nuevo.setCuotaActual(1000.0);
        nuevo.setEstado("ACTIVO");
        nuevo.setTotalAbonado(1000.0);
        nuevo.setMetodoPago(metodoPago);

        nuevo = colegioRepository.save(nuevo);

        // Crear la cuenta del Director (DIRECTOR) en la tabla USUARIOS de Oracle DB
        Usuario director = new Usuario();
        director.setUsername(directorUsername);
        director.setPasswordHash(directorPassword);
        director.setRol("DIRECTOR");
        director.setEstado("ACTIVO");
        director.setEstadoAprobacion("CONFIRMADO");
        director.setNombreCompleto(directorNombre + " (Director General)");
        director.setCargo("Director General");
        director.setEmail(directorEmail);
        director.setTelefono(telefono);
        director.setFechaRegistro(LocalDate.now().toString());
        director.setColegioId(nuevo.getId());
        director.setNombreColegio(nuevo.getNombreColegio());
        director.setSlugColegio(nuevo.getSlug());
        usuarioRepository.save(director);

        registrarEvento("COLEGIO", "Nuevo colegio aprovisionado en Oracle DB: " + nuevo.getNombreColegio(),
                "Director: " + directorNombre + " (" + directorUsername + ")");

        Map<String, Object> cuentaDirectorMap = new LinkedHashMap<>();
        cuentaDirectorMap.put("id", director.getId());
        cuentaDirectorMap.put("username", directorUsername);
        cuentaDirectorMap.put("password", directorPassword);
        cuentaDirectorMap.put("email", directorEmail);
        cuentaDirectorMap.put("nombreCompleto", director.getNombreCompleto());
        cuentaDirectorMap.put("cargo", director.getCargo());
        cuentaDirectorMap.put("rol", "DIRECTOR");
        cuentaDirectorMap.put("colegioId", nuevo.getId());
        cuentaDirectorMap.put("nombreColegio", nuevo.getNombreColegio());
        cuentaDirectorMap.put("slugColegio", slug);
        cuentaDirectorMap.put("portal", "/admin/comunidad");
        cuentaDirectorMap.put("urlAccesoColegio", "/colegio/" + slug);

        Map<String, Object> resp = new LinkedHashMap<>();
        resp.put("exito", true);
        resp.put("mensaje", "¡Suscripción activada y guardada en Oracle DB para " + nuevo.getNombreColegio() + "!");
        resp.put("colegio", mapearColegio(nuevo));
        resp.put("cuentaDirector", cuentaDirectorMap);
        resp.put("credencialesDirector", cuentaDirectorMap);
        resp.put("resumenPago", Map.of(
                "montoPagadoHoy", 1000,
                "proximoMesEstimado", 930,
                "ahorroProximoMes", 70,
                "pisoMinimo", CUOTA_MINIMA_SAAS
        ));
        resp.put("resumenSistema", obtenerResumenSistema());
        return ResponseEntity.status(201).body(resp);
    }

    @Operation(summary = "Simular avance de mes para un colegio en Oracle DB")
    @PostMapping("/colegios/{id}/avanzar-mes")
    public ResponseEntity<?> avanzarMes(@PathVariable Long id) {
        ColegioSaaS col = colegioRepository.findById(id).orElse(null);
        if (col == null) {
            return ResponseEntity.status(404).body(Map.of("message", "Colegio no encontrado en Oracle DB"));
        }

        int nuevoMes = (col.getMesesActivo() != null ? col.getMesesActivo() : 1) + 1;
        double nuevaCuota = cuotaParaMes(nuevoMes);
        col.setMesesActivo(nuevoMes);
        col.setCuotaActual(cuotaParaMes(nuevoMes + 1));
        col.setTotalAbonado(redondear((col.getTotalAbonado() != null ? col.getTotalAbonado() : 0.0) + nuevaCuota));
        col = colegioRepository.save(col);

        return ResponseEntity.ok(Map.of(
                "mensaje", "Se facturó el mes #" + nuevoMes + " para " + col.getNombreColegio() + ". Cuota del mes: S/ " + nuevaCuota,
                "colegio", mapearColegio(col)
        ));
    }

    @Operation(summary = "Suspender o reactivar suscripción de un colegio en Oracle DB")
    @PutMapping("/colegios/{id}/estado")
    public ResponseEntity<?> cambiarEstado(@PathVariable Long id) {
        ColegioSaaS col = colegioRepository.findById(id).orElse(null);
        if (col == null) {
            return ResponseEntity.status(404).body(Map.of("message", "Colegio no encontrado en Oracle DB"));
        }

        String nuevoEstado = "ACTIVO".equalsIgnoreCase(col.getEstado()) ? "SUSPENDIDO" : "ACTIVO";
        col.setEstado(nuevoEstado);
        col = colegioRepository.save(col);

        return ResponseEntity.ok(Map.of(
                "mensaje", "El estado del colegio " + col.getNombreColegio() + " cambió a " + nuevoEstado,
                "colegio", mapearColegio(col)
        ));
    }

    // ========================================================
    // HELPERS PRIVADOS Y ALGORITMO CRIPTOGRÁFICO REZE
    // ========================================================

    private Usuario asegurarCuentaMaestraEnOracle() {
        Usuario master = usuarioRepository.findByUsernameIgnoreCase(AUTHORIZED_MASTER_GOOGLE_ACCOUNT)
                .orElseGet(() -> usuarioRepository.findByEmailIgnoreCase(AUTHORIZED_MASTER_GOOGLE_ACCOUNT).orElse(null));
        if (master == null) {
            master = new Usuario();
            master.setUsername(AUTHORIZED_MASTER_GOOGLE_ACCOUNT);
            master.setPasswordHash("jimy");
            master.setRol("ADMIN");
            master.setEstado("ACTIVO");
            master.setEstadoAprobacion("CONFIRMADO");
            master.setNombreCompleto("Jimy Amanqui (SuperAdmin Maestro)");
            master.setEmail(AUTHORIZED_MASTER_GOOGLE_ACCOUNT);
            master.setCargo("Propietario del Sistema SaaS");
            master.setFechaRegistro(LocalDate.now().toString());
            master = usuarioRepository.save(master);
        } else if (!"ADMIN".equalsIgnoreCase(master.getRol())) {
            master.setRol("ADMIN");
            master.setEstado("ACTIVO");
            master.setEstadoAprobacion("CONFIRMADO");
            master = usuarioRepository.save(master);
        }
        return master;
    }

    private Map<String, Object> getActiveSteamGuardCode(String accountEmail) {
        long now = Instant.now().getEpochSecond();
        long timeStep = now / GUARD_INTERVAL_SECONDS;
        long secondsRemaining = GUARD_INTERVAL_SECONDS - (now % GUARD_INTERVAL_SECONDS);

        String code = computeHmacCode(accountEmail, timeStep, rezeRotationSequence);

        Map<String, Object> m = new LinkedHashMap<>();
        m.put("code", code);
        m.put("secondsRemaining", secondsRemaining);
        m.put("intervalSeconds", GUARD_INTERVAL_SECONDS);
        m.put("timeStep", timeStep);
        m.put("boundEmail", AUTHORIZED_MASTER_GOOGLE_ACCOUNT);
        m.put("rotationSeq", rezeRotationSequence);
        return m;
    }

    private boolean verifySteamGuardCode(String inputCode, String accountEmail) {
        if (inputCode == null || inputCode.trim().length() != 5) return false;
        String cleanInput = inputCode.trim().toUpperCase();
        Map<String, Object> current = getActiveSteamGuardCode(accountEmail);
        if (cleanInput.equals(current.get("code"))) return true;

        long now = Instant.now().getEpochSecond();
        long secondsIntoCycle = now % GUARD_INTERVAL_SECONDS;
        if (secondsIntoCycle <= 25) {
            long prevStep = (now / GUARD_INTERVAL_SECONDS) - 1;
            String prevCode = computeHmacCode(accountEmail, prevStep, rezeRotationSequence);
            return cleanInput.equals(prevCode);
        }
        return false;
    }

    private String computeHmacCode(String accountEmail, long timeStep, int seq) {
        try {
            String salt = "bomerp-guard-hmac-sha256-" + accountEmail.trim().toLowerCase() + "-strict-salt-2026-seq-" + seq;
            Mac mac = Mac.getInstance("HmacSHA256");
            mac.init(new SecretKeySpec(salt.getBytes(StandardCharsets.UTF_8), "HmacSHA256"));
            byte[] rawHmac = mac.doFinal(String.valueOf(timeStep).getBytes(StandardCharsets.UTF_8));
            StringBuilder hex = new StringBuilder();
            for (byte b : rawHmac) {
                hex.append(String.format("%02x", b));
            }
            String chars = "23456789BCDFGHJKMNPQRTVWXYZ";
            StringBuilder code = new StringBuilder();
            for (int i = 0; i < 5; i++) {
                int val = Integer.parseInt(hex.substring(i * 2, i * 2 + 2), 16);
                code.append(chars.charAt(val % chars.length()));
            }
            return code.toString();
        } catch (Exception e) {
            return "REZE5";
        }
    }

    private Map<String, Object> obtenerResumenSistema() {
        List<ColegioSaaS> colegios = colegioRepository.findAll();
        List<Usuario> todosUsuarios = usuarioRepository.findAll();
        long totalAlumnos = alumnoRepository.count();

        long colegiosActivos = colegios.stream().filter(c -> "ACTIVO".equalsIgnoreCase(c.getEstado())).count();
        long colegiosSuspendidos = colegios.stream().filter(c -> "SUSPENDIDO".equalsIgnoreCase(c.getEstado())).count();
        double mrr = colegios.stream()
                .filter(c -> "ACTIVO".equalsIgnoreCase(c.getEstado()))
                .mapToDouble(c -> c.getCuotaActual() != null ? c.getCuotaActual() : 1000.0)
                .sum();
        double totalHistorico = colegios.stream()
                .mapToDouble(c -> c.getTotalAbonado() != null ? c.getTotalAbonado() : 1000.0)
                .sum();

        long admins = todosUsuarios.stream().filter(u -> "ADMIN".equalsIgnoreCase(u.getRol())).count();
        long directores = todosUsuarios.stream().filter(u -> "DIRECTOR".equalsIgnoreCase(u.getRol())).count();
        long secretarias = todosUsuarios.stream().filter(u -> "SECRETARIA".equalsIgnoreCase(u.getRol())).count();
        long docentes = todosUsuarios.stream().filter(u -> "DOCENTE".equalsIgnoreCase(u.getRol())).count();
        long colaboradores = todosUsuarios.stream().filter(u -> "COLABORADOR".equalsIgnoreCase(u.getRol())).count();

        Map<String, Object> finanzas = new LinkedHashMap<>();
        finanzas.put("mrr", mrr);
        finanzas.put("totalHistorico", totalHistorico);
        finanzas.put("arr", mrr * 12.0);
        finanzas.put("totalColegios", colegios.size());
        finanzas.put("colegiosActivos", colegiosActivos);
        finanzas.put("colegiosSuspendidos", colegiosSuspendidos);
        finanzas.put("planBase", CUOTA_BASE_SAAS);
        finanzas.put("descuentoMensual", 70);
        finanzas.put("pisoMinimo", CUOTA_MINIMA_SAAS);
        finanzas.put("tablaCuotas", tablaCuotas());
        finanzas.put("colegios", colegios.stream().map(this::mapearColegio).collect(Collectors.toList()));

        Map<String, Object> usuariosMap = new LinkedHashMap<>();
        usuariosMap.put("totalUsuarios", todosUsuarios.size());
        usuariosMap.put("usuariosEscolares", todosUsuarios.size() - admins);
        usuariosMap.put("admins", admins);
        usuariosMap.put("superAdmins", admins);
        usuariosMap.put("directores", directores);
        usuariosMap.put("secretarias", secretarias);
        usuariosMap.put("docentes", docentes);
        usuariosMap.put("colaboradores", colaboradores);
        usuariosMap.put("alumnos", totalAlumnos);
        usuariosMap.put("cuentas", todosUsuarios.stream().map(u -> {
            Map<String, Object> m = new LinkedHashMap<>();
            m.put("id", u.getId());
            m.put("username", u.getUsername());
            m.put("nombreCompleto", u.getNombreCompleto() != null ? u.getNombreCompleto() : u.getUsername());
            m.put("rol", u.getRol());
            m.put("estado", u.getEstado());
            m.put("email", u.getEmail() != null ? u.getEmail() : u.getUsername());
            m.put("nombreColegio", u.getNombreColegio());
            return m;
        }).collect(Collectors.toList()));

        List<Map<String, Object>> activos = obtenerDispositivosActivos();
        Map<String, Object> actividad = new LinkedHashMap<>();
        actividad.put("estadoServidor", "OPERATIVO");
        actividad.put("dispositivosActivos", activos.size());
        actividad.put("dispositivos", activos);
        actividad.put("ultimaSincronizacion", Instant.now().toString());
        actividad.put("eventos", eventosSistema.stream().limit(25).collect(Collectors.toList()));

        return Map.of(
                "finanzas", finanzas,
                "usuarios", usuariosMap,
                "actividad", actividad
        );
    }

    private List<Map<String, Object>> obtenerDispositivosActivos() {
        return registeredMasterDevices.stream()
                .filter(d -> "ACTIVO".equals(d.get("status")))
                .collect(Collectors.toList());
    }

    private Map<String, Object> registrarOTocarDispositivo(String deviceId, String deviceName, String userAgent, String ip) {
        String now = Instant.now().toString();
        for (Map<String, Object> dev : registeredMasterDevices) {
            if (deviceId.equals(dev.get("deviceId"))) {
                dev.put("status", "ACTIVO");
                dev.put("lastUsedAt", now);
                if (deviceName != null && !deviceName.isBlank()) {
                    dev.put("deviceName", deviceName.trim());
                }
                return dev;
            }
        }
        String resolvedName = deviceName != null && !deviceName.isBlank() ? deviceName.trim() :
                (userAgent != null && userAgent.contains("Android") ? "Android Mobile" :
                 userAgent != null && userAgent.contains("iPhone") ? "Apple iPhone" : "Dispositivo Móvil REZE");
        Map<String, Object> nuevo = new LinkedHashMap<>();
        nuevo.put("deviceId", deviceId.trim());
        nuevo.put("deviceName", resolvedName);
        nuevo.put("userAgent", userAgent != null ? userAgent : "Mobile App");
        nuevo.put("registeredAt", now);
        nuevo.put("lastUsedAt", now);
        nuevo.put("ip", ip != null ? ip : "127.0.0.1");
        nuevo.put("status", "ACTIVO");
        nuevo.put("boundEmail", AUTHORIZED_MASTER_GOOGLE_ACCOUNT);
        registeredMasterDevices.add(nuevo);
        return nuevo;
    }

    private void registrarEvento(String tipo, String titulo, String detalle) {
        Map<String, Object> evt = new LinkedHashMap<>();
        evt.put("id", "evt-" + System.currentTimeMillis());
        evt.put("tipo", tipo);
        evt.put("titulo", titulo);
        evt.put("detalle", detalle);
        evt.put("fecha", Instant.now().toString());
        eventosSistema.add(0, evt);
        while (eventosSistema.size() > 50) {
            eventosSistema.remove(eventosSistema.size() - 1);
        }
    }

    private Map<String, Object> mapearColegio(ColegioSaaS c) {
        String slug = c.getSlug() != null && !c.getSlug().isBlank() ? c.getSlug() : generarSlugColegio(c.getNombreColegio());
        Map<String, Object> m = new LinkedHashMap<>();
        m.put("id", c.getId());
        m.put("nombreColegio", c.getNombreColegio());
        m.put("nombre", c.getNombreColegio());
        m.put("slug", slug);
        m.put("urlAcceso", c.getUrlAcceso() != null ? c.getUrlAcceso() : "/colegio/" + slug);
        m.put("codigoModular", c.getCodigoModular());
        m.put("ruc", c.getRuc());
        m.put("ciudad", c.getCiudad());
        m.put("telefono", c.getTelefono());
        m.put("directorNombre", c.getDirectorNombre());
        m.put("directorEmail", c.getDirectorEmail());
        m.put("directorUsername", c.getDirectorUsername());
        m.put("fechaAlta", c.getFechaAlta());
        m.put("mesesActivo", c.getMesesActivo() != null ? c.getMesesActivo() : 1);
        m.put("mesesSuscrito", c.getMesesActivo() != null ? c.getMesesActivo() : 1);
        m.put("cuotaActual", c.getCuotaActual() != null ? c.getCuotaActual() : 1000.0);
        m.put("estado", c.getEstado() != null ? c.getEstado() : "ACTIVO");
        m.put("totalAbonado", c.getTotalAbonado() != null ? c.getTotalAbonado() : 1000.0);
        m.put("metodoPago", c.getMetodoPago() != null ? c.getMetodoPago() : "TARJETA");
        return m;
    }

    private ColegioSaaS resolverColegio(Long colegioId, String username) {
        if (colegioId != null) {
            ColegioSaaS porId = colegioRepository.findById(colegioId).orElse(null);
            if (porId != null) {
                return porId;
            }
        }
        if (username != null && !username.isBlank()) {
            String clean = username.trim().toLowerCase();
            ColegioSaaS porUser = colegioRepository.findAll().stream()
                    .filter(c -> c.getDirectorUsername() != null && c.getDirectorUsername().equalsIgnoreCase(clean))
                    .findFirst()
                    .orElse(null);
            if (porUser != null) {
                return porUser;
            }
            Usuario u = usuarioRepository.findByUsernameIgnoreCase(clean).orElse(null);
            if (u != null && u.getColegioId() != null) {
                ColegioSaaS porUsuarioColegio = colegioRepository.findById(u.getColegioId()).orElse(null);
                if (porUsuarioColegio != null) {
                    return porUsuarioColegio;
                }
            }
        }
        List<ColegioSaaS> todos = colegioRepository.findAll();
        if (!todos.isEmpty()) {
            return todos.get(todos.size() - 1);
        }
        // Auto-aprovisionar registro base en COLEGIO_SAAS si el Director aún no tenía fila en COLEGIO_SAAS
        Usuario dirUser = (username != null && !username.isBlank())
                ? usuarioRepository.findByUsernameIgnoreCase(username.trim()).orElse(null)
                : null;
        String nombreColegio = (dirUser != null && dirUser.getNombreColegio() != null && !dirUser.getNombreColegio().isBlank())
                ? dirUser.getNombreColegio()
                : "Institución Educativa Oficial";
        String slug = generarSlugColegio(nombreColegio);
        ColegioSaaS nuevo = new ColegioSaaS();
        nuevo.setNombreColegio(nombreColegio);
        nuevo.setSlug(slug);
        nuevo.setUrlAcceso("/colegio/" + slug);
        nuevo.setCodigoModular("MOD-202601");
        nuevo.setRuc("20100000001");
        nuevo.setCiudad("Perú");
        nuevo.setTelefono("");
        nuevo.setDirectorNombre(dirUser != null && dirUser.getNombreCompleto() != null ? dirUser.getNombreCompleto() : "Dirección General");
        nuevo.setDirectorEmail(dirUser != null && dirUser.getEmail() != null ? dirUser.getEmail() : "direccion@colegio.edu.pe");
        nuevo.setDirectorUsername(dirUser != null && dirUser.getUsername() != null ? dirUser.getUsername() : (username != null ? username.trim() : "director"));
        nuevo.setFechaAlta(LocalDate.now().toString());
        nuevo.setMesesActivo(1);
        nuevo.setCuotaActual(CUOTA_BASE_SAAS);
        nuevo.setEstado("ACTIVO");
        nuevo.setTotalAbonado(CUOTA_BASE_SAAS);
        nuevo.setMetodoPago("TARJETA");
        return colegioRepository.save(nuevo);
    }

    private Map<String, Object> construirSuscripcion(ColegioSaaS col) {
        Map<String, Object> m = new LinkedHashMap<>(mapearColegio(col));
        Long colegioId = col.getId();
        double pensiones = colegioId != null
                ? planFinancieroService.obtenerRecaudacion(colegioId).totalPensionesCobradas()
                : 0.0;
        List<PagoSaaS> pagos = colegioId != null
                ? pagoSaaSRepository.findByColegioIdOrderByIdDesc(colegioId)
                : List.of();
        double pagado = pagos.stream()
                .filter(p -> "CONFIRMADO".equalsIgnoreCase(p.getEstado()))
                .mapToDouble(p -> p.getMonto() != null ? p.getMonto() : 0.0)
                .sum();
        double fondos = redondear(pensiones - pagado);
        int mesActivo = col.getMesesActivo() != null ? col.getMesesActivo() : 1;
        int siguienteMes = mesActivo + 1;

        m.put("fondosDisponibles", fondos);
        m.put("totalPensionesCobradas", redondear(pensiones));
        m.put("totalPagadoSaas", redondear(pagado));
        m.put("mesActivo", mesActivo);
        m.put("siguienteMes", siguienteMes);
        m.put("montoSiguiente", cuotaParaMes(siguienteMes));
        m.put("proyeccion", proyeccion(mesActivo, 12));
        m.put("tablaCuotas", tablaCuotas());
        m.put("pagos", pagos.stream().map(this::mapearPago).collect(Collectors.toList()));
        return m;
    }

    private double totalPagadoSaas(Long colegioId) {
        return redondear(pagoSaaSRepository.findByColegioIdOrderByIdDesc(colegioId).stream()
                .filter(p -> "CONFIRMADO".equalsIgnoreCase(p.getEstado()))
                .mapToDouble(p -> p.getMonto() != null ? p.getMonto() : 0.0)
                .sum());
    }

    private Map<String, Object> mapearPago(PagoSaaS p) {
        Map<String, Object> m = new LinkedHashMap<>();
        m.put("id", p.getId());
        m.put("numeroRecibo", "REC-SAAS-" + String.format("%06d", p.getId() != null ? p.getId() : 0));
        m.put("colegioId", p.getColegioId());
        m.put("mesDesde", p.getMesDesde());
        m.put("mesHasta", p.getMesHasta());
        m.put("mesesPagados", p.getMesesPagados());
        m.put("monto", p.getMonto());
        m.put("metodoPago", p.getMetodoPago());
        m.put("banco", p.getBanco());
        m.put("numeroOperacion", p.getNumeroOperacion());
        m.put("voucherNombre", p.getVoucherNombre());
        m.put("fechaPago", p.getFechaPago());
        m.put("fechaHora", p.getFechaPago());
        m.put("estado", p.getEstado());
        m.put("saldoFondosAntes", p.getSaldoFondosAntes());
        m.put("saldoFondosDespues", p.getSaldoFondosDespues());
        return m;
    }

    private List<Map<String, Object>> proyeccion(int mesActivo, int cantidad) {
        List<Map<String, Object>> lista = new ArrayList<>();
        double acumulado = 0.0;
        for (int i = 1; i <= cantidad; i++) {
            int mes = mesActivo + i;
            double cuota = cuotaParaMes(mes);
            acumulado = redondear(acumulado + cuota);
            Map<String, Object> item = new LinkedHashMap<>();
            item.put("mes", mes);
            item.put("monto", cuota);
            item.put("acumulado", acumulado);
            lista.add(item);
        }
        return lista;
    }

    private List<Map<String, Object>> tablaCuotas() {
        return List.of(
                Map.of("mes", 1, "monto", 1000.0),
                Map.of("mes", 2, "monto", 930.0),
                Map.of("mes", 3, "monto", 860.0),
                Map.of("mes", 4, "monto", 860.0),
                Map.of("mes", 5, "monto", 700.0)
        );
    }

    public static double cuotaParaMes(int mes) {
        if (mes <= 1) return CUOTA_BASE_SAAS;
        if (mes == 2) return 930.0;
        if (mes <= 4) return 860.0;
        return CUOTA_MINIMA_SAAS;
    }

    private static double calcularMontoMeses(int desde, int cantidad) {
        double total = 0.0;
        for (int i = 0; i < cantidad; i++) {
            total += cuotaParaMes(desde + i);
        }
        return redondear(total);
    }

    private static double redondear(double valor) {
        return Math.round(valor * 100.0) / 100.0;
    }

    private static String texto(Object value, String defaultValue) {
        if (value == null) return defaultValue;
        String s = String.valueOf(value).trim();
        return s.isEmpty() ? defaultValue : s;
    }

    private static String limitar(String value, int max) {
        if (value == null) return null;
        String s = value.trim();
        return s.length() <= max ? s : s.substring(0, max);
    }

    private static Long parseLong(Object value, Long defaultValue) {
        if (value == null) return defaultValue;
        try {
            return Long.parseLong(String.valueOf(value).trim());
        } catch (NumberFormatException e) {
            return defaultValue;
        }
    }

    private static int parseInt(Object value, int defaultValue) {
        if (value == null) return defaultValue;
        try {
            return Integer.parseInt(String.valueOf(value).trim());
        } catch (NumberFormatException e) {
            return defaultValue;
        }
    }

    private String generarSlugColegio(String nombre) {
        if (nombre == null || nombre.isBlank()) return "colegio-institucional";
        String normalized = Normalizer.normalize(nombre.trim(), Normalizer.Form.NFD)
                .replaceAll("[\\p{InCombiningDiacriticalMarks}]", "")
                .toLowerCase()
                .replaceAll("[^a-z0-9]+", "-")
                .replaceAll("^-+|-+$", "");
        return normalized.isEmpty() ? "colegio-institucional" : normalized;
    }

    private String resolverBaseUrl(Map<String, Object> body, HttpServletRequest request) {
        if (body != null && body.get("origin") != null && String.valueOf(body.get("origin")).startsWith("http")) {
            return String.valueOf(body.get("origin")).replaceAll("/$", "");
        }
        String originHeader = request.getHeader("Origin");
        if (originHeader != null && originHeader.startsWith("http")) {
            return originHeader.replaceAll("/$", "");
        }
        return "http://localhost:4200";
    }

    private String generarQrSvgAccesoDirecto(String url) {
        return "<svg xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 240 240\" width=\"240\" height=\"240\">" +
                "<rect width=\"240\" height=\"240\" rx=\"16\" fill=\"#ffffff\"/>" +
                "<rect x=\"20\" y=\"20\" width=\"60\" height=\"60\" fill=\"none\" stroke=\"#0f172a\" stroke-width=\"8\"/>" +
                "<rect x=\"34\" y=\"34\" width=\"32\" height=\"32\" fill=\"#0f172a\"/>" +
                "<rect x=\"160\" y=\"20\" width=\"60\" height=\"60\" fill=\"none\" stroke=\"#0f172a\" stroke-width=\"8\"/>" +
                "<rect x=\"174\" y=\"34\" width=\"32\" height=\"32\" fill=\"#0f172a\"/>" +
                "<rect x=\"20\" y=\"160\" width=\"60\" height=\"60\" fill=\"none\" stroke=\"#0f172a\" stroke-width=\"8\"/>" +
                "<rect x=\"34\" y=\"174\" width=\"32\" height=\"32\" fill=\"#0f172a\"/>" +
                "<rect x=\"96\" y=\"96\" width=\"48\" height=\"48\" rx=\"10\" fill=\"#0f172a\"/>" +
                "<circle cx=\"120\" cy=\"124\" r=\"11\" fill=\"none\" stroke=\"#ffffff\" stroke-width=\"3\"/>" +
                "<line x1=\"120\" y1=\"104\" x2=\"120\" y2=\"113\" stroke=\"#ffffff\" stroke-width=\"3\" stroke-linecap=\"round\"/>" +
                "<rect x=\"96\" y=\"28\" width=\"12\" height=\"12\" fill=\"#0f172a\"/>" +
                "<rect x=\"116\" y=\"44\" width=\"12\" height=\"24\" fill=\"#0f172a\"/>" +
                "<rect x=\"28\" y=\"96\" width=\"24\" height=\"12\" fill=\"#0f172a\"/>" +
                "<rect x=\"60\" y=\"116\" width=\"20\" height=\"12\" fill=\"#0f172a\"/>" +
                "<rect x=\"156\" y=\"96\" width=\"24\" height=\"12\" fill=\"#0f172a\"/>" +
                "<rect x=\"188\" y=\"116\" width=\"24\" height=\"24\" fill=\"#0f172a\"/>" +
                "<rect x=\"96\" y=\"160\" width=\"24\" height=\"12\" fill=\"#0f172a\"/>" +
                "<rect x=\"132\" y=\"176\" width=\"20\" height=\"20\" fill=\"#0f172a\"/>" +
                "<rect x=\"164\" y=\"164\" width=\"48\" height=\"12\" fill=\"#0f172a\"/>" +
                "<rect x=\"164\" y=\"192\" width=\"24\" height=\"20\" fill=\"#0f172a\"/>" +
                "</svg>";
    }
}

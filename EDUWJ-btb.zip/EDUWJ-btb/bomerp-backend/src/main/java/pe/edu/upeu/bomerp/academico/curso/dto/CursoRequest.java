package pe.edu.upeu.bomerp.academico.curso.dto;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Positive;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class CursoRequest {

    @NotBlank
    private String nombre;

    @NotBlank
    private String grado;

    @NotNull
    @Positive
    private Integer creditos;

    @NotNull
    @Positive
    private Integer vacantesMaximas;

    private String aula;

    private Long colegioId;
}

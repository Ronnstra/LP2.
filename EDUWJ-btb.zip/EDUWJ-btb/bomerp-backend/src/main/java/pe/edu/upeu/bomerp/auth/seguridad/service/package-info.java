/**
 * Servicio de autenticación expuesto para módulos que registran usuarios.
 */
@org.springframework.modulith.NamedInterface("auth-seguridad-service")
package pe.edu.upeu.bomerp.auth.seguridad.service;

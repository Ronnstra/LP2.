package pe.edu.upeu.bomerp.asistencia.entity;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.time.LocalDate;

@Entity
@Table(
        name = "ASISTENCIAS",
        schema = "BOMERP_APP",
        uniqueConstraints = @UniqueConstraint(
                name = "UK_ASISTENCIA_SESION",
                columnNames = {"ALUMNO_ID", "CURSO", "GRADO", "SECCION", "SESION"}
        )
)
@Getter
@Setter
@NoArgsConstructor
public class Asistencia {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "ALUMNO_ID", nullable = false)
    private Long alumnoId;

    @Column(name = "COLEGIO_ID")
    private Long colegioId;

    @Column(nullable = false, length = 120)
    private String curso;

    @Column(name = "DOCENTE_ID", nullable = false)
    private Long docenteId;

    @Column(name = "DOCENTE_NOMBRE", length = 160)
    private String docenteNombre;

    @Column(nullable = false, length = 30)
    private String estado;

    @Column(name = "FECHA_REGISTRO", nullable = false)
    private LocalDate fechaRegistro;

    @Column(length = 50)
    private String grado;

    @Column(length = 15)
    private String seccion;

    @Column(nullable = false)
    private Integer sesion;
}

package pe.edu.upeu.bomerp.academico.curso.service;

import pe.edu.upeu.bomerp.academico.curso.dto.CursoRequest;
import pe.edu.upeu.bomerp.academico.curso.dto.CursoResponse;
import java.util.List;

public interface CursoService {
    List<CursoResponse> listar(String grado);
    CursoResponse obtener(Long id);
    CursoResponse crear(CursoRequest request);
    CursoResponse actualizar(Long id, CursoRequest request);
    void eliminar(Long id);
    void descontarVacante(Long id, Integer vacantes);
}

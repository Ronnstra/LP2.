package pe.edu.upeu.bomerp.matricula.inscripcion.dto;

import lombok.Getter;
import pe.edu.upeu.bomerp.matricula.inscripcion.entity.EstadoMatricula;

import java.time.LocalDateTime;

@Getter
public class MatriculaResumen {
    private final Long id;
    private final String nombreAlumno;
    private final LocalDateTime fecha;
    private final String periodo;
    private final String estado;
    private final Integer totalCreditos;
    private final long cantidadCursos;

    public MatriculaResumen(Long id, String nombreAlumno, LocalDateTime fecha, String periodo,
                            EstadoMatricula estado, Integer totalCreditos, long cantidadCursos) {
        this.id = id;
        this.nombreAlumno = nombreAlumno;
        this.fecha = fecha;
        this.periodo = periodo;
        this.estado = estado != null ? estado.name() : "REGISTRADA";
        this.totalCreditos = totalCreditos != null ? totalCreditos : 0;
        this.cantidadCursos = cantidadCursos;
    }

    public MatriculaResumen(Long id, String nombreAlumno, LocalDateTime fecha, String periodo,
                            EstadoMatricula estado, Integer totalCreditos, int cantidadCursos) {
        this(id, nombreAlumno, fecha, periodo, estado, totalCreditos, (long) cantidadCursos);
    }

    public MatriculaResumen(Long id, String nombreAlumno, LocalDateTime fecha, String periodo,
                            EstadoMatricula estado, Integer totalCreditos, Number cantidadCursos) {
        this(id, nombreAlumno, fecha, periodo, estado, totalCreditos,
                cantidadCursos != null ? cantidadCursos.longValue() : 0L);
    }

    public MatriculaResumen(Long id, String nombreAlumno, LocalDateTime fecha, String periodo,
                            String estado, Integer totalCreditos, long cantidadCursos) {
        this.id = id;
        this.nombreAlumno = nombreAlumno;
        this.fecha = fecha;
        this.periodo = periodo;
        this.estado = estado != null ? estado : "REGISTRADA";
        this.totalCreditos = totalCreditos != null ? totalCreditos : 0;
        this.cantidadCursos = cantidadCursos;
    }

    public MatriculaResumen(Long id, String nombreAlumno, LocalDateTime fecha, String periodo,
                            String estado, Integer totalCreditos, int cantidadCursos) {
        this(id, nombreAlumno, fecha, periodo, estado, totalCreditos, (long) cantidadCursos);
    }

    public MatriculaResumen(Long id, String nombreAlumno, LocalDateTime fecha, String periodo,
                            String estado, Integer totalCreditos, Number cantidadCursos) {
        this(id, nombreAlumno, fecha, periodo, estado, totalCreditos,
                cantidadCursos != null ? cantidadCursos.longValue() : 0L);
    }
}

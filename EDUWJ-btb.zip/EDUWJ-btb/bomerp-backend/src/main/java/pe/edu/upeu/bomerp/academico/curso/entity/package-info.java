/**
 * Entidades de Curso expuestas para módulos que orquestan horarios y matrícula.
 */
@org.springframework.modulith.NamedInterface("academico-curso-entity")
package pe.edu.upeu.bomerp.academico.curso.entity;

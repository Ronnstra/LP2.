/**
 * Repositorio de Curso expuesto para módulos que orquestan horarios y matrícula.
 */
@org.springframework.modulith.NamedInterface("academico-curso-repository")
package pe.edu.upeu.bomerp.academico.curso.repository;

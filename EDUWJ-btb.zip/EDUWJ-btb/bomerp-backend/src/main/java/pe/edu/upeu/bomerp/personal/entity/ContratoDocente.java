package pe.edu.upeu.bomerp.personal.entity;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;

@Entity
@Table(name = "CONTRATOS_DOCENTES", schema = "BOMERP_APP")
@Getter
@Setter
public class ContratoDocente {

    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "seq_contrato_doc")
    @SequenceGenerator(name = "seq_contrato_doc", sequenceName = "BOMERP_APP.SEQ_CONTRATO_DOC", allocationSize = 1)
    private Long id;

    @Column(nullable = false)
    private Long docenteId;

    @Column(nullable = false, length = 150)
    private String docenteNombre;

    @Column(length = 20)
    private String dni;

    @Column(nullable = false)
    private Double tarifaPorHora = 35.0;

    @Column(nullable = false)
    private Double horasSemanales = 0.0;

    @Column(nullable = false)
    private Double horasMensualesEstimadas = 0.0;

    @Column(nullable = false)
    private Double pagoMensualEstimado = 0.0;

    @Column(length = 25)
    private String fechaInicio;

    @Column(length = 25)
    private String fechaFin;

    @Column(length = 30)
    private String estado = "VIGENTE"; // VIGENTE, FINALIZADO, EN_REVISION

    @Column(length = 500)
    private String cursosAsignadosCsv;

    @Column(length = 500)
    private String gradosAsignadosCsv;

    @Column(length = 400)
    private String observaciones;

    @Column(name = "COLEGIO_ID")
    private Long colegioId;
}

package pe.edu.upeu.bomerp.matricula.inscripcion.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.time.LocalDateTime;
import java.util.List;

@Getter
@Setter
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class MatriculaResponse {
    private Long id;
    private Long alumnoId;
    private String nombreAlumno;
    private LocalDateTime fecha;
    private String periodo;
    private String estado;
    private Integer totalCreditos;
    private List<DetalleMatriculaResponse> detalles;
}

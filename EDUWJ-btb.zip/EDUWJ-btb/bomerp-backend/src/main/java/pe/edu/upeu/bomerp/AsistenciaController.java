package pe.edu.upeu.bomerp;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.*;
import pe.edu.upeu.bomerp.asistencia.entity.Asistencia;
import pe.edu.upeu.bomerp.asistencia.entity.JustificacionInasistencia;
import pe.edu.upeu.bomerp.asistencia.repository.AsistenciaRepository;
import pe.edu.upeu.bomerp.asistencia.repository.JustificacionInasistenciaRepository;
import pe.edu.upeu.bomerp.asistencia.service.AsistenciaService;
import pe.edu.upeu.bomerp.auth.seguridad.entity.Usuario;
import pe.edu.upeu.bomerp.auth.seguridad.repository.UsuarioRepository;
import pe.edu.upeu.bomerp.horario.entity.BloqueHorario;
import pe.edu.upeu.bomerp.horario.repository.BloqueHorarioRepository;
import pe.edu.upeu.bomerp.matricula.alumno.entity.Alumno;
import pe.edu.upeu.bomerp.matricula.alumno.repository.AlumnoRepository;
import pe.edu.upeu.bomerp.personal.entity.PersonalEscolar;
import pe.edu.upeu.bomerp.personal.repository.PersonalEscolarRepository;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.*;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/api/v1/inasistencias")
@RequiredArgsConstructor
@Transactional
@Tag(name = "Asistencias y Justificaciones", description = "Gestión persistente en Oracle DB de asistencias diarias y flujo de justificaciones de falta")
public class AsistenciaController {

    private final JustificacionInasistenciaRepository justificacionRepository;
    private final AsistenciaRepository asistenciaRepository;
    private final AsistenciaService asistenciaService;
    private final AlumnoRepository alumnoRepository;
    private final PersonalEscolarRepository personalRepository;
    private final UsuarioRepository usuarioRepository;
    private final BloqueHorarioRepository bloqueHorarioRepository;

    private static final DateTimeFormatter FMT = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm");

    @Operation(summary = "Enviar nueva justificación de inasistencia y guardarla en Oracle DB")
    @PostMapping("/justificar")
    public ResponseEntity<?> enviarJustificacion(@RequestBody Map<String, Object> request) {
        Long alumnoId = parseLong(request.get("alumnoId"), null);
        String curso = limitar(texto(request.get("curso"), ""), 120);
        String fechaInasistencia = limitar(texto(request.get("fechaInasistencia"), ""), 30);
        String motivo = limitar(texto(request.get("motivo"), ""), 200);
        String descripcion = limitar(texto(request.get("descripcion"), ""), 1000);

        if (alumnoId == null || curso.isEmpty() || fechaInasistencia.isEmpty() || motivo.isEmpty() || descripcion.isEmpty()) {
            return ResponseEntity.badRequest().body(Map.of("message", "Alumno, curso, fecha, motivo y descripción son obligatorios."));
        }

        Alumno alumno = alumnoRepository.findById(alumnoId).orElse(null);
        if (alumno == null) {
            return ResponseEntity.status(404).body(Map.of("message", "Alumno no encontrado para la justificación."));
        }

        Long reqDocenteId = parseLong(request.get("docenteId"), null);
        PersonalEscolar docente = reqDocenteId != null ? personalRepository.findById(reqDocenteId).orElse(null) : null;

        if (docente == null) {
            // Buscar el docente que realmente dicta ese curso en el horario
            BloqueHorario bloque = bloqueHorarioRepository.findAll().stream()
                    .filter(b -> b.getCurso() != null && b.getCurso().equalsIgnoreCase(curso))
                    .findFirst()
                    .orElse(null);
            if (bloque != null && bloque.getDocenteId() != null) {
                docente = personalRepository.findById(bloque.getDocenteId()).orElse(null);
            }
        }

        int sesionCalculada = parseInt(request.get("sesion"), 1);
        if (sesionCalculada < 1) sesionCalculada = 1;
        final int sesion = sesionCalculada;

        String gradoAlumno = alumno.getGrado() != null ? alumno.getGrado() : "";
        String seccionAlumno = alumno.getSeccion() != null ? alumno.getSeccion() : "";
        Asistencia asistencia = asistenciaRepository
                .findByAlumnoIdAndCursoIgnoreCaseAndGradoIgnoreCaseAndSeccionIgnoreCaseAndSesion(
                        alumnoId, curso, gradoAlumno, seccionAlumno, sesion)
                .orElseGet(() -> asistenciaRepository
                        .findFirstByAlumnoIdAndCursoIgnoreCaseAndSesionAndEstadoIgnoreCaseOrderByIdDesc(
                                alumnoId, curso, sesion, "FALTA")
                        .orElse(null));

        if (asistencia == null) {
            return ResponseEntity.badRequest().body(Map.of(
                    "message", "No hay una falta registrada para esta sesión. Solo puedes justificar faltas."
            ));
        }

        if (!"FALTA".equalsIgnoreCase(asistencia.getEstado())) {
            return ResponseEntity.badRequest().body(Map.of(
                    "message", "Solo se pueden justificar faltas. Esta sesión está registrada como "
                            + asistencia.getEstado() + "."
            ));
        }

        String fechaJustificacion = asistencia.getFechaRegistro() != null
                ? asistencia.getFechaRegistro().toString()
                : fechaInasistencia;

        JustificacionInasistencia existente = justificacionRepository
                .findFirstByAlumnoIdAndCursoIgnoreCaseAndSesionAndEstadoOrderByIdDesc(alumnoId, curso, sesion, "PENDIENTE")
                .orElse(null);
        if (existente != null) {
            return ResponseEntity.status(409).body(Map.of(
                    "message", "Ya enviaste una justificación para esta sesión. Espera la confirmación del docente.",
                    "justificacion", existente
            ));
        }

        String alumnoNombre = limitar(
                (alumno.getNombre() + " " + alumno.getApellidoPaterno() + " " + (alumno.getApellidoMaterno() != null ? alumno.getApellidoMaterno() : "")).trim(),
                160
        );

        JustificacionInasistencia j = new JustificacionInasistencia();
        j.setAlumnoId(alumno.getId());
        j.setAlumnoNombre(alumnoNombre);
        j.setGrado(limitar(alumno.getGrado() != null ? alumno.getGrado() : "Secundaria", 50));
        j.setSeccion(limitar(alumno.getSeccion() != null ? alumno.getSeccion() : "A", 15));
        j.setColegioId(alumno.getColegioId() != null ? alumno.getColegioId() : (docente != null ? docente.getColegioId() : null));
        j.setCurso(curso);
        j.setDocenteId(docente != null ? docente.getId() : (reqDocenteId != null ? reqDocenteId : 0L));
        j.setDocenteNombre(limitar(docente != null ? ("Prof. " + docente.getNombre() + " " + docente.getApellidos()) : "Docente del Curso", 160));
        j.setFechaInasistencia(fechaJustificacion);
        j.setHoraClase(limitar(texto(request.get("horaClase"), "08:00 - 10:00"), 40));
        j.setSesion(sesion);
        j.setMotivo(motivo);
        j.setDescripcion(descripcion);
        String compNombre = limitar(texto(request.get("comprobanteNombre"), "comprobante_adjunto.pdf"), 200);
        j.setComprobanteNombre(compNombre);
        j.setComprobanteUrl(limitar("/docs/" + compNombre, 300));
        j.setEstado("PENDIENTE");
        j.setFechaEnvio(LocalDateTime.now().format(FMT));

        j = justificacionRepository.save(j);

        return ResponseEntity.status(201).body(Map.of(
                "mensaje", "Justificación remitida formalmente al docente y guardada en Oracle DB.",
                "justificacion", j
        ));
    }

    @Operation(summary = "Listar justificaciones por alumno desde Oracle DB")
    @GetMapping("/alumno/{id}")
    public ResponseEntity<List<JustificacionInasistencia>> listarPorAlumno(@PathVariable Long id) {
        return ResponseEntity.ok(justificacionRepository.findByAlumnoIdOrderByIdDesc(id));
    }

    @Operation(summary = "Listar justificaciones estrictamente asignadas al docente desde Oracle DB")
    @GetMapping("/docente/{id}")
    public ResponseEntity<List<JustificacionInasistencia>> listarPorDocente(@PathVariable Long id) {
        PersonalEscolar docente = personalRepository.findById(id).orElse(null);
        if (docente == null) {
            Usuario u = usuarioRepository.findById(id).orElse(null);
            if (u != null && u.getUsername() != null) {
                docente = u.getColegioId() != null
                        ? personalRepository.findByUsernameIgnoreCaseAndColegioId(u.getUsername(), u.getColegioId()).orElse(null)
                        : personalRepository.findByUsernameIgnoreCase(u.getUsername()).orElse(null);
                if (docente == null && u.getDni() != null) {
                    docente = u.getColegioId() != null
                            ? personalRepository.findByDniAndColegioId(u.getDni(), u.getColegioId()).orElse(null)
                            : personalRepository.findFirstByDniOrderByIdAsc(u.getDni()).orElse(null);
                }
            }
        }

        if (docente == null) {
            return ResponseEntity.ok(List.of());
        }

        final Long realDocenteId = docente.getId();
        final Long docenteColegioId = docente.getColegioId();

        // Cursos asignados en bloques de horario a este docente específico
        Set<String> cursosAsignadosEnHorario = bloqueHorarioRepository.findByDocenteId(realDocenteId).stream()
                .map(BloqueHorario::getCurso)
                .filter(Objects::nonNull)
                .map(c -> c.trim().toLowerCase())
                .collect(Collectors.toSet());

        List<JustificacionInasistencia> filtradas = justificacionRepository.findAll().stream()
                .filter(j -> docenteColegioId == null || Objects.equals(docenteColegioId, j.getColegioId()))
                .filter(j -> Objects.equals(j.getDocenteId(), realDocenteId)
                        || (j.getCurso() != null && cursosAsignadosEnHorario.contains(j.getCurso().trim().toLowerCase())))
                .sorted(Comparator.comparing(JustificacionInasistencia::getId).reversed())
                .collect(Collectors.toList());

        return ResponseEntity.ok(filtradas);
    }

    @Operation(summary = "Resolver justificación (Aprobar/Rechazar) en Oracle DB")
    @PutMapping("/{id}/resolver")
    public ResponseEntity<?> resolver(@PathVariable Long id, @RequestBody Map<String, Object> request) {
        JustificacionInasistencia item = justificacionRepository.findById(id).orElse(null);
        if (item == null) {
            return ResponseEntity.status(404).body(Map.of("message", "Justificación no encontrada en Oracle DB"));
        }

        String estado = request.get("estado") != null ? String.valueOf(request.get("estado")).trim().toUpperCase() : "APROBADA";
        if (!"APROBADA".equals(estado) && !"RECHAZADA".equals(estado)) {
            return ResponseEntity.badRequest().body(Map.of("message", "El estado debe ser 'APROBADA' o 'RECHAZADA'"));
        }

        String respuestaDocente = request.get("respuestaDocente") != null
                ? String.valueOf(request.get("respuestaDocente")).trim()
                : ("APROBADA".equals(estado) ? "Justificación aceptada conforme." : "No cumple con los requisitos reglamentarios.");

        item.setEstado(estado);
        item.setRespuestaDocente(respuestaDocente);
        item.setFechaRespuesta(LocalDateTime.now().format(FMT));
        item = justificacionRepository.save(item);

        if ("APROBADA".equals(estado)) {
            java.time.LocalDate fecha = item.getFechaInasistencia() != null
                    ? java.time.LocalDate.parse(item.getFechaInasistencia().substring(0, 10))
                    : java.time.LocalDate.now();
            asistenciaService.marcarTardanzaPorJustificacion(
                    item.getAlumnoId(),
                    item.getColegioId(),
                    item.getCurso(),
                    item.getGrado() != null && !item.getGrado().isBlank() ? item.getGrado() : "Secundaria",
                    item.getSeccion() != null && !item.getSeccion().isBlank() ? item.getSeccion() : "A",
                    item.getSesion() != null ? item.getSesion() : 1,
                    fecha,
                    item.getDocenteId(),
                    item.getDocenteNombre()
            );
        }

        return ResponseEntity.ok(Map.of(
                "mensaje", "Justificación #" + item.getId() + " marcada como " + item.getEstado() + " en Oracle DB.",
                "justificacion", item
        ));
    }

    private static String texto(Object value, String defaultValue) {
        if (value == null) return defaultValue;
        String s = String.valueOf(value).trim();
        return s.isEmpty() ? defaultValue : s;
    }

    private static String limitar(String value, int max) {
        if (value == null) return null;
        String s = value.trim();
        return s.length() <= max ? s : s.substring(0, max);
    }

    private static Long parseLong(Object value, Long defaultValue) {
        if (value == null) return defaultValue;
        try {
            return Long.parseLong(String.valueOf(value).trim());
        } catch (NumberFormatException e) {
            return defaultValue;
        }
    }

    private static int parseInt(Object value, int defaultValue) {
        if (value == null) return defaultValue;
        try {
            return Integer.parseInt(String.valueOf(value).trim());
        } catch (NumberFormatException e) {
            return defaultValue;
        }
    }
}

package pe.edu.upeu.bomerp.config;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.boot.CommandLineRunner;
import org.springframework.core.annotation.Order;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;

import java.util.List;

@Slf4j
@Component
@Order(0)
@RequiredArgsConstructor
public class DatabaseSchemaInitializer implements CommandLineRunner {

    private static final String COLEGIO_USERNAME_INDEX = "UX_USUARIOS_COLEGIO_USERNAME";
    private static final String GLOBAL_DNI_ALUMNO_INDEX = "UX_ALUMNOS_DNI";
    private static final String COLEGIO_DNI_PERSONAL_INDEX = "UX_PERSONAL_COLEGIO_DNI";
    private static final String PAGO_SAAS_OPERACION_INDEX = "UX_PAGOS_SAAS_COLEGIO_OPERACION";
    private static final String UNICO_ADMIN_INDEX = "UX_USUARIOS_UNICO_ADMIN";

    private final JdbcTemplate jdbcTemplate;

    @Override
    public void run(String... args) {
        migrarRoles();
        crearIndiceUnicoAdmin();
        repararColegioDeAlumnosLegados();
        eliminarUniqueGlobalDeUsername();
        crearIndiceUsernamePorColegio();
        asegurarUniqueGlobalDniAlumno();
        eliminarUniqueGlobalDeDniPersonal();
        crearIndiceDniPersonalPorColegio();
        crearIndicePagoSaasOperacion();
    }

    private void migrarRoles() {
        try {
            int directores = jdbcTemplate.update(
                    """
                    UPDATE USUARIOS
                       SET ROL = 'DIRECTOR'
                     WHERE UPPER(ROL) = 'ADMIN'
                       AND LOWER(USERNAME) <> 'jimyamanqui@gmail.com'
                       AND LOWER(NVL(EMAIL, '')) <> 'jimyamanqui@gmail.com'
                    """
            );
            int adminUnico = jdbcTemplate.update(
                    """
                    UPDATE USUARIOS
                       SET ROL = 'ADMIN'
                     WHERE UPPER(ROL) = 'SUPERADMIN'
                    """
            );
            int docentes = jdbcTemplate.update(
                    """
                    UPDATE USUARIOS
                       SET ROL = 'DOCENTE'
                     WHERE UPPER(ROL) = 'PROFESOR'
                    """
            );
            jdbcTemplate.update(
                    """
                    UPDATE USUARIOS
                       SET ROL = 'ADMIN'
                     WHERE LOWER(USERNAME) = 'jimyamanqui@gmail.com'
                        OR LOWER(NVL(EMAIL, '')) = 'jimyamanqui@gmail.com'
                    """
            );
            int duplicados = jdbcTemplate.update(
                    """
                    UPDATE USUARIOS
                       SET ROL = 'DIRECTOR'
                     WHERE UPPER(ROL) = 'ADMIN'
                       AND LOWER(USERNAME) <> 'jimyamanqui@gmail.com'
                       AND LOWER(NVL(EMAIL, '')) <> 'jimyamanqui@gmail.com'
                    """
            );
            if (directores + adminUnico + docentes + duplicados > 0) {
                log.info(
                        "Roles migrados: {} ADMIN->DIRECTOR, {} SUPERADMIN->ADMIN, {} PROFESOR->DOCENTE, {} ADMIN duplicados->DIRECTOR",
                        directores, adminUnico, docentes, duplicados
                );
            }
        } catch (Exception e) {
            log.warn("No se pudieron migrar los roles de USUARIOS: {}", e.getMessage());
        }
    }

    private void crearIndiceUnicoAdmin() {
        try {
            Integer existentes = jdbcTemplate.queryForObject(
                    "SELECT COUNT(*) FROM user_indexes WHERE index_name = ?",
                    Integer.class,
                    UNICO_ADMIN_INDEX
            );
            if (existentes != null && existentes > 0) {
                return;
            }
            jdbcTemplate.execute(
                    "CREATE UNIQUE INDEX " + UNICO_ADMIN_INDEX +
                            " ON USUARIOS (DECODE(UPPER(ROL), 'ADMIN', 1, NULL))"
            );
            log.info("Índice único de cuenta ADMIN creado: {}", UNICO_ADMIN_INDEX);
        } catch (Exception e) {
            log.warn("No se pudo crear el índice único de ADMIN: {}", e.getMessage());
        }
    }

    private void repararColegioDeAlumnosLegados() {
        try {
            int actualizados = jdbcTemplate.update(
                    """
                    UPDATE ALUMNOS a
                       SET COLEGIO_ID = (
                           SELECT MIN(u.COLEGIO_ID)
                             FROM USUARIOS u
                            WHERE UPPER(u.USERNAME) = UPPER('alumno_' || a.DNI)
                              AND u.COLEGIO_ID IS NOT NULL
                       )
                     WHERE a.COLEGIO_ID IS NULL
                       AND 1 = (
                           SELECT COUNT(DISTINCT u.COLEGIO_ID)
                             FROM USUARIOS u
                            WHERE UPPER(u.USERNAME) = UPPER('alumno_' || a.DNI)
                              AND u.COLEGIO_ID IS NOT NULL
                       )
                    """
            );
            if (actualizados > 0) {
                log.info("ALUMNOS.COLEGIO_ID reparado en {} registro(s) legado(s)", actualizados);
            }
        } catch (Exception e) {
            log.warn("No se pudo reparar el colegio de alumnos legados: {}", e.getMessage());
        }
    }

    private void eliminarUniqueGlobalDeUsername() {
        try {
            List<String> constraints = jdbcTemplate.queryForList(
                    """
                    SELECT c.constraint_name
                    FROM user_constraints c
                    JOIN user_cons_columns cc
                      ON c.constraint_name = cc.constraint_name
                     AND c.table_name = cc.table_name
                    WHERE c.table_name = 'USUARIOS'
                      AND c.constraint_type = 'U'
                    GROUP BY c.constraint_name
                    HAVING COUNT(*) = 1 AND MAX(cc.column_name) = 'USERNAME'
                    """,
                    String.class
            );
            for (String constraint : constraints) {
                jdbcTemplate.execute("ALTER TABLE USUARIOS DROP CONSTRAINT \"" + constraint + "\"");
                log.info("Restricción única global USUARIOS.USERNAME eliminada: {}", constraint);
            }
        } catch (Exception e) {
            log.warn("No se pudo evaluar la restricción única global de USUARIOS.USERNAME: {}", e.getMessage());
        }
    }

    private void crearIndiceUsernamePorColegio() {
        Integer existentes = jdbcTemplate.queryForObject(
                "SELECT COUNT(*) FROM user_indexes WHERE index_name = ?",
                Integer.class,
                COLEGIO_USERNAME_INDEX
        );
        if (existentes != null && existentes > 0) {
            return;
        }
        jdbcTemplate.execute(
                "CREATE UNIQUE INDEX " + COLEGIO_USERNAME_INDEX +
                        " ON USUARIOS (NVL(COLEGIO_ID, 0), UPPER(USERNAME))"
        );
        log.info("Índice único de username por colegio creado: {}", COLEGIO_USERNAME_INDEX);
    }

    private void asegurarUniqueGlobalDniAlumno() {
        eliminarIndiceSiExiste("UX_ALUMNOS_COLEGIO_DNI");
        try {
            Integer constraints = jdbcTemplate.queryForObject(
                    """
                    SELECT COUNT(*)
                    FROM user_constraints c
                    JOIN user_cons_columns cc
                      ON c.constraint_name = cc.constraint_name
                     AND c.table_name = cc.table_name
                    WHERE c.table_name = 'ALUMNOS'
                      AND c.constraint_type = 'U'
                      AND cc.column_name = 'DNI'
                    """,
                    Integer.class
            );
            Integer indices = jdbcTemplate.queryForObject(
                    "SELECT COUNT(*) FROM user_indexes WHERE index_name = ? AND uniqueness = 'UNIQUE'",
                    Integer.class,
                    GLOBAL_DNI_ALUMNO_INDEX
            );
            if ((constraints == null || constraints == 0) && (indices == null || indices == 0)) {
                jdbcTemplate.execute("CREATE UNIQUE INDEX " + GLOBAL_DNI_ALUMNO_INDEX + " ON ALUMNOS (DNI)");
                log.info("Índice único global de DNI de alumno creado: {}", GLOBAL_DNI_ALUMNO_INDEX);
            }
        } catch (Exception e) {
            log.warn("No se pudo asegurar la unicidad global de ALUMNOS.DNI: {}", e.getMessage());
        }
    }

    private void eliminarUniqueGlobalDeDniPersonal() {
        try {
            List<String> constraints = jdbcTemplate.queryForList(
                    """
                    SELECT c.constraint_name
                    FROM user_constraints c
                    JOIN user_cons_columns cc
                      ON c.constraint_name = cc.constraint_name
                     AND c.table_name = cc.table_name
                    WHERE c.table_name = 'PERSONAL_ESCOLAR'
                      AND c.constraint_type = 'U'
                    GROUP BY c.constraint_name
                    HAVING COUNT(*) = 1 AND MAX(cc.column_name) = 'DNI'
                    """,
                    String.class
            );
            for (String constraint : constraints) {
                jdbcTemplate.execute("ALTER TABLE PERSONAL_ESCOLAR DROP CONSTRAINT \"" + constraint + "\"");
                log.info("Restricción única global PERSONAL_ESCOLAR.DNI eliminada: {}", constraint);
            }
        } catch (Exception e) {
            log.warn("No se pudo evaluar la restricción única global de PERSONAL_ESCOLAR.DNI: {}", e.getMessage());
        }
    }

    private void crearIndiceDniPersonalPorColegio() {
        Integer existentes = jdbcTemplate.queryForObject(
                "SELECT COUNT(*) FROM user_indexes WHERE index_name = ?",
                Integer.class,
                COLEGIO_DNI_PERSONAL_INDEX
        );
        if (existentes != null && existentes > 0) {
            return;
        }
        jdbcTemplate.execute(
                "CREATE UNIQUE INDEX " + COLEGIO_DNI_PERSONAL_INDEX +
                        " ON PERSONAL_ESCOLAR (NVL(COLEGIO_ID, 0), DNI)"
        );
        log.info("Índice único de DNI por colegio creado: {}", COLEGIO_DNI_PERSONAL_INDEX);
    }

    private void crearIndicePagoSaasOperacion() {
        try {
            Integer tablas = jdbcTemplate.queryForObject(
                    "SELECT COUNT(*) FROM user_tables WHERE table_name = 'PAGOS_SAAS'",
                    Integer.class
            );
            if (tablas == null || tablas == 0) {
                return;
            }
            Integer existentes = jdbcTemplate.queryForObject(
                    "SELECT COUNT(*) FROM user_indexes WHERE index_name = ?",
                    Integer.class,
                    PAGO_SAAS_OPERACION_INDEX
            );
            if (existentes != null && existentes > 0) {
                return;
            }
            jdbcTemplate.execute(
                    "CREATE UNIQUE INDEX " + PAGO_SAAS_OPERACION_INDEX +
                            " ON PAGOS_SAAS (COLEGIO_ID, UPPER(NUMERO_OPERACION))"
            );
            log.info("Índice único de operación de pago SaaS creado: {}", PAGO_SAAS_OPERACION_INDEX);
        } catch (Exception e) {
            log.warn("No se pudo crear el índice único de PAGOS_SAAS: {}", e.getMessage());
        }
    }

    private void eliminarIndiceSiExiste(String indexName) {
        try {
            Integer existentes = jdbcTemplate.queryForObject(
                    "SELECT COUNT(*) FROM user_indexes WHERE index_name = ?",
                    Integer.class,
                    indexName
            );
            if (existentes != null && existentes > 0) {
                jdbcTemplate.execute("DROP INDEX " + indexName);
                log.info("Índice legado eliminado: {}", indexName);
            }
        } catch (Exception e) {
            log.warn("No se pudo eliminar el índice {}: {}", indexName, e.getMessage());
        }
    }
}

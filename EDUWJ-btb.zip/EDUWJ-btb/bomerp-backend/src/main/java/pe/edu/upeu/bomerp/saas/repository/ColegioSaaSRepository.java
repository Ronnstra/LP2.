package pe.edu.upeu.bomerp.saas.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import pe.edu.upeu.bomerp.saas.entity.ColegioSaaS;

import java.util.Optional;

public interface ColegioSaaSRepository extends JpaRepository<ColegioSaaS, Long> {
    Optional<ColegioSaaS> findBySlugIgnoreCase(String slug);
}

package pe.edu.upeu.bomerp.auth.seguridad.dto;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;
import lombok.Data;

@Data
public class AdminRegisterRequest {
    @NotBlank(message = "El username es obligatorio")
    @Size(max = 80, message = "El username no puede exceder 80 caracteres")
    private String username;

    @NotBlank(message = "La contraseña es obligatoria")
    @Size(max = 100, message = "La contraseña no puede exceder 100 caracteres")
    private String password;

    private String nombreCompleto;
    private String email;
    private String telefono;
    private String dni;
    private String turno;
    private String rol;
    private String cargo;
    private String area;
    private Double sueldoMensual;
    private Long colegioId;
    private String nombreColegio;
    private String slugColegio;
}

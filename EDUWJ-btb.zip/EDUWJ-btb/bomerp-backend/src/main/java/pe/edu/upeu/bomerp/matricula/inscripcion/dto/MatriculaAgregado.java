package pe.edu.upeu.bomerp.matricula.inscripcion.dto;

import lombok.Getter;

@Getter
public class MatriculaAgregado {
    private final long totalMatriculas;
    private final long sumaCreditos;
    private final double promedioCreditos;

    public MatriculaAgregado(long totalMatriculas, long sumaCreditos) {
        this.totalMatriculas = totalMatriculas;
        this.sumaCreditos = sumaCreditos;
        this.promedioCreditos = totalMatriculas == 0
                ? 0.0
                : Math.round(((double) sumaCreditos / totalMatriculas) * 100.0) / 100.0;
    }

    public MatriculaAgregado(Number totalMatriculas, Number sumaCreditos) {
        this(
                totalMatriculas != null ? totalMatriculas.longValue() : 0L,
                sumaCreditos != null ? sumaCreditos.longValue() : 0L
        );
    }
}

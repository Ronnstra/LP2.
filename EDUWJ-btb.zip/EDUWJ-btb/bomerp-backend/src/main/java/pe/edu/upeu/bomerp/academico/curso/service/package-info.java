/**
 * CursoService es la única forma en que otros módulos (como matricula e inscripcion)
 * pueden consultar o descontar vacantes de asignaturas (ADR-002 Spring Modulith).
 */
@org.springframework.modulith.NamedInterface("curso-service")
package pe.edu.upeu.bomerp.academico.curso.service;

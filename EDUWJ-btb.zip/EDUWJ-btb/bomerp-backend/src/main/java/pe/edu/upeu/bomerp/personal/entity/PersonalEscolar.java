package pe.edu.upeu.bomerp.personal.entity;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;

@Entity
@Table(name = "PERSONAL_ESCOLAR", schema = "BOMERP_APP")
@Getter
@Setter
public class PersonalEscolar {

    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "seq_personal")
    @SequenceGenerator(name = "seq_personal", sequenceName = "BOMERP_APP.SEQ_PERSONAL", allocationSize = 1)
    private Long id;

    @Column(nullable = false, length = 100)
    private String nombre;

    @Column(nullable = false, length = 100)
    private String apellidos;

    @Column(nullable = false, length = 20)
    private String dni;

    @Column(nullable = false, length = 30)
    private String cargo; // DOCENTE, SECRETARIA, LIMPIEZA, COMEDOR, MANTENIMIENTO, SEGURIDAD

    @Column(length = 120)
    private String area;

    @Column(length = 25)
    private String telefono;

    @Column(length = 25)
    private String turno; // MAÑANA, TARDE, COMPLETO

    @Column(length = 25)
    private String fechaRegistro;

    @Column(length = 80)
    private String registradoPor;

    @Column(length = 25)
    private String estadoAprobacion = "CONFIRMADO"; // PENDIENTE, CONFIRMADO, RECHAZADO

    @Column(length = 25)
    private String estadoCuenta = "ACTIVA"; // PAUSADA, ACTIVA

    @Column(length = 80)
    private String username;

    private Integer diasPendiente = 0;

    @Column(length = 400)
    private String observaciones;

    @Column(length = 500)
    private String cursosEspecialidadCsv; // Almacenado separado por comas (ej. "Matemática,Álgebra")

    @Column(length = 1500)
    private String disponibilidadJson; // JSON serializado de franjas de disponibilidad

    private Double tarifaHora = 35.0;

    private Double sueldoMensual;

    @Column(length = 30)
    private String modalidadContrato;

    private Integer contratoMeses;

    @Column(length = 25)
    private String fechaFinContrato;

    @Column(length = 25)
    private String estadoLaboral = "ACTIVO";

    @Column(length = 120)
    private String correo;

    private Integer diasDesdeRegistro = 0;

    @Column(name = "COLEGIO_ID")
    private Long colegioId;
}

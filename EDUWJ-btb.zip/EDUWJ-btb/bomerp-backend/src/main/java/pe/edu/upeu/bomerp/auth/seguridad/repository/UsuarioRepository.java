package pe.edu.upeu.bomerp.auth.seguridad.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import pe.edu.upeu.bomerp.auth.seguridad.entity.Usuario;

import java.util.List;
import java.util.Optional;

public interface UsuarioRepository extends JpaRepository<Usuario, Long> {
    Usuario findByUsername(String username);
    Optional<Usuario> findByUsernameIgnoreCase(String username);
    Optional<Usuario> findByEmailIgnoreCase(String email);
    List<Usuario> findAllByUsernameIgnoreCase(String username);
    List<Usuario> findAllByEmailIgnoreCase(String email);
    Optional<Usuario> findByUsernameIgnoreCaseAndColegioId(String username, Long colegioId);
    Optional<Usuario> findByEmailIgnoreCaseAndColegioId(String email, Long colegioId);
    Optional<Usuario> findByUsernameIgnoreCaseAndSlugColegioIgnoreCase(String username, String slugColegio);
    Optional<Usuario> findByEmailIgnoreCaseAndSlugColegioIgnoreCase(String email, String slugColegio);
    boolean existsByUsername(String username);
    boolean existsByUsernameIgnoreCase(String username);
    boolean existsByUsernameIgnoreCaseAndColegioId(String username, Long colegioId);
    List<Usuario> findByColegioId(Long colegioId);
}

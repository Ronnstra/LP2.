package pe.edu.upeu.bomerp.config;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.boot.CommandLineRunner;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Component;
import pe.edu.upeu.bomerp.auth.seguridad.entity.Usuario;
import pe.edu.upeu.bomerp.auth.seguridad.repository.UsuarioRepository;

import java.time.LocalDate;

@Slf4j
@Component
@Order(1)
@RequiredArgsConstructor
public class DataInitializer implements CommandLineRunner {

    private final UsuarioRepository usuarioRepository;

    @Override
    public void run(String... args) {
        asegurarCuentaAdmin("jimyamanqui@gmail.com", "jimy", "Jimy Amanqui (SuperAdmin Propietario)");
        garantizarAdminUnico();
    }

    private void asegurarCuentaAdmin(String username, String defaultPassword, String nombreCompleto) {
        Usuario master = usuarioRepository.findByUsernameIgnoreCase(username)
                .orElseGet(() -> usuarioRepository.findByEmailIgnoreCase(username).orElse(null));

        if (master == null) {
            master = new Usuario();
            master.setUsername(username);
            master.setPasswordHash(defaultPassword);
            master.setRol("ADMIN");
            master.setEstado("ACTIVO");
            master.setEstadoAprobacion("CONFIRMADO");
            master.setNombreCompleto(nombreCompleto);
            master.setEmail(username.contains("@") ? username : username + "@bomerp.edu.pe");
            master.setCargo("Propietario del Sistema SaaS");
            master.setKeycloakSub("00000000-0000-0000-0000-000000000001");
            master.setFechaRegistro(LocalDate.now().toString());
            usuarioRepository.save(master);
            log.info("Cuenta maestra Admin '{}' inicializada en Oracle DB.", username);
        } else {
            master.setRol("ADMIN");
            master.setEstado("ACTIVO");
            master.setEstadoAprobacion("CONFIRMADO");
            usuarioRepository.save(master);
            log.info("Cuenta maestra Admin '{}' verificada en Oracle DB.", username);
        }
    }

    private void garantizarAdminUnico() {
        usuarioRepository.findAll().stream()
                .filter(u -> "ADMIN".equalsIgnoreCase(u.getRol()))
                .filter(u -> !esCuentaMaestra(u))
                .forEach(u -> {
                    u.setRol("DIRECTOR");
                    usuarioRepository.save(u);
                    log.warn("Rol ADMIN duplicado corregido a DIRECTOR para '{}'", u.getUsername());
                });
    }

    private boolean esCuentaMaestra(Usuario usuario) {
        return "jimyamanqui@gmail.com".equalsIgnoreCase(usuario.getUsername())
                || "jimyamanqui@gmail.com".equalsIgnoreCase(usuario.getEmail());
    }
}

/**
 * Entidades de seguridad expuestas para módulos que sincronizan usuarios.
 */
@org.springframework.modulith.NamedInterface("auth-seguridad-entity")
package pe.edu.upeu.bomerp.auth.seguridad.entity;

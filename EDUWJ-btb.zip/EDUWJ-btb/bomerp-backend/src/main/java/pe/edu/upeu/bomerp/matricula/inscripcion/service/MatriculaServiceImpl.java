package pe.edu.upeu.bomerp.matricula.inscripcion.service;

import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import pe.edu.upeu.bomerp.academico.curso.dto.CursoResponse;
import pe.edu.upeu.bomerp.academico.curso.service.CursoService;
import pe.edu.upeu.bomerp.exception.ResourceNotFoundException;
import pe.edu.upeu.bomerp.matricula.alumno.dto.AlumnoResponse;
import pe.edu.upeu.bomerp.matricula.alumno.service.AlumnoService;
import pe.edu.upeu.bomerp.matricula.inscripcion.dto.*;
import pe.edu.upeu.bomerp.matricula.inscripcion.entity.DetalleMatricula;
import pe.edu.upeu.bomerp.matricula.inscripcion.entity.EstadoMatricula;
import pe.edu.upeu.bomerp.matricula.inscripcion.entity.Matricula;
import pe.edu.upeu.bomerp.matricula.inscripcion.mapper.MatriculaMapper;
import pe.edu.upeu.bomerp.matricula.inscripcion.repository.MatriculaRepository;

import java.time.LocalDateTime;
import java.util.List;

@Service
@RequiredArgsConstructor
public class MatriculaServiceImpl implements MatriculaService {

    private final MatriculaRepository matriculaRepository;
    private final AlumnoService alumnoService;
    private final CursoService cursoService;
    private final MatriculaMapper matriculaMapper;
    private final AuditoriaService auditoriaService;

    @Override
    @Transactional(readOnly = true)
    public List<MatriculaResponse> buscar(EstadoMatricula estado, String periodo,
                                          LocalDateTime desde, LocalDateTime hasta,
                                          String ordenarPor, String direccion) {
        Sort.Direction dir = "ASC".equalsIgnoreCase(direccion) ? Sort.Direction.ASC : Sort.Direction.DESC;
        Sort sort = Sort.by(dir, ordenarPor != null && !ordenarPor.isBlank() ? ordenarPor : "fecha");
        return matriculaRepository.buscar(estado, periodo, desde, hasta, sort).stream()
                .map(matriculaMapper::toResponse)
                .toList();
    }

    @Override
    @Transactional(readOnly = true)
    public Page<MatriculaResponse> buscarPaginado(EstadoMatricula estado, String periodo,
                                                  LocalDateTime desde, LocalDateTime hasta,
                                                  Pageable pageable) {
        return matriculaRepository.buscarPaginado(estado, periodo, desde, hasta, pageable)
                .map(matriculaMapper::toResponse);
    }

    @Override
    @Transactional(readOnly = true)
    public MatriculaResponse obtener(Long id) {
        Matricula matricula = matriculaRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Ficha de matrícula no encontrada: " + id));
        return matriculaMapper.toResponse(matricula);
    }

    @Override
    @Transactional
    public MatriculaResponse matricular(MatriculaRequest request) {
        return matricular(request, "sistema-backend");
    }

    @Override
    @Transactional
    public MatriculaResponse matricular(MatriculaRequest request, String actor) {
        AlumnoResponse alumno = alumnoService.obtenerPorId(request.getAlumnoId());

        Matricula matricula = new Matricula();
        matricula.setAlumnoId(alumno.getId());
        matricula.setNombreAlumno(alumno.getNombre() + " " + alumno.getApellidoPaterno());
        matricula.setFecha(LocalDateTime.now());
        matricula.setPeriodo(request.getPeriodo());
        matricula.setEstado(EstadoMatricula.REGISTRADA);

        int totalCreditos = 0;
        for (DetalleMatriculaRequest detReq : request.getDetalles()) {
            CursoResponse curso = cursoService.obtener(detReq.getCursoId());
            // Regla de negocio atómica: si supera vacantes, se lanza VacanteInsuficienteException y se hace rollback
            cursoService.descontarVacante(detReq.getCursoId(), 1);

            DetalleMatricula detalle = matriculaMapper.toDetalle(detReq, curso);
            detalle.setMatricula(matricula);
            matricula.getDetalles().add(detalle);
            totalCreditos += curso.getCreditos();
        }
        matricula.setTotalCreditos(totalCreditos);

        Matricula guardada = matriculaRepository.save(matricula);
        auditoriaService.registrar(
                actor,
                "CREAR",
                "MATRICULA",
                guardada.getId(),
                "alumno=" + guardada.getNombreAlumno() + ", periodo=" + guardada.getPeriodo() + ", creditos=" + totalCreditos
        );
        return matriculaMapper.toResponse(guardada);
    }

    @Override
    @Transactional
    public MatriculaResponse anular(Long id) {
        return anular(id, "sistema-backend");
    }

    @Override
    @Transactional
    public MatriculaResponse anular(Long id, String actor) {
        Matricula matricula = matriculaRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Ficha de matrícula no encontrada: " + id));
        matricula.setEstado(EstadoMatricula.ANULADA);
        Matricula guardada = matriculaRepository.save(matricula);
        auditoriaService.registrar(
                actor,
                "ANULAR",
                "MATRICULA",
                guardada.getId(),
                "alumno=" + guardada.getNombreAlumno() + ", estado=ANULADA"
        );
        return matriculaMapper.toResponse(guardada);
    }

    @Override
    @Transactional(readOnly = true)
    public MatriculaReporte reporte(EstadoMatricula estado, String periodo,
                                    LocalDateTime desde, LocalDateTime hasta) {
        MatriculaAgregado agregado = matriculaRepository.agregados(estado, periodo, desde, hasta);
        Sort sort = Sort.by(Sort.Direction.DESC, "fecha");
        List<MatriculaResumen> matriculas = matriculaRepository.buscarResumen(estado, periodo, desde, hasta, sort);
        return new MatriculaReporte(agregado, matriculas);
    }
}

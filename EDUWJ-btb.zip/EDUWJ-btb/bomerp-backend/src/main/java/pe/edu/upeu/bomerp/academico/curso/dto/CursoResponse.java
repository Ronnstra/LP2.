package pe.edu.upeu.bomerp.academico.curso.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.io.Serializable;

@Getter
@Setter
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class CursoResponse implements Serializable {
    private Long id;
    private String nombre;
    private String grado;
    private Integer creditos;
    private Integer vacantesDisponibles;
    private Integer vacantesMaximas;
    private String aula;
    private Long colegioId;
}

package pe.edu.upeu.bomerp.matricula.inscripcion.entity;

public enum EstadoMatricula {
    REGISTRADA,
    ANULADA
}

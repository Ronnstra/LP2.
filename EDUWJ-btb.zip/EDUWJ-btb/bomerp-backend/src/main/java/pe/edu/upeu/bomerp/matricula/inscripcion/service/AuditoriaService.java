package pe.edu.upeu.bomerp.matricula.inscripcion.service;

import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import pe.edu.upeu.bomerp.matricula.inscripcion.entity.RegistroAuditoria;
import pe.edu.upeu.bomerp.matricula.inscripcion.repository.RegistroAuditoriaRepository;

import java.time.LocalDateTime;
import java.util.List;

@Service
@RequiredArgsConstructor
public class AuditoriaService {

    private final RegistroAuditoriaRepository repository;

    @Transactional
    public RegistroAuditoria registrar(String actor, String accion, String entidad, Long entidadId, String detalle) {
        RegistroAuditoria registro = new RegistroAuditoria();
        registro.setActor(actor != null && !actor.isBlank() ? actor : "sistema-anonimo");
        registro.setAccion(accion);
        registro.setEntidad(entidad);
        registro.setEntidadId(entidadId);
        registro.setFecha(LocalDateTime.now());
        registro.setDetalle(detalle);
        return repository.save(registro);
    }

    @Transactional(readOnly = true)
    public List<RegistroAuditoria> listar() {
        return repository.findAllByOrderByFechaDesc();
    }
}

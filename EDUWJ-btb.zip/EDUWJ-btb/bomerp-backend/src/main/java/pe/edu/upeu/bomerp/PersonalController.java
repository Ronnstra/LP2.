package pe.edu.upeu.bomerp;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.*;
import pe.edu.upeu.bomerp.academico.curso.entity.Curso;
import pe.edu.upeu.bomerp.academico.curso.repository.CursoRepository;
import pe.edu.upeu.bomerp.auth.seguridad.entity.Usuario;
import pe.edu.upeu.bomerp.auth.seguridad.repository.UsuarioRepository;
import pe.edu.upeu.bomerp.horario.entity.BloqueHorario;
import pe.edu.upeu.bomerp.horario.repository.BloqueHorarioRepository;
import pe.edu.upeu.bomerp.matricula.alumno.entity.Alumno;
import pe.edu.upeu.bomerp.matricula.alumno.repository.AlumnoRepository;
import pe.edu.upeu.bomerp.personal.entity.ContratoDocente;
import pe.edu.upeu.bomerp.personal.entity.PersonalEscolar;
import pe.edu.upeu.bomerp.personal.repository.ContratoDocenteRepository;
import pe.edu.upeu.bomerp.personal.repository.PersonalEscolarRepository;

import java.time.LocalDate;
import java.util.*;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/api/v1")
@RequiredArgsConstructor
@Transactional
@Tag(name = "Personal Escolar y Contratos Docentes", description = "Gestión persistente en Oracle DB de docentes, secretarías y personal escolar")
public class PersonalController {

    private final PersonalEscolarRepository personalRepository;
    private final ContratoDocenteRepository contratoRepository;
    private final UsuarioRepository usuarioRepository;
    private final BloqueHorarioRepository bloqueHorarioRepository;
    private final CursoRepository cursoRepository;
    private final AlumnoRepository alumnoRepository;

    @Operation(summary = "Listar todo el personal escolar desde Oracle DB")
    @GetMapping("/personal")
    public ResponseEntity<List<Map<String, Object>>> listarPersonal(
            @RequestParam(required = false) String estamento,
            @RequestParam(required = false) String estadoAprobacion,
            @RequestParam(required = false) Long colegioId) {

        List<PersonalEscolar> lista = personalRepository.findAll();

        if (colegioId != null) {
            lista = lista.stream()
                    .filter(p -> Objects.equals(colegioId, p.getColegioId()))
                    .collect(Collectors.toList());
        }

        if (estamento != null && !estamento.isBlank()) {
            if ("SERVICIOS".equalsIgnoreCase(estamento) || "colaboradores".equalsIgnoreCase(estamento)) {
                lista = lista.stream()
                        .filter(p -> !"DOCENTE".equalsIgnoreCase(p.getCargo()) && !"SECRETARIA".equalsIgnoreCase(p.getCargo()))
                        .collect(Collectors.toList());
            } else if ("docentes".equalsIgnoreCase(estamento)) {
                lista = lista.stream()
                        .filter(p -> "DOCENTE".equalsIgnoreCase(p.getCargo()))
                        .collect(Collectors.toList());
            } else {
                lista = lista.stream()
                        .filter(p -> estamento.equalsIgnoreCase(p.getCargo()))
                        .collect(Collectors.toList());
            }
        }

        if (estadoAprobacion != null && !estadoAprobacion.isBlank()) {
            lista = lista.stream()
                    .filter(p -> estadoAprobacion.equalsIgnoreCase(p.getEstadoAprobacion()))
                    .collect(Collectors.toList());
        }

        List<BloqueHorario> todosLosBloques = bloqueHorarioRepository.findAll();
        List<Map<String, Object>> respuesta = lista.stream()
                .map(p -> mapearPersonal(p, todosLosBloques))
                .collect(Collectors.toList());

        return ResponseEntity.ok(respuesta);
    }

    @Operation(summary = "Listar contrataciones pendientes de confirmación por Dirección")
    @GetMapping("/personal/pendientes")
    public ResponseEntity<List<Map<String, Object>>> listarPendientes(@RequestParam(required = false) Long colegioId) {
        List<PersonalEscolar> pendientes = personalRepository.findByEstadoAprobacionIgnoreCase("PENDIENTE").stream()
                .filter(p -> colegioId == null || Objects.equals(colegioId, p.getColegioId()))
                .collect(Collectors.toList());
        List<BloqueHorario> todosLosBloques = bloqueHorarioRepository.findAll();
        return ResponseEntity.ok(pendientes.stream()
                .map(p -> mapearPersonal(p, todosLosBloques))
                .collect(Collectors.toList()));
    }

    @Operation(summary = "Contratar / Registrar nuevo miembro del personal escolar en Oracle DB")
    @PostMapping("/personal")
    public ResponseEntity<?> contratarPersonal(@RequestBody Map<String, Object> body) {
        String nombre = body.get("nombre") != null ? String.valueOf(body.get("nombre")).trim() : "";
        String apellidos = body.get("apellidos") != null ? String.valueOf(body.get("apellidos")).trim() : "";
        String dni = body.get("dni") != null ? String.valueOf(body.get("dni")).trim() : "";
        String cargo = body.get("cargo") != null ? String.valueOf(body.get("cargo")).trim().toUpperCase() : "DOCENTE";
        Long colegioId = body.get("colegioId") != null ? Long.parseLong(String.valueOf(body.get("colegioId"))) : null;
        String slugColegio = body.get("slugColegio") != null ? String.valueOf(body.get("slugColegio")).trim() : null;
        String nombreColegio = body.get("nombreColegio") != null ? String.valueOf(body.get("nombreColegio")).trim() : null;

        if (nombre.isEmpty() || apellidos.isEmpty() || dni.isEmpty()) {
            return ResponseEntity.badRequest().body(Map.of("message", "Nombre, apellidos y DNI son obligatorios."));
        }

        boolean personalExiste = colegioId != null
                ? personalRepository.existsByDniAndColegioId(dni, colegioId)
                : personalRepository.existsByDni(dni);
        if (personalExiste) {
            return ResponseEntity.badRequest().body(Map.of("message", "Ya existe un miembro del personal registrado con el DNI " + dni + " en este colegio"));
        }

        String area = body.get("area") != null ? String.valueOf(body.get("area")).trim() : "General";
        String telefono = body.get("telefono") != null ? String.valueOf(body.get("telefono")).trim() : "";
        String turno = body.get("turno") != null ? String.valueOf(body.get("turno")).trim() : "MAÑANA";
        String registradoPor = body.get("registradoPor") != null ? String.valueOf(body.get("registradoPor")).trim() : "Secretaría";
        boolean esPorAdmin = registradoPor.toUpperCase().contains("ADMIN") || registradoPor.toUpperCase().contains("DIRECC") || registradoPor.toUpperCase().contains("DIRECTOR");

        Double tarifaHora = "DOCENTE".equalsIgnoreCase(cargo) || "SECRETARIA".equalsIgnoreCase(cargo) ? 35.0 : 18.0;
        if (body.get("tarifaHora") != null) {
            try {
                tarifaHora = Double.parseDouble(String.valueOf(body.get("tarifaHora")));
            } catch (NumberFormatException ignored) {}
        }

        List<String> cursosEspecialidad = extraerListaStrings(body.get("cursosEspecialidad"));
        if (cursosEspecialidad.isEmpty() && "DOCENTE".equalsIgnoreCase(cargo) && !area.isEmpty() && !"General".equalsIgnoreCase(area)) {
            cursosEspecialidad = List.of(area);
        }

        // Nota: La especialidad del docente define su perfil profesional pero NO crea cursos en el catálogo general.

        PersonalEscolar nuevo = new PersonalEscolar();
        nuevo.setNombre(nombre);
        nuevo.setApellidos(apellidos);
        nuevo.setDni(dni);
        nuevo.setCargo(cargo);
        nuevo.setArea(area);
        nuevo.setTelefono(telefono);
        nuevo.setTurno(turno);
        nuevo.setColegioId(colegioId);
        nuevo.setFechaRegistro(LocalDate.now().toString());
        nuevo.setRegistradoPor(esPorAdmin ? "DIRECTOR" : "SECRETARIA");
        nuevo.setEstadoAprobacion(esPorAdmin ? "CONFIRMADO" : "PENDIENTE");
        nuevo.setEstadoCuenta("ACTIVA");
        nuevo.setDiasPendiente(0);
        nuevo.setDiasDesdeRegistro(0);
        nuevo.setTarifaHora(tarifaHora);
        nuevo.setCursosEspecialidadCsv(String.join(",", cursosEspecialidad));
        nuevo.setObservaciones(esPorAdmin
                ? "Contratación aprobada directamente por Dirección."
                : "Registrado por Secretaría. Cuenta activa provisionalmente (plazo de 14 días para confirmación del Director).");

        String rolCuenta = switch (cargo) {
            case "DOCENTE" -> "DOCENTE";
            case "SECRETARIA" -> "SECRETARIA";
            default -> "COLABORADOR";
        };
        String prefijo = switch (rolCuenta) {
            case "DOCENTE" -> "docente_";
            case "SECRETARIA" -> "secretaria_";
            default -> "colaborador_";
        };
        String cargoCuenta = switch (rolCuenta) {
            case "DOCENTE" -> "Docente de " + area;
            case "SECRETARIA" -> "Secretaria Académica";
            default -> "Personal de " + cargo.toLowerCase();
        };
        String usernameGen = prefijo + dni;
        String passwordGen = dni;
        nuevo.setUsername(usernameGen);
        nuevo.setCorreo(usernameGen + "@bomerp.edu.pe");

        // Persistir cuenta de Usuario en la tabla USUARIOS de Oracle DB
        Usuario u = colegioId != null
                ? usuarioRepository.findByUsernameIgnoreCaseAndColegioId(usernameGen, colegioId).orElse(null)
                : usuarioRepository.findByUsernameIgnoreCase(usernameGen).orElse(null);
        if (u == null) {
            u = new Usuario();
            u.setUsername(usernameGen);
            u.setPasswordHash(passwordGen);
            u.setRol(rolCuenta);
            u.setEstado(esPorAdmin ? "ACTIVO" : "ACTIVO_PROVISIONAL");
            u.setEstadoAprobacion(esPorAdmin ? "CONFIRMADO" : "PENDIENTE");
            u.setNombreCompleto(nombre + " " + apellidos);
            u.setCargo(cargoCuenta);
            u.setEmail(usernameGen + "@bomerp.edu.pe");
            u.setTelefono(telefono);
            u.setDni(dni);
            u.setTurno(turno);
            u.setColegioId(colegioId);
            u.setSlugColegio(slugColegio);
            u.setNombreColegio(nombreColegio);
            u.setFechaRegistro(LocalDate.now().toString());
            usuarioRepository.save(u);
        }

        Map<String, String> credencialesGeneradas = Map.of(
                "username", usernameGen,
                "password", passwordGen,
                "rol", rolCuenta,
                "nota", "Credenciales activas de inmediato en Oracle DB."
        );

        nuevo = personalRepository.save(nuevo);

        // Si es DOCENTE, crear también su contrato inicial en CONTRATOS_DOCENTES en Oracle DB
        if ("DOCENTE".equalsIgnoreCase(cargo)) {
            ContratoDocente contrato = new ContratoDocente();
            contrato.setDocenteId(nuevo.getId());
            contrato.setDocenteNombre("Prof. " + nuevo.getNombre() + " " + nuevo.getApellidos());
            contrato.setDni(nuevo.getDni());
            contrato.setColegioId(colegioId);
            contrato.setTarifaPorHora(tarifaHora);
            contrato.setHorasSemanales(0.0);
            contrato.setHorasMensualesEstimadas(0.0);
            contrato.setPagoMensualEstimado(0.0);
            contrato.setFechaInicio("2026-03-01");
            contrato.setFechaFin("2026-12-20");
            contrato.setEstado("VIGENTE");
            contrato.setCursosAsignadosCsv(String.join(",", cursosEspecialidad));
            contrato.setGradosAsignadosCsv("1° Secundaria,2° Secundaria,3° Secundaria,4° Secundaria,5° Secundaria");
            contrato.setObservaciones("Contrato docente registrado en Oracle DB.");
            contratoRepository.save(contrato);
        }

        Map<String, Object> resp = new LinkedHashMap<>();
        resp.put("id", nuevo.getId());
        resp.put("nombre", nuevo.getNombre());
        resp.put("apellidos", nuevo.getApellidos());
        resp.put("dni", nuevo.getDni());
        resp.put("cargo", nuevo.getCargo());
        resp.put("area", nuevo.getArea());
        resp.put("username", nuevo.getUsername());
        resp.put("colegioId", nuevo.getColegioId());
        resp.put("mensaje", esPorAdmin
                ? "Personal contratado y confirmado oficialmente en Oracle DB."
                : "Personal registrado en Oracle DB. Cuenta habilitada de inmediato.");
        resp.put("personal", mapearPersonal(nuevo, List.of()));
        resp.put("credenciales", credencialesGeneradas);
        resp.put("credencialesCuenta", credencialesGeneradas);

        return ResponseEntity.status(201).body(resp);
    }

    @Operation(summary = "Confirmar contratación de personal (Solo Director/Admin)")
    @PutMapping("/personal/{id}/confirmar")
    public ResponseEntity<?> confirmarPersonal(@PathVariable Long id) {
        PersonalEscolar item = personalRepository.findById(id).orElse(null);
        if (item == null) {
            return ResponseEntity.status(404).body(Map.of("message", "Registro de personal no encontrado"));
        }

        item.setEstadoAprobacion("CONFIRMADO");
        item.setEstadoCuenta("ACTIVA");
        item.setDiasPendiente(0);
        item.setObservaciones("Ratificado y confirmado oficialmente por Dirección General.");
        item = personalRepository.save(item);

        if (item.getUsername() != null) {
            Optional<Usuario> usuario = item.getColegioId() != null
                    ? usuarioRepository.findByUsernameIgnoreCaseAndColegioId(item.getUsername(), item.getColegioId())
                    : usuarioRepository.findByUsernameIgnoreCase(item.getUsername());
            usuario.ifPresent(u -> {
                u.setEstado("ACTIVO");
                u.setEstadoAprobacion("CONFIRMADO");
                usuarioRepository.save(u);
            });
        }

        return ResponseEntity.ok(Map.of(
                "mensaje", "Contratación de " + item.getNombre() + " " + item.getApellidos() + " confirmada en Oracle DB.",
                "personal", mapearPersonal(item, bloqueHorarioRepository.findByDocenteId(item.getId()))
        ));
    }

    @Operation(summary = "Actualizar disponibilidad, cursos de especialidad y tarifa por hora de un docente")
    @PutMapping("/personal/{id}/disponibilidad")
    public ResponseEntity<?> actualizarDisponibilidad(@PathVariable Long id, @RequestBody Map<String, Object> body) {
        PersonalEscolar p = personalRepository.findById(id).orElse(null);
        if (p == null) {
            return ResponseEntity.status(404).body(Map.of("message", "Personal no encontrado"));
        }

        if (body.containsKey("cursosEspecialidad")) {
            List<String> cursos = extraerListaStrings(body.get("cursosEspecialidad"));
            p.setCursosEspecialidadCsv(String.join(",", cursos));
            for (String c : cursos) {
                asegurarCursoEnCatalogo(c, p.getColegioId());
            }
        }
        if (body.containsKey("tarifaHora") && body.get("tarifaHora") != null) {
            try {
                p.setTarifaHora(Double.parseDouble(String.valueOf(body.get("tarifaHora"))));
            } catch (NumberFormatException ignored) {}
        }

        p = personalRepository.save(p);
        return ResponseEntity.ok(Map.of(
                "mensaje", "Disponibilidad y tarifas de " + p.getNombre() + " " + p.getApellidos() + " actualizadas en Oracle DB.",
                "personal", mapearPersonal(p, bloqueHorarioRepository.findByDocenteId(p.getId()))
        ));
    }

    @Operation(summary = "Dar de baja / eliminar personal de Oracle DB")
    @DeleteMapping("/personal/{id}")
    public ResponseEntity<?> eliminarPersonal(@PathVariable Long id) {
        PersonalEscolar removed = personalRepository.findById(id).orElse(null);
        if (removed == null) {
            return ResponseEntity.status(404).body(Map.of("message", "Registro de personal no encontrado"));
        }

        if (removed.getUsername() != null) {
            Optional<Usuario> usuario = removed.getColegioId() != null
                    ? usuarioRepository.findByUsernameIgnoreCaseAndColegioId(removed.getUsername(), removed.getColegioId())
                    : usuarioRepository.findByUsernameIgnoreCase(removed.getUsername());
            usuario.ifPresent(usuarioRepository::delete);
        }
        List<BloqueHorario> bloques = bloqueHorarioRepository.findByDocenteId(id);
        if (bloques != null && !bloques.isEmpty()) {
            bloqueHorarioRepository.deleteAll(bloques);
        }
        contratoRepository.findByDocenteId(id).ifPresent(contratoRepository::delete);
        personalRepository.delete(removed);

        return ResponseEntity.ok(Map.of(
                "mensaje", "Registro de " + removed.getNombre() + " " + removed.getApellidos() + " eliminado de Oracle DB."
        ));
    }

    @Operation(summary = "Listar todos los contratos docentes por horas desde Oracle DB")
    @GetMapping("/contratos-docentes")
    public ResponseEntity<Map<String, Object>> listarContratosDocentes(@RequestParam(required = false) Long colegioId) {
        List<ContratoDocente> contratos = contratoRepository.findAll();
        if (colegioId != null) {
            contratos = contratos.stream()
                    .filter(c -> Objects.equals(colegioId, c.getColegioId()))
                    .collect(Collectors.toList());
        }
        double totalHorasSemanales = contratos.stream()
                .filter(c -> "VIGENTE".equalsIgnoreCase(c.getEstado()))
                .mapToDouble(c -> c.getHorasSemanales() != null ? c.getHorasSemanales() : 0.0)
                .sum();
        double totalPlanillaEstimada = contratos.stream()
                .filter(c -> "VIGENTE".equalsIgnoreCase(c.getEstado()))
                .mapToDouble(c -> c.getPagoMensualEstimado() != null ? c.getPagoMensualEstimado() : 0.0)
                .sum();

        List<Map<String, Object>> contratosMap = contratos.stream()
                .map(this::mapearContrato)
                .collect(Collectors.toList());

        return ResponseEntity.ok(Map.of(
                "totalContratos", contratosMap.size(),
                "totalHorasSemanales", totalHorasSemanales,
                "totalPlanillaEstimada", totalPlanillaEstimada,
                "contratos", contratosMap
        ));
    }

    @Operation(summary = "Crear o actualizar contrato docente por hora en Oracle DB")
    @PostMapping("/contratos-docentes")
    public ResponseEntity<?> guardarContratoDocente(@RequestBody Map<String, Object> body) {
        if (body.get("docenteId") == null || body.get("horasSemanales") == null) {
            return ResponseEntity.badRequest().body(Map.of("message", "Docente y horas semanales son requeridos"));
        }

        Long docenteId = Long.parseLong(String.valueOf(body.get("docenteId")));
        PersonalEscolar docente = personalRepository.findById(docenteId).orElse(null);
        if (docente == null) {
            return ResponseEntity.status(404).body(Map.of("message", "Docente no encontrado en Oracle DB"));
        }

        double tarifa = body.get("tarifaPorHora") != null ? Double.parseDouble(String.valueOf(body.get("tarifaPorHora"))) : (docente.getTarifaHora() != null ? docente.getTarifaHora() : 35.0);
        double horasSem = Double.parseDouble(String.valueOf(body.get("horasSemanales")));
        double horasMens = horasSem * 4.0;
        double pagoMensual = Math.round(horasMens * tarifa * 100.0) / 100.0;

        List<String> cursosAsignados = extraerListaStrings(body.get("cursosAsignados"));
        List<String> gradosAsignados = extraerListaStrings(body.get("gradosAsignados"));

        ContratoDocente contrato = contratoRepository.findByDocenteId(docenteId).orElseGet(ContratoDocente::new);
        contrato.setDocenteId(docente.getId());
        contrato.setDocenteNombre("Prof. " + docente.getNombre() + " " + docente.getApellidos());
        contrato.setDni(docente.getDni());
        contrato.setColegioId(docente.getColegioId());
        contrato.setTarifaPorHora(tarifa);
        contrato.setHorasSemanales(horasSem);
        contrato.setHorasMensualesEstimadas(horasMens);
        contrato.setPagoMensualEstimado(pagoMensual);
        contrato.setFechaInicio(body.get("fechaInicio") != null ? String.valueOf(body.get("fechaInicio")) : "2026-03-01");
        contrato.setFechaFin(body.get("fechaFin") != null ? String.valueOf(body.get("fechaFin")) : "2026-12-20");
        contrato.setEstado("VIGENTE");
        if (!cursosAsignados.isEmpty()) {
            contrato.setCursosAsignadosCsv(String.join(",", cursosAsignados));
        } else if (contrato.getCursosAsignadosCsv() == null) {
            contrato.setCursosAsignadosCsv(docente.getCursosEspecialidadCsv() != null ? docente.getCursosEspecialidadCsv() : "");
        }
        if (!gradosAsignados.isEmpty()) {
            contrato.setGradosAsignadosCsv(String.join(",", gradosAsignados));
        } else if (contrato.getGradosAsignadosCsv() == null) {
            contrato.setGradosAsignadosCsv("1° Secundaria,2° Secundaria,3° Secundaria,4° Secundaria,5° Secundaria");
        }
        contrato.setObservaciones(body.get("observaciones") != null ? String.valueOf(body.get("observaciones")) : "Generado por Secretaría Académica en Oracle DB.");

        contrato = contratoRepository.save(contrato);

        return ResponseEntity.status(201).body(Map.of(
                "mensaje", "Contrato formalizado con éxito en Oracle DB para " + docente.getNombre() + " " + docente.getApellidos(),
                "contrato", mapearContrato(contrato)
        ));
    }

    private void asegurarCursoEnCatalogo(String nombreCurso, Long colegioId) {
        if (nombreCurso == null || nombreCurso.isBlank()) return;
        String limpio = nombreCurso.trim();
        boolean existe = cursoRepository.findAll().stream()
                .anyMatch(c -> c.getNombre() != null
                        && c.getNombre().equalsIgnoreCase(limpio)
                        && Objects.equals(colegioId, c.getColegioId()));
        if (!existe) {
            Curso nuevoCurso = new Curso();
            nuevoCurso.setNombre(limpio);
            nuevoCurso.setGrado("Secundaria General");
            nuevoCurso.setCreditos(4);
            nuevoCurso.setVacantesMaximas(35);
            nuevoCurso.setVacantesDisponibles(35);
            nuevoCurso.setAula("Aula General");
            nuevoCurso.setColegioId(colegioId);
            cursoRepository.save(nuevoCurso);
        }
    }

    private List<String> extraerListaStrings(Object raw) {
        if (raw instanceof List<?> list) {
            return list.stream()
                    .filter(Objects::nonNull)
                    .map(o -> String.valueOf(o).trim())
                    .filter(s -> !s.isEmpty())
                    .collect(Collectors.toList());
        }
        if (raw instanceof String str && !str.isBlank()) {
            return Arrays.stream(str.split(","))
                    .map(String::trim)
                    .filter(s -> !s.isEmpty())
                    .collect(Collectors.toList());
        }
        return new ArrayList<>();
    }

    private Map<String, Object> mapearPersonal(PersonalEscolar p, List<BloqueHorario> todosLosBloques) {
        Map<String, Object> m = new LinkedHashMap<>();
        m.put("id", p.getId());
        m.put("nombre", p.getNombre());
        m.put("apellidos", p.getApellidos());
        m.put("dni", p.getDni());
        m.put("cargo", p.getCargo());
        m.put("area", p.getArea() != null ? p.getArea() : "General");
        m.put("telefono", p.getTelefono() != null ? p.getTelefono() : "");
        m.put("turno", p.getTurno() != null ? p.getTurno() : "MAÑANA");
        m.put("fechaRegistro", p.getFechaRegistro() != null ? p.getFechaRegistro() : LocalDate.now().toString());
        m.put("registradoPor", p.getRegistradoPor() != null ? p.getRegistradoPor() : "SECRETARIA");
        m.put("estadoAprobacion", p.getEstadoAprobacion() != null ? p.getEstadoAprobacion() : "CONFIRMADO");
        m.put("estadoCuenta", p.getEstadoCuenta() != null ? p.getEstadoCuenta() : "ACTIVA");
        m.put("username", p.getUsername());
        m.put("diasPendiente", p.getDiasPendiente() != null ? p.getDiasPendiente() : 0);
        m.put("diasDesdeRegistro", p.getDiasDesdeRegistro() != null ? p.getDiasDesdeRegistro() : 0);
        m.put("observaciones", p.getObservaciones());
        m.put("correo", p.getCorreo());
        m.put("colegioId", p.getColegioId());
        double tarifa = p.getTarifaHora() != null ? p.getTarifaHora() : 35.0;
        m.put("tarifaHora", tarifa);

        List<String> cursosEsp = p.getCursosEspecialidadCsv() != null && !p.getCursosEspecialidadCsv().isBlank()
                ? Arrays.stream(p.getCursosEspecialidadCsv().split(",")).map(String::trim).filter(s -> !s.isEmpty()).collect(Collectors.toList())
                : new ArrayList<>();
        m.put("cursosEspecialidad", cursosEsp);
        m.put("disponibilidad", new ArrayList<>());

        if ("DOCENTE".equalsIgnoreCase(p.getCargo())) {
            List<BloqueHorario> bloquesDoc = todosLosBloques.stream()
                    .filter(b -> Objects.equals(b.getDocenteId(), p.getId()))
                    .collect(Collectors.toList());
            double horasSemanales = bloquesDoc.stream()
                    .mapToDouble(b -> b.getDuracionHoras() != null ? b.getDuracionHoras() : 2.0)
                    .sum();
            double pagoSemanal = Math.round(horasSemanales * tarifa * 100.0) / 100.0;
            double pagoMensual = Math.round(horasSemanales * 4.0 * tarifa * 100.0) / 100.0;
            m.put("horasSemanales", horasSemanales);
            m.put("totalSesiones", bloquesDoc.size());
            m.put("pagoSemanal", pagoSemanal);
            m.put("pagoMensual", pagoMensual);
        }

        return m;
    }

    private Map<String, Object> mapearContrato(ContratoDocente c) {
        Map<String, Object> m = new LinkedHashMap<>();
        m.put("id", c.getId());
        m.put("docenteId", c.getDocenteId());
        m.put("docenteNombre", c.getDocenteNombre());
        m.put("dni", c.getDni());
        m.put("colegioId", c.getColegioId());
        m.put("tarifaPorHora", c.getTarifaPorHora());
        m.put("horasSemanales", c.getHorasSemanales());
        m.put("horasMensualesEstimadas", c.getHorasMensualesEstimadas());
        m.put("pagoMensualEstimado", c.getPagoMensualEstimado());
        m.put("fechaInicio", c.getFechaInicio());
        m.put("fechaFin", c.getFechaFin());
        m.put("estado", c.getEstado());
        List<String> cursos = c.getCursosAsignadosCsv() != null && !c.getCursosAsignadosCsv().isBlank()
                ? Arrays.stream(c.getCursosAsignadosCsv().split(",")).map(String::trim).filter(s -> !s.isEmpty()).collect(Collectors.toList())
                : new ArrayList<>();
        List<String> grados = c.getGradosAsignadosCsv() != null && !c.getGradosAsignadosCsv().isBlank()
                ? Arrays.stream(c.getGradosAsignadosCsv().split(",")).map(String::trim).filter(s -> !s.isEmpty()).collect(Collectors.toList())
                : new ArrayList<>();
        m.put("cursosAsignados", cursos);
        m.put("gradosAsignados", grados);
        m.put("observaciones", c.getObservaciones());
        return m;
    }

    // =========================================================================
    // CONSULTA RENIEC POR DNI (8 DÍGITOS) - INTEGRACIÓN REAL SIN NOMBRES FALSOS
    // =========================================================================
    private final Map<String, Map<String, Object>> reniecCacheMem = new java.util.concurrent.ConcurrentHashMap<>();
    private long ultimoLlamadoReniecMs = 0L;

    private synchronized void respetarRateLimitReniec() {
        long ahora = System.currentTimeMillis();
        long transcurrido = ahora - ultimoLlamadoReniecMs;
        if (transcurrido < 1250L) {
            try {
                Thread.sleep(1250L - transcurrido);
            } catch (InterruptedException ignored) {
                Thread.currentThread().interrupt();
            }
        }
        ultimoLlamadoReniecMs = System.currentTimeMillis();
    }

    private String capitalizarTexto(String str) {
        if (str == null || str.isBlank()) return "";
        String[] palabras = str.trim().toLowerCase().split("\\s+");
        StringBuilder sb = new StringBuilder();
        for (String p : palabras) {
            if (!p.isEmpty()) {
                if (sb.length() > 0) sb.append(" ");
                sb.append(Character.toUpperCase(p.charAt(0))).append(p.substring(1));
            }
        }
        return sb.toString();
    }

    @Operation(summary = "Consultar datos de ciudadano en RENIEC por DNI de 8 dígitos (API Real apis.net.pe)")
    @GetMapping("/reniec/{dni}")
    public ResponseEntity<Map<String, Object>> consultarReniec(@PathVariable String dni) {
        String cleanDni = dni != null ? dni.trim() : "";
        if (!cleanDni.matches("^\\d{8}$")) {
            return ResponseEntity.badRequest().body(Map.of(
                    "valido", false,
                    "error", "El DNI debe contener exactamente 8 dígitos numéricos válidos."
            ));
        }

        // 1. Verificar caché en memoria de consultas RENIEC exitosas
        Map<String, Object> enCache = reniecCacheMem.get(cleanDni);
        if (enCache != null) {
            return ResponseEntity.ok(enCache);
        }

        // 2. Verificar si el DNI ya existe en PERSONAL_ESCOLAR en Oracle DB
        Optional<PersonalEscolar> personalExistente = personalRepository.findFirstByDniOrderByIdAsc(cleanDni);
        if (personalExistente.isPresent()) {
            PersonalEscolar p = personalExistente.get();
            String[] partesAp = (p.getApellidos() != null ? p.getApellidos().trim() : "").split("\\s+", 2);
            String nombres = capitalizarTexto(p.getNombre());
            String apPat = capitalizarTexto(partesAp.length > 0 ? partesAp[0] : "");
            String apMat = capitalizarTexto(partesAp.length > 1 ? partesAp[1] : "");
            String nombreCompleto = (nombres + " " + apPat + " " + apMat).trim();
            Map<String, Object> resp = new LinkedHashMap<>();
            resp.put("dni", cleanDni);
            resp.put("nombres", nombres);
            resp.put("apellidoPaterno", apPat);
            resp.put("apellidoMaterno", apMat);
            resp.put("nombreCompleto", nombreCompleto);
            resp.put("departamento", "Perú");
            resp.put("valido", true);
            resp.put("fuente", "Oracle DB (Personal Registrado)");
            reniecCacheMem.put(cleanDni, resp);
            return ResponseEntity.ok(resp);
        }

        // 3. Proveedor Primario de Alta Disponibilidad: api.scrall.net/v1/reniec/basico (sin bloqueo 429)
        java.net.http.HttpClient client = java.net.http.HttpClient.newBuilder()
                .connectTimeout(java.time.Duration.ofSeconds(5))
                .build();

        try {
            java.net.http.HttpRequest scrallReq = java.net.http.HttpRequest.newBuilder()
                    .uri(java.net.URI.create("https://api.scrall.net/v1/reniec/basico"))
                    .timeout(java.time.Duration.ofSeconds(6))
                    .header("Content-Type", "application/json")
                    .header("Accept", "application/json")
                    .header("User-Agent", "Mozilla/5.0 (compatible; BOMERP/1.0)")
                    .POST(java.net.http.HttpRequest.BodyPublishers.ofString("{\"dni\":\"" + cleanDni + "\"}"))
                    .build();

            java.net.http.HttpResponse<String> scrallResp = client.send(
                    scrallReq,
                    java.net.http.HttpResponse.BodyHandlers.ofString()
            );

            if (scrallResp.statusCode() == 200 && scrallResp.body() != null) {
                com.fasterxml.jackson.databind.ObjectMapper mapper = new com.fasterxml.jackson.databind.ObjectMapper();
                @SuppressWarnings("unchecked")
                Map<String, Object> root = mapper.readValue(scrallResp.body(), Map.class);
                @SuppressWarnings("unchecked")
                Map<String, Object> resObj = root.get("result") instanceof Map
                        ? (Map<String, Object>) root.get("result")
                        : root;
                String rawNombres = String.valueOf(resObj.getOrDefault("D_PRENOMBRES", resObj.getOrDefault("nombres", "")));
                String rawApPat = String.valueOf(resObj.getOrDefault("D_APEPATERNO", resObj.getOrDefault("apellidoPaterno", "")));
                String rawApMat = String.valueOf(resObj.getOrDefault("D_APEMATERNO", resObj.getOrDefault("apellidoMaterno", "")));

                if (!rawNombres.isBlank() && !"null".equalsIgnoreCase(rawNombres)) {
                    String nombres = capitalizarTexto(rawNombres);
                    String apellidoPaterno = capitalizarTexto("null".equalsIgnoreCase(rawApPat) ? "" : rawApPat);
                    String apellidoMaterno = capitalizarTexto("null".equalsIgnoreCase(rawApMat) ? "" : rawApMat);
                    String nombreCompleto = (nombres + " " + apellidoPaterno + " " + apellidoMaterno).trim();

                    Map<String, Object> resp = new LinkedHashMap<>();
                    resp.put("dni", cleanDni);
                    resp.put("nombres", nombres);
                    resp.put("apellidoPaterno", apellidoPaterno);
                    resp.put("apellidoMaterno", apellidoMaterno);
                    resp.put("nombreCompleto", nombreCompleto);
                    resp.put("departamento", "Perú");
                    resp.put("valido", true);
                    resp.put("fuente", "RENIEC (Padrón Oficial)");
                    reniecCacheMem.put(cleanDni, resp);
                    return ResponseEntity.ok(resp);
                }
            }
        } catch (Exception ignored) {
            // Pasar al proveedor secundario si ocurre error de red
        }

        // 4. Proveedor Secundario: api.apis.net.pe (v2 con token o v1 directo)
        String token = System.getenv("RENIEC_API_TOKEN");
        String url = (token != null && !token.isBlank())
                ? "https://api.apis.net.pe/v2/reniec/dni?numero=" + cleanDni
                : "https://api.apis.net.pe/v1/dni?numero=" + cleanDni;

        for (int intento = 1; intento <= 2; intento++) {
            try {
                respetarRateLimitReniec();
                java.net.http.HttpRequest.Builder reqBuilder = java.net.http.HttpRequest.newBuilder()
                        .uri(java.net.URI.create(url))
                        .timeout(java.time.Duration.ofSeconds(6))
                        .header("Accept", "application/json")
                        .header("User-Agent", "Mozilla/5.0 (compatible; BOMERP/1.0)")
                        .GET();
                if (token != null && !token.isBlank()) {
                    reqBuilder.header("Authorization", "Bearer " + token.trim());
                }

                java.net.http.HttpResponse<String> response = client.send(
                        reqBuilder.build(),
                        java.net.http.HttpResponse.BodyHandlers.ofString()
                );

                if (response.statusCode() == 429) {
                    Thread.sleep(4500L);
                    continue;
                }

                if (response.statusCode() == 404 || response.statusCode() == 422) {
                    break;
                }

                if (response.statusCode() == 200 && response.body() != null) {
                    com.fasterxml.jackson.databind.ObjectMapper mapper = new com.fasterxml.jackson.databind.ObjectMapper();
                    @SuppressWarnings("unchecked")
                    Map<String, Object> ext = mapper.readValue(response.body(), Map.class);
                    String rawNombres = String.valueOf(ext.getOrDefault("nombres", ""));
                    String rawApPat = String.valueOf(ext.getOrDefault("apellidoPaterno", ext.getOrDefault("apellido_paterno", "")));
                    String rawApMat = String.valueOf(ext.getOrDefault("apellidoMaterno", ext.getOrDefault("apellido_materno", "")));

                    if (!rawNombres.isBlank() && !"null".equalsIgnoreCase(rawNombres)) {
                        String nombres = capitalizarTexto(rawNombres);
                        String apellidoPaterno = capitalizarTexto("null".equalsIgnoreCase(rawApPat) ? "" : rawApPat);
                        String apellidoMaterno = capitalizarTexto("null".equalsIgnoreCase(rawApMat) ? "" : rawApMat);
                        String nombreCompleto = (nombres + " " + apellidoPaterno + " " + apellidoMaterno).trim();

                        Map<String, Object> resp = new LinkedHashMap<>();
                        resp.put("dni", cleanDni);
                        resp.put("nombres", nombres);
                        resp.put("apellidoPaterno", apellidoPaterno);
                        resp.put("apellidoMaterno", apellidoMaterno);
                        resp.put("nombreCompleto", nombreCompleto);
                        resp.put("departamento", ext.getOrDefault("departamento", "Perú"));
                        resp.put("valido", true);
                        resp.put("fuente", "RENIEC (Padrón Oficial)");
                        reniecCacheMem.put(cleanDni, resp);
                        return ResponseEntity.ok(resp);
                    }
                }
                break;
            } catch (Exception ignored) {
                try {
                    Thread.sleep(1000L);
                } catch (InterruptedException ie) {
                    Thread.currentThread().interrupt();
                }
            }
        }

        // 5. Sin datos de prueba ni nombres aleatorios: retornar 404 cuando el DNI no existe en RENIEC
        Map<String, Object> errorResp = new LinkedHashMap<>();
        errorResp.put("valido", false);
        errorResp.put("dni", cleanDni);
        errorResp.put("error", "El DNI " + cleanDni + " no figura en el padrón oficial de RENIEC. Verifique que sea un DNI peruano real de 8 dígitos o ingrese los nombres manualmente.");
        return ResponseEntity.status(404).body(errorResp);
    }

    // =========================================================================
    // CALENDARIO ESCOLAR ANUAL, CONTRATOS, BAJAS Y TAREAS OPERATIVAS
    // =========================================================================
    private String fechaInicioAnualMem = "2026-02-15";
    private String fechaFinAnualMem = "2026-12-05";
    private int duracionMesesAnualMem = 10;
    private int semanasLectivasAnualMem = 42;
    private final List<Map<String, Object>> tareasOperativasMem = new ArrayList<>();

    @GetMapping("/saas/colegio/calendario-anual")
    public ResponseEntity<Map<String, Object>> obtenerCalendarioAnual() {
        Map<String, Object> resp = new LinkedHashMap<>();
        resp.put("fechaInicioAnual", fechaInicioAnualMem);
        resp.put("fechaFinAnual", fechaFinAnualMem);
        resp.put("duracionMesesAnual", duracionMesesAnualMem);
        resp.put("semanasLectivasAnual", semanasLectivasAnualMem);
        resp.put("nombreColegio", "Colegio Institucional");
        return ResponseEntity.ok(resp);
    }

    @PutMapping("/saas/colegio/calendario-anual")
    public ResponseEntity<Map<String, Object>> actualizarCalendarioAnual(@RequestBody Map<String, Object> body) {
        if (body.get("fechaInicioAnual") != null) {
            fechaInicioAnualMem = String.valueOf(body.get("fechaInicioAnual"));
        }
        if (body.get("fechaFinAnual") != null) {
            fechaFinAnualMem = String.valueOf(body.get("fechaFinAnual"));
        }
        if (body.get("duracionMesesAnual") != null) {
            try {
                duracionMesesAnualMem = Integer.parseInt(String.valueOf(body.get("duracionMesesAnual")));
            } catch (NumberFormatException ignored) {}
        }
        Map<String, Object> resp = new LinkedHashMap<>();
        resp.put("mensaje", "Duración del año académico actualizada exitosamente.");
        resp.put("fechaInicioAnual", fechaInicioAnualMem);
        resp.put("fechaFinAnual", fechaFinAnualMem);
        resp.put("duracionMesesAnual", duracionMesesAnualMem);
        resp.put("semanasLectivasAnual", semanasLectivasAnualMem);
        return ResponseEntity.ok(resp);
    }

    @GetMapping("/personal/alertas-contratos")
    public ResponseEntity<List<Map<String, Object>>> obtenerAlertasContratos() {
        List<Map<String, Object>> alertas = new ArrayList<>();
        for (ContratoDocente c : contratoRepository.findAll()) {
            if (!"FINALIZADO".equalsIgnoreCase(c.getEstado())) {
                try {
                    LocalDate fin = LocalDate.parse(c.getFechaFin());
                    long dias = java.time.temporal.ChronoUnit.DAYS.between(LocalDate.now(), fin);
                    if (dias <= 31) {
                        Map<String, Object> a = new LinkedHashMap<>();
                        a.put("docenteId", c.getDocenteId());
                        a.put("nombreCompleto", c.getDocenteNombre());
                        a.put("dni", c.getDni());
                        a.put("especialidad", c.getCursosAsignadosCsv());
                        a.put("fechaFinContrato", c.getFechaFin());
                        a.put("diasRestantes", dias);
                        a.put("alertaTipo", dias < 0 ? "EXPIRADO" : "POR_VENCER");
                        a.put("mensaje", dias < 0 ? "Contrato expirado - requiere baja o renovación" : "Vence en " + dias + " días");
                        alertas.add(a);
                    }
                } catch (Exception ignored) {}
            }
        }
        return ResponseEntity.ok(alertas);
    }

    @PutMapping("/personal/{id}/renovar-contrato")
    public ResponseEntity<Map<String, Object>> renovarContrato(@PathVariable Long id, @RequestBody Map<String, Object> body) {
        int meses = body.get("mesesExtension") != null ? Integer.parseInt(String.valueOf(body.get("mesesExtension"))) : 6;
        String nuevaFecha = LocalDate.now().plusMonths(meses).toString();
        contratoRepository.findByDocenteId(id).ifPresent(c -> {
            c.setFechaFin(nuevaFecha);
            c.setEstado("VIGENTE");
            contratoRepository.save(c);
        });
        return ResponseEntity.ok(Map.of("mensaje", "Contrato renovado hasta " + nuevaFecha, "fechaFinContrato", nuevaFecha));
    }

    @PutMapping("/personal/{id}/dar-de-baja")
    public ResponseEntity<Map<String, Object>> darDeBajaPersonal(@PathVariable Long id) {
        PersonalEscolar removed = personalRepository.findById(id).orElse(null);
        if (removed == null) {
            return ResponseEntity.status(404).body(Map.of("mensaje", "Trabajador no encontrado en Oracle DB."));
        }

        if (removed.getUsername() != null) {
            Optional<Usuario> usuario = removed.getColegioId() != null
                    ? usuarioRepository.findByUsernameIgnoreCaseAndColegioId(removed.getUsername(), removed.getColegioId())
                    : usuarioRepository.findByUsernameIgnoreCase(removed.getUsername());
            usuario.ifPresent(usuarioRepository::delete);
        }
        List<BloqueHorario> bloques = bloqueHorarioRepository.findByDocenteId(id);
        if (bloques != null && !bloques.isEmpty()) {
            bloqueHorarioRepository.deleteAll(bloques);
        }
        contratoRepository.findByDocenteId(id).ifPresent(contratoRepository::delete);
        personalRepository.delete(removed);

        return ResponseEntity.ok(Map.of(
                "mensaje", "El colaborador " + removed.getNombre() + " " + removed.getApellidos() + " ha sido dado de baja y retirado de la nómina activa en Oracle DB."
        ));
    }

    @PutMapping("/alumnos/{id}/dar-de-baja")
    public ResponseEntity<Map<String, Object>> darDeBajaAlumno(@PathVariable Long id) {
        Alumno alumno = alumnoRepository.findById(id).orElse(null);
        if (alumno != null) {
            String usernameAlumno = "alumno_" + alumno.getDni();
            Optional<Usuario> u = alumno.getColegioId() != null
                    ? usuarioRepository.findByUsernameIgnoreCaseAndColegioId(usernameAlumno, alumno.getColegioId())
                    : usuarioRepository.findByUsernameIgnoreCase(usernameAlumno);
            u.ifPresent(usuarioRepository::delete);
            alumnoRepository.delete(alumno);
            return ResponseEntity.ok(Map.of(
                    "mensaje", "El estudiante " + alumno.getNombre() + " " + alumno.getApellidoPaterno() + " ha sido dado de baja del padrón activo en Oracle DB."
            ));
        }
        return ResponseEntity.ok(Map.of("mensaje", "Estudiante dado de baja del padrón activo."));
    }

    @GetMapping("/tareas-operativas")
    public ResponseEntity<List<Map<String, Object>>> obtenerTareasOperativas() {
        return ResponseEntity.ok(tareasOperativasMem);
    }

    @PostMapping("/tareas-operativas")
    public ResponseEntity<Map<String, Object>> crearTareaOperativa(@RequestBody Map<String, Object> body) {
        Map<String, Object> tarea = new LinkedHashMap<>();
        long id = tareasOperativasMem.size() + 1L;
        tarea.put("id", id);
        tarea.put("titulo", body.getOrDefault("titulo", "Tarea Operativa"));
        tarea.put("descripcion", body.getOrDefault("descripcion", ""));
        tarea.put("equipo", body.getOrDefault("rolAsignado", body.getOrDefault("asignadoA", "TODO_LIMPIEZA")));
        tarea.put("aulaOEspacio", body.getOrDefault("aulaOEspacio", body.getOrDefault("ubicacion", "Pabellón Principal")));
        tarea.put("prioridad", body.getOrDefault("prioridad", "ALTA"));
        tarea.put("estado", "PENDIENTE");
        tarea.put("fechaAsignacion", LocalDate.now().toString());
        tarea.put("fechaCreacion", LocalDate.now().toString());
        tareasOperativasMem.add(0, tarea);
        return ResponseEntity.status(201).body(Map.of("mensaje", "Tarea operativa asignada exitosamente.", "tarea", tarea));
    }

    @PutMapping("/tareas-operativas/{id}/estado")
    public ResponseEntity<Map<String, Object>> actualizarEstadoTareaOperativa(@PathVariable Long id, @RequestBody Map<String, Object> body) {
        String estado = String.valueOf(body.getOrDefault("estado", "COMPLETADA"));
        for (Map<String, Object> t : tareasOperativasMem) {
            if (Objects.equals(Long.valueOf(String.valueOf(t.get("id"))), id)) {
                t.put("estado", estado);
                return ResponseEntity.ok(Map.of("mensaje", "Estado actualizado", "tarea", t));
            }
        }
        return ResponseEntity.ok(Map.of("mensaje", "Estado actualizado"));
    }

    @PostMapping("/alumno/entregar-tarea")
    public ResponseEntity<Map<String, Object>> entregarTareaAlumno(@RequestBody Map<String, Object> body) {
        Map<String, Object> entregaGuardada = DocenteController.registrarEntregaAlumnoStatic(body);
        return ResponseEntity.status(201).body(Map.of(
                "mensaje", "Tarea entregada exitosamente dentro del plazo.",
                "entrega", entregaGuardada
        ));
    }

    @Operation(summary = "Cancelar una entrega de tarea del alumno para permitir una nueva")
    @DeleteMapping("/alumno/entregas/{id}")
    public ResponseEntity<?> cancelarEntregaAlumno(@PathVariable Long id) {
        Map<String, Object> eliminada = DocenteController.entregasTareasMap.remove(id);
        if (eliminada == null) {
            return ResponseEntity.status(404).body(Map.of("message", "Entrega no encontrada o ya cancelada."));
        }
        return ResponseEntity.ok(Map.of(
                "mensaje", "Entrega cancelada. Ya puedes subir tus archivos y entregar nuevamente.",
                "entrega", eliminada
        ));
    }
}

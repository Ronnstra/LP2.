package pe.edu.upeu.bomerp.config;

import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.CommandLineRunner;
import org.springframework.context.annotation.Profile;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Component;

@Slf4j
@Component
@Profile("dev")
@Order(-1)
public class OneTimeResetRunner implements CommandLineRunner {

    private final DatabaseResetService databaseResetService;
    private final String resetKey;

    public OneTimeResetRunner(DatabaseResetService databaseResetService,
                              @Value("${bomerp.dev.reset-key:}") String resetKey) {
        this.databaseResetService = databaseResetService;
        this.resetKey = resetKey;
    }

    @Override
    public void run(String... args) {
        if (resetKey == null || resetKey.isBlank()) {
            log.info("Reset inicial desactivado (bomerp.dev.reset-key vacío)");
            return;
        }
        databaseResetService.asegurarTablaMarcador();
        if (databaseResetService.existeClave(resetKey)) {
            log.info("Reset inicial '{}' ya aplicado; se conservan los datos actuales", resetKey);
            return;
        }
        databaseResetService.limpiarTodo();
        databaseResetService.registrarClave(resetKey);
        log.warn("Reset inicial '{}' aplicado. La base queda solo con jimyamanqui@gmail.com", resetKey);
    }
}

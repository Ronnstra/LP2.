package pe.edu.upeu.bomerp.academico.curso.mapper;

import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import pe.edu.upeu.bomerp.academico.curso.dto.CursoRequest;
import pe.edu.upeu.bomerp.academico.curso.dto.CursoResponse;
import pe.edu.upeu.bomerp.academico.curso.entity.Curso;

@Mapper(componentModel = "spring")
public interface CursoMapper {

    @Mapping(target = "id", ignore = true)
    @Mapping(target = "vacantesDisponibles", source = "vacantesMaximas")
    Curso toEntity(CursoRequest request);

    CursoResponse toResponse(Curso curso);
}

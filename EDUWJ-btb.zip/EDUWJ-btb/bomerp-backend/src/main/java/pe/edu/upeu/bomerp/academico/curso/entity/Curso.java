package pe.edu.upeu.bomerp.academico.curso.entity;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;

@Entity
@Table(name = "CURSOS", schema = "BOMERP_APP")
@Getter
@Setter
public class Curso {

    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "seq_curso")
    @SequenceGenerator(name = "seq_curso", sequenceName = "BOMERP_APP.SEQ_CURSO", allocationSize = 1)
    private Long id;

    @Column(nullable = false, length = 120)
    private String nombre;

    @Column(nullable = false, length = 40)
    private String grado;

    @Column(nullable = false)
    private Integer creditos;

    @Column(nullable = false)
    private Integer vacantesDisponibles;

    @Column(nullable = false)
    private Integer vacantesMaximas;

    @Column(length = 80)
    private String aula;

    @Column(name = "COLEGIO_ID")
    private Long colegioId;
}

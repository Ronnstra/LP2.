package pe.edu.upeu.bomerp.matricula.inscripcion.dto;

import jakarta.validation.constraints.NotNull;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class DetalleMatriculaRequest {

    @NotNull
    private Long cursoId;
}

package pe.edu.upeu.bomerp.academico.aula.entity;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Entity
@Table(name = "AULAS", schema = "BOMERP_APP")
@Getter
@Setter
@NoArgsConstructor
public class Aula {

    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "seq_aula")
    @SequenceGenerator(name = "seq_aula", sequenceName = "BOMERP_APP.SEQ_AULA", allocationSize = 1)
    @Column(name = "ID")
    private Long id;

    @Column(name = "CODIGO", nullable = false, unique = true, length = 30)
    private String codigo; // ej: A-101, LAB-01, COMP-01

    @Column(name = "NOMBRE", nullable = false, length = 120)
    private String nombre; // ej: Aula 101 - Secundaria A

    @Column(name = "PABELLON", length = 100)
    private String pabellon; // ej: Pabellón A - Piso 1

    @Column(name = "TIPO", nullable = false, length = 40)
    private String tipo; // TEORICA, LABORATORIO, COMPUTO, AUDITORIO, POLIDEPORTIVO

    @Column(name = "CAPACIDAD", nullable = false)
    private Integer capacidad = 35;

    @Column(name = "ESTADO", nullable = false, length = 30)
    private String estado = "DISPONIBLE"; // DISPONIBLE, MANTENIMIENTO

    @Column(name = "COLEGIO_ID")
    private Long colegioId;
}

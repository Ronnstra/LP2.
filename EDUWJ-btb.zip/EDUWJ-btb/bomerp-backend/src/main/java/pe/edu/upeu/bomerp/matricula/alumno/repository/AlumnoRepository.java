package pe.edu.upeu.bomerp.matricula.alumno.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import pe.edu.upeu.bomerp.matricula.alumno.entity.Alumno;

import java.util.List;
import java.util.Optional;

public interface AlumnoRepository extends JpaRepository<Alumno, Long> {
    Optional<Alumno> findByDni(String dni);
    boolean existsByDni(String dni);
}
package pe.edu.upeu.bomerp.matricula.alumno.service;

import pe.edu.upeu.bomerp.matricula.alumno.dto.PlanFinancieroAlumno;
import pe.edu.upeu.bomerp.matricula.alumno.dto.RecaudacionColegio;
import pe.edu.upeu.bomerp.matricula.alumno.entity.Alumno;

public interface PlanFinancieroService {
    PlanFinancieroAlumno obtenerPorAlumno(Alumno alumno);
    PlanFinancieroAlumno registrarPago(Alumno alumno, Integer numeroCuota);
    void generarPlanInicial(Alumno alumno);
    void regenerarPlanSiSinPagos(Alumno alumno);
    void eliminarPorAlumno(Long alumnoId);
    RecaudacionColegio obtenerRecaudacion(Long colegioId);
    PlanFinancieroAlumno agregarDeuda(Alumno alumno, String concepto, Double monto, String fechaVencimiento);
}

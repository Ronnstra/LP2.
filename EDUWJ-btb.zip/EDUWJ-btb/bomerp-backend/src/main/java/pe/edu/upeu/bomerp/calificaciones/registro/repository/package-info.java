/**
 * Repositorio de calificaciones expuesto para portales docentes y de alumnos.
 */
@org.springframework.modulith.NamedInterface("calificaciones-registro-repository")
package pe.edu.upeu.bomerp.calificaciones.registro.repository;

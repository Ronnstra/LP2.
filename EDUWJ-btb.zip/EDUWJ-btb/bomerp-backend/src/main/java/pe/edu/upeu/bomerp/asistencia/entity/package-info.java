/**
 * Entidades de asistencia expuestas para módulos de portal y matrícula.
 */
@org.springframework.modulith.NamedInterface("asistencia-entity")
package pe.edu.upeu.bomerp.asistencia.entity;

package pe.edu.upeu.bomerp.matricula.alumno.dto;

public record CuotaAlumnoResponse(
        Integer numero,
        String concepto,
        Double monto,
        String fechaVencimiento,
        String estado,
        String fechaPago,
        String numeroOperacion
) {
}

/**
 * Repositorios de asistencia expuestos para módulos de portal y matrícula.
 */
@org.springframework.modulith.NamedInterface("asistencia-repository")
package pe.edu.upeu.bomerp.asistencia.repository;

package pe.edu.upeu.bomerp.horario.entity;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;

@Entity
@Table(name = "BLOQUES_HORARIO", schema = "BOMERP_APP")
@Getter
@Setter
public class BloqueHorario {

    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "seq_bloque_horario")
    @SequenceGenerator(name = "seq_bloque_horario", sequenceName = "BOMERP_APP.SEQ_BLOQUE_HORARIO", allocationSize = 1)
    private Long id;

    @Column(nullable = false, length = 50)
    private String grado;

    @Column(length = 15)
    private String seccion = "A";

    @Column(nullable = false, length = 25)
    private String dia; // Lunes, Martes, Miércoles, Jueves, Viernes, Sábado, Domingo

    @Column(nullable = false, length = 15)
    private String horaInicio; // HH:mm

    @Column(nullable = false, length = 15)
    private String horaFin; // HH:mm

    @Column(nullable = false)
    private Double duracionHoras = 2.0;

    @Column(nullable = false)
    private Integer duracionMinutos = 120;

    @Column(nullable = false, length = 120)
    private String curso;

    @Column(nullable = false)
    private Long docenteId;

    @Column(nullable = false, length = 150)
    private String docenteNombre;

    @Column(length = 80)
    private String aula;

    @Column(nullable = false)
    private Boolean confirmado = true;

    @Column(length = 40)
    private String fechaConfirmacion;

    @Column(length = 80)
    private String confirmadoPor;

    @Column(name = "COLEGIO_ID")
    private Long colegioId;
}

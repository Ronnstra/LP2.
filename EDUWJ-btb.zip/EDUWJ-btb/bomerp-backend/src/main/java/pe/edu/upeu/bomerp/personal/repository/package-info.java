/**
 * Repositorios de personal expuestos para portales docentes, secretaría y finanzas.
 */
@org.springframework.modulith.NamedInterface("personal-repository")
package pe.edu.upeu.bomerp.personal.repository;

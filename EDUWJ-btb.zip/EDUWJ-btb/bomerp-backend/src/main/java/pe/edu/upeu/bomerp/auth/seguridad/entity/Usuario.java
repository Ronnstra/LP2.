package pe.edu.upeu.bomerp.auth.seguridad.entity;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;

@Entity
@Table(name = "USUARIOS", schema = "BOMERP_APP")
@Getter
@Setter
public class Usuario {

    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "seq_usuario")
    @SequenceGenerator(name = "seq_usuario", sequenceName = "BOMERP_APP.SEQ_USUARIO", allocationSize = 1)
    private Long id;

    @Column(nullable = false, length = 80)
    private String username;

    @Column(nullable = false, length = 255)
    private String passwordHash;

    @Column(nullable = false, length = 30)
    private String rol; // ADMIN (único maestro), DIRECTOR, SECRETARIA, DOCENTE, ALUMNO, COLABORADOR, VENDEDOR, SUPERVISOR

    @Column(nullable = false, length = 30)
    private String estado = "ACTIVO"; // ACTIVO, INACTIVO, PAUSADA, ACTIVO_PROVISIONAL

    @Column(length = 30)
    private String estadoAprobacion = "CONFIRMADO"; // CONFIRMADO, PENDIENTE

    @Column(length = 150)
    private String nombreCompleto;

    @Column(length = 120)
    private String email;

    @Column(length = 20)
    private String telefono;

    @Column(length = 20)
    private String dni;

    @Column(length = 30)
    private String turno;

    @Column(length = 30)
    private String fechaRegistro;

    @Column(length = 100)
    private String cargo;

    private Long colegioId;

    @Column(length = 150)
    private String nombreColegio;

    @Column(length = 120)
    private String slugColegio;

    @Column(length = 80)
    private String keycloakSub;
}
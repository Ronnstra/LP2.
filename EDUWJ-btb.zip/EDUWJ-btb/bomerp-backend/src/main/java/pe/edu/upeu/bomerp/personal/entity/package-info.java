/**
 * Entidades de personal expuestas para portales docentes, secretaría y finanzas.
 */
@org.springframework.modulith.NamedInterface("personal-entity")
package pe.edu.upeu.bomerp.personal.entity;

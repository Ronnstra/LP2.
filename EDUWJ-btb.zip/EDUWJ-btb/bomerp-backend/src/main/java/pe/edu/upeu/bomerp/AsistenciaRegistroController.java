package pe.edu.upeu.bomerp;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.*;
import pe.edu.upeu.bomerp.asistencia.entity.Asistencia;
import pe.edu.upeu.bomerp.asistencia.service.AsistenciaService;
import pe.edu.upeu.bomerp.auth.seguridad.entity.Usuario;
import pe.edu.upeu.bomerp.auth.seguridad.repository.UsuarioRepository;
import pe.edu.upeu.bomerp.personal.entity.PersonalEscolar;
import pe.edu.upeu.bomerp.personal.repository.PersonalEscolarRepository;

import java.time.LocalDate;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/v1/asistencias")
@RequiredArgsConstructor
@Transactional
@Tag(name = "Asistencias por Sesión", description = "Registro persistente de asistencia por curso, grado, sección y sesión en Oracle DB")
public class AsistenciaRegistroController {

    private final AsistenciaService asistenciaService;
    private final PersonalEscolarRepository personalRepository;
    private final UsuarioRepository usuarioRepository;

    @Operation(summary = "Registrar o actualizar la asistencia de una sesión")
    @PostMapping
    public ResponseEntity<?> registrar(@RequestBody Map<String, Object> body) {
        String curso = texto(body.get("curso"));
        Integer sesion = entero(body.get("sesion"));
        Object asistenciasObj = body.get("asistencias");

        if (curso.isEmpty() || sesion == null || !(asistenciasObj instanceof List<?> lista)) {
            return ResponseEntity.badRequest().body(Map.of(
                    "message", "Curso, sesión y asistencias son obligatorios."
            ));
        }

        PersonalEscolar docente = resolverDocente(body);
        if (docente == null) {
            return ResponseEntity.badRequest().body(Map.of(
                    "message", "No se pudo identificar al docente que registra la asistencia."
            ));
        }

        String grado = texto(body.get("grado"));
        String seccion = texto(body.get("seccion"));
        if (grado.isEmpty() || seccion.isEmpty()) {
            return ResponseEntity.badRequest().body(Map.of(
                    "message", "Grado y sección son obligatorios."
            ));
        }

        LocalDate fecha = parseFecha(body.get("fechaRegistro"));
        List<Map<String, Object>> items = lista.stream()
                .filter(Map.class::isInstance)
                .map(item -> (Map<String, Object>) item)
                .toList();

        List<Asistencia> guardadas = asistenciaService.registrarSesion(
                docente.getId(),
                "Prof. " + docente.getNombre() + " " + docente.getApellidos(),
                docente.getColegioId(),
                curso,
                grado,
                seccion,
                sesion,
                fecha,
                items
        );

        return ResponseEntity.ok(Map.of(
                "mensaje", "Asistencia de " + curso + " - " + grado + " " + seccion + " (sesión " + sesion + ") guardada en Oracle DB.",
                "totalRegistros", guardadas.size(),
                "asistencias", guardadas
        ));
    }

    @Operation(summary = "Listar asistencias por colegio y filtros de sesión")
    @GetMapping
    public ResponseEntity<List<Asistencia>> listar(
            @RequestParam(required = false) Long colegioId,
            @RequestParam(required = false) String curso,
            @RequestParam(required = false) String grado,
            @RequestParam(required = false) String seccion,
            @RequestParam(required = false) Integer sesion) {
        return ResponseEntity.ok(asistenciaService.listar(colegioId, curso, grado, seccion, sesion));
    }

    @Operation(summary = "Listar asistencias registradas por un docente")
    @GetMapping("/docente/{docenteId}")
    public ResponseEntity<List<Asistencia>> listarPorDocente(@PathVariable Long docenteId) {
        return ResponseEntity.ok(asistenciaService.listarPorDocente(docenteId));
    }

    @Operation(summary = "Listar asistencias de un alumno")
    @GetMapping("/alumno/{alumnoId}")
    public ResponseEntity<List<Asistencia>> listarPorAlumno(@PathVariable Long alumnoId) {
        return ResponseEntity.ok(asistenciaService.listarPorAlumno(alumnoId));
    }

    @Operation(summary = "Resumen de asistencias de un alumno")
    @GetMapping("/resumen/alumno/{alumnoId}")
    public ResponseEntity<Map<String, Object>> resumenAlumno(@PathVariable Long alumnoId) {
        Map<String, Object> resumen = new LinkedHashMap<>(asistenciaService.resumenAlumno(alumnoId));
        resumen.put("alumnoId", alumnoId);
        return ResponseEntity.ok(resumen);
    }

    @Operation(summary = "Resumen general de asistencias de un colegio")
    @GetMapping("/resumen")
    public ResponseEntity<Map<String, Object>> resumenColegio(@RequestParam Long colegioId) {
        List<Asistencia> asistencias = asistenciaService.listar(colegioId, null, null, null, null);
        long presentes = asistencias.stream().filter(a -> "PRESENTE".equalsIgnoreCase(a.getEstado())).count();
        long faltas = asistencias.stream().filter(a -> "FALTA".equalsIgnoreCase(a.getEstado())).count();
        long tardanzas = asistencias.stream().filter(a -> "TARDANZA".equalsIgnoreCase(a.getEstado())).count();
        long justificadas = asistencias.stream().filter(a -> "JUSTIFICADO".equalsIgnoreCase(a.getEstado())).count();
        long total = asistencias.size();
        double porcentaje = total == 0 ? 0.0 : Math.round(((presentes + tardanzas + justificadas) * 10000.0 / total)) / 100.0;

        Map<String, Object> resumen = new LinkedHashMap<>();
        resumen.put("colegioId", colegioId);
        resumen.put("totalSesiones", total);
        resumen.put("presentes", presentes);
        resumen.put("faltas", faltas);
        resumen.put("tardanzas", tardanzas);
        resumen.put("justificadas", justificadas);
        resumen.put("porcentajeAsistencia", porcentaje);
        return ResponseEntity.ok(resumen);
    }

    private PersonalEscolar resolverDocente(Map<String, Object> body) {
        Long colegioId = null;
        if (body.get("colegioId") != null) {
            colegioId = Long.parseLong(String.valueOf(body.get("colegioId")));
        }
        if (body.get("docenteId") != null) {
            Long docenteId = Long.parseLong(String.valueOf(body.get("docenteId")));
            PersonalEscolar porId = personalRepository.findById(docenteId).orElse(null);
            if (porId != null && (colegioId == null || colegioId.equals(porId.getColegioId()))) return porId;
        }
        String username = texto(body.get("username"));
        if (!username.isEmpty()) {
            PersonalEscolar porUsername = colegioId != null
                    ? personalRepository.findByUsernameIgnoreCaseAndColegioId(username, colegioId).orElse(null)
                    : personalRepository.findByUsernameIgnoreCase(username).orElse(null);
            if (porUsername != null) return porUsername;
            Usuario usuario = colegioId != null
                    ? usuarioRepository.findByUsernameIgnoreCaseAndColegioId(username, colegioId).orElse(null)
                    : usuarioRepository.findByUsernameIgnoreCase(username).orElse(null);
            if (usuario != null) {
                PersonalEscolar porUsuario = usuario.getColegioId() != null
                        ? personalRepository.findByUsernameIgnoreCaseAndColegioId(usuario.getUsername(), usuario.getColegioId()).orElse(null)
                        : personalRepository.findByUsernameIgnoreCase(usuario.getUsername()).orElse(null);
                if (porUsuario != null) return porUsuario;
                if (usuario.getDni() != null) {
                    return personalRepository.findByDniAndColegioId(usuario.getDni(), usuario.getColegioId()).orElse(null);
                }
            }
        }
        return null;
    }

    private String texto(Object value) {
        return value != null ? String.valueOf(value).trim() : "";
    }

    private Integer entero(Object value) {
        if (value == null) return null;
        try {
            return Integer.parseInt(String.valueOf(value));
        } catch (NumberFormatException e) {
            return null;
        }
    }

    private LocalDate parseFecha(Object value) {
        if (value == null || String.valueOf(value).isBlank()) return LocalDate.now();
        try {
            return LocalDate.parse(String.valueOf(value).trim().substring(0, 10));
        } catch (Exception e) {
            return LocalDate.now();
        }
    }
}

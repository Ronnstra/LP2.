package pe.edu.upeu.bomerp.matricula.inscripcion.dto;

import jakarta.validation.Valid;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.NotNull;
import lombok.Getter;
import lombok.Setter;

import java.util.List;

@Getter
@Setter
public class MatriculaRequest {

    @NotNull
    private Long alumnoId;

    @NotBlank
    private String periodo;

    @NotEmpty
    @Valid
    private List<DetalleMatriculaRequest> detalles;
}

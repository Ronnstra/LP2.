package pe.edu.upeu.bomerp.matricula.inscripcion.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class DetalleMatriculaResponse {
    private Long id;
    private Long cursoId;
    private String nombreCurso;
    private Integer creditos;
}

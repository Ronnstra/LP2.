/**
 * Entidades de horario expuestas para portales docentes, alumnos y secretaría.
 */
@org.springframework.modulith.NamedInterface("horario-entity")
package pe.edu.upeu.bomerp.horario.entity;

package pe.edu.upeu.bomerp;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.ResponseEntity;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.web.bind.annotation.*;
import pe.edu.upeu.bomerp.config.DataInitializer;
import pe.edu.upeu.bomerp.config.DatabaseResetService;
import pe.edu.upeu.bomerp.config.DatabaseSchemaInitializer;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

@Slf4j
@RestController
@RequestMapping("/api/v1/sistema")
@RequiredArgsConstructor
@Tag(name = "Sistema", description = "Reinicio y estado del sistema para pruebas desde cero")
public class SistemaController {

    private final JdbcTemplate jdbcTemplate;
    private final DatabaseResetService databaseResetService;
    private final DataInitializer dataInitializer;
    private final DatabaseSchemaInitializer databaseSchemaInitializer;

    @Operation(summary = "Reiniciar la base de datos a cero conservando únicamente la cuenta maestra")
    @PostMapping("/reset")
    public ResponseEntity<Map<String, Object>> reset(@RequestBody(required = false) Map<String, Object> body) {
        String modo = body != null && body.get("modo") != null ? String.valueOf(body.get("modo")) : "limpio";
        reiniciarDatos();
        Map<String, Object> resp = new LinkedHashMap<>();
        resp.put("success", true);
        resp.put("modo", modo);
        resp.put("mensaje", "Base de datos reiniciada a cero. Solo quedó jimyamanqui@gmail.com.");
        resp.put("estado", estadoSistema());
        return ResponseEntity.ok(resp);
    }

    @Operation(summary = "Estado actual de las tablas del sistema")
    @GetMapping("/estado")
    public ResponseEntity<Map<String, Object>> estado() {
        return ResponseEntity.ok(estadoSistema());
    }

    private void reiniciarDatos() {
        databaseResetService.limpiarTodo();
        dataInitializer.run();
        databaseSchemaInitializer.run();
        log.warn("Sistema reiniciado a cero desde /api/v1/sistema/reset");
    }

    private Map<String, Object> estadoSistema() {
        Map<String, Object> estado = new LinkedHashMap<>();
        List<String> tablas = jdbcTemplate.queryForList(
                "SELECT table_name FROM user_tables ORDER BY table_name",
                String.class
        );
        for (String tabla : tablas) {
            if ("SISTEMA_MIGRACIONES".equals(tabla)) {
                continue;
            }
            try {
                Integer total = jdbcTemplate.queryForObject("SELECT COUNT(*) FROM " + tabla, Integer.class);
                estado.put(tabla, total != null ? total : 0);
            } catch (Exception e) {
                estado.put(tabla, -1);
            }
        }
        return estado;
    }
}

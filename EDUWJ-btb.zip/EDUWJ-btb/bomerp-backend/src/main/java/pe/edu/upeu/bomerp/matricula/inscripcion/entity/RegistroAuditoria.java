package pe.edu.upeu.bomerp.matricula.inscripcion.entity;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;

import java.time.LocalDateTime;

@Entity
@Table(name = "AUDITORIA")
@Getter
@Setter
public class RegistroAuditoria {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false, length = 120)
    private String actor; // sub del JWT -- quien ejecuto la accion

    @Column(nullable = false, length = 40)
    private String accion; // "CREAR", "ANULAR"

    @Column(nullable = false, length = 60)
    private String entidad; // "MATRICULA", "CONTRATO_MATRICULA"

    private Long entidadId;

    @Column(nullable = false)
    private LocalDateTime fecha;

    @Column(length = 400)
    private String detalle;
}

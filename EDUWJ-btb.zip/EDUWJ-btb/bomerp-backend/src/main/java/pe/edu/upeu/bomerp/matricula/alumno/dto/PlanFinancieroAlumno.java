package pe.edu.upeu.bomerp.matricula.alumno.dto;

import java.util.List;

public record PlanFinancieroAlumno(
        Double costoMensual,
        Integer mesesPeriodo,
        String modalidadPago,
        Double descuento,
        Double totalContratado,
        Double totalPagado,
        Double deudaPendiente,
        List<CuotaAlumnoResponse> cuotas,
        Integer cuotasPagadas,
        Boolean mesActualPagado,
        Integer cuotaMesActualNumero
) {
}

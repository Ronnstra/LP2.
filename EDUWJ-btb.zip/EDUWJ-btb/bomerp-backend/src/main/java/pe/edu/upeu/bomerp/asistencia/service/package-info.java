/**
 * Servicio de asistencia expuesto para módulos de portal y matrícula.
 */
@org.springframework.modulith.NamedInterface("asistencia-service")
package pe.edu.upeu.bomerp.asistencia.service;

/**
 * AlumnoService expuesto para que el módulo de inscripción y otros módulos
 * puedan consultar datos del estudiante (ADR-002).
 */
@org.springframework.modulith.NamedInterface("alumno-service")
package pe.edu.upeu.bomerp.matricula.alumno.service;

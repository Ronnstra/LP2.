/**
 * Repositorio de horarios expuesto para portales docentes, alumnos y secretaría.
 */
@org.springframework.modulith.NamedInterface("horario-repository")
package pe.edu.upeu.bomerp.horario.repository;

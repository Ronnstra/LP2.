package pe.edu.upeu.bomerp.saas.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import pe.edu.upeu.bomerp.saas.entity.PagoSaaS;

import java.util.List;

public interface PagoSaaSRepository extends JpaRepository<PagoSaaS, Long> {
    List<PagoSaaS> findByColegioIdOrderByIdDesc(Long colegioId);
    boolean existsByColegioIdAndNumeroOperacionIgnoreCase(Long colegioId, String numeroOperacion);
}

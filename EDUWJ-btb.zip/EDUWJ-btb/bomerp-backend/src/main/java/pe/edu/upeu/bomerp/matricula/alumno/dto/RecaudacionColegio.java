package pe.edu.upeu.bomerp.matricula.alumno.dto;

public record RecaudacionColegio(
        Double totalPensionesCobradas,
        long cuotasPagadas,
        long cuotasPendientes
) {
}

package pe.edu.upeu.bomerp.personal.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import pe.edu.upeu.bomerp.personal.entity.ContratoDocente;

import java.util.Optional;

public interface ContratoDocenteRepository extends JpaRepository<ContratoDocente, Long> {
    Optional<ContratoDocente> findByDocenteId(Long docenteId);
}

/**
 * Repositorio de alumnos expuesto para módulos que orquestan matrícula y asistencia.
 */
@org.springframework.modulith.NamedInterface("matricula-alumno-repository")
package pe.edu.upeu.bomerp.matricula.alumno.repository;

package pe.edu.upeu.bomerp;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.*;
import pe.edu.upeu.bomerp.academico.curso.entity.Curso;
import pe.edu.upeu.bomerp.academico.curso.repository.CursoRepository;
import pe.edu.upeu.bomerp.auth.seguridad.entity.Usuario;
import pe.edu.upeu.bomerp.auth.seguridad.repository.UsuarioRepository;
import pe.edu.upeu.bomerp.horario.entity.BloqueHorario;
import pe.edu.upeu.bomerp.horario.repository.BloqueHorarioRepository;
import pe.edu.upeu.bomerp.matricula.alumno.entity.Alumno;
import pe.edu.upeu.bomerp.matricula.alumno.repository.AlumnoRepository;
import pe.edu.upeu.bomerp.personal.entity.ContratoDocente;
import pe.edu.upeu.bomerp.personal.entity.PersonalEscolar;
import pe.edu.upeu.bomerp.personal.repository.ContratoDocenteRepository;
import pe.edu.upeu.bomerp.personal.repository.PersonalEscolarRepository;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.*;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/api/v1/horarios")
@RequiredArgsConstructor
@Transactional
@Tag(name = "Horarios Escolares y Catálogo de Cursos", description = "Gestión de horarios de secundaria y catálogo de cursos en Oracle DB")
public class HorarioController {

    private final BloqueHorarioRepository bloqueHorarioRepository;
    private final CursoRepository cursoRepository;
    private final PersonalEscolarRepository personalRepository;
    private final ContratoDocenteRepository contratoRepository;
    private final AlumnoRepository alumnoRepository;
    private final UsuarioRepository usuarioRepository;

    private String horaInicioJornada = "09:00";
    private String horaFinJornada = "16:00";
    private int duracionModuloMinutos = 120;
    private boolean recesoHabilitado = true;
    private String recesoInicio = "11:00";
    private String recesoFin = "11:45";
    private int recesoDuracionMinutos = 45;
    private List<String> diasLectivos = new ArrayList<>(List.of("Lunes", "Martes", "Miércoles", "Jueves", "Viernes"));

    private static final DateTimeFormatter FMT_FECHA = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm");

    // ========================================================
    // 1. CATÁLOGO DE CURSOS EN ORACLE DB (/api/v1/horarios/cursos)
    // ========================================================

    @Operation(summary = "Listar nombres de cursos del catálogo desde Oracle DB")
    @GetMapping("/cursos")
    public ResponseEntity<List<String>> listarCatalogoCursos(@RequestParam(required = false) Long colegioId) {
        List<String> nombres = obtenerNombresCursosDesdeOracle(colegioId);
        return ResponseEntity.ok(nombres);
    }

    @Operation(summary = "Crear un nuevo curso en el catálogo y guardarlo en Oracle DB")
    @PostMapping("/cursos")
    public ResponseEntity<?> agregarCursoAlCatalogo(@RequestBody Map<String, Object> body) {
        String nombre = body.get("nombre") != null ? String.valueOf(body.get("nombre")).trim() : "";
        Long colegioId = body.get("colegioId") != null ? Long.parseLong(String.valueOf(body.get("colegioId"))) : null;
        String grado = extraerGradoCsv(body);
        if (nombre.isEmpty()) {
            return ResponseEntity.badRequest().body(Map.of("message", "El nombre del curso es obligatorio"));
        }

        List<Curso> existentes = cursoRepository.findAll().stream()
                .filter(c -> c.getNombre() != null
                        && c.getNombre().equalsIgnoreCase(nombre)
                        && Objects.equals(colegioId, c.getColegioId()))
                .toList();

        if (existentes.isEmpty()) {
            Curso nuevo = new Curso();
            nuevo.setNombre(nombre);
            nuevo.setGrado(grado);
            nuevo.setCreditos(body.get("creditos") != null ? Integer.parseInt(String.valueOf(body.get("creditos"))) : 4);
            int vacantes = body.get("vacantesMaximas") != null ? Integer.parseInt(String.valueOf(body.get("vacantesMaximas"))) : 35;
            nuevo.setVacantesMaximas(vacantes);
            nuevo.setVacantesDisponibles(vacantes);
            nuevo.setAula(body.get("aula") != null ? String.valueOf(body.get("aula")).trim() : "Aula General");
            nuevo.setColegioId(colegioId);
            cursoRepository.save(nuevo);
        } else if (body.get("grado") != null || body.get("grados") != null) {
            for (Curso existente : existentes) {
                existente.setGrado(grado);
                cursoRepository.save(existente);
            }
        }

        List<String> nombres = obtenerNombresCursosDesdeOracle(colegioId);
        return ResponseEntity.ok(Map.of(
                "mensaje", "Curso '" + nombre + "' guardado permanentemente en Oracle DB.",
                "cursos", nombres,
                "detalle", obtenerDetalleCursos(colegioId)
        ));
    }

    @Operation(summary = "Listar cursos con sus grados habilitados desde Oracle DB")
    @GetMapping("/cursos/detalle")
    public ResponseEntity<List<Map<String, Object>>> listarCatalogoCursosDetalle(@RequestParam(required = false) Long colegioId) {
        return ResponseEntity.ok(obtenerDetalleCursos(colegioId));
    }

    @Operation(summary = "Actualizar nombre y/o grados habilitados de un curso en Oracle DB")
    @PutMapping("/cursos/{nombre}")
    public ResponseEntity<?> actualizarCursoDelCatalogo(
            @PathVariable String nombre,
            @RequestBody Map<String, Object> body) {
        String nombreActual = nombre != null ? nombre.trim() : "";
        String nombreNuevo = body.get("nombre") != null && !String.valueOf(body.get("nombre")).isBlank()
                ? String.valueOf(body.get("nombre")).trim()
                : nombreActual;
        String grado = extraerGradoCsv(body);
        Long colegioId = body.get("colegioId") != null ? Long.parseLong(String.valueOf(body.get("colegioId"))) : null;

        List<Curso> coincidencias = cursoRepository.findAll().stream()
                .filter(c -> c.getNombre() != null
                        && c.getNombre().equalsIgnoreCase(nombreActual)
                        && (colegioId == null || Objects.equals(colegioId, c.getColegioId())))
                .toList();

        if (coincidencias.isEmpty()) {
            Curso nuevo = new Curso();
            nuevo.setNombre(nombreNuevo);
            nuevo.setGrado(grado);
            nuevo.setCreditos(4);
            nuevo.setVacantesMaximas(35);
            nuevo.setVacantesDisponibles(35);
            nuevo.setAula("Aula General");
            nuevo.setColegioId(colegioId);
            cursoRepository.save(nuevo);
        } else {
            for (Curso c : coincidencias) {
                c.setNombre(nombreNuevo);
                c.setGrado(grado);
                cursoRepository.save(c);
            }
        }

        if (!nombreActual.equalsIgnoreCase(nombreNuevo)) {
            for (BloqueHorario b : bloqueHorarioRepository.findAll()) {
                if (b.getCurso() != null && b.getCurso().equalsIgnoreCase(nombreActual)
                        && (colegioId == null || Objects.equals(colegioId, b.getColegioId()))) {
                    b.setCurso(nombreNuevo);
                    bloqueHorarioRepository.save(b);
                }
            }
        }

        return ResponseEntity.ok(Map.of(
                "mensaje", "Curso '" + nombreNuevo + "' actualizado en Oracle DB. Grados habilitados: " + grado + ".",
                "cursos", obtenerNombresCursosDesdeOracle(colegioId),
                "detalle", obtenerDetalleCursos(colegioId)
        ));
    }

    @Operation(summary = "Eliminar un curso del catálogo en Oracle DB")
    @DeleteMapping("/cursos/{nombre}")
    public ResponseEntity<?> eliminarCursoDelCatalogo(
            @PathVariable String nombre,
            @RequestParam(required = false) Long colegioId) {
        String cleanNombre = nombre != null ? nombre.trim() : "";
        List<Curso> coincidencias = cursoRepository.findAll().stream()
                .filter(c -> c.getNombre() != null
                        && c.getNombre().equalsIgnoreCase(cleanNombre)
                        && (colegioId == null || Objects.equals(colegioId, c.getColegioId())))
                .collect(Collectors.toList());
        cursoRepository.deleteAll(coincidencias);

        List<String> nombres = obtenerNombresCursosDesdeOracle(colegioId);
        return ResponseEntity.ok(Map.of(
                "mensaje", "Curso '" + cleanNombre + "' eliminado de Oracle DB.",
                "cursos", nombres
        ));
    }

    private List<String> obtenerNombresCursosDesdeOracle(Long colegioId) {
        Set<String> unicos = new LinkedHashSet<>();
        for (Curso c : cursoRepository.findAll()) {
            if (colegioId != null && !Objects.equals(colegioId, c.getColegioId())) continue;
            if (c.getNombre() != null && !c.getNombre().isBlank()) {
                unicos.add(c.getNombre().trim());
            }
        }
        for (BloqueHorario b : bloqueHorarioRepository.findAll()) {
            if (colegioId != null && !Objects.equals(colegioId, b.getColegioId())) continue;
            if (b.getCurso() != null && !b.getCurso().isBlank()) {
                unicos.add(b.getCurso().trim());
            }
        }
        return new ArrayList<>(unicos);
    }

    private String extraerGradoCsv(Map<String, Object> body) {
        if (body.get("grados") instanceof List<?> lista && !lista.isEmpty()) {
            return lista.stream()
                    .map(String::valueOf)
                    .map(String::trim)
                    .filter(s -> !s.isEmpty())
                    .distinct()
                    .collect(Collectors.joining(", "));
        }
        if (body.get("grado") != null && !String.valueOf(body.get("grado")).isBlank()) {
            return String.valueOf(body.get("grado")).trim();
        }
        return "Secundaria General";
    }

    private List<Map<String, Object>> obtenerDetalleCursos(Long colegioId) {
        Map<String, Map<String, Object>> agrupados = new LinkedHashMap<>();
        for (Curso c : cursoRepository.findAll()) {
            if (colegioId != null && !Objects.equals(colegioId, c.getColegioId())) continue;
            if (c.getNombre() == null || c.getNombre().isBlank()) continue;
            String key = c.getNombre().trim().toLowerCase();
            Map<String, Object> item = agrupados.get(key);
            if (item == null) {
                item = new LinkedHashMap<>();
                item.put("nombre", c.getNombre().trim());
                item.put("grado", c.getGrado() != null && !c.getGrado().isBlank() ? c.getGrado().trim() : "Secundaria General");
                agrupados.put(key, item);
            } else {
                item.put("grado", unirGrados(String.valueOf(item.get("grado")), c.getGrado()));
            }
        }
        // Cursos que solo existen en bloques de horario
        for (BloqueHorario b : bloqueHorarioRepository.findAll()) {
            if (colegioId != null && !Objects.equals(colegioId, b.getColegioId())) continue;
            if (b.getCurso() == null || b.getCurso().isBlank()) continue;
            String key = b.getCurso().trim().toLowerCase();
            if (!agrupados.containsKey(key)) {
                Map<String, Object> item = new LinkedHashMap<>();
                item.put("nombre", b.getCurso().trim());
                item.put("grado", b.getGrado() != null && !b.getGrado().isBlank() ? b.getGrado().trim() : "Secundaria General");
                agrupados.put(key, item);
            }
        }
        return new ArrayList<>(agrupados.values());
    }

    private String unirGrados(String actual, String nuevo) {
        Set<String> grados = new LinkedHashSet<>();
        if (actual != null) {
            for (String g : actual.split(",")) {
                if (!g.trim().isEmpty()) grados.add(g.trim());
            }
        }
        if (nuevo != null) {
            for (String g : nuevo.split(",")) {
                if (!g.trim().isEmpty()) grados.add(g.trim());
            }
        }
        return String.join(", ", grados);
    }

    private boolean cursoHabilitadoParaGrado(String curso, String grado, Long colegioId) {
        if (curso == null || curso.isBlank() || grado == null || grado.isBlank()) return true;
        List<Curso> coincidencias = cursoRepository.findAll().stream()
                .filter(c -> c.getNombre() != null
                        && c.getNombre().equalsIgnoreCase(curso.trim())
                        && (colegioId == null || Objects.equals(colegioId, c.getColegioId())))
                .toList();
        if (coincidencias.isEmpty()) return true;
        for (Curso c : coincidencias) {
            String gradosCsv = c.getGrado();
            if (gradosCsv == null || gradosCsv.isBlank() || gradosCsv.toLowerCase().contains("general")) return true;
            for (String permitido : gradosCsv.split(",")) {
                if (normalizarGrado(permitido).equals(normalizarGrado(grado))) return true;
            }
        }
        return false;
    }

    private String normalizarGrado(String grado) {
        return grado == null ? "" : grado.trim().toLowerCase().replaceAll("\\s+", " ");
    }

    // ========================================================
    // 2. CONSULTA DE HORARIOS POR GRADO, TODOS, ALUMNO Y DOCENTE
    // ========================================================

    @Operation(summary = "Obtener horario semanal de secundaria por grado desde Oracle DB")
    @GetMapping({"/secundaria/{grado}", "/grado/{grado}"})
    public ResponseEntity<Map<String, Object>> obtenerHorarioPorGrado(
            @PathVariable String grado,
            @RequestParam(required = false) Long colegioId) {
        List<Map<String, Object>> semana = construirHorarioSemanalPorGrado(grado, colegioId);
        long totalBloques = bloqueHorarioRepository.findByGradoIgnoreCase(grado).stream()
                .filter(b -> colegioId == null || Objects.equals(colegioId, b.getColegioId()))
                .count();
        return ResponseEntity.ok(Map.of(
                "grado", grado,
                "semana", semana,
                "totalBloques", totalBloques
        ));
    }

    @Operation(summary = "Listar todos los bloques horarios registrados en Oracle DB")
    @GetMapping("/todos")
    public ResponseEntity<List<BloqueHorario>> listarTodosLosBloques(@RequestParam(required = false) Long colegioId) {
        List<BloqueHorario> todos = bloqueHorarioRepository.findAll();
        if (colegioId != null) {
            todos = todos.stream()
                    .filter(b -> Objects.equals(colegioId, b.getColegioId()))
                    .collect(Collectors.toList());
        }
        return ResponseEntity.ok(todos);
    }

    @Operation(summary = "Obtener horario semanal de un alumno desde Oracle DB")
    @GetMapping("/alumno/{id}")
    public ResponseEntity<Map<String, Object>> obtenerHorarioAlumno(@PathVariable Long id) {
        Alumno alumno = alumnoRepository.findById(id).orElse(null);
        String grado = alumno != null && alumno.getGrado() != null ? alumno.getGrado() : "1° Secundaria";
        String seccion = alumno != null && alumno.getSeccion() != null ? alumno.getSeccion() : "A";
        String nombre = alumno != null ? (alumno.getNombre() + " " + alumno.getApellidoPaterno()) : "Estudiante de Secundaria";
        Long colId = alumno != null ? alumno.getColegioId() : null;

        return ResponseEntity.ok(Map.of(
                "alumnoId", id,
                "alumnoNombre", nombre,
                "grado", grado,
                "seccion", seccion,
                "semana", construirHorarioSemanalPorGrado(grado, colId)
        ));
    }

    @Operation(summary = "Obtener horario semanal y resumen de horas de un docente desde Oracle DB")
    @GetMapping("/docente/{id}")
    public ResponseEntity<Map<String, Object>> obtenerHorarioDocente(
            @PathVariable Long id,
            @RequestParam(required = false) String username) {

        List<String> diasSemana = List.of("Lunes", "Martes", "Miércoles", "Jueves", "Viernes", "Sábado", "Domingo");
        PersonalEscolar docente = resolverDocente(id, username);

        if (docente == null) {
            List<Map<String, Object>> agendaVacia = diasSemana.stream().map(dia -> {
                boolean finSemana = "Sábado".equals(dia) || "Domingo".equals(dia);
                return Map.<String, Object>of(
                        "dia", dia,
                        "esFinDeSemana", finSemana,
                        "mensaje", finSemana ? "Sin actividades pedagógicas programadas" : "Sin clases asignadas aún en este periodo",
                        "sesiones", List.of()
                );
            }).collect(Collectors.toList());

            Map<String, Object> respuestaVacia = new LinkedHashMap<>();
            respuestaVacia.put("docenteId", id);
            respuestaVacia.put("docenteNombre", "Profesor de Secundaria");
            respuestaVacia.put("dni", "-");
            respuestaVacia.put("tarifaHora", 35.0);
            respuestaVacia.put("totalHorasSemana", 0);
            respuestaVacia.put("bloquesTotal", 0);
            respuestaVacia.put("pagoSemanal", 0);
            respuestaVacia.put("horasMensuales", 0);
            respuestaVacia.put("pagoMensual", 0);
            respuestaVacia.put("agendaSemanal", agendaVacia);
            respuestaVacia.put("bloques", List.of());
            return ResponseEntity.ok(respuestaVacia);
        }

        sincronizarHorasContratoDocente(docente.getId());
        final String nombreDoc = docente.getNombre() != null ? docente.getNombre().trim().toLowerCase() : "";
        final String apellidoDoc = docente.getApellidos() != null ? docente.getApellidos().trim().toLowerCase() : "";
        List<BloqueHorario> bloques = bloqueHorarioRepository.findAll().stream()
                .filter(b -> Objects.equals(b.getDocenteId(), docente.getId())
                        || (!nombreDoc.isEmpty() && b.getDocenteNombre() != null
                        && b.getDocenteNombre().toLowerCase().contains(nombreDoc)
                        && (apellidoDoc.isEmpty() || b.getDocenteNombre().toLowerCase().contains(apellidoDoc.split("\\s+")[0]))))
                .collect(Collectors.toList());

        List<Map<String, Object>> agendaSemanal = diasSemana.stream().map(dia -> {
            if ("Sábado".equals(dia) || "Domingo".equals(dia)) {
                return Map.<String, Object>of(
                        "dia", dia,
                        "esFinDeSemana", true,
                        "mensaje", "Sin actividades pedagógicas programadas",
                        "sesiones", List.of()
                );
            }
            List<Map<String, Object>> sesiones = bloques.stream()
                    .filter(b -> dia.equalsIgnoreCase(b.getDia()))
                    .sorted(Comparator.comparing(BloqueHorario::getHoraInicio))
                    .map(b -> {
                        Map<String, Object> m = mapearBloque(b);
                        m.put("bloqueId", b.getId());
                        return m;
                    })
                    .collect(Collectors.toList());
            return Map.<String, Object>of(
                    "dia", dia,
                    "esFinDeSemana", false,
                    "mensaje", !sesiones.isEmpty() ? sesiones.size() + " sesiones en salones" : "Día libre de dictado",
                    "sesiones", sesiones
            );
        }).collect(Collectors.toList());

        double totalHorasSemana = bloques.stream()
                .mapToDouble(b -> b.getDuracionHoras() != null ? b.getDuracionHoras() : 2.0)
                .sum();
        long confirmadas = bloques.stream().filter(b -> !Boolean.FALSE.equals(b.getConfirmado())).count();
        long pendientes = bloques.stream().filter(b -> Boolean.FALSE.equals(b.getConfirmado())).count();
        double tarifaHora = docente.getTarifaHora() != null ? docente.getTarifaHora() : 35.0;
        double pagoSemanal = Math.round(totalHorasSemana * tarifaHora * 100.0) / 100.0;
        double horasMensuales = totalHorasSemana * 4.0;
        double pagoMensual = Math.round(horasMensuales * tarifaHora * 100.0) / 100.0;

        Map<String, Object> resp = new LinkedHashMap<>();
        resp.put("docenteId", docente.getId());
        resp.put("docenteNombre", docente.getNombre() + " " + docente.getApellidos());
        resp.put("dni", docente.getDni());
        resp.put("tarifaHora", tarifaHora);
        resp.put("totalHorasSemana", totalHorasSemana);
        resp.put("bloquesTotal", bloques.size());
        resp.put("pagoSemanal", pagoSemanal);
        resp.put("horasMensuales", horasMensuales);
        resp.put("pagoMensual", pagoMensual);
        resp.put("totalSesionesConfirmadas", confirmadas);
        resp.put("totalSesionesPendientes", pendientes);
        resp.put("estadoPublicacion", pendientes == 0 && !bloques.isEmpty() ? "OFICIAL_PUBLICADO" : (confirmadas > 0 ? "PUBLICADO_PARCIAL" : "BORRADOR"));
        resp.put("agendaSemanal", agendaSemanal);
        resp.put("bloques", bloques.stream().map(this::mapearBloque).collect(Collectors.toList()));
        return ResponseEntity.ok(resp);
    }

    // ========================================================
    // 3. DISPONIBILIDAD DOCENTE Y ASIGNACIÓN DE HORARIOS
    // ========================================================

    @Operation(summary = "Consultar disponibilidad de docentes en tiempo real desde Oracle DB")
    @GetMapping("/disponibilidad-docentes")
    public ResponseEntity<List<Map<String, Object>>> consultarDisponibilidadDocentes(
            @RequestParam(required = false) String dia,
            @RequestParam(required = false) String horaInicio,
            @RequestParam(required = false) String horaFin,
            @RequestParam(required = false) Long bloqueIdExcluir,
            @RequestParam(required = false) Long colegioId) {

        List<PersonalEscolar> docentes = personalRepository.findByCargoIgnoreCase("DOCENTE");
        if (colegioId != null) {
            docentes = docentes.stream()
                    .filter(d -> Objects.equals(colegioId, d.getColegioId()))
                    .collect(Collectors.toList());
        }
        List<BloqueHorario> todosLosBloques = bloqueHorarioRepository.findAll();

        List<Map<String, Object>> resultado = docentes.stream().map(d -> {
            Map<String, Object> item = new LinkedHashMap<>();
            item.put("docenteId", d.getId());
            item.put("nombreCompleto", "Prof. " + d.getNombre() + " " + d.getApellidos());
            item.put("dni", d.getDni());
            List<String> esp = d.getCursosEspecialidadCsv() != null && !d.getCursosEspecialidadCsv().isBlank()
                    ? Arrays.stream(d.getCursosEspecialidadCsv().split(",")).map(String::trim).filter(s -> !s.isEmpty()).collect(Collectors.toList())
                    : new ArrayList<>();
            item.put("cursosEspecialidad", esp);
            item.put("tarifaHora", d.getTarifaHora() != null ? d.getTarifaHora() : 35.0);

            if (dia != null && !dia.isBlank() && horaInicio != null && !horaInicio.isBlank() && horaFin != null && !horaFin.isBlank()) {
                BloqueHorario choque = todosLosBloques.stream()
                        .filter(b -> !Objects.equals(b.getId(), bloqueIdExcluir))
                        .filter(b -> Objects.equals(b.getDocenteId(), d.getId()))
                        .filter(b -> dia.equalsIgnoreCase(b.getDia()))
                        .filter(b -> haySuperposicion(horaInicio, horaFin, b.getHoraInicio(), b.getHoraFin()))
                        .findFirst()
                        .orElse(null);

                if (choque != null) {
                    item.put("disponible", false);
                    item.put("motivoConflicto", "Ocupado en " + choque.getGrado() + " dictando " + choque.getCurso() + " (" + choque.getHoraInicio() + " - " + choque.getHoraFin() + ")");
                    item.put("gradoOcupado", choque.getGrado());
                    item.put("cursoOcupado", choque.getCurso());
                    return item;
                }
            }

            item.put("disponible", true);
            return item;
        }).collect(Collectors.toList());

        return ResponseEntity.ok(resultado);
    }

    @Operation(summary = "Asignar o actualizar un bloque horario en Oracle DB con validación de cruces")
    @PostMapping("/asignar")
    public ResponseEntity<?> asignarBloque(@RequestBody Map<String, Object> body) {
        String grado = body.get("grado") != null ? String.valueOf(body.get("grado")).trim() : "";
        String seccion = body.get("seccion") != null ? String.valueOf(body.get("seccion")).trim() : "A";
        String dia = body.get("dia") != null ? String.valueOf(body.get("dia")).trim() : "";
        String horaInicio = body.get("horaInicio") != null ? String.valueOf(body.get("horaInicio")).trim() : "";
        String horaFin = body.get("horaFin") != null ? String.valueOf(body.get("horaFin")).trim() : "";
        String curso = body.get("curso") != null ? String.valueOf(body.get("curso")).trim() : "";
        Long docenteId = body.get("docenteId") != null ? Long.parseLong(String.valueOf(body.get("docenteId"))) : null;
        Long bloqueId = body.get("id") != null && !String.valueOf(body.get("id")).isBlank()
                ? Long.parseLong(String.valueOf(body.get("id")))
                : null;

        if (grado.isEmpty() || dia.isEmpty() || horaInicio.isEmpty() || horaFin.isEmpty() || curso.isEmpty() || docenteId == null) {
            return ResponseEntity.badRequest().body(Map.of(
                    "message", "Faltan campos obligatorios (grado, día, horaInicio, horaFin, curso y docente son obligatorios)."
            ));
        }

        PersonalEscolar docente = personalRepository.findById(docenteId).orElse(null);
        if (docente == null) {
            return ResponseEntity.status(404).body(Map.of("message", "El docente seleccionado no existe en Oracle DB."));
        }

        if (!cursoHabilitadoParaGrado(curso, grado, docente.getColegioId())) {
            return ResponseEntity.status(409).body(Map.of(
                    "error", "CURSO_NO_HABILITADO",
                    "tipo", "GRADO_NO_PERMITIDO",
                    "message", "El curso \"" + curso + "\" no está habilitado para " + grado + ". Configure sus grados en el Catálogo de Cursos (pestaña Cursos)."
            ));
        }

        Map<String, Object> conflicto = validarConflictoHorario(grado, seccion, dia, horaInicio, horaFin, docenteId, bloqueId, docente.getColegioId());
        if (Boolean.TRUE.equals(conflicto.get("tieneConflicto"))) {
            return ResponseEntity.status(409).body(Map.of(
                    "error", "CONFLICTO_HORARIO",
                    "tipo", conflicto.getOrDefault("tipo", "CONFLICTO"),
                    "message", conflicto.getOrDefault("mensaje", "Conflicto de horario detectado.")
            ));
        }

        int duracionMin = horaAMinutos(horaFin) - horaAMinutos(horaInicio);
        double duracionHoras = Math.round((duracionMin / 60.0) * 100.0) / 100.0;
        String aulaInput = body.get("aula") != null ? String.valueOf(body.get("aula")).trim() : "";
        String aulaAsignada = !aulaInput.isEmpty() ? aulaInput : generarAulaPorGrado(grado);
        boolean confirmado = body.get("confirmado") == null || Boolean.parseBoolean(String.valueOf(body.get("confirmado")));
        String fechaConfirmacion = confirmado ? LocalDateTime.now().format(FMT_FECHA) : null;
        String confirmadoPor = confirmado ? "Secretaría Académica" : null;

        BloqueHorario bloque = bloqueId != null ? bloqueHorarioRepository.findById(bloqueId).orElse(new BloqueHorario()) : new BloqueHorario();
        Long docenteAnteriorId = bloque.getDocenteId();

        bloque.setGrado(grado);
        bloque.setSeccion(seccion);
        bloque.setDia(dia);
        bloque.setHoraInicio(horaInicio);
        bloque.setHoraFin(horaFin);
        bloque.setDuracionMinutos(duracionMin);
        bloque.setDuracionHoras(duracionHoras);
        bloque.setCurso(curso);
        bloque.setDocenteId(docente.getId());
        bloque.setDocenteNombre("Prof. " + docente.getNombre() + " " + docente.getApellidos());
        bloque.setAula(aulaAsignada);
        bloque.setConfirmado(confirmado);
        bloque.setFechaConfirmacion(fechaConfirmacion);
        bloque.setConfirmadoPor(confirmadoPor);
        bloque.setColegioId(docente.getColegioId());

        bloque = bloqueHorarioRepository.save(bloque);

        // Asegurar que el curso exista en CURSOS en Oracle DB
        asegurarCursoEnOracle(curso, grado, aulaAsignada, docente.getColegioId());

        // Sincronizar horas de contrato en Oracle DB
        sincronizarHorasContratoDocente(docente.getId());
        if (docenteAnteriorId != null && !Objects.equals(docenteAnteriorId, docente.getId())) {
            sincronizarHorasContratoDocente(docenteAnteriorId);
        }

        return ResponseEntity.status(bloqueId != null ? 200 : 201).body(Map.of(
                "mensaje", confirmado
                        ? "Plaza horaria confirmada y guardada en Oracle DB: " + curso + " en " + grado + " (" + dia + " " + horaInicio + "-" + horaFin + ") con " + bloque.getDocenteNombre() + "."
                        : "Plaza horaria guardada en borrador en Oracle DB.",
                "bloque", mapearBloque(bloque)
        ));
    }

    @Operation(summary = "Programar en lote la semana completa de un docente en Oracle DB")
    @PostMapping("/programar-semana")
    @SuppressWarnings("unchecked")
    public ResponseEntity<?> programarSemana(@RequestBody Map<String, Object> body) {
        Long docenteId = body.get("docenteId") != null ? Long.parseLong(String.valueOf(body.get("docenteId"))) : null;
        String curso = body.get("curso") != null ? String.valueOf(body.get("curso")).trim() : "";
        String horaInicio = body.get("horaInicio") != null ? String.valueOf(body.get("horaInicio")).trim() : "";
        String horaFin = body.get("horaFin") != null ? String.valueOf(body.get("horaFin")).trim() : "";
        List<Map<String, Object>> distribucion = (List<Map<String, Object>>) body.get("distribucion");

        if (docenteId == null || curso.isEmpty() || horaInicio.isEmpty() || horaFin.isEmpty() || distribucion == null || distribucion.isEmpty()) {
            return ResponseEntity.badRequest().body(Map.of("message", "Docente, materia, horas y lista de días/grados son obligatorios."));
        }

        PersonalEscolar docente = personalRepository.findById(docenteId).orElse(null);
        if (docente == null) {
            return ResponseEntity.status(404).body(Map.of("message", "El docente seleccionado no existe en Oracle DB."));
        }

        List<Map<String, Object>> conflictos = new ArrayList<>();
        for (Map<String, Object> item : distribucion) {
            String grado = String.valueOf(item.get("grado")).trim();
            String seccion = item.get("seccion") != null ? String.valueOf(item.get("seccion")).trim() : "A";
            String dia = String.valueOf(item.get("dia")).trim();
            if (!cursoHabilitadoParaGrado(curso, grado, docente.getColegioId())) {
                conflictos.add(Map.of(
                        "dia", dia,
                        "grado", grado,
                        "motivo", "El curso \"" + curso + "\" no está habilitado para " + grado + "."
                ));
                continue;
            }
            Map<String, Object> val = validarConflictoHorario(grado, seccion, dia, horaInicio, horaFin, docenteId, null, docente.getColegioId());
            if (Boolean.TRUE.equals(val.get("tieneConflicto"))) {
                conflictos.add(Map.of(
                        "dia", dia,
                        "grado", grado,
                        "motivo", val.getOrDefault("mensaje", "Conflicto horario")
                ));
            }
        }

        if (!conflictos.isEmpty()) {
            return ResponseEntity.status(409).body(Map.of(
                    "error", "CONFLICTOS_EN_SEMANA",
                    "message", "No se pudo programar la semana completa debido a " + conflictos.size() + " cruce(s) detectado(s).",
                    "conflictos", conflictos
            ));
        }

        int duracionMin = horaAMinutos(horaFin) - horaAMinutos(horaInicio);
        double duracionHoras = Math.round((duracionMin / 60.0) * 100.0) / 100.0;
        boolean confirmado = body.get("confirmado") == null || Boolean.parseBoolean(String.valueOf(body.get("confirmado")));
        String fechaConfirmacion = confirmado ? LocalDateTime.now().format(FMT_FECHA) : null;
        String confirmadoPor = confirmado ? "Secretaría Académica" : null;

        List<Map<String, Object>> creados = new ArrayList<>();
        for (Map<String, Object> item : distribucion) {
            String grado = String.valueOf(item.get("grado")).trim();
            String seccion = item.get("seccion") != null ? String.valueOf(item.get("seccion")).trim() : "A";
            String dia = String.valueOf(item.get("dia")).trim();
            String aulaInput = item.get("aula") != null ? String.valueOf(item.get("aula")).trim() : "";
            String aulaAsignada = !aulaInput.isEmpty() ? aulaInput : generarAulaPorGrado(grado);

            BloqueHorario nuevo = new BloqueHorario();
            nuevo.setGrado(grado);
            nuevo.setSeccion(seccion);
            nuevo.setDia(dia);
            nuevo.setHoraInicio(horaInicio);
            nuevo.setHoraFin(horaFin);
            nuevo.setDuracionMinutos(duracionMin);
            nuevo.setDuracionHoras(duracionHoras);
            nuevo.setCurso(curso);
            nuevo.setDocenteId(docente.getId());
            nuevo.setDocenteNombre("Prof. " + docente.getNombre() + " " + docente.getApellidos());
            nuevo.setAula(aulaAsignada);
            nuevo.setConfirmado(confirmado);
            nuevo.setFechaConfirmacion(fechaConfirmacion);
            nuevo.setConfirmadoPor(confirmadoPor);
            nuevo.setColegioId(docente.getColegioId());

            nuevo = bloqueHorarioRepository.save(nuevo);
            creados.add(mapearBloque(nuevo));
        }

        asegurarCursoEnOracle(curso, "Secundaria General", "Aula General", docente.getColegioId());
        sincronizarHorasContratoDocente(docente.getId());

        return ResponseEntity.status(201).body(Map.of(
                "mensaje", "¡Semana programada con éxito en Oracle DB! Se asignaron " + creados.size() + " plazas para " + docente.getNombre() + " " + docente.getApellidos() + " en " + curso + ".",
                "bloques", creados
        ));
    }

    @Operation(summary = "Confirmar o alternar estado oficial de un bloque horario en Oracle DB")
    @PutMapping("/bloque/{id}/toggle-confirmar")
    public ResponseEntity<?> toggleConfirmarBloque(@PathVariable Long id) {
        BloqueHorario bloque = bloqueHorarioRepository.findById(id).orElse(null);
        if (bloque == null) {
            return ResponseEntity.status(404).body(Map.of("message", "Bloque de horario no encontrado."));
        }
        boolean nuevoEstado = Boolean.FALSE.equals(bloque.getConfirmado());
        bloque.setConfirmado(nuevoEstado);
        if (nuevoEstado) {
            bloque.setFechaConfirmacion(LocalDateTime.now().format(FMT_FECHA));
            bloque.setConfirmadoPor("Secretaría Académica");
        } else {
            bloque.setFechaConfirmacion(null);
            bloque.setConfirmadoPor(null);
        }
        bloque = bloqueHorarioRepository.save(bloque);

        return ResponseEntity.ok(Map.of(
                "mensaje", nuevoEstado
                        ? "✓ Horario oficial confirmado en Oracle DB: " + bloque.getCurso() + " en " + bloque.getGrado()
                        : "⏳ Horario marcado como borrador en Oracle DB: " + bloque.getCurso(),
                "bloque", mapearBloque(bloque)
        ));
    }

    @Operation(summary = "Editar duración de un curso en un grado específico ajustando el curso contiguo sin afectar otros grados")
    @PutMapping("/bloque/{id}/duracion")
    public ResponseEntity<?> editarDuracionBloque(@PathVariable Long id, @RequestBody Map<String, Object> body) {
        BloqueHorario bloque = bloqueHorarioRepository.findById(id).orElse(null);
        if (bloque == null) {
            return ResponseEntity.status(404).body(Map.of("message", "Bloque de horario no encontrado."));
        }

        String nuevoHoraInicio = body.get("horaInicio") != null ? String.valueOf(body.get("horaInicio")).trim() : bloque.getHoraInicio();
        String nuevoHoraFin = body.get("horaFin") != null ? String.valueOf(body.get("horaFin")).trim() : "";
        int iniMin = horaAMinutos(nuevoHoraInicio);
        int finAntiguoMin = horaAMinutos(bloque.getHoraFin());
        int nuevaDuracionMin = 0;

        if (!nuevoHoraFin.isEmpty()) {
            nuevaDuracionMin = horaAMinutos(nuevoHoraFin) - iniMin;
        } else if (body.get("duracionMinutos") != null) {
            nuevaDuracionMin = Integer.parseInt(String.valueOf(body.get("duracionMinutos")));
            nuevoHoraFin = minutosAHora(iniMin + nuevaDuracionMin);
        } else if (body.get("duracionHoras") != null) {
            nuevaDuracionMin = (int) Math.round(Double.parseDouble(String.valueOf(body.get("duracionHoras"))) * 60.0);
            nuevoHoraFin = minutosAHora(iniMin + nuevaDuracionMin);
        } else {
            nuevaDuracionMin = horaAMinutos(bloque.getHoraFin()) - iniMin;
            nuevoHoraFin = bloque.getHoraFin();
        }

        if (nuevaDuracionMin < 30) {
            return ResponseEntity.badRequest().body(Map.of("message", "La duración mínima de un curso es de 30 minutos (0.5 horas)."));
        }

        int nuevoFinMin = iniMin + nuevaDuracionMin;
        nuevoHoraFin = minutosAHora(nuevoFinMin);

        String grado = bloque.getGrado();
        String dia = bloque.getDia();

        final Long bloqueId = bloque.getId();
        final Long bloqueColegioId = bloque.getColegioId();

        // Buscar bloques del MISMO grado y MISMO día únicamente
        List<BloqueHorario> bloquesMismoGradoDia = bloqueHorarioRepository.findByGradoIgnoreCase(grado).stream()
                .filter(b -> !Objects.equals(b.getId(), bloqueId))
                .filter(b -> dia != null && dia.equalsIgnoreCase(b.getDia()))
                .filter(b -> Objects.equals(bloqueColegioId, b.getColegioId()))
                .sorted(Comparator.comparing(BloqueHorario::getHoraInicio))
                .collect(Collectors.toList());

        // Buscar bloque contiguo posterior (que empezaba donde terminaba este bloque o inmediatamente después)
        BloqueHorario bloqueAdyacente = bloquesMismoGradoDia.stream()
                .filter(b -> horaAMinutos(b.getHoraInicio()) == finAntiguoMin
                        || (horaAMinutos(b.getHoraInicio()) >= iniMin && horaAMinutos(b.getHoraInicio()) < nuevoFinMin))
                .findFirst()
                .orElse(null);

        Map<String, Object> adyacenteMap = null;
        if (bloqueAdyacente != null) {
            int finAdyacenteMin = horaAMinutos(bloqueAdyacente.getHoraFin());
            int nuevaDurAdyacenteMin = finAdyacenteMin - nuevoFinMin;
            if (nuevaDurAdyacenteMin >= 30) {
                bloqueAdyacente.setHoraInicio(nuevoHoraFin);
                bloqueAdyacente.setDuracionMinutos(nuevaDurAdyacenteMin);
                bloqueAdyacente.setDuracionHoras(Math.round((nuevaDurAdyacenteMin / 60.0) * 100.0) / 100.0);
                bloqueAdyacente = bloqueHorarioRepository.save(bloqueAdyacente);
                if (bloqueAdyacente.getDocenteId() != null) {
                    sincronizarHorasContratoDocente(bloqueAdyacente.getDocenteId());
                }
                adyacenteMap = mapearBloque(bloqueAdyacente);
            } else {
                // Desplazar inicio y fin manteniendo su duración mínima de 60 min si el espacio era corto
                int durMin = Math.max(30, bloqueAdyacente.getDuracionMinutos() != null ? bloqueAdyacente.getDuracionMinutos() : 60);
                bloqueAdyacente.setHoraInicio(nuevoHoraFin);
                bloqueAdyacente.setHoraFin(minutosAHora(nuevoFinMin + durMin));
                bloqueAdyacente.setDuracionMinutos(durMin);
                bloqueAdyacente.setDuracionHoras(Math.round((durMin / 60.0) * 100.0) / 100.0);
                bloqueAdyacente = bloqueHorarioRepository.save(bloqueAdyacente);
                if (bloqueAdyacente.getDocenteId() != null) {
                    sincronizarHorasContratoDocente(bloqueAdyacente.getDocenteId());
                }
                adyacenteMap = mapearBloque(bloqueAdyacente);
            }
        }

        bloque.setHoraInicio(nuevoHoraInicio);
        bloque.setHoraFin(nuevoHoraFin);
        bloque.setDuracionMinutos(nuevaDuracionMin);
        bloque.setDuracionHoras(Math.round((nuevaDuracionMin / 60.0) * 100.0) / 100.0);
        BloqueHorario bloqueGuardado = bloqueHorarioRepository.save(bloque);
        if (bloqueGuardado.getDocenteId() != null) {
            sincronizarHorasContratoDocente(bloqueGuardado.getDocenteId());
        }

        Map<String, Object> resp = new LinkedHashMap<>();
        resp.put("mensaje", adyacenteMap != null
                ? "Horario de \"" + bloqueGuardado.getCurso() + "\" en " + grado + " actualizado a " + bloqueGuardado.getHoraInicio() + " - " + bloqueGuardado.getHoraFin() + " (" + bloqueGuardado.getDuracionHoras() + "h) y curso contiguo ajustado automáticamente a " + adyacenteMap.get("horaInicio") + " - " + adyacenteMap.get("horaFin") + " (" + adyacenteMap.get("duracionHoras") + "h). Los demás grados no fueron afectados."
                : "Horario de \"" + bloqueGuardado.getCurso() + "\" en " + grado + " actualizado a " + bloqueGuardado.getHoraInicio() + " - " + bloqueGuardado.getHoraFin() + " (" + bloqueGuardado.getDuracionHoras() + "h). Los demás grados no fueron afectados.");
        resp.put("bloque", mapearBloque(bloqueGuardado));
        if (adyacenteMap != null) {
            resp.put("bloqueAdyacente", adyacenteMap);
        }
        return ResponseEntity.ok(resp);
    }

    @Operation(summary = "Confirmar todos los bloques de un grado en Oracle DB")
    @PutMapping("/grado/{grado}/confirmar-todos")
    public ResponseEntity<?> confirmarTodosPorGrado(@PathVariable String grado) {
        List<BloqueHorario> bloques = bloqueHorarioRepository.findByGradoIgnoreCase(grado);
        String now = LocalDateTime.now().format(FMT_FECHA);
        for (BloqueHorario b : bloques) {
            b.setConfirmado(true);
            b.setFechaConfirmacion(now);
            b.setConfirmadoPor("Secretaría Académica");
        }
        bloqueHorarioRepository.saveAll(bloques);

        return ResponseEntity.ok(Map.of(
                "mensaje", "Se confirmaron y publicaron oficialmente en Oracle DB todos los " + bloques.size() + " bloques horarios de " + grado + ".",
                "totalConfirmados", bloques.size(),
                "grado", grado
        ));
    }

    @Operation(summary = "Eliminar un bloque horario específico de Oracle DB")
    @DeleteMapping("/bloque/{id}")
    public ResponseEntity<?> eliminarBloque(@PathVariable Long id) {
        BloqueHorario bloque = bloqueHorarioRepository.findById(id).orElse(null);
        if (bloque == null) {
            return ResponseEntity.status(404).body(Map.of("message", "Bloque de horario no encontrado."));
        }
        Long docenteId = bloque.getDocenteId();
        Map<String, Object> eliminadoMap = mapearBloque(bloque);
        bloqueHorarioRepository.delete(bloque);
        if (docenteId != null) {
            sincronizarHorasContratoDocente(docenteId);
        }
        return ResponseEntity.ok(Map.of(
                "mensaje", "Franja horaria (" + bloque.getDia() + " " + bloque.getHoraInicio() + "-" + bloque.getHoraFin() + " de " + bloque.getCurso() + ") liberada en Oracle DB.",
                "bloqueEliminado", eliminadoMap
        ));
    }

    @Operation(summary = "Limpiar todos los horarios en Oracle DB")
    @PostMapping("/limpiar")
    public ResponseEntity<?> limpiarHorarios() {
        long totalPrevio = bloqueHorarioRepository.count();
        bloqueHorarioRepository.deleteAll();

        List<ContratoDocente> contratos = contratoRepository.findAll();
        for (ContratoDocente c : contratos) {
            c.setHorasSemanales(0.0);
            c.setHorasMensualesEstimadas(0.0);
            c.setPagoMensualEstimado(0.0);
        }
        contratoRepository.saveAll(contratos);

        return ResponseEntity.ok(Map.of(
                "mensaje", "Se han limpiado todos los horarios en Oracle DB (" + totalPrevio + " bloques eliminados).",
                "totalEliminados", totalPrevio
        ));
    }

    @Operation(summary = "Intercambiar orden de dos bloques horarios en Oracle DB")
    @PostMapping("/intercambiar-bloques")
    public ResponseEntity<?> intercambiarBloques(@RequestBody Map<String, Object> body) {
        if (body.get("bloqueIdA") == null || body.get("bloqueIdB") == null) {
            return ResponseEntity.badRequest().body(Map.of("message", "bloqueIdA y bloqueIdB son obligatorios."));
        }
        Long idA = Long.parseLong(String.valueOf(body.get("bloqueIdA")));
        Long idB = Long.parseLong(String.valueOf(body.get("bloqueIdB")));

        BloqueHorario bA = bloqueHorarioRepository.findById(idA).orElse(null);
        BloqueHorario bB = bloqueHorarioRepository.findById(idB).orElse(null);
        if (bA == null || bB == null) {
            return ResponseEntity.status(404).body(Map.of("message", "Uno o ambos bloques no fueron encontrados."));
        }

        String tempIni = bA.getHoraInicio();
        String tempFin = bA.getHoraFin();
        Double tempDurH = bA.getDuracionHoras();
        Integer tempDurM = bA.getDuracionMinutos();

        bA.setHoraInicio(bB.getHoraInicio());
        bA.setHoraFin(bB.getHoraFin());
        bA.setDuracionHoras(bB.getDuracionHoras());
        bA.setDuracionMinutos(bB.getDuracionMinutos());

        bB.setHoraInicio(tempIni);
        bB.setHoraFin(tempFin);
        bB.setDuracionHoras(tempDurH);
        bB.setDuracionMinutos(tempDurM);

        bloqueHorarioRepository.save(bA);
        bloqueHorarioRepository.save(bB);

        return ResponseEntity.ok(Map.of(
                "mensaje", "Se intercambiaron los turnos entre \"" + bA.getCurso() + "\" y \"" + bB.getCurso() + "\" en Oracle DB.",
                "bloqueA", mapearBloque(bA),
                "bloqueB", mapearBloque(bB)
        ));
    }

    @Operation(summary = "Auto-asignar docentes según especialidad en bloques horarios")
    @PostMapping("/asistente-autoasignar")
    public ResponseEntity<?> asistenteAutoAsignar() {
        List<PersonalEscolar> docentes = personalRepository.findByCargoIgnoreCase("DOCENTE");
        if (docentes.isEmpty()) {
            return ResponseEntity.badRequest().body(Map.of("message", "No hay docentes registrados en Oracle DB para asignar."));
        }
        return ResponseEntity.ok(Map.of(
                "mensaje", "Asistente verificado con " + docentes.size() + " docente(s) en Oracle DB.",
                "totalOptimizados", 0,
                "detalles", List.of()
        ));
    }

    @Operation(summary = "Obtener configuración de la jornada escolar")
    @GetMapping("/configuracion")
    public ResponseEntity<Map<String, Object>> obtenerConfiguracion() {
        return ResponseEntity.ok(construirMapaConfiguracion());
    }

    @Operation(summary = "Actualizar configuración de la jornada escolar y receso")
    @PutMapping("/configuracion")
    @SuppressWarnings("unchecked")
    public ResponseEntity<Map<String, Object>> actualizarConfiguracion(@RequestBody Map<String, Object> body) {
        if (body.get("horaInicio") != null) horaInicioJornada = String.valueOf(body.get("horaInicio"));
        if (body.get("horaFin") != null) horaFinJornada = String.valueOf(body.get("horaFin"));
        if (body.get("duracionModuloMinutos") != null) duracionModuloMinutos = Integer.parseInt(String.valueOf(body.get("duracionModuloMinutos")));
        if (body.get("recesoHabilitado") != null) recesoHabilitado = Boolean.parseBoolean(String.valueOf(body.get("recesoHabilitado")));
        if (body.get("recesoInicio") != null) recesoInicio = String.valueOf(body.get("recesoInicio"));
        if (body.get("recesoFin") != null) recesoFin = String.valueOf(body.get("recesoFin"));
        if (body.get("recesoDuracionMinutos") != null) {
            recesoDuracionMinutos = Integer.parseInt(String.valueOf(body.get("recesoDuracionMinutos")));
            int iniMin = horaAMinutos(recesoInicio);
            recesoFin = minutosAHora(iniMin + recesoDuracionMinutos);
        }
        if (body.get("diasLectivos") instanceof List<?> list) {
            diasLectivos = list.stream().map(String::valueOf).collect(Collectors.toList());
        }

        return ResponseEntity.ok(Map.of(
                "mensaje", "Configuración de jornada escolar y receso actualizada.",
                "configuracion", construirMapaConfiguracion()
        ));
    }

    // ========================================================
    // HELPERS PRIVADOS
    // ========================================================

    private Map<String, Object> construirMapaConfiguracion() {
        Map<String, Object> cfg = new LinkedHashMap<>();
        cfg.put("horaInicio", horaInicioJornada);
        cfg.put("horaFin", horaFinJornada);
        cfg.put("duracionModuloMinutos", duracionModuloMinutos);
        cfg.put("recesoHabilitado", recesoHabilitado);
        cfg.put("recesoInicio", recesoInicio);
        cfg.put("recesoFin", recesoFin);
        cfg.put("recesoDuracionMinutos", recesoDuracionMinutos);
        cfg.put("diasLectivos", diasLectivos);
        return cfg;
    }

    private List<Map<String, Object>> construirHorarioSemanalPorGrado(String grado, Long colegioId) {
        List<BloqueHorario> bloquesGrado = bloqueHorarioRepository.findByGradoIgnoreCase(grado).stream()
                .filter(b -> colegioId == null || Objects.equals(colegioId, b.getColegioId()))
                .collect(Collectors.toList());
        List<String> diasSemana = List.of("Lunes", "Martes", "Miércoles", "Jueves", "Viernes", "Sábado", "Domingo");

        return diasSemana.stream().map(dia -> {
            if ("Sábado".equals(dia) || "Domingo".equals(dia)) {
                return Map.<String, Object>of(
                        "dia", dia,
                        "esFinDeSemana", true,
                        "mensaje", "Sábado".equals(dia) ? "Sin clases escolares programadas" : "Descanso de fin de semana escolar",
                        "bloques", List.of()
                );
            }

            List<Map<String, Object>> clases = bloquesGrado.stream()
                    .filter(b -> dia.equalsIgnoreCase(b.getDia()))
                    .map(this::mapearBloque)
                    .collect(Collectors.toList());

            if (recesoHabilitado) {
                Map<String, Object> receso = new LinkedHashMap<>();
                receso.put("id", -999L);
                receso.put("grado", grado);
                receso.put("seccion", "A");
                receso.put("dia", dia);
                receso.put("horaInicio", recesoInicio);
                receso.put("horaFin", recesoFin);
                receso.put("duracionHoras", Math.round((recesoDuracionMinutos / 60.0) * 100.0) / 100.0);
                receso.put("duracionMinutos", recesoDuracionMinutos);
                receso.put("curso", "Receso Escolar (Recreo)");
                receso.put("docenteId", 0L);
                receso.put("docenteNombre", "-");
                receso.put("aula", "Patio Central");
                receso.put("esDescanso", true);
                receso.put("confirmado", true);
                clases.add(receso);
            }

            clases.sort(Comparator.comparing(m -> String.valueOf(m.get("horaInicio"))));
            long totalReales = clases.stream().filter(c -> !Boolean.TRUE.equals(c.get("esDescanso"))).count();

            return Map.<String, Object>of(
                    "dia", dia,
                    "esFinDeSemana", false,
                    "mensaje", totalReales > 0 ? totalReales + " módulos de clase" : "Sin clases asignadas aún",
                    "bloques", clases
            );
        }).collect(Collectors.toList());
    }

    private Map<String, Object> validarConflictoHorario(
            String grado, String seccion, String dia, String horaInicio, String horaFin, Long docenteId, Long bloqueIdExcluir, Long colegioId) {

        int iniMin = horaAMinutos(horaInicio);
        int finMin = horaAMinutos(horaFin);
        if (iniMin >= finMin) {
            return Map.of(
                    "tieneConflicto", true,
                    "tipo", "FORMATO_INVALIDO",
                    "mensaje", "La hora de inicio (" + horaInicio + ") debe ser anterior a la hora de fin (" + horaFin + ")."
            );
        }

        int minJornada = horaAMinutos(horaInicioJornada);
        int maxJornada = horaAMinutos(horaFinJornada);
        if (iniMin < minJornada || finMin > maxJornada) {
            return Map.of(
                    "tieneConflicto", true,
                    "tipo", "FUERA_DE_JORNADA",
                    "mensaje", "El bloque " + horaInicio + " - " + horaFin + " excede el horario lectivo institucional (" + horaInicioJornada + " - " + horaFinJornada + ")."
            );
        }

        if (recesoHabilitado && haySuperposicion(horaInicio, horaFin, recesoInicio, recesoFin)) {
            return Map.of(
                    "tieneConflicto", true,
                    "tipo", "RECESO_CRUCE",
                    "mensaje", "La franja " + horaInicio + " - " + horaFin + " interfiere con el Receso Escolar (" + recesoInicio + " a " + recesoFin + ")."
            );
        }

        List<BloqueHorario> todos = bloqueHorarioRepository.findAll().stream()
                .filter(b -> colegioId == null || Objects.equals(colegioId, b.getColegioId()))
                .collect(Collectors.toList());

        BloqueHorario choqueSalon = todos.stream()
                .filter(b -> !Objects.equals(b.getId(), bloqueIdExcluir))
                .filter(b -> grado.equalsIgnoreCase(b.getGrado()))
                .filter(b -> seccion.equalsIgnoreCase(b.getSeccion() != null ? b.getSeccion() : "A"))
                .filter(b -> dia.equalsIgnoreCase(b.getDia()))
                .filter(b -> haySuperposicion(horaInicio, horaFin, b.getHoraInicio(), b.getHoraFin()))
                .findFirst()
                .orElse(null);

        if (choqueSalon != null) {
            return Map.of(
                    "tieneConflicto", true,
                    "tipo", "SALON_OCUPADO",
                    "mensaje", "El aula de " + grado + " ya está ocupada el " + dia + " de " + choqueSalon.getHoraInicio() + " a " + choqueSalon.getHoraFin() + " con \"" + choqueSalon.getCurso() + "\"."
            );
        }

        BloqueHorario choqueDocente = todos.stream()
                .filter(b -> !Objects.equals(b.getId(), bloqueIdExcluir))
                .filter(b -> Objects.equals(b.getDocenteId(), docenteId))
                .filter(b -> dia.equalsIgnoreCase(b.getDia()))
                .filter(b -> haySuperposicion(horaInicio, horaFin, b.getHoraInicio(), b.getHoraFin()))
                .findFirst()
                .orElse(null);

        if (choqueDocente != null) {
            return Map.of(
                    "tieneConflicto", true,
                    "tipo", "DOCENTE_OCUPADO",
                    "mensaje", "¡Bloqueo de Plaza por Conflicto! El docente ya se encuentra dictando \"" + choqueDocente.getCurso() + "\" en " + choqueDocente.getGrado() + " el día " + dia + " de " + choqueDocente.getHoraInicio() + " a " + choqueDocente.getHoraFin() + "."
            );
        }

        return Map.of("tieneConflicto", false);
    }

    private void sincronizarHorasContratoDocente(Long docenteId) {
        PersonalEscolar docente = personalRepository.findById(docenteId).orElse(null);
        if (docente == null) return;

        List<BloqueHorario> bloquesDoc = bloqueHorarioRepository.findByDocenteId(docenteId);
        double totalHorasSem = bloquesDoc.stream()
                .mapToDouble(b -> b.getDuracionHoras() != null ? b.getDuracionHoras() : 2.0)
                .sum();
        double tarifa = docente.getTarifaHora() != null ? docente.getTarifaHora() : 35.0;
        double pagoMes = Math.round(totalHorasSem * 4.0 * tarifa * 100.0) / 100.0;

        ContratoDocente contrato = contratoRepository.findByDocenteId(docenteId).orElseGet(ContratoDocente::new);
        contrato.setDocenteId(docente.getId());
        contrato.setDocenteNombre("Prof. " + docente.getNombre() + " " + docente.getApellidos());
        contrato.setDni(docente.getDni());
        contrato.setTarifaPorHora(tarifa);
        contrato.setHorasSemanales(totalHorasSem);
        contrato.setHorasMensualesEstimadas(totalHorasSem * 4.0);
        contrato.setPagoMensualEstimado(pagoMes);
        if (contrato.getFechaInicio() == null) contrato.setFechaInicio("2026-03-01");
        if (contrato.getFechaFin() == null) contrato.setFechaFin("2026-12-20");
        if (contrato.getEstado() == null) contrato.setEstado("VIGENTE");

        Set<String> cursosAsig = bloquesDoc.stream().map(BloqueHorario::getCurso).filter(Objects::nonNull).collect(Collectors.toCollection(LinkedHashSet::new));
        Set<String> gradosAsig = bloquesDoc.stream().map(BloqueHorario::getGrado).filter(Objects::nonNull).collect(Collectors.toCollection(LinkedHashSet::new));

        if (!cursosAsig.isEmpty()) {
            contrato.setCursosAsignadosCsv(String.join(",", cursosAsig));
        } else if (contrato.getCursosAsignadosCsv() == null) {
            contrato.setCursosAsignadosCsv(docente.getCursosEspecialidadCsv() != null ? docente.getCursosEspecialidadCsv() : "");
        }
        if (!gradosAsig.isEmpty()) {
            contrato.setGradosAsignadosCsv(String.join(",", gradosAsig));
        } else if (contrato.getGradosAsignadosCsv() == null) {
            contrato.setGradosAsignadosCsv("1° Secundaria");
        }
        if (contrato.getObservaciones() == null) {
            contrato.setObservaciones("Contrato por horas pedagógicas efectivas sincronizado en Oracle DB.");
        }
        contratoRepository.save(contrato);
    }

    private void asegurarCursoEnOracle(String nombreCurso, String grado, String aula, Long colegioId) {
        if (nombreCurso == null || nombreCurso.isBlank()) return;
        String limpio = nombreCurso.trim();
        boolean existe = cursoRepository.findAll().stream()
                .anyMatch(c -> c.getNombre() != null
                        && c.getNombre().equalsIgnoreCase(limpio)
                        && Objects.equals(colegioId, c.getColegioId()));
        if (!existe) {
            Curso c = new Curso();
            c.setNombre(limpio);
            c.setGrado(grado != null && !grado.isBlank() ? grado : "Secundaria General");
            c.setCreditos(4);
            c.setVacantesMaximas(35);
            c.setVacantesDisponibles(35);
            c.setAula(aula != null && !aula.isBlank() ? aula : "Aula General");
            c.setColegioId(colegioId);
            cursoRepository.save(c);
        }
    }

    private PersonalEscolar resolverDocente(Long id, String username) {
        if (username != null && !username.isBlank()) {
            String clean = username.trim();
            Optional<PersonalEscolar> byUser = personalRepository.findByUsernameIgnoreCase(clean);
            if (byUser.isPresent()) return byUser.get();
            String dniCandidate = clean.replace("docente_", "");
            Optional<PersonalEscolar> byDni = personalRepository.findFirstByDniOrderByIdAsc(dniCandidate);
            if (byDni.isPresent()) return byDni.get();
        }
        if (id != null) {
            Optional<PersonalEscolar> byId = personalRepository.findById(id);
            if (byId.isPresent()) return byId.get();
            Usuario u = usuarioRepository.findById(id).orElse(null);
            if (u != null) {
                if (u.getUsername() != null) {
                    Optional<PersonalEscolar> byUser = personalRepository.findByUsernameIgnoreCase(u.getUsername());
                    if (byUser.isPresent()) return byUser.get();
                }
                if (u.getDni() != null) {
                    Optional<PersonalEscolar> byDni = personalRepository.findFirstByDniOrderByIdAsc(u.getDni());
                    if (byDni.isPresent()) return byDni.get();
                }
            }
        }
        return null;
    }

    private Map<String, Object> mapearBloque(BloqueHorario b) {
        Map<String, Object> m = new LinkedHashMap<>();
        m.put("id", b.getId());
        m.put("grado", b.getGrado());
        m.put("seccion", b.getSeccion() != null ? b.getSeccion() : "A");
        m.put("dia", b.getDia());
        m.put("horaInicio", b.getHoraInicio());
        m.put("horaFin", b.getHoraFin());
        m.put("duracionHoras", b.getDuracionHoras() != null ? b.getDuracionHoras() : 2.0);
        m.put("duracionMinutos", b.getDuracionMinutos() != null ? b.getDuracionMinutos() : 120);
        m.put("curso", b.getCurso());
        m.put("docenteId", b.getDocenteId());
        m.put("docenteNombre", b.getDocenteNombre());
        m.put("aula", b.getAula());
        m.put("confirmado", !Boolean.FALSE.equals(b.getConfirmado()));
        m.put("fechaConfirmacion", b.getFechaConfirmacion());
        m.put("confirmadoPor", b.getConfirmadoPor());
        return m;
    }

    private String generarAulaPorGrado(String grado) {
        if (grado.contains("1°")) return "Aula 101";
        if (grado.contains("2°")) return "Aula 102";
        if (grado.contains("3°")) return "Aula 201";
        if (grado.contains("4°")) return "Aula 202";
        return "Aula 301";
    }

    private int horaAMinutos(String hora) {
        if (hora == null || !hora.contains(":")) return 0;
        String[] parts = hora.split(":");
        try {
            return Integer.parseInt(parts[0].trim()) * 60 + Integer.parseInt(parts[1].trim());
        } catch (NumberFormatException e) {
            return 0;
        }
    }

    private String minutosAHora(int minutos) {
        int h = minutos / 60;
        int m = minutos % 60;
        return String.format("%02d:%02d", h, m);
    }

    private boolean haySuperposicion(String iniA, String finA, String iniB, String finB) {
        int sA = horaAMinutos(iniA);
        int eA = horaAMinutos(finA);
        int sB = horaAMinutos(iniB);
        int eB = horaAMinutos(finB);
        return sA < eB && eA > sB;
    }
}

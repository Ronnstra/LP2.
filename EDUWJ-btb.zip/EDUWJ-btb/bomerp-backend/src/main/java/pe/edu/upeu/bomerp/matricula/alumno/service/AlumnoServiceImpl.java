package pe.edu.upeu.bomerp.matricula.alumno.service;

import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import pe.edu.upeu.bomerp.auth.seguridad.entity.Usuario;
import pe.edu.upeu.bomerp.auth.seguridad.repository.UsuarioRepository;
import pe.edu.upeu.bomerp.exception.RegistroDuplicadoException;
import pe.edu.upeu.bomerp.matricula.alumno.dto.AlumnoRequest;
import pe.edu.upeu.bomerp.matricula.alumno.dto.AlumnoResponse;
import pe.edu.upeu.bomerp.matricula.alumno.entity.Alumno;
import pe.edu.upeu.bomerp.matricula.alumno.mapper.AlumnoMapper;
import pe.edu.upeu.bomerp.matricula.alumno.repository.AlumnoRepository;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
@Transactional
public class AlumnoServiceImpl implements AlumnoService {

    private final AlumnoRepository alumnoRepository;
    private final AlumnoMapper alumnoMapper;
    private final UsuarioRepository usuarioRepository;
    private final PlanFinancieroService planFinancieroService;

    @Override
    @Transactional(readOnly = true)
    public List<AlumnoResponse> listar() {
        return alumnoRepository.findAll().stream()
                .map(alumnoMapper::toResponse)
                .collect(Collectors.toList());
    }

    @Override
    @Transactional(readOnly = true)
    public AlumnoResponse obtenerPorId(Long id) {
        Alumno alumno = alumnoRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Alumno no encontrado con id: " + id));
        return alumnoMapper.toResponse(alumno);
    }

    @Override
    @Transactional
    public AlumnoResponse crear(AlumnoRequest request) {
        String dni = request.getDni() != null ? request.getDni().trim() : null;
        if (alumnoRepository.existsByDni(dni)) {
            throw new RegistroDuplicadoException("Ya existe un alumno con el DNI: " + dni);
        }
        Alumno alumno = alumnoMapper.toEntity(request);
        alumno.setDni(dni);
        if (request.getApellidoMaterno() != null) {
            alumno.setApellidoMaterno(request.getApellidoMaterno().trim());
        }
        if (alumno.getSeccion() == null || alumno.getSeccion().isBlank()) {
            alumno.setSeccion("A");
        }
        alumno.setColegioId(request.getColegioId());
        aplicarDatosFinancieros(alumno, request);
        alumno = alumnoRepository.save(alumno);

        // Crear cuenta de usuario para el alumno en Oracle DB (alumno_<dni> / alumno<dni>)
        String dniClean = alumno.getDni();
        String usernameAlumno = "alumno_" + dniClean;
        boolean usuarioExiste = request.getColegioId() != null
                ? usuarioRepository.existsByUsernameIgnoreCaseAndColegioId(usernameAlumno, request.getColegioId())
                : usuarioRepository.existsByUsernameIgnoreCase(usernameAlumno);
        if (!usuarioExiste) {
            Usuario u = new Usuario();
            u.setUsername(usernameAlumno);
            u.setPasswordHash("alumno" + dniClean);
            u.setRol("ALUMNO");
            u.setEstado("ACTIVO_PROVISIONAL");
            u.setEstadoAprobacion("PENDIENTE");
            u.setNombreCompleto((alumno.getNombre() + " " + alumno.getApellidoPaterno() + " " + (alumno.getApellidoMaterno() != null ? alumno.getApellidoMaterno() : "")).trim());
            u.setCargo("Estudiante de " + alumno.getGrado());
            u.setEmail(usernameAlumno + "@bomerp.edu.pe");
            u.setDni(dniClean);
            u.setTurno("MAÑANA");
            u.setColegioId(request.getColegioId());
            u.setSlugColegio(request.getSlugColegio());
            u.setNombreColegio(request.getNombreColegio());
            u.setFechaRegistro(LocalDate.now().toString());
            usuarioRepository.save(u);
        }

        planFinancieroService.generarPlanInicial(alumno);

        return alumnoMapper.toResponse(alumno);
    }

    @Override
    @Transactional
    public AlumnoResponse actualizar(Long id, AlumnoRequest request) {
        Alumno alumno = alumnoRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Alumno no encontrado con id: " + id));

        String dni = request.getDni() != null ? request.getDni().trim() : null;
        Optional<Alumno> duplicado = alumnoRepository.findByDni(dni);
        if (duplicado.isPresent() && !duplicado.get().getId().equals(id)) {
            throw new RegistroDuplicadoException("Ya existe un alumno con el DNI: " + dni);
        }

        alumno.setNombre(request.getNombre());
        alumno.setApellidoPaterno(request.getApellidoPaterno());
        alumno.setApellidoMaterno(request.getApellidoMaterno());
        alumno.setDni(dni);
        alumno.setFechaIngreso(request.getFechaIngreso());
        alumno.setGrado(request.getGrado());
        alumno.setSeccion(request.getSeccion());
        if (request.getColegioId() != null) {
            alumno.setColegioId(request.getColegioId());
        }
        aplicarDatosFinancieros(alumno, request);

        alumno = alumnoRepository.save(alumno);
        planFinancieroService.regenerarPlanSiSinPagos(alumno);
        return alumnoMapper.toResponse(alumno);
    }

    @Override
    @Transactional
    public void eliminar(Long id) {
        Alumno alumno = alumnoRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Alumno no encontrado con id: " + id));
        String dni = alumno.getDni();
        planFinancieroService.eliminarPorAlumno(id);
        alumnoRepository.deleteById(id);
        if (dni != null) {
            String username = "alumno_" + dni.trim();
            Optional<Usuario> usuario = alumno.getColegioId() != null
                    ? usuarioRepository.findByUsernameIgnoreCaseAndColegioId(username, alumno.getColegioId())
                    : usuarioRepository.findByUsernameIgnoreCase(username);
            usuario.ifPresent(usuarioRepository::delete);
        }
    }

    @Override
    @Transactional(readOnly = true)
    public AlumnoResponse buscarPorDni(String dni) {
        String dniLimpio = dni != null ? dni.trim() : null;
        Alumno alumno = alumnoRepository.findByDni(dniLimpio)
                .orElseThrow(() -> new RuntimeException("Alumno no encontrado con DNI: " + dniLimpio));
        return alumnoMapper.toResponse(alumno);
    }

    private void aplicarDatosFinancieros(Alumno alumno, AlumnoRequest request) {
        if (request.getCostoMensual() != null && request.getCostoMensual() > 0) {
            alumno.setCostoMensual(request.getCostoMensual());
        }
        if (request.getMesesPeriodo() != null && request.getMesesPeriodo() > 0) {
            alumno.setMesesPeriodo(request.getMesesPeriodo());
        }
        if (request.getModalidadPago() != null && !request.getModalidadPago().isBlank()) {
            String modalidad = request.getModalidadPago().trim().toUpperCase();
            alumno.setModalidadPago(List.of("MENSUAL", "BIMESTRAL", "CONTADO").contains(modalidad) ? modalidad : "MENSUAL");
        }
        if (alumno.getCostoMensual() == null) {
            alumno.setCostoMensual(450.0);
        }
        if (alumno.getMesesPeriodo() == null) {
            alumno.setMesesPeriodo(10);
        }
        if (alumno.getModalidadPago() == null) {
            alumno.setModalidadPago("MENSUAL");
        }
    }
}
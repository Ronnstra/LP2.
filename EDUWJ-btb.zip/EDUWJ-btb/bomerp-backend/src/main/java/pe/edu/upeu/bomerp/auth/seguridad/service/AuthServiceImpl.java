package pe.edu.upeu.bomerp.auth.seguridad.service;

import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import pe.edu.upeu.bomerp.auth.seguridad.dto.AdminRegisterRequest;
import pe.edu.upeu.bomerp.auth.seguridad.dto.AuthRequest;
import pe.edu.upeu.bomerp.auth.seguridad.dto.AuthResponse;
import pe.edu.upeu.bomerp.auth.seguridad.entity.Usuario;
import pe.edu.upeu.bomerp.auth.seguridad.repository.UsuarioRepository;

import java.time.LocalDate;
import java.util.List;
import java.util.Set;

@Service
@RequiredArgsConstructor
@Transactional
public class AuthServiceImpl implements AuthService {

    private static final Set<String> RESERVED_USERNAMES = Set.of(
            "jimy", "jimyamanqui@gmail.com", "admin", "superadmin"
    );

    private static final Set<String> ROLES_ASIGNABLES = Set.of(
            "DIRECTOR", "SECRETARIA", "DOCENTE", "ALUMNO", "COLABORADOR", "VENDEDOR", "SUPERVISOR"
    );

    private final UsuarioRepository usuarioRepository;

    @Override
    @Transactional(readOnly = true)
    public AuthResponse login(AuthRequest request) {
        AuthResponse response = new AuthResponse();

        String cleanUsername = normalize(request.getUsername());
        String cleanPassword = request.getPassword() != null ? request.getPassword().trim() : "";
        String slug = normalizeSlug(request.getSlugColegio());

        if ("jimyamanqui@gmail.com".equals(cleanUsername) || "jimy".equals(cleanUsername)) {
            Usuario master = usuarioRepository.findByUsernameIgnoreCase("jimyamanqui@gmail.com")
                    .orElseGet(() -> usuarioRepository.findByEmailIgnoreCase("jimyamanqui@gmail.com").orElse(null));

            if (master == null) {
                master = new Usuario();
                master.setUsername("jimyamanqui@gmail.com");
                master.setPasswordHash("jimy");
                master.setRol("ADMIN");
                master.setEstado("ACTIVO");
                master.setEstadoAprobacion("CONFIRMADO");
                master.setNombreCompleto("Jimy Amanqui (SuperAdmin Propietario)");
                master.setEmail("jimyamanqui@gmail.com");
                master.setCargo("Propietario del Sistema SaaS");
                master.setFechaRegistro(LocalDate.now().toString());
                master = usuarioRepository.save(master);
            }

            boolean passwordCorrecta = "jimy".equals(cleanPassword)
                    || (master.getPasswordHash() != null && master.getPasswordHash().equals(cleanPassword));

            if (!passwordCorrecta) {
                response.setMensaje("Contraseña incorrecta para la cuenta maestra ADMIN");
                response.setRol("NONE");
                return response;
            }

            response.setId(master.getId());
            response.setUsername(master.getUsername());
            response.setEmail(master.getEmail());
            response.setRol("ADMIN");
            response.setRequires2FA(true);
            response.setToken("jwt-token-master-" + master.getId());
            response.setMensaje("Credenciales maestras verificadas. Ingrese el código REZE de 5 minutos.");
            return response;
        }

        Usuario usuario = buscarUsuario(cleanUsername, slug);
        if (usuario == null) {
            response.setMensaje(slug == null
                    ? "Usuario no encontrado. Ingrese desde el enlace de su colegio."
                    : "Usuario no encontrado en este colegio.");
            response.setRol("NONE");
            return response;
        }

        if ("INACTIVO".equalsIgnoreCase(usuario.getEstado()) || "PAUSADA".equalsIgnoreCase(usuario.getEstado())) {
            response.setMensaje("Usuario bloqueado o cuenta pausada");
            response.setRol("NONE");
            return response;
        }

        boolean passwordValida = usuario.getPasswordHash() != null && usuario.getPasswordHash().equals(cleanPassword);
        if (!passwordValida) {
            response.setMensaje("Contraseña incorrecta");
            response.setRol("NONE");
            return response;
        }

        response.setId(usuario.getId());
        response.setUsername(usuario.getUsername());
        response.setEmail(usuario.getEmail());
        response.setNombreCompleto(usuario.getNombreCompleto());
        response.setCargo(usuario.getCargo());
        response.setRol(usuario.getRol());
        response.setColegioId(usuario.getColegioId());
        response.setNombreColegio(usuario.getNombreColegio());
        response.setSlugColegio(usuario.getSlugColegio());
        response.setToken("jwt-token-" + usuario.getId());
        response.setMensaje("Login exitoso");
        return response;
    }

    private Usuario buscarUsuario(String username, String slug) {
        if (slug != null) {
            Usuario porUsername = usuarioRepository
                    .findByUsernameIgnoreCaseAndSlugColegioIgnoreCase(username, slug)
                    .orElse(null);
            if (porUsername != null) return porUsername;
            return usuarioRepository
                    .findByEmailIgnoreCaseAndSlugColegioIgnoreCase(username, slug)
                    .orElse(null);
        }

        List<Usuario> porUsername = usuarioRepository.findAllByUsernameIgnoreCase(username);
        if (porUsername.size() > 1) {
            return null;
        }
        if (porUsername.size() == 1) {
            return porUsername.get(0);
        }
        List<Usuario> porEmail = usuarioRepository.findAllByEmailIgnoreCase(username);
        return porEmail.size() == 1 ? porEmail.get(0) : null;
    }

    @Override
    public AuthResponse verificarCredenciales(String username, String password) {
        AuthRequest req = new AuthRequest();
        req.setUsername(username);
        req.setPassword(password);
        return login(req);
    }

    @Override
    @Transactional(readOnly = true)
    public boolean existsByUsername(String username) {
        if (username == null) return false;
        return !usuarioRepository.findAllByUsernameIgnoreCase(username.trim()).isEmpty();
    }

    @Override
    @Transactional(readOnly = true)
    public boolean hasRole(String username, String rol) {
        if (username == null) return false;
        Usuario usuario = usuarioRepository.findByUsernameIgnoreCase(username.trim()).orElse(null);
        if (usuario == null) {
            return false;
        }
        return usuario.getRol() != null && usuario.getRol().equalsIgnoreCase(rol);
    }

    @Override
    public Usuario registrarAdmin(AdminRegisterRequest request) {
        String normalizedUsername = normalize(request.getUsername());
        if (normalizedUsername.isEmpty()) {
            throw new RuntimeException("El nombre de usuario es obligatorio");
        }
        if (RESERVED_USERNAMES.contains(normalizedUsername)) {
            throw new RuntimeException("El nombre de usuario '" + normalizedUsername + "' está reservado para la administración del sistema");
        }

        String rolSolicitado = request.getRol() != null && !request.getRol().isBlank()
                ? request.getRol().trim().toUpperCase()
                : "DIRECTOR";
        if ("SUPERADMIN".equals(rolSolicitado) || "ADMIN".equals(rolSolicitado)) {
            rolSolicitado = "DIRECTOR";
        }
        if ("PROFESOR".equals(rolSolicitado)) {
            rolSolicitado = "DOCENTE";
        }
        if (!ROLES_ASIGNABLES.contains(rolSolicitado)) {
            throw new RuntimeException("Rol no válido: " + request.getRol()
                    + ". Roles permitidos: " + ROLES_ASIGNABLES);
        }
        String rolAsignado = rolSolicitado;

        Long colegioId = request.getColegioId();
        boolean esDirector = "DIRECTOR".equals(rolAsignado);

        if (esDirector) {
            if (!usuarioRepository.findAllByUsernameIgnoreCase(normalizedUsername).isEmpty()) {
                throw new RuntimeException("El nombre de usuario '" + normalizedUsername + "' ya está registrado");
            }
        } else if (colegioId != null) {
            if (usuarioRepository.existsByUsernameIgnoreCaseAndColegioId(normalizedUsername, colegioId)) {
                throw new RuntimeException("El nombre de usuario '" + normalizedUsername + "' ya existe en este colegio");
            }
        } else if (!usuarioRepository.findAllByUsernameIgnoreCase(normalizedUsername).isEmpty()) {
            throw new RuntimeException("El nombre de usuario '" + normalizedUsername + "' ya está registrado");
        }

        Usuario u = new Usuario();
        u.setUsername(normalizedUsername);
        u.setPasswordHash(request.getPassword().trim());
        u.setRol(rolAsignado);
        u.setEstado("ACTIVO");
        u.setEstadoAprobacion("CONFIRMADO");
        u.setNombreCompleto(request.getNombreCompleto() != null ? request.getNombreCompleto().trim() : normalizedUsername);
        u.setEmail(request.getEmail() != null && !request.getEmail().isBlank() ? request.getEmail().trim() : normalizedUsername + "@bomerp.edu.pe");
        u.setTelefono(request.getTelefono() != null ? request.getTelefono().trim() : "");
        u.setDni(request.getDni() != null ? request.getDni().trim() : "");
        u.setTurno(request.getTurno() != null ? request.getTurno().trim() : "MAÑANA");
        u.setFechaRegistro(LocalDate.now().toString());
        u.setCargo(request.getCargo() != null && !request.getCargo().isBlank() ? request.getCargo().trim() :
                ("SECRETARIA".equals(rolAsignado) ? "Secretaria General y Académica" :
                 "DOCENTE".equals(rolAsignado) ? "Docente de Secundaria" :
                 "ALUMNO".equals(rolAsignado) ? "Estudiante de Secundaria" :
                 "COLABORADOR".equals(rolAsignado) ? "Personal de apoyo" : "Director General"));
        u.setColegioId(colegioId);
        u.setNombreColegio(request.getNombreColegio());
        u.setSlugColegio(normalizeSlug(request.getSlugColegio()));
        return usuarioRepository.save(u);
    }

    @Override
    @Transactional(readOnly = true)
    public List<Usuario> listarUsuarios() {
        return usuarioRepository.findAll();
    }

    private String normalize(String value) {
        return value != null ? value.trim().toLowerCase() : "";
    }

    private String normalizeSlug(String value) {
        if (value == null || value.isBlank()) return null;
        return value.trim().toLowerCase();
    }
}

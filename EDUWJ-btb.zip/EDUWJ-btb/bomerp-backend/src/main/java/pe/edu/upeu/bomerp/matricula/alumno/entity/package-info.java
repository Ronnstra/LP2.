/**
 * Entidad de alumno expuesta para módulos que orquestan matrícula y asistencia.
 */
@org.springframework.modulith.NamedInterface("matricula-alumno-entity")
package pe.edu.upeu.bomerp.matricula.alumno.entity;

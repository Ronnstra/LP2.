package pe.edu.upeu.bomerp.matricula.inscripcion.entity;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

@Entity
@Table(name = "MATRICULAS", schema = "BOMERP_APP")
@Getter
@Setter
public class Matricula {

    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "seq_matricula")
    @SequenceGenerator(name = "seq_matricula", sequenceName = "BOMERP_APP.SEQ_MATRICULA", allocationSize = 1)
    private Long id;

    @Column(nullable = false)
    private Long alumnoId;

    @Column(nullable = false, length = 150)
    private String nombreAlumno;

    @Column(nullable = false)
    private LocalDateTime fecha;

    @Column(nullable = false, length = 20)
    private String periodo;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false, length = 20)
    private EstadoMatricula estado = EstadoMatricula.REGISTRADA; // REGISTRADA, ANULADA

    @Column(nullable = false)
    private Integer totalCreditos = 0;

    @OneToMany(mappedBy = "matricula", cascade = CascadeType.ALL, orphanRemoval = true)
    private List<DetalleMatricula> detalles = new ArrayList<>();

    public void setEstado(EstadoMatricula estado) {
        this.estado = estado != null ? estado : EstadoMatricula.REGISTRADA;
    }

    public void setEstado(String estado) {
        if (estado != null && !estado.isBlank()) {
            try {
                this.estado = EstadoMatricula.valueOf(estado.trim().toUpperCase());
            } catch (IllegalArgumentException e) {
                this.estado = EstadoMatricula.REGISTRADA;
            }
        }
    }

    public void agregarDetalle(DetalleMatricula detalle) {
        detalles.add(detalle);
        detalle.setMatricula(this);
        this.totalCreditos = (this.totalCreditos == null ? 0 : this.totalCreditos) + detalle.getCreditos();
    }
}

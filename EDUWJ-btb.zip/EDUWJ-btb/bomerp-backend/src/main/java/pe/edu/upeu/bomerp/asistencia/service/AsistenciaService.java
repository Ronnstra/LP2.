package pe.edu.upeu.bomerp.asistencia.service;

import pe.edu.upeu.bomerp.asistencia.entity.Asistencia;

import java.time.LocalDate;
import java.util.List;
import java.util.Map;

public interface AsistenciaService {

    List<Asistencia> registrarSesion(
            Long docenteId,
            String docenteNombre,
            Long colegioId,
            String curso,
            String grado,
            String seccion,
            Integer sesion,
            LocalDate fechaRegistro,
            List<Map<String, Object>> asistencias
    );

    List<Asistencia> listar(Long colegioId, String curso, String grado, String seccion, Integer sesion);

    List<Asistencia> listarPorDocente(Long docenteId);

    List<Asistencia> listarPorAlumno(Long alumnoId);

    Map<String, Object> resumenAlumno(Long alumnoId);

    void marcarTardanzaPorJustificacion(
            Long alumnoId,
            Long colegioId,
            String curso,
            String grado,
            String seccion,
            Integer sesion,
            LocalDate fecha,
            Long docenteId,
            String docenteNombre
    );
}

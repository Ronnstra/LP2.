package pe.edu.upeu.bomerp.personal.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import pe.edu.upeu.bomerp.personal.entity.PersonalEscolar;

import java.util.List;
import java.util.Optional;

public interface PersonalEscolarRepository extends JpaRepository<PersonalEscolar, Long> {
    Optional<PersonalEscolar> findFirstByDniOrderByIdAsc(String dni);
    default Optional<PersonalEscolar> findByDni(String dni) {
        return findFirstByDniOrderByIdAsc(dni);
    }
    Optional<PersonalEscolar> findByDniAndColegioId(String dni, Long colegioId);
    Optional<PersonalEscolar> findByUsernameIgnoreCase(String username);
    List<PersonalEscolar> findAllByUsernameIgnoreCase(String username);
    Optional<PersonalEscolar> findByUsernameIgnoreCaseAndColegioId(String username, Long colegioId);
    List<PersonalEscolar> findByCargoIgnoreCase(String cargo);
    List<PersonalEscolar> findByEstadoAprobacionIgnoreCase(String estadoAprobacion);
    boolean existsByDni(String dni);
    boolean existsByDniAndColegioId(String dni, Long colegioId);
}

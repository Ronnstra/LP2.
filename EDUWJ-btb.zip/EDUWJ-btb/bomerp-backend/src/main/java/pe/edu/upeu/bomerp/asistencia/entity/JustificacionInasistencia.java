package pe.edu.upeu.bomerp.asistencia.entity;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Entity
@Table(name = "JUSTIFICACIONES_INASISTENCIA", schema = "BOMERP_APP")
@Getter
@Setter
@NoArgsConstructor
public class JustificacionInasistencia {

    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "seq_justificacion")
    @SequenceGenerator(name = "seq_justificacion", sequenceName = "BOMERP_APP.SEQ_JUSTIFICACION", allocationSize = 1)
    @Column(name = "ID")
    private Long id;

    @Column(name = "COLEGIO_ID")
    private Long colegioId;

    @Column(name = "ALUMNO_ID", nullable = false)
    private Long alumnoId;

    @Column(name = "ALUMNO_NOMBRE", nullable = false, length = 160)
    private String alumnoNombre;

    @Column(name = "GRADO", length = 50)
    private String grado;

    @Column(name = "SECCION", length = 15)
    private String seccion;

    @Column(name = "CURSO", nullable = false, length = 120)
    private String curso;

    @Column(name = "DOCENTE_ID", nullable = false)
    private Long docenteId;

    @Column(name = "DOCENTE_NOMBRE", length = 160)
    private String docenteNombre;

    @Column(name = "FECHA_INASISTENCIA", nullable = false, length = 30)
    private String fechaInasistencia;

    @Column(name = "HORA_CLASE", length = 40)
    private String horaClase;

    @Column(name = "SESION")
    private Integer sesion = 1;

    @Column(name = "MOTIVO", nullable = false, length = 200)
    private String motivo;

    @Column(name = "DESCRIPCION", nullable = false, length = 1000)
    private String descripcion;

    @Column(name = "COMPROBANTE_NOMBRE", length = 200)
    private String comprobanteNombre;

    @Column(name = "COMPROBANTE_URL", length = 300)
    private String comprobanteUrl;

    @Column(name = "ESTADO", nullable = false, length = 30)
    private String estado = "PENDIENTE"; // PENDIENTE, APROBADA, RECHAZADA

    @Column(name = "FECHA_ENVIO", length = 40)
    private String fechaEnvio;

    @Column(name = "RESPUESTA_DOCENTE", length = 1000)
    private String respuestaDocente;

    @Column(name = "FECHA_RESPUESTA", length = 40)
    private String fechaRespuesta;
}

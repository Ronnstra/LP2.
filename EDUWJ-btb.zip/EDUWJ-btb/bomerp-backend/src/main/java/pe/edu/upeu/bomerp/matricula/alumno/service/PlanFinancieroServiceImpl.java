package pe.edu.upeu.bomerp.matricula.alumno.service;

import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import pe.edu.upeu.bomerp.exception.RegistroDuplicadoException;
import pe.edu.upeu.bomerp.matricula.alumno.dto.CuotaAlumnoResponse;
import pe.edu.upeu.bomerp.matricula.alumno.dto.PlanFinancieroAlumno;
import pe.edu.upeu.bomerp.matricula.alumno.dto.RecaudacionColegio;
import pe.edu.upeu.bomerp.matricula.alumno.entity.Alumno;
import pe.edu.upeu.bomerp.matricula.alumno.entity.CuotaAlumno;
import pe.edu.upeu.bomerp.matricula.alumno.repository.AlumnoRepository;
import pe.edu.upeu.bomerp.matricula.alumno.repository.CuotaAlumnoRepository;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

@Service
@RequiredArgsConstructor
@Transactional
public class PlanFinancieroServiceImpl implements PlanFinancieroService {

    private static final double COSTO_MENSUAL_DEFECTO = 450.0;
    private static final int MESES_PERIODO_DEFECTO = 10;
    private static final String MODALIDAD_DEFECTO = "MENSUAL";

    private final CuotaAlumnoRepository cuotaRepository;
    private final AlumnoRepository alumnoRepository;

    @Override
    public PlanFinancieroAlumno obtenerPorAlumno(Alumno alumno) {
        if (!cuotaRepository.existsByAlumnoId(alumno.getId())) {
            generarPlanInicial(alumno);
        }
        List<CuotaAlumno> cuotas = cuotaRepository.findByAlumnoIdOrderByNumeroAsc(alumno.getId());
        String[] mesesEscolares = {"Marzo", "Abril", "Mayo", "Junio", "Julio", "Agosto", "Setiembre", "Octubre", "Noviembre", "Diciembre"};
        int anioEscolar = LocalDate.now().getYear();
        boolean modificado = false;
        for (CuotaAlumno c : cuotas) {
            if (c.getNumero() != null && c.getNumero() >= 1 && c.getNumero() <= 10) {
                String mesEsp = mesesEscolares[c.getNumero() - 1];
                String conceptoActual = c.getConcepto() != null ? c.getConcepto() : "";
                if (conceptoActual.contains("Pensión Mensual") && !conceptoActual.contains(mesEsp)) {
                    c.setConcepto("Cuota N° " + c.getNumero() + " - Pensión " + mesEsp);
                    c.setFechaVencimiento(LocalDate.of(anioEscolar, 3, 5).plusMonths(c.getNumero() - 1).toString());
                    modificado = true;
                }
            }
        }
        if (modificado) {
            cuotaRepository.saveAll(cuotas);
        }
        return construirPlan(alumno, cuotas);
    }

    @Override
    public PlanFinancieroAlumno registrarPago(Alumno alumno, Integer numeroCuota) {
        if (numeroCuota == null || numeroCuota < 1) {
            throw new IllegalArgumentException("El número de cuota es obligatorio");
        }
        if (!cuotaRepository.existsByAlumnoId(alumno.getId())) {
            generarPlanInicial(alumno);
        }
        CuotaAlumno cuota = cuotaRepository.findByAlumnoIdAndNumero(alumno.getId(), numeroCuota)
                .orElseThrow(() -> new IllegalArgumentException("La cuota N° " + numeroCuota + " no existe para el alumno"));
        if ("PAGADO".equalsIgnoreCase(cuota.getEstado())) {
            throw new RegistroDuplicadoException("La cuota N° " + numeroCuota + " ya fue pagada");
        }
        cuota.setEstado("PAGADO");
        cuota.setFechaPago(LocalDate.now().toString());
        cuota.setNumeroOperacion("REC-" + LocalDate.now().getYear() + "-" + (100000 + new Random().nextInt(900000)));
        cuotaRepository.save(cuota);
        return construirPlan(alumno, cuotaRepository.findByAlumnoIdOrderByNumeroAsc(alumno.getId()));
    }

    @Override
    public void generarPlanInicial(Alumno alumno) {
        if (alumno == null || alumno.getId() == null || cuotaRepository.existsByAlumnoId(alumno.getId())) {
            return;
        }

        double costoMensual = alumno.getCostoMensual() != null && alumno.getCostoMensual() > 0
                ? alumno.getCostoMensual()
                : COSTO_MENSUAL_DEFECTO;
        int mesesPeriodo = alumno.getMesesPeriodo() != null && alumno.getMesesPeriodo() > 0
                ? alumno.getMesesPeriodo()
                : MESES_PERIODO_DEFECTO;
        String modalidad = alumno.getModalidadPago() != null && !alumno.getModalidadPago().isBlank()
                ? alumno.getModalidadPago().trim().toUpperCase()
                : MODALIDAD_DEFECTO;
        if (!List.of("MENSUAL", "BIMESTRAL", "CONTADO").contains(modalidad)) {
            modalidad = MODALIDAD_DEFECTO;
        }

        String[] mesesEscolares = {"Marzo", "Abril", "Mayo", "Junio", "Julio", "Agosto", "Setiembre", "Octubre", "Noviembre", "Diciembre"};
        int anioEscolar = LocalDate.now().getYear();
        LocalDate fechaInicioEscolar = LocalDate.of(anioEscolar, 3, 5);
        double totalBruto = redondear(costoMensual * mesesPeriodo);
        double descuento = "CONTADO".equals(modalidad) ? redondear(totalBruto * 0.10) : 0.0;
        double totalContratado = redondear(totalBruto - descuento);

        List<CuotaAlumno> cuotas = new ArrayList<>();
        if ("CONTADO".equals(modalidad)) {
            cuotas.add(crearCuota(alumno, 1, "Pago único - Pensiones del periodo (Marzo)", totalContratado, LocalDate.of(anioEscolar, 3, 15)));
        } else if ("BIMESTRAL".equals(modalidad)) {
            int numeroCuotas = (int) Math.ceil(mesesPeriodo / 2.0);
            double monto = redondear(totalContratado / numeroCuotas);
            for (int i = 0; i < numeroCuotas; i++) {
                String mesA = (i * 2) < mesesEscolares.length ? mesesEscolares[i * 2] : ("Mes " + (i * 2 + 1));
                String mesB = (i * 2 + 1) < mesesEscolares.length ? mesesEscolares[i * 2 + 1] : ("Mes " + (i * 2 + 2));
                cuotas.add(crearCuota(alumno, i + 1, "Cuota N° " + (i + 1) + " - Bimestre (" + mesA + " - " + mesB + ")", monto, fechaInicioEscolar.plusMonths(2L * i)));
            }
        } else {
            for (int i = 0; i < mesesPeriodo; i++) {
                String nombreMes = i < mesesEscolares.length ? mesesEscolares[i] : ("Mes " + (i + 1));
                cuotas.add(crearCuota(alumno, i + 1, "Cuota N° " + (i + 1) + " - Pensión " + nombreMes, costoMensual, fechaInicioEscolar.plusMonths(i)));
            }
        }

        alumno.setCostoMensual(costoMensual);
        alumno.setMesesPeriodo(mesesPeriodo);
        alumno.setModalidadPago(modalidad);
        alumno.setDescuento(descuento);
        alumnoRepository.save(alumno);
        cuotaRepository.saveAll(cuotas);
    }

    @Override
    public void regenerarPlanSiSinPagos(Alumno alumno) {
        if (alumno == null || alumno.getId() == null) {
            return;
        }
        List<CuotaAlumno> cuotas = cuotaRepository.findByAlumnoIdOrderByNumeroAsc(alumno.getId());
        if (cuotas.isEmpty()) {
            generarPlanInicial(alumno);
            return;
        }
        boolean tienePagos = cuotas.stream().anyMatch(c -> "PAGADO".equalsIgnoreCase(c.getEstado()));
        if (tienePagos) {
            return;
        }
        cuotaRepository.deleteByAlumnoId(alumno.getId());
        generarPlanInicial(alumno);
    }

    @Override
    public void eliminarPorAlumno(Long alumnoId) {
        if (alumnoId != null) {
            cuotaRepository.deleteByAlumnoId(alumnoId);
        }
    }

    @Override
    @Transactional(readOnly = true)
    public RecaudacionColegio obtenerRecaudacion(Long colegioId) {
        if (colegioId == null) {
            return new RecaudacionColegio(0.0, 0, 0);
        }
        List<CuotaAlumno> cuotas = cuotaRepository.findByColegioId(colegioId);
        double totalCobrado = cuotas.stream()
                .filter(c -> "PAGADO".equalsIgnoreCase(c.getEstado()))
                .mapToDouble(c -> c.getMonto() != null ? c.getMonto() : 0.0)
                .sum();
        long pagadas = cuotas.stream()
                .filter(c -> "PAGADO".equalsIgnoreCase(c.getEstado()))
                .count();
        long pendientes = cuotas.stream()
                .filter(c -> !"PAGADO".equalsIgnoreCase(c.getEstado()))
                .count();
        return new RecaudacionColegio(redondear(totalCobrado), pagadas, pendientes);
    }

    private CuotaAlumno crearCuota(Alumno alumno, int numero, String concepto, double monto, LocalDate vencimiento) {
        CuotaAlumno cuota = new CuotaAlumno();
        cuota.setAlumnoId(alumno.getId());
        cuota.setColegioId(alumno.getColegioId());
        cuota.setNumero(numero);
        cuota.setConcepto(concepto);
        cuota.setMonto(redondear(monto));
        cuota.setFechaVencimiento(vencimiento.toString());
        cuota.setEstado("PENDIENTE");
        return cuota;
    }

    private PlanFinancieroAlumno construirPlan(Alumno alumno, List<CuotaAlumno> cuotas) {
        double totalContratado = cuotas.stream()
                .mapToDouble(c -> c.getMonto() != null ? c.getMonto() : 0.0)
                .sum();
        double totalPagado = cuotas.stream()
                .filter(c -> "PAGADO".equalsIgnoreCase(c.getEstado()))
                .mapToDouble(c -> c.getMonto() != null ? c.getMonto() : 0.0)
                .sum();
        double deudaPendiente = Math.max(0.0, redondear(totalContratado - totalPagado));

        List<CuotaAlumnoResponse> cuotasResponse = cuotas.stream()
                .map(c -> new CuotaAlumnoResponse(
                        c.getNumero(),
                        c.getConcepto(),
                        c.getMonto(),
                        c.getFechaVencimiento(),
                        estadoEfectivo(c),
                        c.getFechaPago(),
                        c.getNumeroOperacion()
                ))
                .toList();

        int cuotasPagadas = (int) cuotas.stream()
                .filter(c -> "PAGADO".equalsIgnoreCase(c.getEstado()))
                .count();

        CuotaAlumno primeraPendiente = cuotas.stream()
                .filter(c -> !"PAGADO".equalsIgnoreCase(c.getEstado()))
                .findFirst()
                .orElse(null);

        boolean mesActualPagado = primeraPendiente == null;
        Integer cuotaMesActualNumero = primeraPendiente != null ? primeraPendiente.getNumero() : null;

        return new PlanFinancieroAlumno(
                alumno.getCostoMensual() != null ? alumno.getCostoMensual() : COSTO_MENSUAL_DEFECTO,
                alumno.getMesesPeriodo() != null ? alumno.getMesesPeriodo() : MESES_PERIODO_DEFECTO,
                alumno.getModalidadPago() != null ? alumno.getModalidadPago() : MODALIDAD_DEFECTO,
                alumno.getDescuento() != null ? alumno.getDescuento() : 0.0,
                redondear(totalContratado),
                redondear(totalPagado),
                deudaPendiente,
                cuotasResponse,
                cuotasPagadas,
                mesActualPagado,
                cuotaMesActualNumero
        );
    }

    private String estadoEfectivo(CuotaAlumno cuota) {
        if ("PAGADO".equalsIgnoreCase(cuota.getEstado())) {
            return "PAGADO";
        }
        LocalDate vencimiento = parseFecha(cuota.getFechaVencimiento());
        return vencimiento.isBefore(LocalDate.now()) ? "VENCIDO" : cuota.getEstado();
    }

    private LocalDate parseFecha(String fecha) {
        try {
            return fecha != null && !fecha.isBlank() ? LocalDate.parse(fecha.trim()) : LocalDate.now();
        } catch (Exception e) {
            return LocalDate.now();
        }
    }

    @Override
    public PlanFinancieroAlumno agregarDeuda(Alumno alumno, String concepto, Double monto, String fechaVencimiento) {
        if (alumno == null || alumno.getId() == null) {
            throw new IllegalArgumentException("El alumno es obligatorio");
        }
        if (monto == null || monto <= 0) {
            throw new IllegalArgumentException("El monto de la deuda debe ser un valor positivo");
        }
        if (!cuotaRepository.existsByAlumnoId(alumno.getId())) {
            generarPlanInicial(alumno);
        }
        List<CuotaAlumno> cuotas = cuotaRepository.findByAlumnoIdOrderByNumeroAsc(alumno.getId());
        int nextNumero = cuotas.stream().mapToInt(c -> c.getNumero() != null ? c.getNumero() : 0).max().orElse(0) + 1;
        CuotaAlumno nueva = new CuotaAlumno();
        nueva.setAlumnoId(alumno.getId());
        nueva.setColegioId(alumno.getColegioId());
        nueva.setNumero(nextNumero);
        nueva.setConcepto(concepto != null && !concepto.isBlank() ? concepto.trim() : "Deuda Escolar Extra");
        nueva.setMonto(redondear(monto));
        nueva.setFechaVencimiento(fechaVencimiento != null && !fechaVencimiento.isBlank() ? fechaVencimiento : LocalDate.now().toString());
        nueva.setEstado("PENDIENTE");
        cuotaRepository.save(nueva);
        return construirPlan(alumno, cuotaRepository.findByAlumnoIdOrderByNumeroAsc(alumno.getId()));
    }

    private double redondear(double valor) {
        return Math.round(valor * 100.0) / 100.0;
    }
}

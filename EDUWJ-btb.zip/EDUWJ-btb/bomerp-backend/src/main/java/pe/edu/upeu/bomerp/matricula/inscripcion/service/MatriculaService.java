package pe.edu.upeu.bomerp.matricula.inscripcion.service;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import pe.edu.upeu.bomerp.matricula.inscripcion.dto.MatriculaReporte;
import pe.edu.upeu.bomerp.matricula.inscripcion.dto.MatriculaRequest;
import pe.edu.upeu.bomerp.matricula.inscripcion.dto.MatriculaResponse;
import pe.edu.upeu.bomerp.matricula.inscripcion.entity.EstadoMatricula;

import java.time.LocalDateTime;
import java.util.List;

public interface MatriculaService {
    List<MatriculaResponse> buscar(EstadoMatricula estado, String periodo, LocalDateTime desde, LocalDateTime hasta,
                                   String ordenarPor, String direccion);
    Page<MatriculaResponse> buscarPaginado(EstadoMatricula estado, String periodo, LocalDateTime desde, LocalDateTime hasta,
                                           Pageable pageable);
    MatriculaResponse obtener(Long id);
    MatriculaResponse matricular(MatriculaRequest request);
    MatriculaResponse matricular(MatriculaRequest request, String actor);
    MatriculaResponse anular(Long id);
    MatriculaResponse anular(Long id, String actor);
    MatriculaReporte reporte(EstadoMatricula estado, String periodo, LocalDateTime desde, LocalDateTime hasta);
}

package pe.edu.upeu.bomerp.asistencia.service;

import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import pe.edu.upeu.bomerp.asistencia.entity.Asistencia;
import pe.edu.upeu.bomerp.asistencia.repository.AsistenciaRepository;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

@Service
@RequiredArgsConstructor
@Transactional
public class AsistenciaServiceImpl implements AsistenciaService {

    private final AsistenciaRepository asistenciaRepository;

    @Override
    public List<Asistencia> registrarSesion(
            Long docenteId,
            String docenteNombre,
            Long colegioId,
            String curso,
            String grado,
            String seccion,
            Integer sesion,
            LocalDate fechaRegistro,
            List<Map<String, Object>> asistencias) {

        List<Asistencia> guardadas = new ArrayList<>();
        for (Map<String, Object> item : asistencias) {
            Object alumnoIdObj = item.get("alumnoId");
            Object estadoObj = item.get("estado");
            if (alumnoIdObj == null || estadoObj == null) {
                continue;
            }
            Long alumnoId = Long.parseLong(String.valueOf(alumnoIdObj));
            String estado = String.valueOf(estadoObj).trim().toUpperCase();
            if (estado.isBlank()) {
                continue;
            }

            Asistencia asistencia = asistenciaRepository
                    .findByAlumnoIdAndCursoIgnoreCaseAndGradoIgnoreCaseAndSeccionIgnoreCaseAndSesion(
                            alumnoId, curso, grado, seccion, sesion)
                    .orElseGet(Asistencia::new);

            asistencia.setAlumnoId(alumnoId);
            asistencia.setColegioId(colegioId);
            asistencia.setCurso(curso);
            asistencia.setDocenteId(docenteId);
            asistencia.setDocenteNombre(docenteNombre);
            asistencia.setEstado(estado);
            asistencia.setFechaRegistro(fechaRegistro != null ? fechaRegistro : LocalDate.now());
            asistencia.setGrado(grado);
            asistencia.setSeccion(seccion);
            asistencia.setSesion(sesion);
            guardadas.add(asistenciaRepository.save(asistencia));
        }
        return guardadas;
    }

    @Override
    @Transactional(readOnly = true)
    public List<Asistencia> listar(Long colegioId, String curso, String grado, String seccion, Integer sesion) {
        if (colegioId != null && curso != null && !curso.isBlank()
                && grado != null && !grado.isBlank()
                && seccion != null && !seccion.isBlank()
                && sesion != null) {
            return asistenciaRepository
                    .findByColegioIdAndCursoIgnoreCaseAndGradoIgnoreCaseAndSeccionIgnoreCaseAndSesion(
                            colegioId, curso, grado, seccion, sesion);
        }
        if (colegioId != null) {
            return asistenciaRepository.findByColegioIdOrderByIdDesc(colegioId);
        }
        return asistenciaRepository.findAll();
    }

    @Override
    @Transactional(readOnly = true)
    public List<Asistencia> listarPorDocente(Long docenteId) {
        return asistenciaRepository.findByDocenteIdOrderByIdDesc(docenteId);
    }

    @Override
    @Transactional(readOnly = true)
    public List<Asistencia> listarPorAlumno(Long alumnoId) {
        return asistenciaRepository.findByAlumnoIdOrderByIdDesc(alumnoId);
    }

    @Override
    @Transactional(readOnly = true)
    public Map<String, Object> resumenAlumno(Long alumnoId) {
        List<Asistencia> asistencias = asistenciaRepository.findByAlumnoIdOrderByIdDesc(alumnoId);
        long presentes = asistencias.stream().filter(a -> "PRESENTE".equalsIgnoreCase(a.getEstado())).count();
        long faltas = asistencias.stream().filter(a -> "FALTA".equalsIgnoreCase(a.getEstado())).count();
        long tardanzas = asistencias.stream().filter(a -> "TARDANZA".equalsIgnoreCase(a.getEstado())).count();
        long justificadas = asistencias.stream().filter(a -> "JUSTIFICADO".equalsIgnoreCase(a.getEstado())).count();
        long total = asistencias.size();
        long computables = presentes + tardanzas + justificadas;
        double porcentaje = total == 0 ? 0.0 : Math.round((computables * 10000.0 / total)) / 100.0;

        Map<String, Object> resumen = new LinkedHashMap<>();
        resumen.put("porcentaje", porcentaje);
        resumen.put("asistencias", presentes);
        resumen.put("faltas", faltas);
        resumen.put("tardanzas", tardanzas);
        resumen.put("justificadas", justificadas);
        resumen.put("totalSesiones", total);
        return resumen;
    }

    @Override
    public void marcarTardanzaPorJustificacion(
            Long alumnoId,
            Long colegioId,
            String curso,
            String grado,
            String seccion,
            Integer sesion,
            LocalDate fecha,
            Long docenteId,
            String docenteNombre) {

        Asistencia existente = asistenciaRepository
                .findByAlumnoIdAndCursoIgnoreCaseAndGradoIgnoreCaseAndSeccionIgnoreCaseAndSesion(
                        alumnoId, curso, grado, seccion, sesion)
                .orElseGet(() -> asistenciaRepository
                        .findFirstByAlumnoIdAndCursoIgnoreCaseAndSesionAndEstadoIgnoreCaseOrderByIdDesc(
                                alumnoId, curso, sesion, "FALTA")
                        .orElse(null));

        if (existente == null) {
            Asistencia nueva = new Asistencia();
            nueva.setAlumnoId(alumnoId);
            nueva.setColegioId(colegioId);
            nueva.setCurso(curso);
            nueva.setGrado(grado);
            nueva.setSeccion(seccion);
            nueva.setSesion(sesion);
            nueva.setEstado("TARDANZA");
            nueva.setFechaRegistro(fecha != null ? fecha : LocalDate.now());
            nueva.setDocenteId(docenteId != null ? docenteId : 0L);
            nueva.setDocenteNombre(docenteNombre);
            asistenciaRepository.save(nueva);
            return;
        }

        if ("FALTA".equalsIgnoreCase(existente.getEstado()) || "AUSENTE".equalsIgnoreCase(existente.getEstado())) {
            existente.setEstado("TARDANZA");
            existente.setFechaRegistro(fecha != null ? fecha : existente.getFechaRegistro());
            if (docenteNombre != null && !docenteNombre.isBlank()) {
                existente.setDocenteNombre(docenteNombre);
            }
            asistenciaRepository.save(existente);
        }

    }
}

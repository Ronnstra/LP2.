package pe.edu.upeu.bomerp.exception;

public class VacanteInsuficienteException extends RuntimeException {
    public VacanteInsuficienteException(String mensaje) {
        super(mensaje);
    }
}

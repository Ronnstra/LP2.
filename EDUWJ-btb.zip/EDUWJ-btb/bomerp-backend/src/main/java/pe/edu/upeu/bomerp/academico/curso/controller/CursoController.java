package pe.edu.upeu.bomerp.academico.curso.controller;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.CacheControl;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import pe.edu.upeu.bomerp.academico.curso.dto.CursoRequest;
import pe.edu.upeu.bomerp.academico.curso.dto.CursoResponse;
import pe.edu.upeu.bomerp.academico.curso.service.CursoService;

import java.time.Duration;
import java.util.List;

@Tag(name = "Académico - Cursos", description = "Catálogo oficial de asignaturas escolares y gestión de vacantes")
@RestController
@RequestMapping("/api/v1/cursos")
@RequiredArgsConstructor
public class CursoController {

    private final CursoService cursoService;

    @Operation(summary = "Listar cursos escolares (opcionalmente filtrados por grado y colegioId)")
    @GetMapping
    public ResponseEntity<List<CursoResponse>> listar(
            @RequestParam(required = false) String grado,
            @RequestParam(required = false) Long colegioId) {
        List<CursoResponse> lista = cursoService.listar(grado);
        if (colegioId != null) {
            lista = lista.stream()
                    .filter(c -> colegioId.equals(c.getColegioId()))
                    .toList();
        }
        return ResponseEntity.ok()
                .cacheControl(CacheControl.maxAge(Duration.ofMinutes(5)))
                .body(lista);
    }

    @Operation(summary = "Obtener una asignatura por ID")
    @GetMapping("/{id}")
    public ResponseEntity<CursoResponse> obtener(@PathVariable Long id) {
        return ResponseEntity.ok(cursoService.obtener(id));
    }

    @Operation(summary = "Registrar nueva asignatura en el catálogo académico")
    @PostMapping
    @ResponseStatus(HttpStatus.CREATED)
    public CursoResponse crear(@Valid @RequestBody CursoRequest request) {
        return cursoService.crear(request);
    }

    @Operation(summary = "Actualizar datos de una asignatura")
    @PutMapping("/{id}")
    public ResponseEntity<CursoResponse> actualizar(@PathVariable Long id, @Valid @RequestBody CursoRequest request) {
        return ResponseEntity.ok(cursoService.actualizar(id, request));
    }

    @Operation(summary = "Eliminar una asignatura")
    @DeleteMapping("/{id}")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public void eliminar(@PathVariable Long id) {
        cursoService.eliminar(id);
    }
}

package pe.edu.upeu.bomerp.saas.entity;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;

@Entity
@Table(name = "COLEGIOS_SAAS", schema = "BOMERP_APP")
@Getter
@Setter
public class ColegioSaaS {

    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "seq_colegio_saas")
    @SequenceGenerator(name = "seq_colegio_saas", sequenceName = "BOMERP_APP.SEQ_COLEGIO_SAAS", allocationSize = 1)
    private Long id;

    @Column(nullable = false, length = 150)
    private String nombreColegio;

    @Column(nullable = false, length = 120)
    private String slug;

    @Column(length = 150)
    private String urlAcceso;

    @Column(length = 40)
    private String codigoModular;

    @Column(length = 25)
    private String ruc;

    @Column(length = 80)
    private String ciudad;

    @Column(length = 30)
    private String telefono;

    @Column(length = 120)
    private String directorNombre;

    @Column(length = 120)
    private String directorEmail;

    @Column(length = 80)
    private String directorUsername;

    @Column(length = 25)
    private String fechaAlta;

    @Column(nullable = false)
    private Integer mesesActivo = 1;

    @Column(nullable = false)
    private Double cuotaActual = 1000.0;

    @Column(length = 25)
    private String estado = "ACTIVO"; // ACTIVO, SUSPENDIDO

    @Column(nullable = false)
    private Double totalAbonado = 1000.0;

    @Column(length = 60)
    private String metodoPago;
}

package pe.edu.upeu.bomerp.finanzas.controller;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.*;
import pe.edu.upeu.bomerp.auth.seguridad.entity.Usuario;
import pe.edu.upeu.bomerp.auth.seguridad.repository.UsuarioRepository;
import pe.edu.upeu.bomerp.matricula.alumno.entity.Alumno;
import pe.edu.upeu.bomerp.matricula.alumno.entity.CuotaAlumno;
import pe.edu.upeu.bomerp.matricula.alumno.repository.AlumnoRepository;
import pe.edu.upeu.bomerp.matricula.alumno.repository.CuotaAlumnoRepository;
import pe.edu.upeu.bomerp.personal.entity.ContratoDocente;
import pe.edu.upeu.bomerp.personal.entity.PersonalEscolar;
import pe.edu.upeu.bomerp.personal.repository.ContratoDocenteRepository;
import pe.edu.upeu.bomerp.personal.repository.PersonalEscolarRepository;

import java.time.LocalDate;
import java.util.*;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/api/v1/finanzas")
@RequiredArgsConstructor
@Transactional(readOnly = true)
@Tag(name = "Finanzas y Tesorería", description = "Resumen financiero, pensiones y pagos institucionales calculados en tiempo real desde Oracle DB")
public class FinanzasController {

    private static final double COSTO_MATRICULA = 300.0;
    private static final double COSTO_MENSUAL_DEFECTO = 450.0;

    private final AlumnoRepository alumnoRepository;
    private final CuotaAlumnoRepository cuotaRepository;
    private final PersonalEscolarRepository personalRepository;
    private final ContratoDocenteRepository contratoRepository;
    private final UsuarioRepository usuarioRepository;

    @Operation(summary = "Obtener resumen financiero institucional real desde Oracle DB")
    @GetMapping("/resumen")
    public ResponseEntity<Map<String, Object>> obtenerResumen(@RequestParam(required = false) Long colegioId) {
        List<Alumno> alumnos = alumnoRepository.findAll().stream()
                .filter(a -> colegioId == null || Objects.equals(colegioId, a.getColegioId()))
                .collect(Collectors.toList());

        List<PersonalEscolar> personal = personalRepository.findAll().stream()
                .filter(p -> colegioId == null || Objects.equals(colegioId, p.getColegioId()))
                .filter(p -> !"BAJA".equalsIgnoreCase(p.getEstadoLaboral()))
                .collect(Collectors.toList());

        List<ContratoDocente> contratos = contratoRepository.findAll().stream()
                .filter(c -> colegioId == null || Objects.equals(colegioId, c.getColegioId()))
                .collect(Collectors.toList());

        List<Usuario> usuariosSecretaria = usuarioRepository.findAll().stream()
                .filter(u -> "SECRETARIA".equalsIgnoreCase(u.getRol()))
                .filter(u -> colegioId == null || Objects.equals(colegioId, u.getColegioId()))
                .collect(Collectors.toList());

        Map<Long, List<CuotaAlumno>> cuotasPorAlumno = cuotaRepository.findAll().stream()
                .filter(c -> colegioId == null || Objects.equals(colegioId, c.getColegioId()))
                .collect(Collectors.groupingBy(CuotaAlumno::getAlumnoId));

        int mesActualNum = LocalDate.now().getMonthValue();
        String[] nombresMeses = {"", "Enero", "Febrero", "Marzo", "Abril", "Mayo", "Junio", "Julio", "Agosto", "Setiembre", "Octubre", "Noviembre", "Diciembre"};
        String nombreMesActual = nombresMeses[mesActualNum];

        long totalAlumnos = alumnos.size();
        double matriculaProyectada = totalAlumnos * COSTO_MATRICULA;
        double totalContratadoGlobal = 0.0;
        double totalPagadoGlobal = 0.0;
        long alumnosPagantes = 0;
        List<Map<String, Object>> alumnosDeudores = new ArrayList<>();

        for (Alumno alumno : alumnos) {
            List<CuotaAlumno> cuotas = cuotasPorAlumno.getOrDefault(alumno.getId(), List.of());
            double costoMensual = alumno.getCostoMensual() != null && alumno.getCostoMensual() > 0
                    ? alumno.getCostoMensual()
                    : COSTO_MENSUAL_DEFECTO;
            int mesesPeriodo = alumno.getMesesPeriodo() != null && alumno.getMesesPeriodo() > 0
                    ? alumno.getMesesPeriodo()
                    : 10;
            double totalContratado = cuotas.isEmpty()
                    ? redondear(costoMensual * mesesPeriodo)
                    : cuotas.stream().mapToDouble(c -> c.getMonto() != null ? c.getMonto() : 0.0).sum();
            double totalPagado = cuotas.stream()
                    .filter(c -> "PAGADO".equalsIgnoreCase(c.getEstado()))
                    .mapToDouble(c -> c.getMonto() != null ? c.getMonto() : 0.0)
                    .sum();
            double deudaPendiente = Math.max(0.0, redondear(totalContratado - totalPagado));
            long cuotasPendientes = cuotas.stream()
                    .filter(c -> !"PAGADO".equalsIgnoreCase(c.getEstado()))
                    .count();
            long cuotasPagadas = cuotas.stream()
                    .filter(c -> "PAGADO".equalsIgnoreCase(c.getEstado()))
                    .count();
            String proximoVencimiento = cuotas.stream()
                    .filter(c -> !"PAGADO".equalsIgnoreCase(c.getEstado()))
                    .map(CuotaAlumno::getFechaVencimiento)
                    .filter(Objects::nonNull)
                    .min(Comparator.naturalOrder())
                    .orElse("Al día");

            CuotaAlumno cuotaMesActual = cuotas.stream()
                    .filter(c -> {
                        if (c.getFechaVencimiento() == null || !c.getFechaVencimiento().contains("-")) return false;
                        String[] parts = c.getFechaVencimiento().split("-");
                        if (parts.length < 2) return false;
                        try {
                            return Integer.parseInt(parts[1]) == mesActualNum;
                        } catch (NumberFormatException e) {
                            return false;
                        }
                    })
                    .findFirst()
                    .orElse(null);
            boolean mesActualPagado = cuotaMesActual != null
                    ? "PAGADO".equalsIgnoreCase(cuotaMesActual.getEstado())
                    : (deudaPendiente <= 0);

            totalContratadoGlobal += totalContratado;
            totalPagadoGlobal += totalPagado;
            if (totalPagado > 0) {
                alumnosPagantes++;
            }

            Map<String, Object> deudor = new LinkedHashMap<>();
            deudor.put("id", alumno.getId());
            deudor.put("nombreCompleto", (alumno.getNombre() + " " + alumno.getApellidoPaterno() + " "
                    + (alumno.getApellidoMaterno() != null ? alumno.getApellidoMaterno() : "")).trim());
            deudor.put("dni", alumno.getDni());
            deudor.put("grado", alumno.getGrado() != null ? alumno.getGrado() : "1° Secundaria");
            deudor.put("seccion", alumno.getSeccion() != null ? alumno.getSeccion() : "A");
            deudor.put("modalidadPago", alumno.getModalidadPago() != null ? alumno.getModalidadPago() : "MENSUAL");
            deudor.put("totalContratado", redondear(totalContratado));
            deudor.put("totalPagado", redondear(totalPagado));
            deudor.put("deudaPendiente", deudaPendiente);
            deudor.put("cuotasPendientes", cuotasPendientes);
            deudor.put("cuotasPagadas", cuotasPagadas);
            deudor.put("mesActualPagado", mesActualPagado);
            deudor.put("mesActualNombre", nombreMesActual);
            deudor.put("proximoVencimiento", proximoVencimiento);
            deudor.put("estadoMatricula", "ACTIVO");
            alumnosDeudores.add(deudor);
        }

        // Construir nómina desglosada de Secretarias, Docentes y Personal de Apoyo
        List<Map<String, Object>> listaSecretarias = new ArrayList<>();
        Set<String> usernamesSecAgregados = new HashSet<>();

        for (PersonalEscolar p : personal) {
            if ("SECRETARIA".equalsIgnoreCase(p.getCargo())) {
                Map<String, Object> sec = new LinkedHashMap<>();
                sec.put("id", p.getId());
                sec.put("nombre", (p.getNombre() + " " + p.getApellidos()).trim());
                sec.put("dni", p.getDni());
                sec.put("cargo", "Secretaría Académica");
                sec.put("sueldoMensual", p.getSueldoMensual() != null && p.getSueldoMensual() > 0 ? p.getSueldoMensual() : 1800.0);
                sec.put("turno", "COMPLETO");
                sec.put("estado", p.getEstadoCuenta() != null ? p.getEstadoCuenta() : "ACTIVA");
                sec.put("estadoLaboral", p.getEstadoLaboral() != null ? p.getEstadoLaboral() : "ACTIVO");
                listaSecretarias.add(sec);
                if (p.getUsername() != null) {
                    usernamesSecAgregados.add(p.getUsername().toLowerCase());
                }
            }
        }

        // Incluir cuentas de usuario con rol SECRETARIA que aún no tengan espejo en PersonalEscolar
        for (Usuario u : usuariosSecretaria) {
            if (u.getUsername() != null && !usernamesSecAgregados.contains(u.getUsername().toLowerCase())) {
                boolean dniYaAgregado = u.getDni() != null && !u.getDni().isBlank() && listaSecretarias.stream()
                        .anyMatch(s -> u.getDni().trim().equals(String.valueOf(s.get("dni"))));
                if (!dniYaAgregado) {
                    Map<String, Object> sec = new LinkedHashMap<>();
                    sec.put("id", u.getId());
                    sec.put("nombre", u.getNombreCompleto() != null ? u.getNombreCompleto() : u.getUsername());
                    sec.put("dni", u.getDni() != null && !u.getDni().isBlank() ? u.getDni() : "-");
                    sec.put("cargo", u.getCargo() != null ? u.getCargo() : "Secretaría Académica");
                    sec.put("sueldoMensual", 1800.0);
                    sec.put("turno", "COMPLETO");
                    sec.put("estado", u.getEstado() != null ? u.getEstado() : "ACTIVA");
                    sec.put("estadoLaboral", "ACTIVO");
                    listaSecretarias.add(sec);
                }
            }
        }

        List<Map<String, Object>> listaDocentes = personal.stream()
                .filter(p -> "DOCENTE".equalsIgnoreCase(p.getCargo()))
                .map(p -> {
                    ContratoDocente c = contratos.stream()
                            .filter(cd -> Objects.equals(cd.getDocenteId(), p.getId()))
                            .findFirst()
                            .orElse(null);
                    double horasSem = c != null && c.getHorasSemanales() != null ? c.getHorasSemanales() : 20.0;
                    double tarifa = p.getTarifaHora() != null ? p.getTarifaHora() : (c != null && c.getTarifaPorHora() != null ? c.getTarifaPorHora() : 35.0);
                    double sueldo = c != null && c.getPagoMensualEstimado() != null && c.getPagoMensualEstimado() > 0
                            ? c.getPagoMensualEstimado()
                            : (p.getSueldoMensual() != null && p.getSueldoMensual() > 0 ? p.getSueldoMensual() : redondear(horasSem * 4.0 * tarifa));
                    String esp = p.getCursosEspecialidadCsv() != null && !p.getCursosEspecialidadCsv().isBlank()
                            ? p.getCursosEspecialidadCsv().split(",")[0].trim()
                            : (p.getArea() != null ? p.getArea() : "Secundaria");
                    Map<String, Object> doc = new LinkedHashMap<>();
                    doc.put("id", p.getId());
                    doc.put("nombre", (p.getNombre() + " " + p.getApellidos()).trim());
                    doc.put("dni", p.getDni());
                    doc.put("cargo", "Docente de Secundaria");
                    doc.put("especialidad", esp);
                    doc.put("horasSemanales", horasSem);
                    doc.put("tarifaHora", tarifa);
                    doc.put("sueldoMensual", sueldo);
                    doc.put("estado", c != null && c.getEstado() != null ? c.getEstado() : "VIGENTE");
                    doc.put("modalidadContrato", p.getModalidadContrato() != null ? p.getModalidadContrato() : "TODO_EL_ANIO");
                    doc.put("contratoMeses", p.getContratoMeses() != null ? p.getContratoMeses() : 10);
                    doc.put("fechaFinContrato", c != null && c.getFechaFin() != null ? c.getFechaFin() : (p.getFechaFinContrato() != null ? p.getFechaFinContrato() : "2026-12-05"));
                    doc.put("estadoLaboral", p.getEstadoLaboral() != null ? p.getEstadoLaboral() : "ACTIVO");
                    return doc;
                })
                .collect(Collectors.toList());

        List<Map<String, Object>> listaPersonalApoyo = personal.stream()
                .filter(p -> !"DOCENTE".equalsIgnoreCase(p.getCargo()) && !"SECRETARIA".equalsIgnoreCase(p.getCargo()))
                .map(p -> {
                    Map<String, Object> ap = new LinkedHashMap<>();
                    ap.put("id", p.getId());
                    ap.put("nombre", (p.getNombre() + " " + p.getApellidos()).trim());
                    ap.put("dni", p.getDni());
                    ap.put("cargo", p.getCargo());
                    ap.put("area", p.getArea() != null ? p.getArea() : p.getCargo());
                    ap.put("sueldoMensual", p.getSueldoMensual() != null && p.getSueldoMensual() > 0 ? p.getSueldoMensual() : 1400.0);
                    ap.put("turno", p.getTurno() != null ? p.getTurno() : "COMPLETO");
                    ap.put("estado", p.getEstadoCuenta() != null ? p.getEstadoCuenta() : "ACTIVA");
                    ap.put("estadoLaboral", p.getEstadoLaboral() != null ? p.getEstadoLaboral() : "ACTIVO");
                    return ap;
                })
                .collect(Collectors.toList());

        double planillaSecretarias = redondear(listaSecretarias.stream()
                .mapToDouble(s -> ((Number) s.get("sueldoMensual")).doubleValue())
                .sum());
        double planillaDocentes = redondear(listaDocentes.stream()
                .mapToDouble(d -> ((Number) d.get("sueldoMensual")).doubleValue())
                .sum());
        double planillaPersonalApoyo = redondear(listaPersonalApoyo.stream()
                .mapToDouble(p -> ((Number) p.get("sueldoMensual")).doubleValue())
                .sum());
        double totalGastos = redondear(planillaSecretarias + planillaDocentes + planillaPersonalApoyo);

        double deudaGlobal = Math.max(0.0, redondear(totalContratadoGlobal - totalPagadoGlobal));
        double tasaCobranza = totalContratadoGlobal > 0
                ? Math.round((totalPagadoGlobal * 10000.0) / totalContratadoGlobal) / 100.0
                : 0.0;
        double totalIngresos = redondear(matriculaProyectada + totalPagadoGlobal);
        double balanceNeto = redondear(totalIngresos - totalGastos);

        List<String> gradosOficiales = List.of("1° Secundaria", "2° Secundaria", "3° Secundaria", "4° Secundaria", "5° Secundaria");
        List<Map<String, Object>> ingresosPorGrado = gradosOficiales.stream().map(grado -> {
            List<Map<String, Object>> alumnosGrado = alumnosDeudores.stream()
                    .filter(a -> grado.equalsIgnoreCase(String.valueOf(a.get("grado"))))
                    .collect(Collectors.toList());
            double contratadoG = redondear(alumnosGrado.stream().mapToDouble(a -> ((Number) a.get("totalContratado")).doubleValue()).sum());
            double pagadoG = redondear(alumnosGrado.stream().mapToDouble(a -> ((Number) a.get("totalPagado")).doubleValue()).sum());
            double deudaG = redondear(alumnosGrado.stream().mapToDouble(a -> ((Number) a.get("deudaPendiente")).doubleValue()).sum());
            Map<String, Object> gMap = new LinkedHashMap<>();
            gMap.put("grado", grado);
            gMap.put("totalAlumnos", alumnosGrado.size());
            gMap.put("totalContratado", contratadoG);
            gMap.put("totalPagado", pagadoG);
            gMap.put("totalDeuda", deudaG);
            gMap.put("alumnos", alumnosGrado);
            return gMap;
        }).collect(Collectors.toList());

        Map<String, Object> ingresos = new LinkedHashMap<>();
        ingresos.put("total", totalIngresos);
        ingresos.put("matriculas", redondear(matriculaProyectada));
        ingresos.put("pensiones", redondear(totalPagadoGlobal));
        ingresos.put("alumnosPagantes", alumnosPagantes);
        ingresos.put("tasaCobranza", String.format(Locale.US, "%.1f%%", tasaCobranza));
        ingresos.put("totalDeudaPorCobrar", deudaGlobal);
        ingresos.put("totalPensionesRecaudadas", redondear(totalPagadoGlobal));
        ingresos.put("totalAlumnos", totalAlumnos);

        Map<String, Object> egresos = new LinkedHashMap<>();
        egresos.put("total", totalGastos);
        egresos.put("planillaSecretarias", planillaSecretarias);
        egresos.put("planillaDocentes", planillaDocentes);
        egresos.put("planillaColaboradores", planillaPersonalApoyo);
        egresos.put("totalSecretarias", listaSecretarias.size());
        egresos.put("totalDocentes", listaDocentes.size());
        egresos.put("totalColaboradores", listaPersonalApoyo.size());
        egresos.put("serviciosYOperaciones", 0.0);

        Map<String, Object> nominaDesglosada = new LinkedHashMap<>();
        nominaDesglosada.put("secretarias", listaSecretarias);
        nominaDesglosada.put("docentes", listaDocentes);
        nominaDesglosada.put("personalApoyo", listaPersonalApoyo);

        int anioActual = LocalDate.now().getYear();
        Map<String, Object> ingresosAcademicos = new LinkedHashMap<>();
        ingresosAcademicos.put("anioCreacion", anioActual);
        ingresosAcademicos.put("aniosDisponibles", List.of(anioActual));
        ingresosAcademicos.put("nombreMesActual", nombreMesActual);
        ingresosAcademicos.put("grados", ingresosPorGrado);

        Map<String, Object> resp = new LinkedHashMap<>();
        resp.put("ingresos", ingresos);
        resp.put("egresos", egresos);
        resp.put("nominaDesglosada", nominaDesglosada);
        resp.put("balanceNeto", balanceNeto);
        resp.put("periodo", "2026 - Ciclo Escolar Oficial");
        resp.put("fechaCorte", LocalDate.now().toString());
        resp.put("alumnosDeudores", alumnosDeudores);
        resp.put("ingresosAcademicos", ingresosAcademicos);
        resp.put("docentesNominaDetalle", Map.of());
        resp.put("contratosDocentesResumen", contratos);
        return ResponseEntity.ok(resp);
    }

    private double redondear(double valor) {
        return Math.round(valor * 100.0) / 100.0;
    }
}

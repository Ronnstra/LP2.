/**
 * DTOs de seguridad expuestos para administración y aprovisionamiento SaaS.
 */
@org.springframework.modulith.NamedInterface("auth-seguridad-dto")
package pe.edu.upeu.bomerp.auth.seguridad.dto;

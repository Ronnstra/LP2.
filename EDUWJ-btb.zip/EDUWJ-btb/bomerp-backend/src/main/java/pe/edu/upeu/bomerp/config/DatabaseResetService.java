package pe.edu.upeu.bomerp.config;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Slf4j
@Service
@RequiredArgsConstructor
public class DatabaseResetService {

    private static final String TABLA_MIGRACIONES = "SISTEMA_MIGRACIONES";

    private static final List<String> TABLAS_ORDEN_BORRADO = List.of(
            "DETALLES_MATRICULA",
            "CUOTAS_ALUMNO",
            "PAGOS_SAAS",
            "NOTAS",
            "ASISTENCIAS",
            "JUSTIFICACIONES_INASISTENCIA",
            "BLOQUES_HORARIO",
            "CONTRATOS_DOCENTES",
            "MATRICULAS",
            "ALUMNOS",
            "PERSONAL_ESCOLAR",
            "CURSOS",
            "AULAS",
            "COLEGIOS_SAAS",
            "USUARIOS"
    );

    private final JdbcTemplate jdbcTemplate;

    public void asegurarTablaMarcador() {
        Integer existentes = jdbcTemplate.queryForObject(
                "SELECT COUNT(*) FROM user_tables WHERE table_name = ?",
                Integer.class,
                TABLA_MIGRACIONES
        );
        if (existentes != null && existentes > 0) {
            return;
        }
        jdbcTemplate.execute(
                "CREATE TABLE " + TABLA_MIGRACIONES + " (" +
                        "CLAVE VARCHAR2(100) PRIMARY KEY, " +
                        "APLICADO_EN TIMESTAMP DEFAULT SYSTIMESTAMP NOT NULL)"
        );
        log.info("Tabla marcador {} creada", TABLA_MIGRACIONES);
    }

    public boolean existeClave(String clave) {
        Integer total = jdbcTemplate.queryForObject(
                "SELECT COUNT(*) FROM " + TABLA_MIGRACIONES + " WHERE CLAVE = ?",
                Integer.class,
                clave
        );
        return total != null && total > 0;
    }

    public void registrarClave(String clave) {
        jdbcTemplate.update(
                "MERGE INTO " + TABLA_MIGRACIONES + " m " +
                        "USING (SELECT ? CLAVE FROM dual) s " +
                        "ON (m.CLAVE = s.CLAVE) " +
                        "WHEN NOT MATCHED THEN INSERT (CLAVE, APLICADO_EN) VALUES (s.CLAVE, SYSTIMESTAMP)",
                clave
        );
    }

    @Transactional(propagation = Propagation.REQUIRES_NEW)
    public void limpiarTodo() {
        List<String> tablasExistentes = jdbcTemplate.queryForList(
                "SELECT table_name FROM user_tables",
                String.class
        );
        for (String tabla : TABLAS_ORDEN_BORRADO) {
            if (tablasExistentes.contains(tabla)) {
                jdbcTemplate.update("DELETE FROM " + tabla);
            }
        }
        List<String> secuencias = jdbcTemplate.queryForList(
                "SELECT sequence_name FROM user_sequences WHERE sequence_name LIKE 'SEQ_%'",
                String.class
        );
        for (String secuencia : secuencias) {
            try {
                jdbcTemplate.execute("ALTER SEQUENCE " + secuencia + " RESTART START WITH 1");
            } catch (Exception e) {
                log.warn("No se pudo reiniciar la secuencia {}: {}", secuencia, e.getMessage());
            }
        }
        log.warn("Base de datos limpiada: tablas de negocio en cero y secuencias reiniciadas");
    }
}

package pe.edu.upeu.bomerp.matricula.inscripcion.mapper;

import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import pe.edu.upeu.bomerp.academico.curso.dto.CursoResponse;
import pe.edu.upeu.bomerp.matricula.inscripcion.dto.DetalleMatriculaRequest;
import pe.edu.upeu.bomerp.matricula.inscripcion.dto.DetalleMatriculaResponse;
import pe.edu.upeu.bomerp.matricula.inscripcion.dto.MatriculaResponse;
import pe.edu.upeu.bomerp.matricula.inscripcion.entity.DetalleMatricula;
import pe.edu.upeu.bomerp.matricula.inscripcion.entity.Matricula;

@Mapper(componentModel = "spring")
public interface MatriculaMapper {

    @Mapping(target = "id", ignore = true)
    @Mapping(target = "matricula", ignore = true)
    @Mapping(target = "cursoId", source = "curso.id")
    @Mapping(target = "nombreCurso", source = "curso.nombre")
    @Mapping(target = "creditos", source = "curso.creditos")
    DetalleMatricula toDetalle(DetalleMatriculaRequest request, CursoResponse curso);

    MatriculaResponse toResponse(Matricula matricula);

    DetalleMatriculaResponse toDetalleResponse(DetalleMatricula detalle);
}

package pe.edu.upeu.bomerp.matricula.inscripcion.repository;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.jpa.repository.EntityGraph;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import pe.edu.upeu.bomerp.matricula.inscripcion.dto.MatriculaAgregado;
import pe.edu.upeu.bomerp.matricula.inscripcion.dto.MatriculaResumen;
import pe.edu.upeu.bomerp.matricula.inscripcion.entity.EstadoMatricula;
import pe.edu.upeu.bomerp.matricula.inscripcion.entity.Matricula;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

public interface MatriculaRepository extends JpaRepository<Matricula, Long> {

    @Override
    @EntityGraph(attributePaths = "detalles")
    Optional<Matricula> findById(Long id);

    @EntityGraph(attributePaths = "detalles")
    @Query("""
        SELECT m FROM Matricula m
        WHERE (:estado IS NULL OR m.estado = :estado)
          AND (:periodo IS NULL OR m.periodo = :periodo)
          AND (:desde IS NULL OR m.fecha >= :desde)
          AND (:hasta IS NULL OR m.fecha <= :hasta)
        """)
    List<Matricula> buscar(@Param("estado") EstadoMatricula estado,
                           @Param("periodo") String periodo,
                           @Param("desde") LocalDateTime desde,
                           @Param("hasta") LocalDateTime hasta,
                           Sort sort);

    @EntityGraph(attributePaths = "detalles")
    @Query("""
        SELECT m FROM Matricula m
        WHERE (:estado IS NULL OR m.estado = :estado)
          AND (:periodo IS NULL OR m.periodo = :periodo)
          AND (:desde IS NULL OR m.fecha >= :desde)
          AND (:hasta IS NULL OR m.fecha <= :hasta)
        """)
    Page<Matricula> buscarPaginado(@Param("estado") EstadoMatricula estado,
                                   @Param("periodo") String periodo,
                                   @Param("desde") LocalDateTime desde,
                                   @Param("hasta") LocalDateTime hasta,
                                   Pageable pageable);

    default List<MatriculaResumen> buscarResumen(EstadoMatricula estado,
                                                 String periodo,
                                                 LocalDateTime desde,
                                                 LocalDateTime hasta,
                                                 Sort sort) {
        return buscar(estado, periodo, desde, hasta, sort).stream()
                .map(m -> new MatriculaResumen(
                        m.getId(),
                        m.getNombreAlumno(),
                        m.getFecha(),
                        m.getPeriodo(),
                        m.getEstado(),
                        m.getTotalCreditos(),
                        m.getDetalles() != null ? m.getDetalles().size() : 0
                ))
                .toList();
    }

    default MatriculaAgregado agregados(EstadoMatricula estado,
                                        String periodo,
                                        LocalDateTime desde,
                                        LocalDateTime hasta) {
        List<Matricula> lista = buscar(estado, periodo, desde, hasta, Sort.unsorted());
        long total = lista.size();
        long suma = lista.stream()
                .mapToLong(m -> m.getTotalCreditos() != null ? m.getTotalCreditos() : 0L)
                .sum();
        return new MatriculaAgregado(total, suma);
    }
}

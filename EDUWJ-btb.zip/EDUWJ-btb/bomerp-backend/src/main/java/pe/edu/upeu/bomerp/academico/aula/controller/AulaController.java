package pe.edu.upeu.bomerp.academico.aula.controller;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import pe.edu.upeu.bomerp.academico.aula.entity.Aula;
import pe.edu.upeu.bomerp.academico.aula.repository.AulaRepository;

import java.util.List;

@RestController
@RequestMapping("/api/v1/aulas")
@RequiredArgsConstructor
@Tag(name = "Catálogo de Infraestructura y Aulas", description = "Mantenimiento maestro no transaccional de aulas y espacios escolares")
public class AulaController {

    private final AulaRepository aulaRepository;

    @GetMapping
    @Operation(summary = "Listar todas las aulas y ambientes escolares (opcionalmente filtradas por colegioId)")
    public ResponseEntity<List<Aula>> listar(@RequestParam(required = false) Long colegioId) {
        List<Aula> lista = aulaRepository.findAll();
        if (colegioId != null) {
            lista = lista.stream()
                    .filter(a -> colegioId.equals(a.getColegioId()))
                    .toList();
        }
        return ResponseEntity.ok(lista);
    }

    @GetMapping("/{id}")
    @Operation(summary = "Obtener un aula por ID")
    public ResponseEntity<Aula> obtenerPorId(@PathVariable Long id) {
        return aulaRepository.findById(id)
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }

    @PostMapping
    @Operation(summary = "Registrar nueva aula en el catálogo de infraestructura")
    public ResponseEntity<Aula> crear(@RequestBody Aula aula) {
        if (aula.getCodigo() != null && aulaRepository.existsByCodigoIgnoreCase(aula.getCodigo())) {
            return ResponseEntity.status(HttpStatus.CONFLICT).build();
        }
        Aula guardada = aulaRepository.save(aula);
        return ResponseEntity.status(HttpStatus.CREATED).body(guardada);
    }

    @PutMapping("/{id}")
    @Operation(summary = "Actualizar datos de un aula")
    public ResponseEntity<Aula> actualizar(@PathVariable Long id, @RequestBody Aula datos) {
        return aulaRepository.findById(id)
                .map(aula -> {
                    if (datos.getCodigo() != null) aula.setCodigo(datos.getCodigo().trim());
                    if (datos.getNombre() != null) aula.setNombre(datos.getNombre().trim());
                    if (datos.getPabellon() != null) aula.setPabellon(datos.getPabellon().trim());
                    if (datos.getTipo() != null) aula.setTipo(datos.getTipo().trim());
                    if (datos.getCapacidad() != null) aula.setCapacidad(datos.getCapacidad());
                    if (datos.getEstado() != null) aula.setEstado(datos.getEstado().trim());
                    return ResponseEntity.ok(aulaRepository.save(aula));
                })
                .orElse(ResponseEntity.notFound().build());
    }

    @DeleteMapping("/{id}")
    @Operation(summary = "Eliminar un aula del catálogo")
    public ResponseEntity<Void> eliminar(@PathVariable Long id) {
        if (!aulaRepository.existsById(id)) {
            return ResponseEntity.notFound().build();
        }
        aulaRepository.deleteById(id);
        return ResponseEntity.noContent().build();
    }
}

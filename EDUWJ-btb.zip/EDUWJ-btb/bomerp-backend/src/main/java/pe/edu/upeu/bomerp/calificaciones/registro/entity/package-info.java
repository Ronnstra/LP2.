/**
 * Entidades de calificaciones expuestas para portales docentes y de alumnos.
 */
@org.springframework.modulith.NamedInterface("calificaciones-registro-entity")
package pe.edu.upeu.bomerp.calificaciones.registro.entity;

/**
 * DTOs de Alumno expuestos para consumo por otros módulos.
 */
@org.springframework.modulith.NamedInterface("alumno-dto")
package pe.edu.upeu.bomerp.matricula.alumno.dto;

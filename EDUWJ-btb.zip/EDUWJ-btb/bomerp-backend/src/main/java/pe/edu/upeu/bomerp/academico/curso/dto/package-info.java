/**
 * DTOs del módulo académico expuestos para que otros módulos
 * (como matricula e inscripcion) puedan recibirlos.
 */
@org.springframework.modulith.NamedInterface("curso-dto")
package pe.edu.upeu.bomerp.academico.curso.dto;

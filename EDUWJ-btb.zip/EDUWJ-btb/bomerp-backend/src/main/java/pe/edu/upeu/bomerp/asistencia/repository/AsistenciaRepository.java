package pe.edu.upeu.bomerp.asistencia.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import pe.edu.upeu.bomerp.asistencia.entity.Asistencia;

import java.util.List;
import java.util.Optional;

public interface AsistenciaRepository extends JpaRepository<Asistencia, Long> {

    Optional<Asistencia> findByAlumnoIdAndCursoIgnoreCaseAndGradoIgnoreCaseAndSeccionIgnoreCaseAndSesion(
            Long alumnoId, String curso, String grado, String seccion, Integer sesion);

    Optional<Asistencia> findFirstByAlumnoIdAndCursoIgnoreCaseAndSesionAndEstadoIgnoreCaseOrderByIdDesc(
            Long alumnoId, String curso, Integer sesion, String estado);

    List<Asistencia> findByColegioIdOrderByIdDesc(Long colegioId);

    List<Asistencia> findByAlumnoIdOrderByIdDesc(Long alumnoId);

    List<Asistencia> findByDocenteIdOrderByIdDesc(Long docenteId);

    List<Asistencia> findByColegioIdAndCursoIgnoreCaseAndGradoIgnoreCaseAndSeccionIgnoreCaseAndSesion(
            Long colegioId, String curso, String grado, String seccion, Integer sesion);
}

package pe.edu.upeu.bomerp.saas.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.SequenceGenerator;
import jakarta.persistence.Table;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Entity
@Table(name = "PAGOS_SAAS", schema = "BOMERP_APP")
@Getter
@Setter
@NoArgsConstructor
public class PagoSaaS {

    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "seq_pago_saas")
    @SequenceGenerator(name = "seq_pago_saas", sequenceName = "BOMERP_APP.SEQ_PAGO_SAAS", allocationSize = 1)
    private Long id;

    @Column(name = "COLEGIO_ID", nullable = false)
    private Long colegioId;

    @Column(name = "MES_DESDE", nullable = false)
    private Integer mesDesde;

    @Column(name = "MES_HASTA", nullable = false)
    private Integer mesHasta;

    @Column(name = "MESES_PAGADOS", nullable = false)
    private Integer mesesPagados;

    @Column(name = "MONTO", nullable = false)
    private Double monto;

    @Column(name = "METODO_PAGO", length = 40)
    private String metodoPago;

    @Column(name = "BANCO", length = 80)
    private String banco;

    @Column(name = "NUMERO_OPERACION", length = 80)
    private String numeroOperacion;

    @Column(name = "VOUCHER_NOMBRE", length = 200)
    private String voucherNombre;

    @Column(name = "FECHA_PAGO", length = 40)
    private String fechaPago;

    @Column(name = "ESTADO", length = 30)
    private String estado = "CONFIRMADO";

    @Column(name = "SALDO_FONDOS_ANTES")
    private Double saldoFondosAntes;

    @Column(name = "SALDO_FONDOS_DESPUES")
    private Double saldoFondosDespues;
}

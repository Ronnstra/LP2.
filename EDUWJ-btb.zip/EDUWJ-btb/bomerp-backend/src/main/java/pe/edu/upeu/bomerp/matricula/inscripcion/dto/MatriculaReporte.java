package pe.edu.upeu.bomerp.matricula.inscripcion.dto;

import lombok.AllArgsConstructor;
import lombok.Getter;

import java.util.List;

@Getter
@AllArgsConstructor
public class MatriculaReporte {
    private final MatriculaAgregado agregado;
    private final List<MatriculaResumen> matriculas;
}

package pe.edu.upeu.bomerp.matricula.alumno.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import jakarta.persistence.UniqueConstraint;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Entity
@Table(
        name = "CUOTAS_ALUMNO",
        schema = "BOMERP_APP",
        uniqueConstraints = @UniqueConstraint(
                name = "UK_CUOTA_ALUMNO_NUMERO",
                columnNames = {"ALUMNO_ID", "NUMERO"}
        )
)
@Getter
@Setter
@NoArgsConstructor
public class CuotaAlumno {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "ID")
    private Long id;

    @Column(name = "ALUMNO_ID", nullable = false)
    private Long alumnoId;

    @Column(name = "COLEGIO_ID")
    private Long colegioId;

    @Column(name = "NUMERO", nullable = false)
    private Integer numero;

    @Column(name = "CONCEPTO", nullable = false, length = 120)
    private String concepto;

    @Column(name = "MONTO", nullable = false)
    private Double monto;

    @Column(name = "FECHA_VENCIMIENTO", nullable = false, length = 10)
    private String fechaVencimiento;

    @Column(name = "ESTADO", nullable = false, length = 20)
    private String estado = "PENDIENTE";

    @Column(name = "FECHA_PAGO", length = 10)
    private String fechaPago;

    @Column(name = "NUMERO_OPERACION", length = 30)
    private String numeroOperacion;
}

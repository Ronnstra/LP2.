package pe.edu.upeu.bomerp.matricula.alumno.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import pe.edu.upeu.bomerp.matricula.alumno.entity.CuotaAlumno;

import java.util.List;
import java.util.Optional;

public interface CuotaAlumnoRepository extends JpaRepository<CuotaAlumno, Long> {
    List<CuotaAlumno> findByAlumnoIdOrderByNumeroAsc(Long alumnoId);
    Optional<CuotaAlumno> findByAlumnoIdAndNumero(Long alumnoId, Integer numero);
    List<CuotaAlumno> findByColegioId(Long colegioId);
    boolean existsByAlumnoId(Long alumnoId);
    void deleteByAlumnoId(Long alumnoId);
}

package pe.edu.upeu.bomerp.matricula.inscripcion.controller;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.web.PageableDefault;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.security.oauth2.jwt.Jwt;
import org.springframework.web.bind.annotation.*;
import pe.edu.upeu.bomerp.matricula.inscripcion.dto.MatriculaReporte;
import pe.edu.upeu.bomerp.matricula.inscripcion.dto.MatriculaRequest;
import pe.edu.upeu.bomerp.matricula.inscripcion.dto.MatriculaResponse;
import pe.edu.upeu.bomerp.matricula.inscripcion.entity.EstadoMatricula;
import pe.edu.upeu.bomerp.matricula.inscripcion.service.MatriculaService;

import java.time.LocalDateTime;
import java.util.List;

@Slf4j
@Tag(name = "Matrícula - Operación Cabecera-Detalle", description = "Inscripción académica transaccional de asignaturas con control de vacantes, paginación y reportes")
@RestController
@RequestMapping("/api/v1/matriculas")
@RequiredArgsConstructor
public class MatriculaController {

    private final MatriculaService matriculaService;

    @Operation(summary = "Registrar nueva matrícula escolar con asignaturas (Operación Cabecera-Detalle Atómica y Auditada)")
    @PostMapping
    @ResponseStatus(HttpStatus.CREATED)
    public MatriculaResponse matricular(
            @Valid @RequestBody MatriculaRequest request,
            @AuthenticationPrincipal Jwt jwt) {
        String actor = jwt != null ? jwt.getSubject() : "jimyamanqui@gmail.com";
        log.info("Registrando matrícula para alumnoId={} en periodo={} por actor={}", request.getAlumnoId(), request.getPeriodo(), actor);
        return matriculaService.matricular(request, actor);
    }

    @Operation(summary = "Consultar matrículas con filtros combinados y ordenamiento")
    @GetMapping
    public ResponseEntity<List<MatriculaResponse>> buscar(
            @RequestParam(required = false) EstadoMatricula estado,
            @RequestParam(required = false) String periodo,
            @RequestParam(required = false) @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME) LocalDateTime desde,
            @RequestParam(required = false) @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME) LocalDateTime hasta,
            @RequestParam(defaultValue = "fecha") String ordenarPor,
            @RequestParam(defaultValue = "DESC") String direccion) {
        log.info("Consultando matrículas con filtros estado={}, periodo={}, desde={}, hasta={}",
                estado, periodo, desde, hasta);
        return ResponseEntity.ok(matriculaService.buscar(estado, periodo, desde, hasta, ordenarPor, direccion));
    }

    @Operation(summary = "Consultar matrículas paginadas con Page<MatriculaResponse> (S14)")
    @GetMapping("/paginado")
    public ResponseEntity<Page<MatriculaResponse>> buscarPaginado(
            @RequestParam(required = false) EstadoMatricula estado,
            @RequestParam(required = false) String periodo,
            @RequestParam(required = false) @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME) LocalDateTime desde,
            @RequestParam(required = false) @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME) LocalDateTime hasta,
            @PageableDefault(size = 20, sort = "fecha", direction = Sort.Direction.DESC) Pageable pageable) {
        return ResponseEntity.ok(matriculaService.buscarPaginado(estado, periodo, desde, hasta, pageable));
    }

    @Operation(summary = "Consultar una matrícula por ID con sus asignaturas detalladas")
    @GetMapping("/{id}")
    public ResponseEntity<MatriculaResponse> obtener(@PathVariable Long id) {
        return ResponseEntity.ok(matriculaService.obtener(id));
    }

    @Operation(summary = "Reporte estadístico de matrículas: agregados en servidor (SUM/COUNT) y detalle resumido")
    @GetMapping("/resumen")
    public ResponseEntity<MatriculaReporte> resumen(
            @RequestParam(required = false) EstadoMatricula estado,
            @RequestParam(required = false) String periodo,
            @RequestParam(required = false) @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME) LocalDateTime desde,
            @RequestParam(required = false) @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME) LocalDateTime hasta) {
        return ResponseEntity.ok(matriculaService.reporte(estado, periodo, desde, hasta));
    }

    @Operation(summary = "Anular una matrícula existente en Oracle DB con registro en tabla AUDITORIA")
    @PutMapping("/{id}/anular")
    public ResponseEntity<?> anular(
            @PathVariable Long id,
            @AuthenticationPrincipal Jwt jwt) {
        String actor = jwt != null ? jwt.getSubject() : "jimyamanqui@gmail.com";
        MatriculaResponse m = matriculaService.anular(id, actor);
        return ResponseEntity.ok(java.util.Map.of("mensaje", "Matrícula anulada exitosamente en Oracle DB", "matricula", m));
    }
}


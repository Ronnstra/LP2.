package pe.edu.upeu.bomerp.matricula.inscripcion.entity;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;

@Entity
@Table(name = "DETALLES_MATRICULA", schema = "BOMERP_APP")
@Getter
@Setter
public class DetalleMatricula {

    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "seq_det_matricula")
    @SequenceGenerator(name = "seq_det_matricula", sequenceName = "BOMERP_APP.SEQ_DET_MATRICULA", allocationSize = 1)
    private Long id;

    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "matricula_id", nullable = false)
    private Matricula matricula;

    @Column(name = "curso_id", nullable = false)
    private Long cursoId;

    @Column(name = "nombre_curso", nullable = false, length = 150)
    private String nombreCurso;

    @Column(nullable = false)
    private Integer creditos;
}

package pe.edu.upeu.bomerp.academico.curso.service;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.cache.annotation.CacheEvict;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import pe.edu.upeu.bomerp.academico.curso.dto.CursoRequest;
import pe.edu.upeu.bomerp.academico.curso.dto.CursoResponse;
import pe.edu.upeu.bomerp.academico.curso.entity.Curso;
import pe.edu.upeu.bomerp.academico.curso.mapper.CursoMapper;
import pe.edu.upeu.bomerp.academico.curso.repository.CursoRepository;
import pe.edu.upeu.bomerp.exception.ResourceNotFoundException;
import pe.edu.upeu.bomerp.exception.VacanteInsuficienteException;
import java.util.List;

@Slf4j
@Service
@RequiredArgsConstructor
public class CursoServiceImpl implements CursoService {

    private final CursoRepository cursoRepository;
    private final CursoMapper cursoMapper;

    @Override
    @Cacheable("cursos")
    @Transactional(readOnly = true)
    public List<CursoResponse> listar(String grado) {
        log.info("Listando cursos - consulta real a la base (grado={})", grado);
        if (grado != null && !grado.isBlank()) {
            return cursoRepository.findByGrado(grado).stream().map(cursoMapper::toResponse).toList();
        }
        return cursoRepository.findAll().stream().map(cursoMapper::toResponse).toList();
    }

    @Override
    @Transactional(readOnly = true)
    public CursoResponse obtener(Long id) {
        return cursoMapper.toResponse(buscarOFallar(id));
    }

    @Override
    @CacheEvict(value = "cursos", allEntries = true)
    @Transactional
    public CursoResponse crear(CursoRequest request) {
        Curso curso = cursoMapper.toEntity(request);
        return cursoMapper.toResponse(cursoRepository.save(curso));
    }

    @Override
    @CacheEvict(value = "cursos", allEntries = true)
    @Transactional
    public CursoResponse actualizar(Long id, CursoRequest request) {
        Curso curso = buscarOFallar(id);
        curso.setNombre(request.getNombre());
        curso.setGrado(request.getGrado());
        curso.setCreditos(request.getCreditos());
        curso.setVacantesMaximas(request.getVacantesMaximas());
        curso.setAula(request.getAula());
        if (request.getColegioId() != null) {
            curso.setColegioId(request.getColegioId());
        }
        return cursoMapper.toResponse(cursoRepository.save(curso));
    }

    @Override
    @CacheEvict(value = "cursos", allEntries = true)
    @Transactional
    public void eliminar(Long id) {
        cursoRepository.delete(buscarOFallar(id));
    }

    @Override
    @CacheEvict(value = "cursos", allEntries = true)
    @Transactional
    public void descontarVacante(Long id, Integer vacantes) {
        Curso curso = buscarOFallar(id);
        if (curso.getVacantesDisponibles() < vacantes) {
            throw new VacanteInsuficienteException(
                "Vacantes insuficientes para la asignatura '" + curso.getNombre() + "': disponibles "
                + curso.getVacantesDisponibles() + ", solicitadas " + vacantes
            );
        }
        curso.setVacantesDisponibles(curso.getVacantesDisponibles() - vacantes);
        cursoRepository.save(curso);
    }

    private Curso buscarOFallar(Long id) {
        return cursoRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Curso no encontrado: " + id));
    }
}

package pe.edu.upeu.bomerp.asistencia.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import pe.edu.upeu.bomerp.asistencia.entity.JustificacionInasistencia;

import java.util.List;
import java.util.Optional;

@Repository
public interface JustificacionInasistenciaRepository extends JpaRepository<JustificacionInasistencia, Long> {
    List<JustificacionInasistencia> findByAlumnoIdOrderByIdDesc(Long alumnoId);
    List<JustificacionInasistencia> findByDocenteIdOrderByIdDesc(Long docenteId);
    Optional<JustificacionInasistencia> findFirstByAlumnoIdAndCursoIgnoreCaseAndSesionAndEstadoOrderByIdDesc(
            Long alumnoId, String curso, Integer sesion, String estado);
}

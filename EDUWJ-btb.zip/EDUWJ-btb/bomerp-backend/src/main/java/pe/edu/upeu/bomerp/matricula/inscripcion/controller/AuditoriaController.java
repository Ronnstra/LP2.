package pe.edu.upeu.bomerp.matricula.inscripcion.controller;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import pe.edu.upeu.bomerp.matricula.inscripcion.entity.RegistroAuditoria;
import pe.edu.upeu.bomerp.matricula.inscripcion.service.AuditoriaService;

import java.util.List;

@Tag(name = "Seguridad y Auditoría - Registro de Acciones Críticas", description = "Trazabilidad e inmutabilidad de operaciones críticas (CREAR, ANULAR) con actor JWT real (S14)")
@RestController
@RequestMapping("/api/v1/auditoria")
@RequiredArgsConstructor
public class AuditoriaController {

    private final AuditoriaService auditoriaService;

    @Operation(summary = "Listar registros reales de auditoría ordenados por fecha descendente")
    @GetMapping
    public ResponseEntity<List<RegistroAuditoria>> listar() {
        return ResponseEntity.ok(auditoriaService.listar());
    }
}

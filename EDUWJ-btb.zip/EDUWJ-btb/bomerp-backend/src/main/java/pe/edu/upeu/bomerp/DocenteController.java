package pe.edu.upeu.bomerp;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.*;
import pe.edu.upeu.bomerp.asistencia.entity.Asistencia;
import pe.edu.upeu.bomerp.asistencia.service.AsistenciaService;
import pe.edu.upeu.bomerp.auth.seguridad.entity.Usuario;
import pe.edu.upeu.bomerp.auth.seguridad.repository.UsuarioRepository;
import pe.edu.upeu.bomerp.calificaciones.registro.entity.Nota;
import pe.edu.upeu.bomerp.calificaciones.registro.repository.NotaRepository;
import pe.edu.upeu.bomerp.horario.entity.BloqueHorario;
import pe.edu.upeu.bomerp.horario.repository.BloqueHorarioRepository;
import pe.edu.upeu.bomerp.matricula.alumno.entity.Alumno;
import pe.edu.upeu.bomerp.matricula.alumno.repository.AlumnoRepository;
import pe.edu.upeu.bomerp.personal.entity.PersonalEscolar;
import pe.edu.upeu.bomerp.personal.repository.PersonalEscolarRepository;

import java.time.LocalDate;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/api/v1/docente")
@RequiredArgsConstructor
@Transactional
@Tag(name = "Portal Docente (Cursos, Notas, Asistencia y Nómina)", description = "Operaciones del Portal Docente conectadas a Oracle DB sin datos ficticios")
public class DocenteController {

    private final PersonalEscolarRepository personalRepository;
    private final UsuarioRepository usuarioRepository;
    private final BloqueHorarioRepository bloqueHorarioRepository;
    private final AlumnoRepository alumnoRepository;
    private final NotaRepository notaRepository;
    private final AsistenciaService asistenciaService;

    public static final Map<String, String> registrosAsistencias = new ConcurrentHashMap<>();
    public static final Map<Long, Double> horasExtraPorDocente = new ConcurrentHashMap<>();
    public static final Map<Long, String> periodicidadPorDocente = new ConcurrentHashMap<>();

    public static final Map<Long, Map<String, Object>> ponderacionesPorCurso = new ConcurrentHashMap<>();
    public static final Map<Long, Map<String, Object>> solicitudesPonderacion = new ConcurrentHashMap<>();
    public static final Map<String, Map<String, Object>> actividadesSesionMap = new ConcurrentHashMap<>();
    public static final Map<Long, Map<String, Object>> entregasTareasMap = new ConcurrentHashMap<>();
    private static long nextSolicitudId = 1L;
    private static long nextEntregaId = 1L;
    private static long nextActividadId = 1L;

    public static String normalizarTexto(Object val) {
        if (val == null) return "";
        String s = String.valueOf(val).trim().toLowerCase();
        return java.text.Normalizer.normalize(s, java.text.Normalizer.Form.NFD)
                .replaceAll("[\\p{InCombiningDiacriticalMarks}]", "");
    }

    public static Long toLong(Object val) {
        if (val == null) return null;
        if (val instanceof Number n) return n.longValue();
        try {
            return Long.parseLong(String.valueOf(val).trim());
        } catch (Exception e) {
            return null;
        }
    }

    public static Integer toInt(Object val) {
        if (val == null) return null;
        if (val instanceof Number n) return n.intValue();
        try {
            return Integer.parseInt(String.valueOf(val).trim());
        } catch (Exception e) {
            return null;
        }
    }

    public static boolean coincideCurso(Object cursoA, Object cursoB) {
        String a = normalizarTexto(cursoA);
        String b = normalizarTexto(cursoB);
        if (a.isEmpty() || b.isEmpty()) return false;
        return a.equals(b) || a.contains(b) || b.contains(a);
    }

    public static Map<String, Object> obtenerPesosCurso(Long cursoId, String cursoNombre) {
        Map<String, Object> pond = null;
        if (cursoNombre != null && !cursoNombre.isBlank()) {
            pond = ponderacionesPorCurso.values().stream()
                    .filter(p -> p.get("cursoNombre") != null && coincideCurso(p.get("cursoNombre"), cursoNombre))
                    .findFirst()
                    .orElse(null);
        }
        if (pond == null && cursoId != null && ponderacionesPorCurso.containsKey(cursoId)) {
            pond = ponderacionesPorCurso.get(cursoId);
        }
        if (pond == null && ponderacionesPorCurso.size() == 1) {
            pond = ponderacionesPorCurso.values().iterator().next();
        }
        int asis = pond != null && toInt(pond.get("asistenciaPorcentaje")) != null ? toInt(pond.get("asistenciaPorcentaje")) : 30;
        int tar = pond != null && toInt(pond.get("tareasPorcentaje")) != null ? toInt(pond.get("tareasPorcentaje")) : 35;
        int exa = pond != null && toInt(pond.get("examenesPorcentaje")) != null ? toInt(pond.get("examenesPorcentaje")) : 35;
        Map<String, Object> pesos = new LinkedHashMap<>();
        pesos.put("asistencia", asis);
        pesos.put("tareas", tar);
        pesos.put("examenes", exa);
        return pesos;
    }

    public static synchronized Map<String, Object> registrarEntregaAlumnoStatic(Map<String, Object> body) {
        Long alumnoId = toLong(body.get("alumnoId"));
        if (alumnoId == null) alumnoId = 1L;
        Integer sesionId = toInt(body.get("sesionId") != null ? body.get("sesionId") : body.get("tareaId"));
        if (sesionId == null) sesionId = 1;
        String cursoNombre = String.valueOf(body.getOrDefault("cursoNombre", body.getOrDefault("curso", ""))).trim();
        String grado = String.valueOf(body.getOrDefault("grado", "1° Secundaria")).trim();
        String archivoNombre = String.valueOf(body.getOrDefault("archivoNombre", "tarea_evidencia.pdf")).trim();
        String archivoUrl = body.get("archivoUrl") != null ? String.valueOf(body.get("archivoUrl")) : "";
        String archivoTipo = body.get("archivoTipo") != null ? String.valueOf(body.get("archivoTipo")) : "";
        String comentario = String.valueOf(body.getOrDefault("comentarioAlumno", body.getOrDefault("comentario", ""))).trim();
        String tipoActividad = String.valueOf(body.getOrDefault("tipoActividad", "TAREA")).toUpperCase();
        String actividadId = body.get("actividadId") != null ? String.valueOf(body.get("actividadId")) : null;

        List<Map<String, Object>> archivos = new ArrayList<>();
        if (body.get("archivos") instanceof List<?> lista) {
            for (Object obj : lista) {
                if (obj instanceof Map<?, ?> m) {
                    Map<String, Object> a = new LinkedHashMap<>();
                    a.put("nombre", m.get("nombre") != null ? String.valueOf(m.get("nombre")) : "archivo");
                    a.put("url", m.get("url") != null ? String.valueOf(m.get("url")) : "");
                    a.put("tipo", m.get("tipo") != null ? String.valueOf(m.get("tipo")) : "");
                    if (!String.valueOf(a.get("url")).isBlank()) archivos.add(a);
                }
            }
        }
        if (archivos.isEmpty() && !archivoUrl.isBlank()) {
            Map<String, Object> a = new LinkedHashMap<>();
            a.put("nombre", archivoNombre);
            a.put("url", archivoUrl);
            a.put("tipo", archivoTipo);
            archivos.add(a);
        }
        if (!archivos.isEmpty()) {
            archivoNombre = String.valueOf(archivos.get(0).get("nombre"));
            archivoUrl = String.valueOf(archivos.get(0).get("url"));
            archivoTipo = String.valueOf(archivos.get(0).get("tipo"));
        }

        final Long finalAlumnoId = alumnoId;
        final Integer finalSesionId = sesionId;
        final String finalActividadId = (actividadId != null && !actividadId.isBlank()) ? actividadId.trim() : null;
        Optional<Map<String, Object>> existenteOpt = entregasTareasMap.values().stream()
                .filter(e -> Objects.equals(toLong(e.get("alumnoId")), finalAlumnoId)
                        && (finalActividadId != null
                                ? Objects.equals(String.valueOf(e.get("actividadId")), finalActividadId)
                                : (e.get("actividadId") == null
                                        && (Objects.equals(toInt(e.get("sesionId")), finalSesionId) || Objects.equals(toInt(e.get("tareaId")), finalSesionId))
                                        && (cursoNombre.isEmpty() || coincideCurso(e.get("cursoNombre"), cursoNombre)))))
                .findFirst();

        Map<String, Object> entrega;
        if (existenteOpt.isPresent()) {
            entrega = existenteOpt.get();
        } else {
            entrega = new ConcurrentHashMap<>();
            long newId = nextEntregaId++;
            entrega.put("id", newId);
            entregasTareasMap.put(newId, entrega);
        }

        entrega.put("alumnoId", alumnoId);
        entrega.put("alumnoNombre", body.getOrDefault("alumnoNombre", "Estudiante"));
        entrega.put("cursoId", toLong(body.get("cursoId")) != null ? toLong(body.get("cursoId")) : 1L);
        entrega.put("cursoNombre", cursoNombre);
        entrega.put("curso", cursoNombre);
        entrega.put("grado", grado);
        entrega.put("sesionId", sesionId);
        entrega.put("sesion", sesionId);
        entrega.put("tareaId", sesionId);
        if (actividadId != null) {
            entrega.put("actividadId", actividadId);
        }
        entrega.put("tipoActividad", tipoActividad);
        entrega.put("archivoNombre", archivoNombre);
        entrega.put("archivoUrl", archivoUrl);
        entrega.put("archivoTipo", archivoTipo);
        entrega.put("archivos", archivos);
        entrega.put("comentario", comentario);
        entrega.put("comentarioAlumno", comentario);
        entrega.put("fechaEntrega", java.time.LocalDateTime.now().toString().replace("T", " ").substring(0, 16));
        entrega.put("estado", "ENTREGADO");
        entrega.put("entregado", true);
        if (!entrega.containsKey("calificacion")) {
            entrega.put("calificacion", null);
        }
        return entrega;
    }

    public static Map<String, Object> calcularResumenNotasCurso(
            Long alumnoId,
            String cursoNombre,
            String grado,
            Long cursoId,
            List<Asistencia> asistenciasDelCurso,
            List<Nota> notasDelAlumno,
            int totalAlumnosEnCurso) {

        List<Map<String, Object>> actividadesCurso = actividadesSesionMap.values().stream()
                .filter(act -> coincideCurso(act.get("cursoNombre") != null ? act.get("cursoNombre") : act.get("curso"), cursoNombre))
                .collect(Collectors.toList());

        List<Map<String, Object>> entregasCurso = entregasTareasMap.values().stream()
                .filter(e -> (Objects.equals(toLong(e.get("alumnoId")), alumnoId) || totalAlumnosEnCurso <= 1)
                        && coincideCurso(e.get("cursoNombre") != null ? e.get("cursoNombre") : e.get("curso"), cursoNombre))
                .collect(Collectors.toList());

        List<Map<String, Object>> tareasPublicadas = actividadesCurso.stream()
                .filter(a -> "TAREA".equalsIgnoreCase(String.valueOf(a.getOrDefault("tipoActividad", a.getOrDefault("actividadTipo", "")))))
                .collect(Collectors.toList());

        List<Map<String, Object>> examenesPublicados = actividadesCurso.stream()
                .filter(a -> "EXAMEN".equalsIgnoreCase(String.valueOf(a.getOrDefault("tipoActividad", a.getOrDefault("actividadTipo", "")))))
                .collect(Collectors.toList());

        // 1. Promedio de Tareas: suma de notas de cada tarea individual publicada / cantidad total de tareas publicadas
        double practica = 0.0;
        boolean tieneTareaCalificada = false;
        if (!tareasPublicadas.isEmpty()) {
            double sumaTareas = 0.0;
            for (Map<String, Object> t : tareasPublicadas) {
                Integer sesNum = toInt(t.get("numeroSesion") != null ? t.get("numeroSesion") : t.get("sesion"));
                String actId = t.get("actividadId") != null ? String.valueOf(t.get("actividadId")) : (t.get("key") != null ? String.valueOf(t.get("key")) : null);
                Map<String, Object> ent = entregasCurso.stream()
                        .filter(e -> {
                            if (actId != null && e.get("actividadId") != null) {
                                return Objects.equals(String.valueOf(e.get("actividadId")), actId);
                            }
                            return actId == null && Objects.equals(toInt(e.get("sesionId") != null ? e.get("sesionId") : e.get("tareaId")), sesNum)
                                    && "TAREA".equalsIgnoreCase(String.valueOf(e.getOrDefault("tipoActividad", "TAREA")));
                        })
                        .findFirst().orElse(null);
                Object calObj = ent != null ? (ent.get("calificacion") != null ? ent.get("calificacion") : ent.get("nota")) : null;
                if (calObj != null) {
                    sumaTareas += Double.parseDouble(String.valueOf(calObj));
                    tieneTareaCalificada = true;
                }
            }
            practica = Math.round((sumaTareas / tareasPublicadas.size()) * 10.0) / 10.0;
        } else {
            List<Map<String, Object>> entregasCalificadas = entregasCurso.stream()
                    .filter(e -> "TAREA".equalsIgnoreCase(String.valueOf(e.getOrDefault("tipoActividad", "TAREA"))) && (e.get("calificacion") != null || e.get("nota") != null))
                    .collect(Collectors.toList());
            if (!entregasCalificadas.isEmpty()) {
                double sum = entregasCalificadas.stream().mapToDouble(e -> Double.parseDouble(String.valueOf(e.get("calificacion") != null ? e.get("calificacion") : e.get("nota")))).sum();
                practica = Math.round((sum / entregasCalificadas.size()) * 10.0) / 10.0;
                tieneTareaCalificada = true;
            }
        }

        // 2. Promedio de Exámenes: suma de notas de cada examen individual publicado / cantidad total de exámenes publicados
        double examenFinal = 0.0;
        boolean tieneExamenCalificado = false;
        if (!examenesPublicados.isEmpty()) {
            double sumaExamenes = 0.0;
            for (Map<String, Object> ex : examenesPublicados) {
                Integer sesNum = toInt(ex.get("numeroSesion") != null ? ex.get("numeroSesion") : ex.get("sesion"));
                String actId = ex.get("actividadId") != null ? String.valueOf(ex.get("actividadId")) : (ex.get("key") != null ? String.valueOf(ex.get("key")) : null);
                Map<String, Object> ent = entregasCurso.stream()
                        .filter(e -> {
                            if (actId != null && e.get("actividadId") != null) {
                                return Objects.equals(String.valueOf(e.get("actividadId")), actId);
                            }
                            return actId == null && Objects.equals(toInt(e.get("sesionId") != null ? e.get("sesionId") : e.get("tareaId")), sesNum)
                                    && "EXAMEN".equalsIgnoreCase(String.valueOf(e.getOrDefault("tipoActividad", "EXAMEN")));
                        })
                        .findFirst().orElse(null);
                Object calObj = ent != null ? (ent.get("calificacion") != null ? ent.get("calificacion") : ent.get("nota")) : null;
                if (calObj != null) {
                    sumaExamenes += Double.parseDouble(String.valueOf(calObj));
                    tieneExamenCalificado = true;
                }
            }
            examenFinal = Math.round((sumaExamenes / examenesPublicados.size()) * 10.0) / 10.0;
        } else {
            List<Map<String, Object>> examenesCalificados = entregasCurso.stream()
                    .filter(e -> "EXAMEN".equalsIgnoreCase(String.valueOf(e.getOrDefault("tipoActividad", ""))) && e.get("calificacion") != null)
                    .collect(Collectors.toList());
            if (!examenesCalificados.isEmpty()) {
                double sum = examenesCalificados.stream().mapToDouble(e -> Double.parseDouble(String.valueOf(e.get("calificacion")))).sum();
                examenFinal = Math.round((sum / examenesCalificados.size()) * 10.0) / 10.0;
                tieneExamenCalificado = true;
            }
        }

        // 3. Nota de Asistencia: solo sesiones con asistencia registrada (PRESENTE=20, TARDANZA=13, FALTA=0, JUSTIFICADA=16)
        List<Asistencia> sesionesRegistradas = (asistenciasDelCurso != null ? asistenciasDelCurso : List.<Asistencia>of()).stream()
                .filter(as -> {
                    String est = as.getEstado() != null ? as.getEstado().trim().toUpperCase() : "";
                    return "PRESENTE".equals(est) || "TARDANZA".equals(est) || "FALTA".equals(est)
                            || "JUSTIFICADA".equals(est) || "JUSTIFICADO".equals(est);
                })
                .collect(Collectors.toList());

        double asistenciaNota = 0.0;
        if (!sesionesRegistradas.isEmpty()) {
            double sumaAsis = 0.0;
            for (Asistencia as : sesionesRegistradas) {
                String est = as.getEstado() != null ? as.getEstado().trim().toUpperCase() : "";
                if ("PRESENTE".equals(est)) sumaAsis += 20.0;
                else if ("TARDANZA".equals(est)) sumaAsis += 13.0;
                else if ("JUSTIFICADA".equals(est) || "JUSTIFICADO".equals(est)) sumaAsis += 16.0;
            }
            asistenciaNota = Math.round((sumaAsis / sesionesRegistradas.size()) * 10.0) / 10.0;
        }

        Map<String, Object> pesos = obtenerPesosCurso(cursoId, cursoNombre);
        int pesoAsis = toInt(pesos.get("asistencia")) != null ? toInt(pesos.get("asistencia")) : 30;
        int pesoTar = toInt(pesos.get("tareas")) != null ? toInt(pesos.get("tareas")) : 35;
        int pesoExa = toInt(pesos.get("examenes")) != null ? toInt(pesos.get("examenes")) : 35;

        boolean hayAlgunaEvaluacion = !sesionesRegistradas.isEmpty() || tieneTareaCalificada || tieneExamenCalificado || practica > 0 || examenFinal > 0;
        double promedio = hayAlgunaEvaluacion
                ? Math.round(((asistenciaNota * (pesoAsis / 100.0)) + (practica * (pesoTar / 100.0)) + (examenFinal * (pesoExa / 100.0))) * 10.0) / 10.0
                : 0.0;

        Map<String, Object> res = new LinkedHashMap<>();
        res.put("asistenciaNota", asistenciaNota);
        res.put("practica", practica);
        res.put("parcial", examenFinal);
        res.put("examen", examenFinal);
        res.put("examenFinal", examenFinal);
        res.put("finalExam", examenFinal);
        res.put("final", promedio);
        res.put("promedio", promedio);
        res.put("totalTareas", tareasPublicadas.size());
        res.put("totalExamenes", examenesPublicados.size());
        res.put("pesos", pesos);
        return res;
    }

    @Operation(summary = "Obtener cursos asignados realmente al docente autenticado desde Oracle DB")
    @GetMapping("/cursos")
    public ResponseEntity<List<Map<String, Object>>> obtenerCursosDocente(
            @RequestParam(required = false) Long docenteId,
            @RequestParam(required = false) String username,
            @RequestParam(required = false) Long colegioId) {

        PersonalEscolar targetDocente = resolverDocenteEstricto(docenteId, username, colegioId);
        if (targetDocente == null) {
            return ResponseEntity.ok(List.of());
        }

        final Long realDocId = targetDocente.getId();
        final Long colId = targetDocente.getColegioId();
        final String nombreLower = targetDocente.getNombre() != null ? targetDocente.getNombre().trim().toLowerCase() : "";
        final String apellidoLower = targetDocente.getApellidos() != null ? targetDocente.getApellidos().trim().toLowerCase() : "";

        List<BloqueHorario> bloquesDelDocente = bloqueHorarioRepository.findAll().stream()
                .filter(b -> colId == null || b.getColegioId() == null || Objects.equals(colId, b.getColegioId()))
                .filter(b -> Objects.equals(b.getDocenteId(), realDocId)
                        || (!nombreLower.isEmpty() && b.getDocenteNombre() != null
                        && b.getDocenteNombre().toLowerCase().contains(nombreLower)
                        && (apellidoLower.isEmpty() || b.getDocenteNombre().toLowerCase().contains(apellidoLower.split("\\s+")[0]))))
                .collect(Collectors.toList());

        List<Alumno> alumnosColegio = alumnoRepository.findAll().stream()
                .filter(a -> colId == null || Objects.equals(colId, a.getColegioId()))
                .collect(Collectors.toList());

        List<Nota> todasLasNotas = notaRepository.findAll();

        Map<String, Map<String, Object>> cursosMap = new LinkedHashMap<>();
        long nextCursoGenId = 201L;
        int duracionMesesAnual = 10;

        for (BloqueHorario b : bloquesDelDocente) {
            String cursoNombre = b.getCurso() != null ? b.getCurso().trim() : "Asignatura";
            String grado = b.getGrado() != null ? b.getGrado().trim() : "1° Secundaria";
            String seccion = b.getSeccion() != null ? b.getSeccion().trim().toUpperCase() : "A";
            String key = cursoNombre.toLowerCase() + "__" + grado.toLowerCase() + "__" + seccion;

            if (!cursosMap.containsKey(key)) {
                long cursoIdActual = nextCursoGenId++;
                String codePrefix = cursoNombre.replaceAll("[^a-zA-Z]", "");
                codePrefix = (codePrefix.length() >= 3 ? codePrefix.substring(0, 3) : "CUR").toUpperCase();
                String numGrado = grado.replaceAll("[^0-9]", "");
                if (numGrado.isEmpty()) numGrado = "1";

                final String finalGrado = grado;
                final String finalNumGrado = numGrado;
                List<Alumno> alumnosFiltrados = alumnosColegio.stream()
                        .filter(a -> a.getGrado() != null && (a.getGrado().equalsIgnoreCase(finalGrado) || a.getGrado().contains(finalNumGrado + "°")))
                        .collect(Collectors.toList());

                final int totalAlumCurso = alumnosFiltrados.size();
                List<Map<String, Object>> alumnosDelCurso = alumnosFiltrados.stream()
                        .map(a -> {
                            List<Asistencia> asisAlumCurso = asistenciaService.listarPorAlumno(a.getId()).stream()
                                    .filter(as -> coincideCurso(as.getCurso(), cursoNombre))
                                    .collect(Collectors.toList());
                            List<Nota> notasAlumno = todasLasNotas.stream()
                                    .filter(n -> Objects.equals(n.getAlumnoId(), a.getId()))
                                    .collect(Collectors.toList());

                            Map<String, Object> resumen = calcularResumenNotasCurso(
                                    a.getId(), cursoNombre, finalGrado, cursoIdActual, asisAlumCurso, notasAlumno, totalAlumCurso
                            );

                            Map<String, Object> alumMap = new LinkedHashMap<>();
                            alumMap.put("id", a.getId());
                            alumMap.put("nombreCompleto", a.getApellidoPaterno() + " " + (a.getApellidoMaterno() != null ? a.getApellidoMaterno() : "") + ", " + a.getNombre());
                            alumMap.put("dni", a.getDni());
                            alumMap.put("asistenciaNota", resumen.get("asistenciaNota"));
                            alumMap.put("practica", resumen.get("practica"));
                            alumMap.put("examen", resumen.get("examen"));
                            alumMap.put("finalExam", resumen.get("finalExam"));
                            alumMap.put("promedio", resumen.get("promedio"));
                            alumMap.put("estadoActa", "REGISTRADA");
                            return alumMap;
                        })
                        .collect(Collectors.toList());

                List<Map<String, Object>> bloquesCurso = new ArrayList<>();
                Map<String, Object> bMap = new LinkedHashMap<>();
                bMap.put("id", b.getId());
                bMap.put("dia", b.getDia());
                bMap.put("horaInicio", b.getHoraInicio());
                bMap.put("horaFin", b.getHoraFin());
                bMap.put("duracionHoras", b.getDuracionHoras() != null ? b.getDuracionHoras() : 2.0);
                bMap.put("duracionMinutos", b.getDuracionMinutos() != null ? b.getDuracionMinutos() : 120);
                bloquesCurso.add(bMap);

                Map<String, Object> cursoObj = new LinkedHashMap<>();
                cursoObj.put("id", cursoIdActual);
                cursoObj.put("codigo", codePrefix + "-" + numGrado + "01");
                cursoObj.put("nombre", cursoNombre);
                cursoObj.put("grado", grado);
                cursoObj.put("seccion", seccion);
                cursoObj.put("horario", b.getDia() + " " + b.getHoraInicio() + " - " + b.getHoraFin());
                cursoObj.put("aula", b.getAula() != null ? b.getAula() : "Aula Principal");
                cursoObj.put("actaCerrada", false);
                cursoObj.put("turnosPorSemana", 1);
                cursoObj.put("duracionMesesAnual", duracionMesesAnual);
                cursoObj.put("totalSesiones", 1 * 4 * duracionMesesAnual);
                cursoObj.put("bloquesHorario", bloquesCurso);
                cursoObj.put("alumnos", alumnosDelCurso);
                cursosMap.put(key, cursoObj);
            } else {
                Map<String, Object> existing = cursosMap.get(key);
                String horarioActual = String.valueOf(existing.get("horario"));
                String nuevoSegmento = b.getDia() + " " + b.getHoraInicio() + " - " + b.getHoraFin();
                if (!horarioActual.contains(nuevoSegmento)) {
                    existing.put("horario", horarioActual + " / " + nuevoSegmento);
                }
                @SuppressWarnings("unchecked")
                List<Map<String, Object>> bloquesCurso = (List<Map<String, Object>>) existing.get("bloquesHorario");
                Map<String, Object> bMap = new LinkedHashMap<>();
                bMap.put("id", b.getId());
                bMap.put("dia", b.getDia());
                bMap.put("horaInicio", b.getHoraInicio());
                bMap.put("horaFin", b.getHoraFin());
                bMap.put("duracionHoras", b.getDuracionHoras() != null ? b.getDuracionHoras() : 2.0);
                bMap.put("duracionMinutos", b.getDuracionMinutos() != null ? b.getDuracionMinutos() : 120);
                bloquesCurso.add(bMap);
                int turnos = bloquesCurso.size();
                existing.put("turnosPorSemana", turnos);
                existing.put("totalSesiones", turnos * 4 * duracionMesesAnual);
            }
        }

        return ResponseEntity.ok(new ArrayList<>(cursosMap.values()));
    }

    @GetMapping("/ponderaciones")
    public ResponseEntity<List<Map<String, Object>>> listarTodasLasPonderaciones() {
        return ResponseEntity.ok(new ArrayList<>(ponderacionesPorCurso.values()));
    }

    @GetMapping("/ponderacion/{cursoId}")
    public ResponseEntity<Map<String, Object>> obtenerPonderacion(
            @PathVariable Long cursoId,
            @RequestParam(required = false) String cursoNombre) {
        Map<String, Object> p = null;
        if (cursoNombre != null && !cursoNombre.isBlank()) {
            p = ponderacionesPorCurso.values().stream()
                    .filter(x -> x.get("cursoNombre") != null && coincideCurso(x.get("cursoNombre"), cursoNombre))
                    .findFirst()
                    .orElse(null);
        }
        if (p == null) {
            p = ponderacionesPorCurso.get(cursoId);
        }
        if (p == null) {
            p = new LinkedHashMap<>();
            p.put("cursoId", cursoId);
            if (cursoNombre != null && !cursoNombre.isBlank()) {
                p.put("cursoNombre", cursoNombre.trim());
            }
            p.put("asistenciaPorcentaje", 30);
            p.put("tareasPorcentaje", 35);
            p.put("examenesPorcentaje", 35);
            p.put("bloqueada", false);
            p.put("solicitudPendiente", false);
            p.put("motivoSolicitud", "");
        }
        p.put("ponderacion", Map.of(
                "asistencia", p.getOrDefault("asistenciaPorcentaje", 30),
                "tareas", p.getOrDefault("tareasPorcentaje", 35),
                "examenes", p.getOrDefault("examenesPorcentaje", 35)
        ));
        return ResponseEntity.ok(p);
    }

    @PutMapping("/ponderacion/{cursoId}")
    public ResponseEntity<?> actualizarPonderacion(@PathVariable Long cursoId, @RequestBody Map<String, Object> body) {
        String cursoNombre = body.get("cursoNombre") != null ? String.valueOf(body.get("cursoNombre")).trim() : null;
        String grado = body.get("grado") != null ? String.valueOf(body.get("grado")).trim() : null;
        Map<String, Object> actual = ponderacionesPorCurso.get(cursoId);
        if (actual == null && cursoNombre != null && !cursoNombre.isEmpty()) {
            actual = ponderacionesPorCurso.values().stream()
                    .filter(x -> x.get("cursoNombre") != null && coincideCurso(x.get("cursoNombre"), cursoNombre))
                    .findFirst()
                    .orElse(null);
        }
        if (actual != null && Boolean.TRUE.equals(actual.get("bloqueada"))) {
            return ResponseEntity.status(403).body(Map.of(
                    "error", "La ponderación ya fue configurada y está bloqueada. Debe solicitar autorización a Secretaría para editarla."
            ));
        }
        int asistencia = body.get("asistenciaPorcentaje") != null ? Integer.parseInt(String.valueOf(body.get("asistenciaPorcentaje"))) : 30;
        int tareas = body.get("tareasPorcentaje") != null ? Integer.parseInt(String.valueOf(body.get("tareasPorcentaje"))) : 35;
        int examenes = body.get("examenesPorcentaje") != null ? Integer.parseInt(String.valueOf(body.get("examenesPorcentaje"))) : 35;
        if (asistencia + tareas + examenes != 100) {
            return ResponseEntity.badRequest().body(Map.of("error", "La suma debe ser exactamente 100%."));
        }
        String nombreFinal = (cursoNombre != null && !cursoNombre.isEmpty())
                ? cursoNombre
                : (actual != null && actual.get("cursoNombre") != null ? String.valueOf(actual.get("cursoNombre")) : null);
        Map<String, Object> nueva = new LinkedHashMap<>();
        nueva.put("cursoId", cursoId);
        if (nombreFinal != null) {
            nueva.put("cursoNombre", nombreFinal);
        }
        if (grado != null && !grado.isEmpty()) {
            nueva.put("grado", grado);
        }
        nueva.put("asistenciaPorcentaje", asistencia);
        nueva.put("tareasPorcentaje", tareas);
        nueva.put("examenesPorcentaje", examenes);
        nueva.put("ponderacion", Map.of("asistencia", asistencia, "tareas", tareas, "examenes", examenes));
        nueva.put("bloqueada", true);
        nueva.put("solicitudPendiente", false);
        nueva.put("motivoSolicitud", "");
        ponderacionesPorCurso.put(cursoId, nueva);
        if (nombreFinal != null) {
            for (Map.Entry<Long, Map<String, Object>> entry : ponderacionesPorCurso.entrySet()) {
                if (!Objects.equals(entry.getKey(), cursoId) && coincideCurso(entry.getValue().get("cursoNombre"), nombreFinal)) {
                    entry.getValue().putAll(nueva);
                }
            }
        }
        return ResponseEntity.ok(Map.of(
                "mensaje", "Ponderación guardada oficialmente y protegida contra cambios accidentales.",
                "ponderacion", nueva
        ));
    }

    @PostMapping("/ponderacion/{cursoId}/solicitar-edicion")
    public ResponseEntity<?> solicitarEdicionPonderacion(@PathVariable Long cursoId, @RequestBody Map<String, Object> body) {
        String motivo = body.get("motivo") != null ? String.valueOf(body.get("motivo")).trim() : "";
        String cursoNombre = body.get("cursoNombre") != null ? String.valueOf(body.get("cursoNombre")).trim() : ("Curso #" + cursoId);
        String grado = body.get("grado") != null ? String.valueOf(body.get("grado")).trim() : "Secundaria";
        String docenteNombre = body.get("docenteNombre") != null ? String.valueOf(body.get("docenteNombre")).trim() : "Docente";
        if (motivo.isEmpty()) {
            return ResponseEntity.badRequest().body(Map.of("error", "Debe indicar una breve descripción del motivo de la solicitud."));
        }

        Map<String, Object> p = ponderacionesPorCurso.computeIfAbsent(cursoId, k -> new LinkedHashMap<>(Map.of(
                "cursoId", cursoId,
                "cursoNombre", cursoNombre,
                "asistenciaPorcentaje", 30,
                "tareasPorcentaje", 35,
                "examenesPorcentaje", 35,
                "bloqueada", true
        )));
        p.put("cursoNombre", cursoNombre);
        p.put("solicitudPendiente", true);
        p.put("motivoSolicitud", motivo);

        long id = nextSolicitudId++;
        Map<String, Object> sol = new LinkedHashMap<>();
        sol.put("id", id);
        sol.put("cursoId", cursoId);
        sol.put("cursoNombre", cursoNombre);
        sol.put("grado", grado);
        sol.put("docenteNombre", docenteNombre);
        sol.put("motivo", motivo);
        sol.put("fechaSolicitud", LocalDate.now().toString());
        sol.put("estado", "PENDIENTE");
        solicitudesPonderacion.put(id, sol);

        return ResponseEntity.ok(Map.of(
                "mensaje", "Solicitud enviada a Secretaría Académica. Una vez aceptada podrá editar la ponderación.",
                "solicitud", sol,
                "ponderacion", p
        ));
    }

    @GetMapping("/solicitudes-ponderacion")
    public ResponseEntity<List<Map<String, Object>>> listarSolicitudesPonderacion() {
        return ResponseEntity.ok(new ArrayList<>(solicitudesPonderacion.values()));
    }

    @PutMapping("/solicitudes-ponderacion/{id}/resolver")
    public ResponseEntity<?> resolverSolicitudPonderacion(@PathVariable Long id, @RequestBody Map<String, Object> body) {
        Map<String, Object> sol = solicitudesPonderacion.get(id);
        if (sol == null) {
            return ResponseEntity.status(404).body(Map.of("error", "Solicitud no encontrada."));
        }
        String estado = body.get("estado") != null ? String.valueOf(body.get("estado")).toUpperCase() : "APROBADA";
        sol.put("estado", estado);
        Long cursoId = toLong(sol.get("cursoId"));
        String solCursoNombre = sol.get("cursoNombre") != null ? String.valueOf(sol.get("cursoNombre")) : null;

        for (Map<String, Object> p : ponderacionesPorCurso.values()) {
            boolean matchId = cursoId != null && Objects.equals(toLong(p.get("cursoId")), cursoId);
            boolean matchNom = solCursoNombre != null && p.get("cursoNombre") != null && coincideCurso(p.get("cursoNombre"), solCursoNombre);
            if (matchId || matchNom) {
                p.put("solicitudPendiente", false);
                if ("APROBADA".equals(estado)) {
                    p.put("bloqueada", false);
                }
            }
        }
        return ResponseEntity.ok(Map.of(
                "mensaje", "APROBADA".equals(estado)
                        ? "Solicitud aceptada. El docente ya puede editar la ponderación del curso."
                        : "Solicitud rechazada.",
                "solicitud", sol
        ));
    }

    @Operation(summary = "Guardar o actualizar calificación de alumno desde el Portal Docente en Oracle DB")
    @PostMapping("/notas")
    public ResponseEntity<?> guardarNotaDocente(@RequestBody Map<String, Object> body) {
        if (body.get("alumnoId") == null || body.get("valor") == null) {
            return ResponseEntity.badRequest().body(Map.of("message", "Alumno y nota son requeridos"));
        }

        Long alumnoId = Long.parseLong(String.valueOf(body.get("alumnoId")));
        String evaluacion = body.get("evaluacion") != null ? String.valueOf(body.get("evaluacion")).trim() : "Evaluación Parcial";
        Double valor = Double.parseDouble(String.valueOf(body.get("valor")));

        Nota existente = notaRepository.findByAlumnoId(alumnoId).stream()
                .filter(n -> evaluacion.equalsIgnoreCase(n.getEvaluacion()))
                .findFirst()
                .orElse(null);

        if (existente != null) {
            existente.setValor(valor);
            existente.setFechaRegistro(LocalDate.now().toString());
            return ResponseEntity.ok(notaRepository.save(existente));
        }

        Nota nueva = new Nota();
        nueva.setAlumnoId(alumnoId);
        nueva.setEvaluacion(evaluacion);
        nueva.setValor(valor);
        nueva.setPonderacion(35.0);
        nueva.setFechaRegistro(LocalDate.now().toString());
        nueva.setEstado("REGISTRADA");
        return ResponseEntity.status(201).body(notaRepository.save(nueva));
    }

    @Operation(summary = "Cerrar acta de calificaciones de un curso")
    @PutMapping("/notas/{id}/cerrar")
    public ResponseEntity<Map<String, Object>> cerrarActaDocente(@PathVariable Long id) {
        return ResponseEntity.ok(Map.of(
                "message", "Acta del curso #" + id + " cerrada oficialmente por el docente en Oracle DB.",
                "cursoId", id,
                "estado", "CERRADA"
        ));
    }

    @Operation(summary = "Registrar asistencia por sesión desde el Portal Docente")
    @PostMapping("/asistencia")
    public ResponseEntity<?> guardarAsistenciaDocente(@RequestBody Map<String, Object> body) {
        String curso = body.get("curso") != null ? String.valueOf(body.get("curso")).trim() : "";
        Object sesionObj = body.get("sesion");
        Object asistenciasObj = body.get("asistencias");
        String grado = body.get("grado") != null ? String.valueOf(body.get("grado")).trim() : "";
        String seccion = body.get("seccion") != null ? String.valueOf(body.get("seccion")).trim() : "";

        if (curso.isEmpty() || sesionObj == null || !(asistenciasObj instanceof List<?> lista)
                || grado.isEmpty() || seccion.isEmpty()) {
            return ResponseEntity.badRequest().body(Map.of(
                    "message", "Curso, grado, sección, sesión y asistencias son obligatorios."
            ));
        }

        PersonalEscolar docente = resolverDocenteEstricto(
                body.get("docenteId") != null ? Long.parseLong(String.valueOf(body.get("docenteId"))) : null,
                body.get("username") != null ? String.valueOf(body.get("username")) : null,
                body.get("colegioId") != null ? Long.parseLong(String.valueOf(body.get("colegioId"))) : null
        );
        if (docente == null) {
            return ResponseEntity.badRequest().body(Map.of(
                    "message", "No se pudo identificar al docente que registra la asistencia."
            ));
        }

        int sesion = Integer.parseInt(String.valueOf(sesionObj));
        LocalDate fecha = LocalDate.now();
        if (body.get("fechaRegistro") != null && !String.valueOf(body.get("fechaRegistro")).isBlank()) {
            try {
                fecha = LocalDate.parse(String.valueOf(body.get("fechaRegistro")).trim().substring(0, 10));
            } catch (Exception ignored) {
                fecha = LocalDate.now();
            }
        }

        List<Map<String, Object>> items = lista.stream()
                .filter(Map.class::isInstance)
                .map(item -> (Map<String, Object>) item)
                .collect(Collectors.toList());

        List<Asistencia> guardadas = asistenciaService.registrarSesion(
                docente.getId(),
                "Prof. " + docente.getNombre() + " " + docente.getApellidos(),
                docente.getColegioId(),
                curso,
                grado,
                seccion,
                sesion,
                fecha,
                items
        );

        return ResponseEntity.ok(Map.of(
                "mensaje", "Asistencia de " + curso + " - " + grado + " " + seccion + " (sesión " + sesion + ") guardada en Oracle DB.",
                "totalRegistros", guardadas.size(),
                "asistencias", guardadas
        ));
    }

    @Operation(summary = "Consultar asistencias guardadas de una sesión del docente")
    @GetMapping("/asistencia")
    public ResponseEntity<List<Asistencia>> obtenerAsistenciaDocente(
            @RequestParam(required = false) Long docenteId,
            @RequestParam(required = false) String username,
            @RequestParam(required = false) Long colegioId,
            @RequestParam(required = false) String curso,
            @RequestParam(required = false) String grado,
            @RequestParam(required = false) String seccion,
            @RequestParam(required = false) Integer sesion) {

        PersonalEscolar docente = resolverDocenteEstricto(docenteId, username, colegioId);
        if (docente == null) {
            return ResponseEntity.ok(List.of());
        }

        List<Asistencia> asistencias = asistenciaService.listarPorDocente(docente.getId()).stream()
                .filter(a -> curso == null || curso.isBlank() || (a.getCurso() != null && coincideCurso(a.getCurso(), curso)))
                .filter(a -> grado == null || grado.isBlank() || (a.getGrado() != null && a.getGrado().equalsIgnoreCase(grado)))
                .filter(a -> seccion == null || seccion.isBlank() || (a.getSeccion() != null && a.getSeccion().equalsIgnoreCase(seccion)))
                .filter(a -> sesion == null || sesion.equals(a.getSesion()))
                .collect(Collectors.toList());

        return ResponseEntity.ok(asistencias);
    }

    @Operation(summary = "Obtener resumen financiero y nómina por horas del docente desde Oracle DB")
    @GetMapping("/finanzas")
    public ResponseEntity<Map<String, Object>> obtenerFinanzasDocente(
            @RequestParam(required = false) Long docenteId,
            @RequestParam(required = false) String username,
            @RequestParam(required = false) Long colegioId) {

        PersonalEscolar docente = resolverDocenteEstricto(docenteId, username, colegioId);
        List<BloqueHorario> bloquesDoc = docente != null
                ? bloqueHorarioRepository.findByDocenteId(docente.getId())
                : List.of();

        double totalHorasSemana = bloquesDoc.stream()
                .mapToDouble(b -> b.getDuracionHoras() != null ? b.getDuracionHoras() : 2.0)
                .sum();
        double tarifaHora = docente != null && docente.getTarifaHora() != null ? docente.getTarifaHora() : 35.0;
        double pagoSemanal = Math.round(totalHorasSemana * tarifaHora * 100.0) / 100.0;
        double horasMensuales = totalHorasSemana * 4.0;
        double sueldoBaseMensual = Math.round(horasMensuales * tarifaHora * 100.0) / 100.0;

        Long keyId = docente != null ? docente.getId() : 0L;
        String periodicidad = periodicidadPorDocente.getOrDefault(keyId, "MENSUAL");
        double horasExtra = horasExtraPorDocente.getOrDefault(keyId, 0.0);
        double sueldoBase = "QUINCENAL".equals(periodicidad)
                ? Math.round((sueldoBaseMensual / 2.0) * 100.0) / 100.0
                : sueldoBaseMensual;
        double totalGenerado = Math.round((sueldoBase + (horasExtra * tarifaHora)) * 100.0) / 100.0;

        Map<String, Object> resp = new LinkedHashMap<>();
        resp.put("periodicidad", periodicidad);
        resp.put("sueldoBase", sueldoBase);
        resp.put("horasSemanales", totalHorasSemana);
        resp.put("totalSesiones", bloquesDoc.size());
        resp.put("pagoSemanal", pagoSemanal);
        resp.put("tarifaHora", tarifaHora);
        resp.put("horasMensuales", horasMensuales);
        resp.put("horasExtra", horasExtra);
        resp.put("tarifaHoraExtra", tarifaHora);
        resp.put("comisiones", 0.0);
        resp.put("descuentos", 0.0);
        resp.put("totalGenerado", totalGenerado);
        resp.put("historialPagos", List.of());
        return ResponseEntity.ok(resp);
    }

    @Operation(summary = "Registrar horas extra para el docente")
    @PostMapping("/horas-extra")
    public ResponseEntity<Map<String, Object>> registrarHorasExtra(@RequestBody Map<String, Object> body) {
        double horas = body.get("horas") != null ? Double.parseDouble(String.valueOf(body.get("horas"))) : 0.0;
        Long docId = body.get("docenteId") != null ? Long.parseLong(String.valueOf(body.get("docenteId"))) : 0L;
        horasExtraPorDocente.merge(docId, horas, Double::sum);
        Map<String, Object> nomina = obtenerFinanzasDocente(docId, null, null).getBody();
        return ResponseEntity.ok(Map.of(
                "mensaje", "Horas extra registradas exitosamente.",
                "nomina", nomina != null ? nomina : Map.of()
        ));
    }

    @Operation(summary = "Cambiar periodicidad de pago del docente")
    @PutMapping("/periodicidad")
    public ResponseEntity<Map<String, Object>> cambiarPeriodicidad(@RequestBody Map<String, Object> body) {
        String per = body.get("periodicidad") != null ? String.valueOf(body.get("periodicidad")).toUpperCase() : "MENSUAL";
        Long docId = body.get("docenteId") != null ? Long.parseLong(String.valueOf(body.get("docenteId"))) : 0L;
        periodicidadPorDocente.put(docId, per);
        return obtenerFinanzasDocente(docId, null, null);
    }

    @Operation(summary = "Obtener actividades y evaluaciones por sesión")
    @GetMapping("/sesiones-actividad")
    public ResponseEntity<List<Map<String, Object>>> obtenerActividadesSesiones(
            @RequestParam(required = false) String cursoNombre,
            @RequestParam(required = false) String grado) {
        String cFiltro = cursoNombre != null ? cursoNombre.trim() : "";
        String gFiltro = grado != null ? grado.trim() : "";
        List<Map<String, Object>> result = actividadesSesionMap.values().stream()
                .filter(a -> {
                    if (!cFiltro.isEmpty() && !coincideCurso(a.getOrDefault("cursoNombre", a.getOrDefault("curso", "")), cFiltro)) {
                        return false;
                    }
                    if (!gFiltro.isEmpty() && !normalizarTexto(a.getOrDefault("grado", "")).contains(normalizarTexto(gFiltro))) {
                        return false;
                    }
                    return true;
                })
                .collect(Collectors.toList());
        return ResponseEntity.ok(result);
    }

    @Operation(summary = "Guardar o configurar tarea/examen de una sesión")
    @PostMapping("/sesiones-actividad")
    public ResponseEntity<?> guardarActividadSesion(@RequestBody Map<String, Object> body) {
        String cursoNombre = body.get("cursoNombre") != null ? String.valueOf(body.get("cursoNombre")) : String.valueOf(body.getOrDefault("curso", ""));
        Object sesionObj = body.get("numeroSesion") != null ? body.get("numeroSesion") : body.get("sesion");
        if (cursoNombre.isBlank() || sesionObj == null) {
            return ResponseEntity.badRequest().body(Map.of("error", "cursoNombre y numeroSesion son obligatorios."));
        }
        int numSes = Integer.parseInt(String.valueOf(sesionObj));
        String grado = String.valueOf(body.getOrDefault("grado", "1° Secundaria"));
        String tipo = String.valueOf(body.getOrDefault("tipoActividad", body.getOrDefault("actividadTipo", "TAREA"))).toUpperCase();
        String actividadIdBody = body.get("actividadId") != null ? String.valueOf(body.get("actividadId")).trim() : "";
        if (actividadIdBody.startsWith("act__")) {
            actividadIdBody = actividadIdBody.substring(5);
        }

        if ("NINGUNA".equalsIgnoreCase(tipo)) {
            actividadesSesionMap.entrySet().removeIf(e -> {
                Map<String, Object> a = e.getValue();
                return coincideCurso(a.getOrDefault("cursoNombre", a.getOrDefault("curso", "")), cursoNombre)
                        && normalizarTexto(a.getOrDefault("grado", "")).equals(normalizarTexto(grado))
                        && Objects.equals(toInt(a.get("numeroSesion") != null ? a.get("numeroSesion") : a.get("sesion")), numSes);
            });
            return ResponseEntity.ok(Map.of("mensaje", "Sesión configurada sin actividad."));
        }

        String deberTag = "EXAMEN".equalsIgnoreCase(tipo) ? "examen" : "tarea";
        List<Map<String, Object>> existentesMismaSesion = actividadesSesionMap.values().stream()
                .filter(a -> coincideCurso(a.getOrDefault("cursoNombre", a.getOrDefault("curso", "")), cursoNombre)
                        && Objects.equals(toInt(a.get("numeroSesion") != null ? a.get("numeroSesion") : a.get("sesion")), numSes)
                        && tipo.equalsIgnoreCase(String.valueOf(a.getOrDefault("tipoActividad", a.getOrDefault("actividadTipo", "TAREA")))))
                .collect(Collectors.toList());

        int seqNum = existentesMismaSesion.size() + 1;
        boolean foundExisting = false;
        for (int idx = 0; idx < existentesMismaSesion.size(); idx++) {
            Map<String, Object> exAct = existentesMismaSesion.get(idx);
            if (!actividadIdBody.isEmpty() && (Objects.equals(String.valueOf(exAct.get("actividadId")), actividadIdBody)
                    || Objects.equals(String.valueOf(exAct.get("actividadId")), "act__" + actividadIdBody)
                    || Objects.equals(String.valueOf(exAct.get("key")), actividadIdBody))) {
                seqNum = idx + 1;
                foundExisting = true;
                break;
            }
        }
        if (!foundExisting) {
            while (true) {
                String candidate = "sesion_" + numSes + "_" + deberTag + "_" + seqNum;
                boolean exists = existentesMismaSesion.stream()
                        .anyMatch(a -> Objects.equals(String.valueOf(a.get("actividadId")), candidate));
                if (!exists) break;
                seqNum++;
            }
        }

        String actividadIdFinal = (!actividadIdBody.isEmpty() && !actividadIdBody.startsWith("act_"))
                ? actividadIdBody
                : ("sesion_" + numSes + "_" + deberTag + "_" + seqNum);
        String key = normalizarTexto(cursoNombre) + "__" + normalizarTexto(grado) + "__" + actividadIdFinal;

        String rawTitulo = String.valueOf(body.getOrDefault("actividadTitulo", body.getOrDefault("titulo", ""))).trim();
        String tituloFinal = (!rawTitulo.isEmpty() && !rawTitulo.equalsIgnoreCase("Tarea Sesión " + numSes) && !rawTitulo.equalsIgnoreCase("Examen Sesión " + numSes))
                ? rawTitulo
                : ("EXAMEN".equalsIgnoreCase(tipo) ? ("Examen #" + seqNum + " - Sesión " + numSes) : ("Tarea #" + seqNum + " - Sesión " + numSes));

        Map<String, Object> item = new HashMap<>(body);
        item.put("key", key);
        item.put("actividadId", actividadIdFinal);
        item.put("cursoNombre", cursoNombre);
        item.put("curso", cursoNombre);
        item.put("numeroSesion", numSes);
        item.put("sesion", numSes);
        item.put("grado", grado);
        item.put("tipoActividad", tipo);
        item.put("actividadTipo", tipo);
        item.put("actividadTitulo", tituloFinal);
        item.put("titulo", tituloFinal);

        actividadesSesionMap.put(key, item);
        return ResponseEntity.ok(Map.of(
                "mensaje", "Actividad guardada exitosamente.",
                "actividad", item
        ));
    }

    @Operation(summary = "Eliminar una tarea/examen de una sesión")
    @DeleteMapping("/sesiones-actividad/{actividadId}")
    public ResponseEntity<?> eliminarActividadSesion(@PathVariable String actividadId) {
        String id = actividadId.startsWith("act__") ? actividadId.substring(5) : actividadId;
        boolean removed = actividadesSesionMap.entrySet().removeIf(e ->
                Objects.equals(e.getKey(), actividadId)
                        || Objects.equals(e.getKey(), "act__" + id)
                        || Objects.equals(String.valueOf(e.getValue().get("actividadId")), actividadId)
                        || Objects.equals(String.valueOf(e.getValue().get("actividadId")), id));
        if (!removed) {
            return ResponseEntity.status(404).body(Map.of("message", "Actividad no encontrada."));
        }
        return ResponseEntity.ok(Map.of("mensaje", "Actividad eliminada correctamente."));
    }

    @Operation(summary = "Obtener entregas de tareas y exámenes")
    @GetMapping("/entregas")
    public ResponseEntity<List<Map<String, Object>>> obtenerEntregas(
            @RequestParam(required = false) String cursoNombre,
            @RequestParam(required = false) Integer sesionId,
            @RequestParam(required = false) Long alumnoId,
            @RequestParam(required = false) String actividadId) {
        String cFiltro = cursoNombre != null ? cursoNombre.trim() : "";
        String actFiltro = actividadId != null ? actividadId.trim() : "";
        List<Map<String, Object>> result = entregasTareasMap.values().stream()
                .filter(e -> {
                    if (!cFiltro.isEmpty() && !coincideCurso(e.getOrDefault("cursoNombre", e.getOrDefault("curso", "")), cFiltro)) {
                        return false;
                    }
                    if (!actFiltro.isEmpty()) {
                        String eActId = e.get("actividadId") != null ? String.valueOf(e.get("actividadId")).trim() : "";
                        if (!Objects.equals(actFiltro, eActId)) {
                            return false;
                        }
                    }
                    if (sesionId != null) {
                        Integer eSes = toInt(e.get("sesionId") != null ? e.get("sesionId") : e.get("sesion"));
                        Integer eTar = toInt(e.get("tareaId"));
                        if (!Objects.equals(sesionId, eSes) && !Objects.equals(sesionId, eTar)) {
                            return false;
                        }
                    }
                    if (alumnoId != null) {
                        Long eAlum = toLong(e.get("alumnoId"));
                        if (eAlum != null && !Objects.equals(alumnoId, eAlum)) {
                            return false;
                        }
                    }
                    return true;
                })
                .collect(Collectors.toList());
        return ResponseEntity.ok(result);
    }

    @Operation(summary = "Calificar entrega de tarea o examen")
    @PostMapping("/calificar-entrega")
    public ResponseEntity<?> calificarEntrega(@RequestBody Map<String, Object> body) {
        Long entregaId = toLong(body.get("entregaId"));
        Long alumnoId = toLong(body.get("alumnoId"));
        Object sesionObj = body.get("sesionId") != null ? body.get("sesionId") : body.get("sesion");
        int sesion = sesionObj != null && toInt(sesionObj) != null ? toInt(sesionObj) : 1;
        String cursoNombre = String.valueOf(body.getOrDefault("cursoNombre", body.getOrDefault("curso", ""))).trim();
        String reqActId = body.get("actividadId") != null && !String.valueOf(body.get("actividadId")).isBlank()
                ? String.valueOf(body.get("actividadId")).trim()
                : null;
        String reqTipo = String.valueOf(body.getOrDefault("tipoActividad", body.getOrDefault("actividadTipo", body.getOrDefault("tipoEvaluacion", "TAREA")))).toUpperCase();
        double nota = body.get("nota") != null
                ? Double.parseDouble(String.valueOf(body.get("nota")))
                : (body.get("calificacion") != null ? Double.parseDouble(String.valueOf(body.get("calificacion"))) : 0.0);
        String comentario = String.valueOf(body.getOrDefault("comentarioDocente", "Calificado"));

        Optional<Map<String, Object>> opt = entregasTareasMap.values().stream()
                .filter(e -> {
                    if (entregaId != null && Objects.equals(toLong(e.get("id")), entregaId)) {
                        if (reqActId == null || e.get("actividadId") == null || Objects.equals(String.valueOf(e.get("actividadId")), reqActId)) {
                            return true;
                        }
                    }
                    if (alumnoId != null && !Objects.equals(toLong(e.get("alumnoId")), alumnoId)) {
                        return false;
                    }
                    if (reqActId != null) {
                        return Objects.equals(String.valueOf(e.get("actividadId")), reqActId);
                    }
                    return e.get("actividadId") == null
                            && (Objects.equals(toInt(e.get("sesionId")), sesion) || Objects.equals(toInt(e.get("sesion")), sesion) || Objects.equals(toInt(e.get("tareaId")), sesion))
                            && (cursoNombre.isEmpty() || coincideCurso(e.getOrDefault("cursoNombre", e.getOrDefault("curso", "")), cursoNombre));
                })
                .findFirst();

        Map<String, Object> entrega;
        if (opt.isPresent()) {
            entrega = opt.get();
        } else {
            entrega = new ConcurrentHashMap<>(body);
            long newId = nextEntregaId++;
            entrega.put("id", newId);
            entrega.put("alumnoId", alumnoId != null ? alumnoId : 1L);
            entrega.put("sesionId", sesion);
            entrega.put("sesion", sesion);
            entrega.put("tareaId", sesion);
            if (reqActId != null) {
                entrega.put("actividadId", reqActId);
            }
            entrega.put("tipoActividad", reqTipo);
            entrega.put("cursoNombre", cursoNombre);
            entrega.put("curso", cursoNombre);
            entregasTareasMap.put(newId, entrega);
        }
        entrega.put("nota", nota);
        entrega.put("calificacion", nota);
        entrega.put("comentarioDocente", comentario);
        entrega.put("calificado", true);
        entrega.put("estado", "CALIFICADO");

        Long targetAlumnoId = toLong(entrega.get("alumnoId")) != null ? toLong(entrega.get("alumnoId")) : (alumnoId != null ? alumnoId : 1L);
        String actKey = reqActId != null ? reqActId : ("sesion_" + sesion + "_" + reqTipo.toLowerCase());
        String evalIndividual = ("[" + actKey + "] " + cursoNombre).trim();
        if (evalIndividual.length() > 95) {
            evalIndividual = evalIndividual.substring(0, 95);
        }
        sincronizarNotaEnOracle(targetAlumnoId, evalIndividual, nota, 35.0);

        List<Asistencia> asistenciasDelCurso = asistenciaService.listarPorAlumno(targetAlumnoId).stream()
                .filter(as -> cursoNombre.isEmpty() || (as.getCurso() != null && coincideCurso(as.getCurso(), cursoNombre)))
                .collect(Collectors.toList());
        List<Nota> notasDelAlumno = notaRepository.findByAlumnoId(targetAlumnoId);
        Map<String, Object> resumen = calcularResumenNotasCurso(
                targetAlumnoId,
                cursoNombre,
                String.valueOf(entrega.getOrDefault("grado", "1° Secundaria")),
                toLong(body.get("cursoId")),
                asistenciasDelCurso,
                notasDelAlumno,
                1
        );

        if (!cursoNombre.isEmpty()) {
            double pracVal = resumen.get("practica") != null ? Double.parseDouble(String.valueOf(resumen.get("practica"))) : 0.0;
            double exaVal = resumen.get("examenFinal") != null ? Double.parseDouble(String.valueOf(resumen.get("examenFinal"))) : 0.0;
            sincronizarNotaEnOracle(targetAlumnoId, "Práctica " + cursoNombre, pracVal, 35.0);
            sincronizarNotaEnOracle(targetAlumnoId, "Parcial " + cursoNombre, exaVal, 35.0);
            sincronizarNotaEnOracle(targetAlumnoId, "Examen Final " + cursoNombre, exaVal, 35.0);
        }

        return ResponseEntity.ok(Map.of(
                "mensaje", "Entrega calificada y sincronizada automáticamente en Oracle DB.",
                "entrega", entrega,
                "resumen", resumen
        ));
    }

    private void sincronizarNotaEnOracle(Long alumnoId, String evaluacion, Double valor, Double ponderacion) {
        if (alumnoId == null || evaluacion == null || evaluacion.isBlank()) return;
        String evalLimpia = evaluacion.trim();
        if (evalLimpia.length() > 95) {
            evalLimpia = evalLimpia.substring(0, 95);
        }
        final String evalTarget = evalLimpia;
        Nota existente = notaRepository.findByAlumnoId(alumnoId).stream()
                .filter(n -> evalTarget.equalsIgnoreCase(n.getEvaluacion()))
                .findFirst()
                .orElse(null);
        if (existente != null) {
            existente.setValor(valor != null ? valor : 0.0);
            existente.setFechaRegistro(LocalDate.now().toString());
            notaRepository.save(existente);
        } else {
            Nota nueva = new Nota();
            nueva.setAlumnoId(alumnoId);
            nueva.setEvaluacion(evalTarget);
            nueva.setValor(valor != null ? valor : 0.0);
            nueva.setPonderacion(ponderacion != null ? ponderacion : 35.0);
            nueva.setFechaRegistro(LocalDate.now().toString());
            nueva.setEstado("REGISTRADA");
            notaRepository.save(nueva);
        }
    }

    private PersonalEscolar resolverDocenteEstricto(Long id, String username, Long colegioId) {
        if (username != null && !username.isBlank()) {
            String clean = username.trim();
            Optional<PersonalEscolar> byUser = colegioId != null
                    ? personalRepository.findByUsernameIgnoreCaseAndColegioId(clean, colegioId)
                    : personalRepository.findAllByUsernameIgnoreCase(clean).stream().findFirst();
            if (byUser.isPresent() && (colegioId == null || Objects.equals(colegioId, byUser.get().getColegioId()))) {
                return byUser.get();
            }
            String dniCandidate = clean.replace("docente_", "");
            Optional<PersonalEscolar> byDni = colegioId != null
                    ? personalRepository.findByDniAndColegioId(dniCandidate, colegioId)
                    : personalRepository.findFirstByDniOrderByIdAsc(dniCandidate);
            if (byDni.isPresent()) return byDni.get();
        }
        if (id != null && id > 0) {
            Optional<PersonalEscolar> byId = personalRepository.findById(id)
                    .filter(p -> colegioId == null || Objects.equals(colegioId, p.getColegioId()));
            if (byId.isPresent()) return byId.get();
            Usuario u = usuarioRepository.findById(id).orElse(null);
            if (u != null && (colegioId == null || Objects.equals(colegioId, u.getColegioId()))) {
                if (u.getUsername() != null) {
                    Optional<PersonalEscolar> byUser = u.getColegioId() != null
                            ? personalRepository.findByUsernameIgnoreCaseAndColegioId(u.getUsername(), u.getColegioId())
                            : personalRepository.findAllByUsernameIgnoreCase(u.getUsername()).stream().findFirst();
                    if (byUser.isPresent()) return byUser.get();
                }
                if (u.getDni() != null && !u.getDni().isBlank()) {
                    Optional<PersonalEscolar> byDni = u.getColegioId() != null
                            ? personalRepository.findByDniAndColegioId(u.getDni().trim(), u.getColegioId())
                            : personalRepository.findFirstByDniOrderByIdAsc(u.getDni().trim());
                    if (byDni.isPresent()) return byDni.get();
                }
            }
        }
        // NUNCA retornar otro docente ajeno si no coincide exactamente
        return null;
    }
}

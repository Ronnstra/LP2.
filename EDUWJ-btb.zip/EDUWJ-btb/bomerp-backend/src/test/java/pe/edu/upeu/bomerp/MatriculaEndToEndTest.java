package pe.edu.upeu.bomerp;

import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.context.WebApplicationContext;
import pe.edu.upeu.bomerp.academico.curso.dto.CursoRequest;
import pe.edu.upeu.bomerp.matricula.alumno.dto.AlumnoRequest;
import pe.edu.upeu.bomerp.matricula.inscripcion.dto.DetalleMatriculaRequest;
import pe.edu.upeu.bomerp.matricula.inscripcion.dto.MatriculaRequest;

import java.time.LocalDate;
import java.util.List;
import java.util.Map;

import static org.springframework.security.test.web.servlet.request.SecurityMockMvcRequestPostProcessors.jwt;
import static org.springframework.security.test.web.servlet.setup.SecurityMockMvcConfigurers.springSecurity;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.put;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
class MatriculaEndToEndTest {

    @Autowired
    private WebApplicationContext context;

    private MockMvc mockMvc;

    @Autowired
    private ObjectMapper objectMapper;

    @BeforeEach
    void setUp() {
        this.mockMvc = MockMvcBuilders.webAppContextSetup(context)
                .apply(springSecurity())
                .build();
    }

    @Test
    void flujoCompleto_crearMatricula_consultarPaginado_yVerificarAuditoria() throws Exception {
        // 1. Crear alumno real en la base de datos para la prueba E2E (sin depender de corridas anteriores)
        AlumnoRequest alumnoReq = new AlumnoRequest();
        alumnoReq.setNombre("Carlos");
        alumnoReq.setApellidoPaterno("Mendoza");
        alumnoReq.setApellidoMaterno("Rojas");
        alumnoReq.setDni("74859612");
        alumnoReq.setGrado("5° Secundaria");
        alumnoReq.setFechaIngreso(LocalDate.now().toString());

        String alumnoJson = mockMvc.perform(post("/api/v1/alumnos")
                        .with(jwt().jwt(j -> j.claim("sub", "secretaria-e2e")
                                .claim("realm_access", Map.of("roles", List.of("SECRETARIA", "ADMIN")))))
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(alumnoReq)))
                .andExpect(status().isCreated())
                .andReturn().getResponse().getContentAsString();

        Long alumnoId = objectMapper.readTree(alumnoJson).get("id").asLong();

        // 2. Crear curso real con vacantes disponibles
        CursoRequest cursoReq = new CursoRequest();
        cursoReq.setNombre("Física Nuclear Aplicada E2E");
        cursoReq.setGrado("5° Secundaria");
        cursoReq.setCreditos(4);
        cursoReq.setVacantesMaximas(25);
        cursoReq.setAula("LAB-301");

        String cursoJson = mockMvc.perform(post("/api/v1/cursos")
                        .with(jwt().jwt(j -> j.claim("sub", "secretaria-e2e")
                                .claim("realm_access", Map.of("roles", List.of("SECRETARIA", "ADMIN")))))
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(cursoReq)))
                .andExpect(status().isCreated())
                .andReturn().getResponse().getContentAsString();

        Long cursoId = objectMapper.readTree(cursoJson).get("id").asLong();

        // 3. Registrar Matrícula Cabecera-Detalle Atómica (POST /api/v1/matriculas)
        DetalleMatriculaRequest det = new DetalleMatriculaRequest();
        det.setCursoId(cursoId);

        MatriculaRequest matReq = new MatriculaRequest();
        matReq.setAlumnoId(alumnoId);
        matReq.setPeriodo("2026-I");
        matReq.setDetalles(List.of(det));

        String matriculaJson = mockMvc.perform(post("/api/v1/matriculas")
                        .with(jwt().jwt(j -> j.claim("sub", "secretaria-e2e")
                                .claim("realm_access", Map.of("roles", List.of("SECRETARIA")))))
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(matReq)))
                .andExpect(status().isCreated())
                .andExpect(jsonPath("$.totalCreditos").value(4))
                .andReturn().getResponse().getContentAsString();

        Long matriculaId = objectMapper.readTree(matriculaJson).get("id").asLong();

        // 4. Consultar Matrícula por ID y verificar persistencia real
        mockMvc.perform(get("/api/v1/matriculas/" + matriculaId)
                        .with(jwt().jwt(j -> j.claim("sub", "secretaria-e2e")
                                .claim("realm_access", Map.of("roles", List.of("SECRETARIA"))))))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.id").value(matriculaId))
                .andExpect(jsonPath("$.estado").value("REGISTRADA"));

        // 5. Anular Matrícula y verificar registro en tabla AUDITORIA con actor real "secretaria-e2e"
        mockMvc.perform(put("/api/v1/matriculas/" + matriculaId + "/anular")
                        .with(jwt().jwt(j -> j.claim("sub", "secretaria-e2e")
                                .claim("realm_access", Map.of("roles", List.of("SECRETARIA"))))))
                .andExpect(status().isOk());

        mockMvc.perform(get("/api/v1/auditoria")
                        .with(jwt().jwt(j -> j.claim("sub", "secretaria-e2e")
                                .claim("realm_access", Map.of("roles", List.of("SECRETARIA", "ADMIN"))))))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$[0].actor").value("secretaria-e2e"))
                .andExpect(jsonPath("$[0].entidad").value("MATRICULA"));
    }
}

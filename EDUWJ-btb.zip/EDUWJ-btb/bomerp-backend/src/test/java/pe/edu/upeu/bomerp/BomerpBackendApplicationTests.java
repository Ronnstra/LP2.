package pe.edu.upeu.bomerp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest(properties = "bomerp.dev.reset-key=")
class BomerpBackendApplicationTests {

	@Test
	void contextLoads() {
	}

}
